/*********************************************************************
 *                                                                   *
 * Module Name:                                                      *
 *                                                                   *
 *      PlxMemTest.c                                                 *
 *                                                                   *
 * Abstract:                                                         *
 *                                                                   *
 *      Tests memory regions                                         *
 *                                                                   *
 *********************************************************************/


#include "PlxMemTest.h"
#include "PlxOemIoSupport.h"
#include "PlxSupport.h"




int
PlxMemTest(
    char          *displayText,
    unsigned long  StartAddr,
    unsigned long  EndAddr
    )
{
    unsigned int   TotalErrors;
    unsigned long  CurAddr;
    unsigned long  ValueRead;


    PlxPrintf(displayText);
   
    TotalErrors = 0;
    for (CurAddr=StartAddr; CurAddr<EndAddr; CurAddr += 4)
    {
        if (!(CurAddr & 0x0000FFFF))
        {
            if (OemIoReadByte() != OEM_IO_READ_NODATA)
            {
                PlxPrintf("User abort at 0x%08x\n", CurAddr);
                return 0;
            }
            PlxPrintf("%08x\b\b\b\b\b\b\b\b", CurAddr);
        }

        *(unsigned long *)CurAddr = CurAddr;
        ValueRead = *(unsigned long *)CurAddr;
        if (ValueRead != CurAddr)
        {
            PlxPrintf("%08x - Failed!       wrote: %08x   read: %08x\n",
                      CurAddr, CurAddr, ValueRead);
            PlxPrintf(displayText);

            if (++TotalErrors == MAX_MEMORY_ERRORS)
            {
                PlxPrintf("Aborted - reached max errors (0x%x)\n", TotalErrors);
                return -1;
            }

            PlxPrintf("%08x\b\b\b\b\b\b\b\b", CurAddr);
        }
        else
        {
            *(unsigned long *)CurAddr = ~CurAddr;
            ValueRead = *(unsigned long *)CurAddr;
            if (ValueRead != ~CurAddr)
            {
                PlxPrintf("%08x - Failed!       wrote: %08x   read: %08x\n",
                        CurAddr, ~CurAddr, ValueRead);
                PlxPrintf(displayText);

                if (++TotalErrors == MAX_MEMORY_ERRORS)
                {
                    PlxPrintf("Aborted - reached max errors (0x%x)\n", TotalErrors);
                    return -1;
                }

                PlxPrintf("%08x\b\b\b\b\b\b\b\b", CurAddr);
            }
            else
                *(unsigned long *)CurAddr = 0x0;
        }
    }

    if (TotalErrors)
        PlxPrintf("Complete - %i errors encountered\n", TotalErrors);
    else
        PlxPrintf("Passed    \n");

    return 0;	
}
