/******************************************************************************
 *
 * File Name:
 *
 *      AppMain.c
 *
 * Description:
 *
 *      The application module containing the main entry point
 *
 * Revision History:
 *
 *      05-31-01 : PCI SDK v3.30
 *
 ******************************************************************************/


#include "ManfComm.h"
#include "PlxMemTest.h"
#include "PlxOemBsp.h"
#include "PlxSupport.h"




/**********************************************
*               Definitions
**********************************************/
#if defined(PCI480)
    #define ALL_REGS_SIZE               0x400
    #define FlashBase                   0xfff80000
    #define FlashSize                   0x00080000
    #define RAM_0_BASE                  0x00100000
    #define RAM_0_END                   0x02000000
#elif defined(PCI9054)
    #define ALL_REGS_SIZE               0x100
    #define FlashBase                   0xfff00000
    #define FlashSize                   0x00080000
    #define RAM_0_BASE                  0x00100000
    #define RAM_0_END                   0x02000000
#elif defined(PCI9656)
    #define ALL_REGS_SIZE               0x100
    #define FlashBase                   0xfff00000
    #define FlashSize                   0x00080000
    #define RAM_0_BASE                  0x00100000
    #define RAM_0_END                   0x04000000
#else
    #error ERROR: PLX chip type not defined
#endif


#define TestValue                   0xa5a5a5a5
#define TESTED_MAILBOX              MailBox1

#define MANF_TEST_VERSION           "1.1"




/**********************************************
*               Functions
**********************************************/
void
Sleep(
    U32
    );

BOOL
IopPlxChipTest(
    void
    );

BOOL
IopLedTest(
    void
    );

BOOL
IopFlashTest(
    void
    );

BOOL
IopUartTest(
    void
    );




/******************************************************************************
 *
 * Function   :  AppMain
 *
 * Description:  This is the user code entry point.  This function gets
 *               called by the BSP boot code after the board has initialized.
 *
 * Note       :  The name of this function should NOT be changed because the
 *               BSP will call it as the entry point for the application.
 *
 *****************************************************************************/
int
AppMain(
    void
    )
{
    U16  Command;
    U16  MsgData;


    PlxPrintf("PLX Manufacturing Test, Version %s\n", MANF_TEST_VERSION);
    PlxPrintf("Copyright (c) 2001 PLX Technology, Inc.\n\n");

    PlxPrintf("Waiting for READY message...");

    // Inform the Host that we are ready for commands
    do
    {
        MsgReceive(
            &Command,
            &MsgData
            );
    }
    while (Command != MSG_CMD_READY);

    PlxPrintf("\r                            \r");
    PlxPrintf("Starting Tests...\n");

    MsgSend(
        Command,
        MSG_STATUS_PASSED
        );

    // Wait for commands from Host and process accordingly
    do
    {
        PlxPrintf("Waiting for command message...");

        MsgReceive(
            &Command,
            &MsgData
            );

        PlxPrintf("\r                              \r");

        MsgData = MSG_STATUS_PASSED;
        switch (Command)
        {
            case MSG_CMD_TEST_PLX_CHIP:
                if (IopPlxChipTest() == FALSE)
                    MsgData = MSG_STATUS_FAILED;
                break;

            case MSG_CMD_TEST_LED:
                if (IopLedTest() == FALSE)
                    MsgData = MSG_STATUS_FAILED;
                break;

            case MSG_CMD_TEST_FLASH:
                if (IopFlashTest() == FALSE)
                    MsgData = MSG_STATUS_FAILED;
                break;

            case MSG_CMD_TEST_SRAM:
#if (defined(PCI9054) && defined(CPCI)) || defined(PCI9656)
                if (PlxMemTest(
                        "RAM 1 Test    :  ",
                        0x20000000,
                        0x20080000
                        ) != 0)
                {
                    MsgData = MSG_STATUS_FAILED;
                }
#else
                MsgData = MSG_STATUS_FAILED;
#endif
                break;

            case MSG_CMD_TEST_DRAM:
                if (PlxMemTest(
                        "RAM 0 Test    :  ",
                        RAM_0_BASE,
                        RAM_0_END
                        ) != 0)
                {
                    MsgData = MSG_STATUS_FAILED;
                }
                break;
            
            case MSG_CMD_TEST_UART:
                if (IopUartTest() == FALSE)
                    MsgData = MSG_STATUS_FAILED;
                break;

            default:
                MsgData = MSG_STATUS_FAILED;
        }

        MsgSend(
            Command,
            MsgData
            );
    }
    while (1);
}




/******************************************************************************
 *
 * Function   :
 *
 * Description:
 *
 *****************************************************************************/
void
Sleep(
    U32 waitLoop
    )
{
    U32 i;


    i = 0;
    while (i != waitLoop)
        i++;
}




/******************************************************************************
 *
 * Function   :
 *
 * Description:
 *
 *****************************************************************************/
BOOL
IopPlxChipTest(
    void
    )
{
    U32         RegValue;
    RETURN_CODE rc;


    PlxPrintf("PLX Chip Test :  ");

    // Read a PCI register
    PlxRegisterRead(
        PrimaryPciBus, 
        0x10,                // PCI BAR 0
        &rc
        );

    if (rc != ApiSuccess)
    {
        PlxPrintf("Failed!\n");
        return FALSE;
    }

    if (PlxRegisterMailboxWrite(
            PrimaryPciBus,
            MailBox1, 
            TestValue
            ) != ApiSuccess)
    {
        PlxPrintf("Failed!\n");
        return FALSE;
    }

    RegValue =
        PlxRegisterMailboxRead(
            PrimaryPciBus,
            MailBox1, 
            &rc
            );

    if (RegValue != TestValue)
    {
        PlxPrintf("Failed!\n");
        return FALSE;
    }

    PlxPrintf("Passed\n");

    return TRUE;
}




/******************************************************************************
 *
 * Function   :
 *
 * Description:
 *
 *****************************************************************************/
BOOL
IopLedTest(
    void
    )
{
    // Blink the LED a few times
    PlxPrintf("Blink LED Test:  ");

    OemBlinkLed(
        10
        );

    PlxPrintf("Passed\n");

    return TRUE;
}




/******************************************************************************
 *
 * Function   :
 *
 * Description:
 *
 *****************************************************************************/
BOOL
IopFlashTest(
    void
    )
{
    U32 CurLoc;
    U32 EndLoc;


    PlxPrintf("FLASH Test    :  ");

    CurLoc = FlashBase;
    EndLoc = FlashBase + FlashSize;
    
    // Read Flash
    while (CurLoc < EndLoc)
    {
        if (*(U8*)CurLoc == 1)
        {
        }

        CurLoc++;
    }

    PlxPrintf("Passed\n");

    return TRUE;
}




/******************************************************************************
 *
 * Function   :
 *
 * Description:
 *
 *****************************************************************************/
BOOL
IopUartTest(
    void
    )
{
    U8   i;
    char TestString[] = "Hello there, have a nice day";


    PlxPrintf("UART Test     :  ");

    i = 0;
    while (TestString[i] != '\0')
    {
        PlxPrintf("%c", TestString[i]);
        PlxDelay(0x1000);
        i++;
    }

    return TRUE;
}
