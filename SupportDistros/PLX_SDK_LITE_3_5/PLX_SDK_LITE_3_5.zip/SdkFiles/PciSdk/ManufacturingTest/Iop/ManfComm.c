/**********************************************************************
 *                                                                    *
 * Module Name:                                                       *
 *                                                                    *
 *     ManfComm.c                                                     *
 *                                                                    *
 * Abstract:                                                          *
 *                                                                    *
 *     Implements mailbox communications                              *
 *                                                                    *
 **********************************************************************/


#include "ManfComm.h"



#if defined(PCI_CODE)
void
MsgInitialize(
    HANDLE PlxHandle
    )
{
    PlxRegisterMailboxWrite(
        PlxHandle,
        MSG_MB_SEND,
        0x0
        );

    PlxRegisterMailboxWrite(
        PlxHandle,
        MSG_MB_RECEIVE,
        0x0
        );
}
#endif




/********************************************
********************************************/
#if defined(PCI_CODE)
BOOL
MsgReceive(
    HANDLE  PlxHandle,
    U16    *Command,
    U16    *MsgData,
    double  Timeout
    )
{
    U32         Message;
    clock_t     FinishTime;
    RETURN_CODE rc;


    FinishTime = (clock_t)(Timeout * CLOCKS_PER_SEC) + clock();

    while (1)
    {
        Message = PlxRegisterMailboxRead(
                      PlxHandle,
                      MSG_MB_RECEIVE,
                      &rc
                      );

        if (Message & MSG_PENDING)
        {
            PlxRegisterMailboxWrite(
                PlxHandle,
                MSG_MB_RECEIVE,
                0x0
                );

            *Command = (U16)(Message >> 16);
            *MsgData = (U16)(Message >> 4) & 0xFFF;
            return TRUE;
        }

        if (FinishTime <= clock())
            return FALSE;

        Sleep(1);
    }
}
#elif defined(IOP_CODE)
BOOL
MsgReceive(
    U16 *Command,
    U16 *MsgData
    )
{
    U32         Message;
    RETURN_CODE rc;


    while (1)
    {
        Message =
            PlxRegisterMailboxRead(
                PrimaryPciBus,
                MSG_MB_RECEIVE,
                &rc
                );

        if (Message & MSG_PENDING)
        {
            PlxRegisterMailboxWrite(
                PrimaryPciBus,
                MSG_MB_RECEIVE,
                0x0
                );

            *Command = (U16)(Message >> 16);
            *MsgData = (U16)((Message >> 4) & 0xFFF);
            return TRUE;
        }

        Sleep(50);
    }
}
#endif




/********************************************
********************************************/
#if defined(PCI_CODE)
BOOL
MsgSend(
    HANDLE PlxHandle,
    U16    Command,
    U16    MsgData
    )
{
    U32         Message;
    RETURN_CODE rc;


    if (PlxRegisterMailboxRead(
            PlxHandle,
            MSG_MB_SEND,
            &rc
            ) & MSG_PENDING)
    {
        return FALSE;
    }

    Message = ((U32)Command << 16) | ((U32)MsgData<<4) | MSG_PENDING;
    PlxRegisterMailboxWrite(
        PlxHandle,
        MSG_MB_SEND,
        Message
        );

    return TRUE;
} 
#elif defined(IOP_CODE)
BOOL
MsgSend(
    U16 Command,
    U16 MsgData
    )
{
    U32         Message;
    RETURN_CODE rc;


    if (PlxRegisterMailboxRead(
            PrimaryPciBus,
            MSG_MB_SEND,
            &rc
            ) & MSG_PENDING)
    {
        return FALSE;
    }

    Message = ((U32)Command << 16) | ((U32)MsgData<<4) | MSG_PENDING;

    PlxRegisterMailboxWrite(
        PrimaryPciBus,
        MSG_MB_SEND,
        Message
        );

    return TRUE;
} 
#endif
