/**********************************************************************
 *                                                                    *
 * Module Name:                                                       *
 *                                                                    *
 *     ManfComm.h                                                     *
 *                                                                    *
 * Abstract:                                                          *
 *                                                                    *
 *                                                                    *
 * Revision History:                                                  *
 *                                                                    *
 *     07-27-98 : Created                                             *
 *                                                                    *
 *********************************************************************/


#include "PlxApi.h"

#if defined(PCI_CODE)
    #include <time.h>
#endif




#if defined(PCI_CODE)
    #define MSG_MB_SEND             MailBox4
    #define MSG_MB_RECEIVE          MailBox5
#elif defined(IOP_CODE)
    #define MSG_MB_SEND             MailBox5
    #define MSG_MB_RECEIVE          MailBox4
#endif

#define MSG_PENDING                 0x1
#define MSG_DATA_NONE               0x0

#define MSG_CMD_READY               0x1010

#define MSG_CMD_TEST_PLX_CHIP       0x1F01
#define MSG_CMD_TEST_LED            0x1F02
#define MSG_CMD_TEST_FLASH          0x1F03
#define MSG_CMD_TEST_SRAM           0x1F04
#define MSG_CMD_TEST_DRAM           0x1F05
#define MSG_CMD_TEST_UART           0x1F06
#define MSG_CMD_TEST_INTERRUPT      0x1F07
#define MSG_CMD_TEST_POM            0x1F08

#define MSG_STATUS_PASSED           0x801
#define MSG_STATUS_FAILED           0x802

#define TIMEOUT_CMD_READY           10
#define TIMEOUT_TEST_PLX_CHIP       5
#define TIMEOUT_TEST_LED            30
#define TIMEOUT_TEST_FLASH          5
#define TIMEOUT_TEST_SRAM           60
#define TIMEOUT_TEST_DRAM           180
#define TIMEOUT_TEST_UART           5
#define TIMEOUT_TEST_INTERRUPT      5



#if defined(PCI_CODE)
    void MsgInitialize(HANDLE);
    BOOL MsgSend(HANDLE, U16, U16);
    BOOL MsgReceive(HANDLE, U16 *, U16 *, double);
#elif defined(IOP_CODE)
    BOOL MsgSend(U16, U16);
    BOOL MsgReceive(U16 *, U16 *);
    extern void Sleep(U32);
#endif
