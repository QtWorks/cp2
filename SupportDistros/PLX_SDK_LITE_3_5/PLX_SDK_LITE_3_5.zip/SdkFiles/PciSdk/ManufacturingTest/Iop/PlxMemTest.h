#ifndef _PLXMEMTEST_H_
#define _PLXMEMTEST_H_

/*********************************************************************
 *                                                                   *
 * Module Name:                                                      *
 *                                                                   *
 *      PlxMemTest.h                                                 *
 *                                                                   *
 * Abstract:                                                         *
 *                                                                   *
 *      Header file for the Memory Test module                       *
 *                                                                   *
 *********************************************************************/




/*******************************************
*          Definitions
*******************************************/
#define MAX_MEMORY_ERRORS    0x10




/*******************************************
*        Public Functions
*******************************************/
int
PlxMemTest(
    char          *displayText,
    unsigned long  StartAddr,
    unsigned long  EndAddr
    );



#endif