/*******************************************************************************
 * Copyright (c) 2000 PLX Technology, Inc.
 *
 * PLX Technology Inc. licenses this software under specific terms and
 * conditions.  Use of any of the software or derviatives thereof in any
 * product without a PLX Technology chip is strictly prohibited.
 *
 * PLX Technology, Inc. provides this software AS IS, WITHOUT ANY WARRANTY,
 * EXPRESS OR IMPLIED, INCLUDING, WITHOUT LIMITATION, ANY WARRANTY OF
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  PLX makes no guarantee
 * or representations regarding the use of, or the results of the use of,
 * the software and documentation in terms of correctness, accuracy,
 * reliability, currentness, or otherwise; and you rely on the software,
 * documentation and results solely at your own risk.
 *
 * IN NO EVENT SHALL PLX BE LIABLE FOR ANY LOSS OF USE, LOSS OF BUSINESS,
 * LOSS OF PROFITS, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES
 * OF ANY KIND.  IN NO EVENT SHALL PLX'S TOTAL LIABILITY EXCEED THE SUM
 * PAID TO PLX FOR THE PRODUCT LICENSED HEREUNDER.
 *
 ******************************************************************************/

void SaveRegs(U32* PciRegisterBlock, U32* LocRegisterBlock)
{
	U8*                 PciWriteBuffer;
	U32					i;
	
	//Write register values to a file
    if (RegisterVal == TRUE)
    {
        sprintf(RegFileName, "Regs9054.val");
        hFile = CreateFile(RegFileName,
                           GENERIC_WRITE,
                           0,
                           NULL,
                           CREATE_ALWAYS,
                           FILE_ATTRIBUTE_NORMAL,
                           NULL);

	    PciWriteBuffer = (U8*)malloc(0x50*4);
   
	    for (i = 0; i<0x50; i++)
	    {
		    PciWriteBuffer[i*4]   = (U8) PciRegisterBlock[i] & 0x000000FF;
  		    PciWriteBuffer[i*4+1] = (U8)((PciRegisterBlock[i] & 0x0000FF00)>>8);
  		    PciWriteBuffer[i*4+2] = (U8)((PciRegisterBlock[i] & 0x00FF0000)>>16);
  		    PciWriteBuffer[i*4+3] = (U8)((PciRegisterBlock[i] & 0xFF000000)>>24);
  	    }
    
        WriteFile(hFile, PciWriteBuffer, 0x50*4, &bytesWritten, NULL);

        PciWriteBuffer = (U8*)malloc(0x100*4);
   	
	    for (i = 0; i<0x100; i++)
	    {
		    PciWriteBuffer[i*4]   = (U8)  LocRegisterBlock[i] & 0x000000FF;
  		    PciWriteBuffer[i*4+1] = (U8)((LocRegisterBlock[i] & 0x0000FF00)>>8);
  		    PciWriteBuffer[i*4+2] = (U8)((LocRegisterBlock[i] & 0x00FF0000)>>16);
  		    PciWriteBuffer[i*4+3] = (U8)((LocRegisterBlock[i] & 0xFF000000)>>24);
	    }

 
	    WriteFile(hFile, PciWriteBuffer, 0x100*4, &bytesWritten, NULL);

        CloseHandle(hFile);
    }
}	