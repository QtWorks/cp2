#ifndef     __RDK__BSP9054__H__
#define     __RDK__BSP9054__H__

#include "Bsp.h"


/*
 ********************************************************************************************************
 *
 *  BEGIN : Class CPlx9054Rdk860
 *
 *  This class is derieved from CBsp and it represents the 9054 RDK860. This class overrides only the 
 *  minimum functions that are required to make it a concrete type (the Pure Virtual functions of CBsp).
 *
 ********************************************************************************************************
 */



class CPlx9054Rdk860 : public CBsp
{
protected:

    virtual
    void
    BuildTestVector(
        void
        );



public:
    CPlx9054Rdk860(
        HANDLE          pPlx,
        DEVICE_LOCATION dev,
        CString         szFile
        );

    virtual
    void
    InitBspDefault(
        void
        );


};






/*
 ********************************************************************************************************
 *
 *  BEGIN : Class CPlx9054Lite
 *
 *  This class is derieved from CBsp and it represents the 9054 RDK LITE. This class overrides only the 
 *  minimum functions that are required to make it a concrete type (the Pure Virtual functions of CBsp).
 *
 ********************************************************************************************************
 */



class CPlx9054Lite  : public CBsp
{
protected:

    virtual
    void
    BuildTestVector(
        void
        );

public:
    CPlx9054Lite(
        HANDLE          pPlx,
        DEVICE_LOCATION dev,
        CString         szFile
        );


    virtual
    void
    InitBspDefault(
        void
        );

};







/*
 ********************************************************************************************************
 *
 *  BEGIN : Class CPlxCPci9054Rdk860
 *
 *  This class is derieved from CBsp and it represents the Compaq Pci 9054 RDK860. This class overrides only 
 *  the minimum functions that are required to make it a concrete type (the Pure Virtual functions of CBsp).
 *
 ********************************************************************************************************
 */


class CPlxCPci9054Rdk860 : public CBsp
{
protected:

    virtual
    void
    BuildTestVector(
        void
        );

public:
    CPlxCPci9054Rdk860(
        HANDLE          pPlx,
        DEVICE_LOCATION dev,
        CString         szFile
        );



    virtual
    void
    InitBspDefault(
        void
        );

};






#endif