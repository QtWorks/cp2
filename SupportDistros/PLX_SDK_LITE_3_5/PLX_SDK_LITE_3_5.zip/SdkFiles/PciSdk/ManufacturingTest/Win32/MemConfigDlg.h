/*******************************************************************************
 * Copyright (c) 2000 PLX Technology, Inc.
 *
 * PLX Technology Inc. licenses this software under specific terms and
 * conditions.  Use of any of the software or derviatives thereof in any
 * product without a PLX Technology chip is strictly prohibited.
 *
 * PLX Technology, Inc. provides this software AS IS, WITHOUT ANY WARRANTY,
 * EXPRESS OR IMPLIED, INCLUDING, WITHOUT LIMITATION, ANY WARRANTY OF
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  PLX makes no guarantee
 * or representations regarding the use of, or the results of the use of,
 * the software and documentation in terms of correctness, accuracy,
 * reliability, currentness, or otherwise; and you rely on the software,
 * documentation and results solely at your own risk.
 *
 * IN NO EVENT SHALL PLX BE LIABLE FOR ANY LOSS OF USE, LOSS OF BUSINESS,
 * LOSS OF PROFITS, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES
 * OF ANY KIND.  IN NO EVENT SHALL PLX'S TOTAL LIABILITY EXCEED THE SUM
 * PAID TO PLX FOR THE PRODUCT LICENSED HEREUNDER.
 *
 ******************************************************************************/

#if !defined(AFX_MEMCONFIGDLG_H__589ECBA1_9669_11D2_A3E2_A08449C10801__INCLUDED_)
#define AFX_MEMCONFIGDLG_H__589ECBA1_9669_11D2_A3E2_A08449C10801__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
// MemConfigDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMemConfigDlg dialog

class CMemConfigDlg : public CDialog
{
// Construction
public:
	CMemConfigDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CMemConfigDlg)
	enum { IDD = IDD_MEMORY_CONFIG_DIALOG };
	CString	m_FlashBase;
	CString	m_Memory0;
	CString	m_Memory1;
	CString	m_PlxRegBase;
	CString	m_FlashOffset;
	CString	m_Mem0Size;
	CString	m_Mem1Size;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMemConfigDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CMemConfigDlg)
		virtual BOOL OnInitDialog();
	afx_msg void OnChangeMemory0Edit();
	afx_msg void OnChangeMemory1Edit();
	afx_msg void OnChangeFlashBaseEdit();
	afx_msg void OnChangePlxRegisterBaseEdit();
	afx_msg void OnChangeMemory0SizeEdit();
	afx_msg void OnChangeMemory1SizeEdit();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MEMCONFIGDLG_H__589ECBA1_9669_11D2_A3E2_A08449C10801__INCLUDED_)
