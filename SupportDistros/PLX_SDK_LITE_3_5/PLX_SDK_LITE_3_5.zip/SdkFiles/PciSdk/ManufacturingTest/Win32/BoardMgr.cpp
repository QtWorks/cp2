#include "StdAfx.h"
#include "ManfGUI.h"
#include "BoardMgr.h"
#include "Bsp.h"
#include "Bsp9054.h"
#include "Bsp90X0.h"
#include "Bsp9X56.h"





/************************************************************************
 *  Function    :   CBoardMgr       (Class Constructor)
 *  Abstract    :   None
 ************************************************************************/
CBoardMgr::CBoardMgr(
        void
        )
{

}




/************************************************************************
 *  Function    :   ~CBoardMgr      (Class Destructor)
 *  Abstract    :   The class destructor will iterate through the MAP 
 *                  hold all the CBsp* used by the ManTest and delete 
 *                  those objects.
 ************************************************************************/
CBoardMgr::~CBoardMgr(
        void
        )
{
    
    POSITION    pos;
    CString     szKey;
    CBsp*       pBsp;

    for( pos = BspMap.GetStartPosition(); pos != NULL; )
    {
        // Iterate through the entire map, dumping both name and age.
        BspMap.GetNextAssoc(pos,szKey,(void*&)pBsp);
        BspMap.RemoveKey(szKey);
            //close the old Plx Device
        PlxPciDeviceClose(
            pBsp->hPlx
            );
        delete pBsp;
    }
}



/************************************************************************
 *  Function    :   InitBspMgr      (public member function)
 *  Abstract    :   Initializes the manager with a device list of all the 
 *                  BSP on the bus
 ************************************************************************/
BOOL
CBoardMgr::InitBspMgr(
    void
    )
{
    DevIndex =
        SelectDevice(
            &PlxHandle,
            CurrentDeviceList
            );

    if (DevIndex == 0)
    {
        return FALSE;
    }

    return TRUE;  
}




/************************************************************************
 *  Function    :   GetBsp          (public member function)
 *  Abstract    :   Function will return a pointer to the BSP specified 
 *                  by the device Id.
 ************************************************************************/
CBsp* 
CBoardMgr::GetBsp(
    CString     szBoardSelected
    )
{
    S8              i;
    BOOL            bFound(FALSE);
    CString         szConfigFileName;
    DEVICE_LOCATION dev;
    CBsp*           pBsp = 0;


    for (i=0; i<DevIndex && !bFound; i++)
    {
        if ((strcmp(CurrentDeviceList[i].DevStr, szBoardSelected) == 0) ||
             szBoardSelected == "")
        {
            dev.VendorId   = CurrentDeviceList[i].device.VendorId;
            dev.DeviceId   = CurrentDeviceList[i].device.DeviceId;
            dev.BusNumber  = CurrentDeviceList[i].device.BusNumber;
            dev.SlotNumber = CurrentDeviceList[i].device.SlotNumber;
            strcpy((char*)dev.SerialNumber, "");
            
            bFound  =   TRUE;
            if(BspMap.Lookup(CurrentDeviceList[i].DevStr,(void*&) pBsp))
            {
                return pBsp;
            }

           
            if (PlxPciDeviceOpen(&dev, &PlxHandle) == ApiSuccess)
            {
                if ((dev.DeviceId == PLX_9054RDK_860_DEVICE_ID) &&
                    (dev.VendorId == PLX_VENDOR_ID))
                {
                    szConfigFileName = "Plx9054Rdk860.bsp";
                    pBsp = new CPlx9054Rdk860(PlxHandle,dev,szConfigFileName);
                }
				else if((dev.DeviceId == PLX_CPCI9054RDK_860_DEVICE_ID) &&
                        (dev.VendorId == PLX_VENDOR_ID))
                {
                    szConfigFileName = "PlxCpci9054Rdk860.bsp";
                    pBsp = new CPlxCPci9054Rdk860(PlxHandle,dev,szConfigFileName);
                }
                //Disable the tests if the selected board is 401B.
                else if ((dev.DeviceId == PLX_9080RDK_401B_DEVICE_ID) &&
                         (dev.VendorId == PLX_VENDOR_ID))
                {
                    szConfigFileName = "Plx9080Rdk401b.bsp";				
                    pBsp = new CPlx9080Rdk401b(PlxHandle,dev,szConfigFileName);
                }
				else if ((dev.DeviceId == PLX_9054RDK_LITE_DEVICE_ID) &&
                         (dev.VendorId == PLX_VENDOR_ID)) 
				{
                    szConfigFileName = "Plx9054RdkLite.bsp";
                    pBsp = new CPlx9054Lite(PlxHandle,dev,szConfigFileName);
				}
				else if ((dev.DeviceId == PLX_9030RDK_LITE_DEVICE_ID) &&
						 (dev.VendorId == PLX_VENDOR_ID)) 
				{
                    szConfigFileName = "Plx9030RdkLite.bsp";
                    pBsp = new CPlx9030RdkLite(PlxHandle,dev,szConfigFileName);
				}
				else if ((dev.DeviceId == PLX_CPCI9030RDK_LITE_DEVICE_ID) &&
						 (dev.VendorId == PLX_VENDOR_ID)) 
				{
                    szConfigFileName    =   "Plx9030RdkLite.bsp";				
                    pBsp  =   new CPlxCPci9030RdkLite(PlxHandle,dev,szConfigFileName);
				}

            	else if ((dev.DeviceId == PLX_9056RDK_LITE_DEVICE_ID) &&
                         (dev.VendorId == PLX_VENDOR_ID))
				{
                    szConfigFileName    =   "Plx9056RdkLite.bsp";				
                    pBsp  =   new CPlx9056RdkLite(PlxHandle,dev,szConfigFileName);
				}
                else if (dev.DeviceId == PLX_9056RDK_860_DEVICE_ID &&
                        (dev.VendorId == PLX_VENDOR_ID)) 
				{
                    szConfigFileName    =   "Plx9056Rdk860.bsp";				
                    pBsp  =   new CPlx9056Rdk860(PlxHandle,dev,szConfigFileName);
				}

                else if (dev.DeviceId == PLX_9656RDK_LITE_DEVICE_ID &&
                        (dev.VendorId == PLX_VENDOR_ID)) 
                {
                    szConfigFileName    =   "Plx9656RdkLite.bsp";				
                    pBsp  =   new CPlx9656RdkLite(PlxHandle,dev,szConfigFileName);
                }
                else if (dev.DeviceId == PLX_9656RDK_860_DEVICE_ID &&
                        (dev.VendorId == PLX_VENDOR_ID)) 
                {
                    szConfigFileName    =   "Plx9656Rdk860.bsp";				
                    pBsp  =   new CPlx9656Rdk860(PlxHandle,dev,szConfigFileName);
                }
                else if ((dev.DeviceId == PLX_9050RDK_LITE_DEVICE_ID) &&
                         (dev.VendorId == PLX_VENDOR_ID)) 
                {
                    szConfigFileName    =   "Plx9050Rdk.bsp";				
                    pBsp  =   new CPlx9050Rdk(PlxHandle,dev,szConfigFileName);
                }
                else if ((dev.DeviceId == PLX_9052RDK_LITE_DEVICE_ID) &&
                         (dev.VendorId == PLX_VENDOR_ID)) 
                {
                    szConfigFileName    =   "Plx9050Rdk.bsp";				
                    pBsp  =   new CPlx9052Rdk(PlxHandle,dev,szConfigFileName);
                }
                   
                pBsp->szBspLocator = CurrentDeviceList[i].DevStr;
            }
            else
                return 0;
        }
    }

    if (pBsp)
    {
        pBsp->InitBsp();

        BspMap[pBsp->szBspLocator] = pBsp;
        pBsp->pBsp->device         =  dev;
    }

    return pBsp;
}
