// ManfGUIDlg.h : header file
//
/*******************************************************************************
 * Copyright (c) 2000 PLX Technology, Inc.
 *
 * PLX Technology Inc. licenses this software under specific terms and
 * conditions.  Use of any of the software or derviatives thereof in any
 * product without a PLX Technology chip is strictly prohibited.
 *
 * PLX Technology, Inc. provides this software AS IS, WITHOUT ANY WARRANTY,
 * EXPRESS OR IMPLIED, INCLUDING, WITHOUT LIMITATION, ANY WARRANTY OF
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  PLX makes no guarantee
 * or representations regarding the use of, or the results of the use of,
 * the software and documentation in terms of correctness, accuracy,
 * reliability, currentness, or otherwise; and you rely on the software,
 * documentation and results solely at your own risk.
 *
 * IN NO EVENT SHALL PLX BE LIABLE FOR ANY LOSS OF USE, LOSS OF BUSINESS,
 * LOSS OF PROFITS, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES
 * OF ANY KIND.  IN NO EVENT SHALL PLX'S TOTAL LIABILITY EXCEED THE SUM
 * PAID TO PLX FOR THE PRODUCT LICENSED HEREUNDER.
 *
 ******************************************************************************/

#include "MemConfigDlg.h"

/////////////////////////////////////////////////////////////////////////////
// CManfGUIDlg dialog

class CManfGUIDlg : public CDialog
{
// Construction
public:
	CManfGUIDlg(CWnd* pParent = NULL);	// standard constructor

/////////////////////////

CMemConfigDlg  m_dlg;

////////////////////////

// Dialog Data
	//{{AFX_DATA(CManfGUIDlg)
	enum { IDD = IDD_MANFGUI_DIALOG };
	CSpinButtonCtrl	m_Spin;
	BOOL	m_FlashCheck;
	BOOL	m_IopFlashCheck;
	BOOL	m_IopLedCheck;
	BOOL	m_IopPomCheck;
	BOOL	m_IopPlxChipCheck;
	BOOL	m_IopUartCheck;
	BOOL	m_LedCheck;
	BOOL	m_PomCheck;
	BOOL	m_PlxChipCheck;
	BOOL	m_UartCheck;
	CString	m_UartEdit;
	CString	m_SdramEdit;
	CString	m_SbsramEdit;
	CString	m_PomEdit;
	CString	m_PlxChipEdit;
	CString	m_LedEdit;
	CString	m_PowerMEdit;
	CString	m_FlashEdit;
	CString	m_VpdEdit;
	CString	m_HotSwapEdit;
	CString	m_IopUartEdit;
	CString	m_IopSdramEdit;
	CString	m_IopSbsramEdit;
	CString	m_IopPomEdit;
	CString	m_IopPlxChipEdit;
	CString	m_IopLedEdit;
	CString	m_IopPowerMEdit;
	CString	m_IopFlashEdit;
	CString	m_IopVpdEdit;
	CString	m_TestResultEdit;
	BOOL	m_LogCheck;
	double	m_LoopCount;
	CString	m_DeviceString;
	BOOL	m_HotSwapCheck;
	BOOL	m_IopHotSwapCheck;
	BOOL	m_IopPowerMCheck;
	BOOL	m_IopVpdCheck;
	BOOL	m_PowerMCheck;
	BOOL	m_VpdCheck;
	BOOL	m_IopSdramCheck;
	BOOL	m_SdramCheck;
	BOOL	m_IopSbsramCheck;
	BOOL	m_SbsramCheck;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CManfGUIDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

   long NewMemTest(char*, unsigned long, unsigned long, unsigned long);
   long DiagnosisRamTest(char*, unsigned long, unsigned long, unsigned long);
   void GuiDisable(void);
   BOOL HotSwapTest(void);
   BOOL HostLedTest();
   void CheckAbort(void);
   void ResetButtonText();
   void DisableIopTests();
   void ButtonInitialization();
   void DisableAll();
   void EnablePciButtons();
   void EnableIopButtons();
   void RdkTests(unsigned long );
   void LogError(char*, unsigned long, unsigned long, unsigned long);
   void RdkPciTest(unsigned long );
   void RdkIopTest(unsigned long );

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CManfGUIDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnEnableallButton();
	afx_msg void OnClearallButton();
	afx_msg void OnEnablepciTest();
	afx_msg void OnEnableiopTest();
	afx_msg void OnAbortestButton();
	afx_msg void OnStartestButton();
	afx_msg void OnOpenDevice();
	afx_msg void OnStopButton();
	afx_msg void OnDoubleclickedStopButton();
	afx_msg void OnBoardConfigButton();
	afx_msg void OnCofElf();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
