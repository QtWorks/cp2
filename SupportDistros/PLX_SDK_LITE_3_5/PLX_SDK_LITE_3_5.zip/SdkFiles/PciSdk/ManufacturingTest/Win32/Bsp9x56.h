#ifndef     __RDK__BSP9X56__H__
#define     __RDK__BSP9X56__H__



#include "Bsp9054.h"


/*
 ********************************************************************************************************
 *  BEGIN : Class CPlx9056RdkLite
 *  This class is derieved from CBsp and it represents the 9056 Lite, this class is derieved for the 
 *  9054 Lite class due the similare functionality
 ********************************************************************************************************
 */
class CPlx9056RdkLite : public CPlx9054Lite
{
protected:
    virtual
    void
    BuildTestVector(
        void
        );

public:
    CPlx9056RdkLite(
        HANDLE          pPlx,
        DEVICE_LOCATION dev,
        CString         szFile
        );


    virtual
    void
    InitBspDefault(
        void
        );

};







/*
 ********************************************************************************************************
 *  BEGIN : Class CPlx9656RdkLite
 *  This class is derieved from CBsp and it represents the 9656 Lite, this class is derieved for the 
 *  9054 Lite class due the similare functionality
 ********************************************************************************************************
 */
class CPlx9656RdkLite : public CPlx9054Lite
{
protected:
    virtual
    void
    BuildTestVector(
        void
        );

public:
    CPlx9656RdkLite(
        HANDLE          pPlx,
        DEVICE_LOCATION dev,
        CString         szFile
        );


    virtual
    void
    InitBspDefault(
        void
        );

};






/*
 ********************************************************************************************************
 *  BEGIN : Class CPlx9056Rdk860
 *  This class is derieved from CBsp and it represents the 9056 860, this class is derieved for the 
 *  9054 860 class due the similare functionality
 ********************************************************************************************************
 */
class CPlx9056Rdk860 : public CPlx9054Rdk860
{
protected:
    virtual
    void
    BuildTestVector(
        void
        );

public:
    CPlx9056Rdk860(
        HANDLE          pPlx,
        DEVICE_LOCATION dev,
        CString         szFile
        );

    virtual
    void
    InitBspDefault(
        void
        );

    virtual
    BOOL
    HostTestFlash1(
        void
        );

};






/*
 ********************************************************************************************************
 *  BEGIN : Class CPlx9656RdkLite
 *  This class is derieved from CBsp and it represents the 9056 860, this class is derieved for the 
 *  9054 860 class due the similare functionality
 ********************************************************************************************************
 */
class CPlx9656Rdk860 : public CPlx9054Rdk860
{
protected:
    virtual
    void
    BuildTestVector(
        void
        );

public:
    CPlx9656Rdk860(
        HANDLE          pPlx,
        DEVICE_LOCATION dev,
        CString         szFile
        );

    virtual
    BOOL
    HostTestFlash1(
        void
        );

    virtual
    void
    InitBspDefault(
        void
        );

};



#endif