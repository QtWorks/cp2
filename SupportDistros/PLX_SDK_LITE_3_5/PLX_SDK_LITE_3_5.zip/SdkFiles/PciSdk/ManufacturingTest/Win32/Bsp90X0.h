#ifndef     __RDK__BSP90X0__H__
#define     __RDK__BSP90X0__H__



#include "Bsp.h"



/*
 ********************************************************************************************************
 *
 *  BEGIN : Class CPlx9080Rdk860
 *
 *  This class is derieved from CBsp and it represents the Pci 9080 RDK860. This class overrides only 
 *  the minimum functions that are required to make it a concrete type (the Pure Virtual functions of CBsp).
 *
 ********************************************************************************************************
 */
class CPlx9080Rdk860 : public CBsp
{
protected:

    virtual
    void
    BuildTestVector(
        void
        );


public:
    CPlx9080Rdk860(
        HANDLE          pPlx,
        DEVICE_LOCATION dev,
        CString         szFile
        );


    virtual
    void
    InitBspDefault(
        void
        );

};


/*
 ********************************************************************************************************
 *  BEGIN : Class CPlx9080Rdk401b
 *  This class is derieved from CBsp and it represents the 9080 401b board 
 ********************************************************************************************************
 */

class CPlx9080Rdk401b : public CBsp
{
protected:

    virtual
    void
    BuildTestVector(
        void
        );


public:
    CPlx9080Rdk401b(
        HANDLE          pPlx,
        DEVICE_LOCATION dev,
        CString         szFile
        );



    virtual
    void
    InitBspDefault(
        void
        );

};







/*
 ********************************************************************************************************
 *  BEGIN : Class CPlx9030RdkLite
 *  This class is derieved from CBsp and it represents the 9030 Lite
 ********************************************************************************************************
 */
class CPlx9030RdkLite : public CBsp
{
protected:

    virtual
    void
    BuildTestVector(
        void
        );

public:
    CPlx9030RdkLite(
        HANDLE          pPlx,
        DEVICE_LOCATION dev,
        CString         szFile
        );


    virtual
    void
    InitBspDefault(
        void
        );
        virtual
    
    BOOL
    HostTestPlxChip(
        void
        );


};





/*
 ********************************************************************************************************
 *  BEGIN : Class CPlxPci9030RdkLite
 *  This class is derieved from CBsp and it represents the Compaq Pci 9030 Lite
 ********************************************************************************************************
 */
class CPlxCPci9030RdkLite : public CPlx9030RdkLite
{
public:
    CPlxCPci9030RdkLite (
        HANDLE          pPlx,
        DEVICE_LOCATION dev,
        CString         szFile
        );

};






/*
 ********************************************************************************************************
 *  BEGIN : Class CPlx9050Rdk
 *  This class is derieved from CBsp and it represents the 9050 Rdk
 ********************************************************************************************************
 */
class CPlx9050Rdk : public CBsp
{
protected:

    virtual
    void
    BuildTestVector(
        void
        );

public:
    CPlx9050Rdk(
        HANDLE          pPlx,
        DEVICE_LOCATION dev,
        CString         szFile
        );


    virtual
    void
    InitBspDefault(
        void
        );

    BOOL
    HostTestPlxChip(
        void
        );



};

/*
 ********************************************************************************************************
 *  BEGIN : Class CPlx9050Rdk
 *  This class is derieved from CBsp and it represents the 9050 Rdk
 ********************************************************************************************************
 */
class CPlx9052Rdk : public CBsp
{
protected:

    virtual
    void
    BuildTestVector(
        void
        );

public:
    CPlx9052Rdk(
        HANDLE          pPlx,
        DEVICE_LOCATION dev,
        CString         szFile
        );


    virtual
    void
    InitBspDefault(
        void
        );

    BOOL
    HostTestPlxChip(
        void
        );



};



#endif