#include "Bsp90X0.h"
#include "Reg9030.h"
#include "reg9050.h"
#include "reg9080.h"






/************************************CPlx9080Rdk860**************************/


/************************************************************************
 *
 *  Function    :   
 *
 *  Abstract    :   
 *
 ************************************************************************/
void
CPlx9080Rdk860::BuildTestVector(
    void
    )
{


    uTestVector =   HOST_RAM_0_TEST     |
                    HOST_RAM_1_TEST     |
                    HOST_FLASH_0_TEST   |
                    HOST_HOT_SWAP_TEST  |
                    HOST_VPD_TEST       |
                    HOST_PLX_CHIP_TEST  |
                    LOCAL_RAM_0_TEST    |
                    LOCAL_RAM_1_TEST    |
                    LOCAL_FLASH_0_TEST  |
                    LOCAL_HOT_SWAP_TEST |
                    LOCAL_VPD_TEST      |
                    LOCAL_PLX_CHIP_TEST;

}





/************************************************************************
 *
 *  Function    :   
 *
 *  Abstract    :   
 *
 ************************************************************************/
CPlx9080Rdk860::CPlx9080Rdk860(
        HANDLE          pPlx,
        DEVICE_LOCATION dev,
        CString         szFile
    )
    :   CBsp(pPlx,dev,szFile)

{
    LogFileName =   "MT_9080Rdk860.log";

    BuildTestVector();
    //Use space0 for SDRAM, space1 for FLASH.
    RegisterOffset.Space0Remap = PCI9080_SPACE0_REMAP;
    RegisterOffset.Space0Range = PCI9080_SPACE0_RANGE;
    RegisterOffset.Space1Remap = PCI9080_SPACE1_REMAP;
    RegisterOffset.Space1Range = PCI9080_SPACE1_RANGE;
    RegisterOffset.DramBusDesc = PCI9080_SPACE1_DESC;
}





/************************************************************************
 *
 *  Function    :   
 *
 *  Abstract    :   
 *
 ************************************************************************/
void
CPlx9080Rdk860::InitBspDefault(
    void
    )
{
    pBsp->PlxChipType       =   0x9080;
    pBsp->PlxChipBase       =   0xC0000000;
    pBsp->Ram0Base          =   0x10000000;
    pBsp->Ram0Size          =   0x01000000;
    pBsp->Ram1Base          =   0x10000000;
    pBsp->Ram1Size          =   0X00080000;
    pBsp->Ram2Base          =   0xFFFFFFFF;
    pBsp->Ram2Size          =   0x00000000;
    pBsp->Flash0Base        =   0xFFF00000;
    pBsp->Flash0Size        =   0x00080000;
    pBsp->Flash0Type        =   0;
    pBsp->Flash1Base        =   0xFFFFFFFF;
    pBsp->Flash1Size        =   0x00000000;
    pBsp->Flash1Type        =   0;
    pBsp->InterruptBase     =   0xFFFFFFFF;
    pBsp->SwResetBase       =   0xFFFFFFFF;
}






/************************************CPlx9080Rdk401b**************************/


/************************************************************************
 *
 *  Function    :   
 *
 *  Abstract    :   
 *
 ************************************************************************/
void
CPlx9080Rdk401b::BuildTestVector(
    void
    )
{
    uTestVector =   HOST_RAM_0_TEST     |
                    HOST_RAM_1_TEST     |
                    HOST_FLASH_0_TEST   |
                    HOST_HOT_SWAP_TEST  |
                    HOST_VPD_TEST       |
                    HOST_PLX_CHIP_TEST  |
                    LOCAL_RAM_0_TEST    |
                    LOCAL_RAM_1_TEST    |
                    LOCAL_FLASH_0_TEST  |
                    LOCAL_HOT_SWAP_TEST |
                    LOCAL_VPD_TEST      |
                    LOCAL_PLX_CHIP_TEST |
                    HOST_LED_TEST       |
                    LOCAL_LED_TEST;;


}




/************************************************************************
 *
 *  Function    :   
 *
 *  Abstract    :   
 *
 ************************************************************************/
CPlx9080Rdk401b::CPlx9080Rdk401b(
        HANDLE          pPlx,
        DEVICE_LOCATION dev,
        CString         szFile
    )
    :   CBsp(pPlx,dev,szFile)
{

    LogFileName =   "MT_9080Rdk401b.log";    

    BuildTestVector();
    RegisterOffset.Space0Remap = PCI9080_SPACE0_REMAP;
    RegisterOffset.Space0Range = PCI9080_SPACE0_RANGE;
    RegisterOffset.Space1Remap = PCI9080_SPACE1_REMAP;
    RegisterOffset.Space1Range = PCI9080_SPACE1_RANGE;
    RegisterOffset.DramBusDesc = PCI9080_SPACE1_DESC;
}






/************************************************************************
 *
 *  Function    :   
 *
 *  Abstract    :   
 *
 ************************************************************************/
void
CPlx9080Rdk401b::InitBspDefault(
    void
    )
{

    pBsp->PlxChipType       =   0x9080;
    pBsp->PlxChipBase       =   0x20000000;
    pBsp->Ram0Base          =   0x00000000;
    pBsp->Ram0Size          =   0x01000000;
    pBsp->Ram1Base          =   0x10000000;
    pBsp->Ram1Size          =   0X00080000;
    pBsp->Ram2Base          =   0xFFFFFFFF;
    pBsp->Ram2Size          =   0x00000000;
    pBsp->Flash0Base        =   0xFFF80000;
    pBsp->Flash0Size        =   0x00080000;
    pBsp->Flash0Type        =   0;
    pBsp->Flash1Base        =   0xFFFFFFFF;
    pBsp->Flash1Size        =   0x00000000;
    pBsp->Flash1Type        =   0;
    pBsp->InterruptBase     =   0x80000000;
    pBsp->SwResetBase       =   0xC0000000;
}






/************************************CPlx9030RdkLite**************************/

 
/************************************************************************
 *
 *  Function    :   
 *
 *  Abstract    :   
 *
 ************************************************************************/
void
CPlx9030RdkLite::BuildTestVector(
    void
    )
{
    uTestVector =   HOST_RAM_0_TEST     |
                    HOST_VPD_TEST       |
                    HOST_PLX_CHIP_TEST;
}




/************************************************************************
 *
 *  Function    :   
 *
 *  Abstract    :   
 *
 ************************************************************************/
CPlx9030RdkLite::CPlx9030RdkLite(
    HANDLE          pPlx,
    DEVICE_LOCATION dev,
    CString         szFile
    )
    :   CBsp(pPlx,dev,szFile)
{

    LogFileName =   "MT_CPCI9030.log";    
    
    BuildTestVector();
    RegisterOffset.VpdId   = PCI9030_VPD_CAP_ID;
    RegisterOffset.VpdData = PCI9030_VPD_DATA;
    RegisterOffset.PmCapId = PCI9030_PM_CAP_ID;
    RegisterOffset.PmCsr   = PCI9030_PM_CSR;
    RegisterOffset.HotSwap = PCI9030_HS_CAP_ID;
    //Use space0 for SDRAM, space1 for FLASH.
    RegisterOffset.Space0Remap = PCI9030_REMAP_SPACE0;
    RegisterOffset.Space0Range = PCI9030_RANGE_SPACE0;
    RegisterOffset.Space1Remap = PCI9030_REMAP_SPACE1;
    RegisterOffset.Space1Range = PCI9030_RANGE_SPACE1;

    RegisterOffset.DramBusDesc = PCI9030_DESC_SPACE1;

}






/************************************************************************
 *
 *  Function    :   
 *
 *  Abstract    :   
 *
 ************************************************************************/
void
CPlx9030RdkLite::InitBspDefault(
    void
    )
{
    pBsp->PlxChipType       =   0x9030;
    pBsp->PlxChipBase       =   0x30000000;
    pBsp->Ram0Base          =   0x00000000;
    pBsp->Ram0Size          =   0x00002000;
    pBsp->Ram1Base          =   0xFFFFFFFF;
    pBsp->Ram1Size          =   0X00000000;
    pBsp->Ram2Base          =   0xFFFFFFFF;
    pBsp->Ram2Size          =   0x00000000;
    pBsp->Flash0Base        =   0xFFFFFFFF;
    pBsp->Flash0Size        =   0x00000000;
    pBsp->Flash0Type        =   0;
    pBsp->Flash1Base        =   0xFFFFFFFF;
    pBsp->Flash1Size        =   0x00000000;
    pBsp->Flash1Type        =   0;
    pBsp->InterruptBase     =   0xFFFFFFFF;
    pBsp->SwResetBase       =   0xFFFFFFFF;

}




/************************************************************************
 *
 *  Function    :   
 *
 *  Abstract    :   
 *
 ************************************************************************/
BOOL
CPlx9030RdkLite::HostTestPlxChip(
    void
    )
{
    BOOL    bRetVal(TRUE);
    U8          j;
    U16         RegOffset;
    U32         TestData[] = {0xa5a5a5a5, 0x5a5a5a5a, 0xffffffff, 0x12345678};
    RETURN_CODE rc; 

    struct
    {
        U16   first;
        U16   last;
    } PCI9030_Registers[] =  {	{       PCI9030_VENDOR_ID,		PCI9030_VPD_DATA},
							    {		PCI9030_RANGE_SPACE0,	PCI9030_GP_IO_CTRL}};

    if(!IsTestSupported(HOST_PLX_CHIP_TEST))
        return FALSE;

    for (j=0; j<2; j++)
    {
        for (RegOffset=PCI9030_Registers[j].first; RegOffset<=PCI9030_Registers[j].last; RegOffset+=4)
        {
            if (j == 0)             /* Configuration Registers */
            {
                PlxPciConfigRegisterRead(pBsp->device.BusNumber, pBsp->device.SlotNumber, 
                                     RegOffset, &rc);
                if (rc != ApiSuccess)
                {
                    LogBuffer.Format("Host PLX Chip Test: Error reading Config Register 0x%03x", RegOffset);
                    LogWrite(LogBuffer);
                    bRetVal = TRUE;
                }
            }
            else
            {
                PlxRegisterRead(hPlx, RegOffset, &rc);
                if (rc != ApiSuccess)
                {
                    LogBuffer.Format("Host PLX Chip Test: Error reading Local Register 0x%03x", RegOffset);
                    LogWrite(LogBuffer);
                    bRetVal = TRUE;
                }
            }
        }
    }
    return  bRetVal;
}







/************************************CPlxCPci9030RdkLite**************************/

/************************************************************************
 *
 *  Function    :   
 *
 *  Abstract    :   
 *
 ************************************************************************/
CPlxCPci9030RdkLite::CPlxCPci9030RdkLite(
    HANDLE          pPlx,
    DEVICE_LOCATION dev,
    CString         szFile
    )
    :   CPlx9030RdkLite(pPlx,dev,szFile)
{
    BuildTestVector();
    LogFileName =   "MT_CPCI9030.log";
}





/**********************************CPlx9050Rdk**************************/

 
/************************************************************************
 *
 *  Function    :   
 *
 *  Abstract    :   
 *
 ************************************************************************/
void
CPlx9050Rdk::BuildTestVector(
    void
    )
{
    uTestVector =   HOST_RAM_0_TEST     |
					HOST_ISA_TEST		|
                    HOST_PLX_CHIP_TEST;
}








/************************************************************************
 *
 *  Function    :   
 *
 *  Abstract    :   
 *
 ************************************************************************/
CPlx9050Rdk::CPlx9050Rdk(
    HANDLE          pPlx,
    DEVICE_LOCATION dev,
    CString         szFile
    )
    :   CBsp(pPlx,dev,szFile)
{

    LogFileName =   "MT_9050_2.log";    

    BuildTestVector();
    RegisterOffset.Space0Remap = PCI9050_REMAP_SPACE0;
    RegisterOffset.Space0Range = PCI9050_RANGE_SPACE0;
    RegisterOffset.Space1Remap = PCI9050_REMAP_SPACE1;
    RegisterOffset.Space1Range = PCI9050_RANGE_SPACE1;

    RegisterOffset.DramBusDesc = PCI9050_DESC_SPACE1;

}






/************************************************************************
 *
 *  Function    :   
 *
 *  Abstract    :   
 *
 ************************************************************************/
void
CPlx9050Rdk::InitBspDefault(
    void
    )
{

    pBsp->PlxChipType       =   0x9050;
    pBsp->PlxChipBase       =   0x30000000;
    pBsp->Ram0Base          =   0x01000000;
    pBsp->Ram0Size          =   0x00020000;
    pBsp->Ram1Base          =   0xFFFFFFFF;
    pBsp->Ram1Size          =   0X00000000;
    pBsp->Ram2Base          =   0xFFFFFFFF;
    pBsp->Ram2Size          =   0x00000000;
    pBsp->Flash0Base        =   0xFFFFFFFF;
    pBsp->Flash0Size        =   0x00000000;
    pBsp->Flash0Type        =   0;
    pBsp->Flash1Base        =   0xFFFFFFFF;
    pBsp->Flash1Size        =   0x00000000;
    pBsp->Flash1Type        =   0;
    pBsp->InterruptBase     =   0xFFFFFFFF;
    pBsp->SwResetBase       =   0xFFFFFFFF;
}





/************************************************************************
 *
 *  Function    :   
 *
 *  Abstract    :   
 *
 ************************************************************************/
BOOL
CPlx9050Rdk::HostTestPlxChip(
    void
    )
{

    BOOL    bRetVal(TRUE);
    U8          j;
    U16         RegOffset;
    U32         TestData[] = {0xa5a5a5a5, 0x5a5a5a5a, 0xffffffff, 0x12345678};
    RETURN_CODE rc; 

    struct
    {
        U16   first;
        U16   last;
    } PCI9030_Registers[] =  {	{       PCI9050_VENDOR_ID,		PCI9050_INT_LINE},
							    {		PCI9050_RANGE_SPACE0,	PCI9050_EEPROM_CTRL}};

    if(!IsTestSupported(HOST_PLX_CHIP_TEST))
        return FALSE;

    for (j=0; j<2; j++)
    {
        for (RegOffset=PCI9030_Registers[j].first; RegOffset<=PCI9030_Registers[j].last; RegOffset+=4)
        {
            if (j == 0)             /* Configuration Registers */
            {
                PlxPciConfigRegisterRead(pBsp->device.BusNumber, pBsp->device.SlotNumber, 
                                     RegOffset, &rc);
                if (rc != ApiSuccess)
                {
                    LogBuffer.Format("Host PLX Chip Test: Error reading Config Register 0x%03x", RegOffset);
                    LogWrite(LogBuffer);
                    bRetVal = TRUE;
                }
            }
            else
            {
                PlxRegisterRead(hPlx, RegOffset, &rc);
                if (rc != ApiSuccess)
                {
                    LogBuffer.Format("Host PLX Chip Test: Error reading Local Register 0x%03x", RegOffset);
                    LogWrite(LogBuffer);
                    bRetVal = TRUE;
                }
            }
        }
    }
    return  bRetVal;
}





/**********************************CPlx9050Rdk**************************/

 
/************************************************************************
 *
 *  Function    :   
 *
 *  Abstract    :   
 *
 ************************************************************************/
void
CPlx9052Rdk::BuildTestVector(
    void
    )
{
    uTestVector =   HOST_RAM_0_TEST     |
					HOST_ISA_TEST		|
                    HOST_PLX_CHIP_TEST;
}








/************************************************************************
 *
 *  Function    :   
 *
 *  Abstract    :   
 *
 ************************************************************************/
CPlx9052Rdk::CPlx9052Rdk(
    HANDLE          pPlx,
    DEVICE_LOCATION dev,
    CString         szFile
    )
    :   CBsp(pPlx,dev,szFile)
{

    LogFileName =   "MT_9052_2.log";    

    BuildTestVector();
    RegisterOffset.Space0Remap = PCI9050_REMAP_SPACE2;
    RegisterOffset.Space0Range = PCI9050_RANGE_SPACE2;
    RegisterOffset.Space1Remap = PCI9050_REMAP_SPACE1;
    RegisterOffset.Space1Range = PCI9050_RANGE_SPACE1;

    RegisterOffset.DramBusDesc = PCI9050_DESC_SPACE1;

}






/************************************************************************
 *
 *  Function    :   
 *
 *  Abstract    :   
 *
 ************************************************************************/
void
CPlx9052Rdk::InitBspDefault(
    void
    )
{

    pBsp->PlxChipType       =   0x9050;
    pBsp->PlxChipBase       =   0x30000000;
    pBsp->Ram0Base          =   0x01000000;
    pBsp->Ram0Size          =   0x00020000;
    pBsp->Ram1Base          =   0xFFFFFFFF;
    pBsp->Ram1Size          =   0X00000000;
    pBsp->Ram2Base          =   0xFFFFFFFF;
    pBsp->Ram2Size          =   0x00000000;
    pBsp->Flash0Base        =   0xFFFFFFFF;
    pBsp->Flash0Size        =   0x00000000;
    pBsp->Flash0Type        =   0;
    pBsp->Flash1Base        =   0xFFFFFFFF;
    pBsp->Flash1Size        =   0x00000000;
    pBsp->Flash1Type        =   0;
    pBsp->InterruptBase     =   0xFFFFFFFF;
    pBsp->SwResetBase       =   0xFFFFFFFF;
}





/************************************************************************
 *
 *  Function    :   
 *
 *  Abstract    :   
 *
 ************************************************************************/
BOOL
CPlx9052Rdk::HostTestPlxChip(
    void
    )
{

    BOOL    bRetVal(TRUE);
    U8          j;
    U16         RegOffset;
    U32         TestData[] = {0xa5a5a5a5, 0x5a5a5a5a, 0xffffffff, 0x12345678};
    RETURN_CODE rc; 

    struct
    {
        U16   first;
        U16   last;
    } PCI9030_Registers[] =  {	{       PCI9050_VENDOR_ID,		PCI9050_INT_LINE},
							    {		PCI9050_RANGE_SPACE0,	PCI9050_EEPROM_CTRL}};

    if(!IsTestSupported(HOST_PLX_CHIP_TEST))
        return FALSE;

    for (j=0; j<2; j++)
    {
        for (RegOffset=PCI9030_Registers[j].first; RegOffset<=PCI9030_Registers[j].last; RegOffset+=4)
        {
            if (j == 0)             /* Configuration Registers */
            {
                PlxPciConfigRegisterRead(pBsp->device.BusNumber, pBsp->device.SlotNumber, 
                                     RegOffset, &rc);
                if (rc != ApiSuccess)
                {
                    LogBuffer.Format("Host PLX Chip Test: Error reading Config Register 0x%03x", RegOffset);
                    LogWrite(LogBuffer);
                    bRetVal = TRUE;
                }
            }
            else
            {
                PlxRegisterRead(hPlx, RegOffset, &rc);
                if (rc != ApiSuccess)
                {
                    LogBuffer.Format("Host PLX Chip Test: Error reading Local Register 0x%03x", RegOffset);
                    LogWrite(LogBuffer);
                    bRetVal = TRUE;
                }
            }
        }
    }
    return  bRetVal;
}

