/*******************************************************************************
 * Copyright (c) 2000 PLX Technology, Inc.
 *
 * PLX Technology Inc. licenses this software under specific terms and
 * conditions.  Use of any of the software or derviatives thereof in any
 * product without a PLX Technology chip is strictly prohibited.
 *
 * PLX Technology, Inc. provides this software AS IS, WITHOUT ANY WARRANTY,
 * EXPRESS OR IMPLIED, INCLUDING, WITHOUT LIMITATION, ANY WARRANTY OF
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  PLX makes no guarantee
 * or representations regarding the use of, or the results of the use of,
 * the software and documentation in terms of correctness, accuracy,
 * reliability, currentness, or otherwise; and you rely on the software,
 * documentation and results solely at your own risk.
 *
 * IN NO EVENT SHALL PLX BE LIABLE FOR ANY LOSS OF USE, LOSS OF BUSINESS,
 * LOSS OF PROFITS, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES
 * OF ANY KIND.  IN NO EVENT SHALL PLX'S TOTAL LIABILITY EXCEED THE SUM
 * PAID TO PLX FOR THE PRODUCT LICENSED HEREUNDER.
 *
 ******************************************************************************/

/**********************************************************************
 *                                                                    *
 * Module Name:                                                       *
 *                                                                    *
 *     DownLoad.cpp                                                   *
 *                                                                    *
 * Abstract:                                                          *
 *		This module implements the functionality needed to download   *
 *		an Elf image into a RAM locaiton on the Board.				  *
 * Revision History:                                                  *
 *                                                                    *
 *	   08-03-01 : Created                                             *
 *                                                                    *
 *********************************************************************/

#include "StdAfx.h"
#include "DownLoad.h"
#include "ManfGUI.h"
#include "PlxProtocol.h"
#include "Elf.h"
#include "Reg9054.h"



/**************************************************************************
* Function   : byteswap
* Description: Reverse the order of a string of bytes.
**************************************************************************/
void
byteswap(
    char *p,        // Pointer to source/destination string
    int   n         // Number of bytes in string
    )
{
    int i;          // Index into string
    char c;         // Temp holding place during 2-byte swap


    for (n--, i=0; i < n; i++, n--)
    {
        c = p[i];
        p[i] = p[n];
        p[n] = c;
    }
}




CElfLoader::CElfLoader(
	HANDLE	hPlxDev,
	BSP*	bsp
	)
	:	hPlx(hPlxDev),
		pBsp(bsp)
{
}





/************************************************
* Function: FileRead
*
* Abstract: Reads a file into a buffer
************************************************/
U32 
CElfLoader::FileRead(
	const char *pFileName,
	U8         *pBuffer,
	U32         MaxSize
	)
{
    U32   BytesRead;
    FILE *fpFile;


    if ((fpFile = fopen(pFileName, "rb")) == NULL)
        return 0;

    BytesRead =
        fread(
            pBuffer,
            1,
            MaxSize,
            fpFile
            );

    fclose(
        fpFile
        );

    return BytesRead;
}




/*****************************************************************************************
* Function   : OnButtonDownload
*
* Description: Gets the download options and initiates the download
*
*****************************************************************************************/
BOOL 
CElfLoader::DownloadElfImage(
	U32		loadAddr
	) 
{
    U8             *pFileBuffer;
    U8             *pCbinBuffer;
    U8             *pBinBuffer;
    U8             *pBufferDownload;
    U32             BufferSize;
    U32             Offset;
	U32				RamEntryPoint;
	BOOL			bRet(FALSE);
	CString			szFileName;
	CFile			iFile;
    DWORD			dwFileSize(0);


    Offset = 0;

    switch(pBsp->device.DeviceId)
    {
        case PLX_9054RDK_860_DEVICE_ID:
            uPlxChipType = 0x9054;
            szFileName   = "MT_9054-860.Elf";
            break;

        case PLX_CPCI9054RDK_860_DEVICE_ID:
            uPlxChipType = 0x9054;
            szFileName   = "MT_9054-860.Elf";
            break;

        case PLX_9080RDK_401B_DEVICE_ID:
            uPlxChipType = 0x9080;
            szFileName   = "MT_9080-860.Elf";
            break;

        case PLX_IOP480RDK_DEVICE_ID:
            uPlxChipType = 0x480;
            szFileName	 = "MT_Iop480.Elf";
            break;

        case PLX_9056RDK_860_DEVICE_ID:
            uPlxChipType = 0x9056;
            szFileName   = "MT_9x56-860.Elf";
            break;

        case PLX_9656RDK_860_DEVICE_ID:
            uPlxChipType = 0x9656;
            szFileName	 = "MT_9x56-860.Elf";
            break;

        default:		
            return FALSE;
    }

    pFileBuffer     = NULL;
    pCbinBuffer     = NULL;
    pBinBuffer      = NULL;
    pBufferDownload = NULL;

	if (!iFile.Open(
			szFileName,
			CFile::modeRead
			))
	{
		szFileName = "Unable to Open file : " + szFileName;
		bRet       = FALSE;
		AfxMessageBox(
            szFileName,
            MB_OK
            );

		goto Download_Complete;
	}

	dwFileSize = iFile.GetLength();

	iFile.Close();


    if (dwFileSize == 0)
    {
        AfxMessageBox(
			"ERROR: Unable to open file.",
			MB_OK | MB_ICONSTOP
			);
        goto Download_Complete;
    }

    pFileBuffer = (U8*)malloc(dwFileSize);
    if (pFileBuffer == NULL)
    {
        AfxMessageBox(
            "ERROR: Unable to allocate memory for File buffer (%dkb)",
            MB_OK | MB_ICONSTOP   
            );
        goto Download_Complete;
    }

    if (FileRead(
			szFileName,
			pFileBuffer,
			dwFileSize) != dwFileSize)
    {
        AfxMessageBox(
			"ERROR: Unable to read file.",
			MB_OK | MB_ICONSTOP   
			);
        goto Download_Complete;
    }

    /* Convert the image to the PLX CBin format */
    if (ConvertToCbin(
			pFileBuffer,
			dwFileSize,
			&pBufferDownload,
			&BufferSize,
			&RamEntryPoint
			) == FALSE)
    {
			free(pFileBuffer);
			AfxMessageBox(
				"ERROR: Unable to convert input file to necessary format.",
				MB_OK | MB_ICONSTOP   
				);
			goto Download_Complete;	
    }

    // Release File Buffer - no longer needed
    free(pFileBuffer);

    
    // Now download data to the device
    if (DownloadToIop(
            pBufferDownload,
            BufferSize,
            Offset,
            RamEntryPoint,
            1
            ) == FALSE)
    {
		AfxMessageBox(
			"ERROR: Unable to download file to the Board",
			MB_OK | MB_ICONSTOP   
			);
    }

	bRet = TRUE;

Download_Complete:
    if (pCbinBuffer != NULL)
        free(pCbinBuffer);
    if (pBinBuffer != NULL)
        free(pBinBuffer);
    if (pBufferDownload != NULL)
        free(pBufferDownload);

	return bRet;
}



 
/******************************************************************************
 *
 * Function:    ConvertToCbin (...)
 *
 * Description: 
 *
 *****************************************************************************/
BOOL 
CElfLoader::ConvertToCbin(
	U8   *pBufIn,
	U32   Size,
	U8  **pCbinBuffer,
	U32  *pCbinSize,
	U32  *RamEntryPoint
	)
{
	U32	ReturnValue;


    if (pBufIn == NULL)
    {
        AfxMessageBox(
			"ERROR: Input buffer is empty",
			MB_OK | MB_ICONSTOP   
			);
        return FALSE;
    }

	ReturnValue =
        ElfToCBin(
            pBufIn,
			Size,
			pCbinBuffer,
			pCbinSize,
			RamEntryPoint
            );

    if (ReturnValue == 0)
    {			
        AfxMessageBox(
			"ERROR: ELF to Binary conversion failed."
            "  File may not be a supported ELF format.",
			MB_OK | MB_ICONSTOP   
			);
        return FALSE;
    }
	else if (ReturnValue == 2)
	{
		AfxMessageBox(
			"This is not an executable object file.",
			MB_OK | MB_ICONSTOP   
			);
		return FALSE;
	}

    return TRUE;
}




/******************************************************************************
 *
 * Function:    DownLoadToIop (...)
 *
 * Description: 
 *
 *****************************************************************************/
BOOL 
CElfLoader::DownloadToIop(
	U8          *pBuffer,
	U32         BufferSize,
	U32         DownloadAddr,
	U32         RamEntryPoint,
	BOOL		CpuIsBigEndian
	)
{
    U16      EndianReg;
    U32      DestAddr;
    U32      Plx_Mailbox5;
    U32      Plx_Mailbox6;
    U32      Plx_Mailbox7;
    U32      OldEndian;
	S32		 timeStart;
    BOOL     bRet    =   TRUE;
    RETURN_CODE rc;



/////////////////////////////////////////    
    timeStart = time(&timeStart);
/////////////////////////////////////////

    if (pBuffer == NULL)
        return FALSE;

    if (CpuIsBigEndian)
		DestAddr = EndianSwap32(((U32*)pBuffer)[0]);
    else
        DestAddr = ((U32*)pBuffer)[0];

    switch (uPlxChipType)
    {
        case 0x9080:
        case 0x9054:
        case 0x9056:
        case 0x9656:
            Plx_Mailbox5   = 0x54;
            Plx_Mailbox6   = 0x58;
            Plx_Mailbox7   = 0x5c;
            EndianReg      = PCI9054_ENDIAN_DESC;   
			CpuIsBigEndian = 1;
            break;
    }


	/* Get IOP ready for the RAM download */
	if (PrepareDownloadIopRamApp() == FALSE)
	{
		AfxMessageBox(
			"ERROR: Unable to execute PCI download protocol.",
			MB_OK | MB_ICONSTOP   
			);
		return FALSE;
	}


    OldEndian =
        PlxRegisterRead(
            hPlx,
            EndianReg,
            &rc
            );

    PlxRegisterWrite(
        hPlx,
        EndianReg,
        OldEndian | (1 <<2) | (1<<5)
        );

	/* Download the data to RAM using direct slave */
	if (RamDownload(
            pBuffer,
			BufferSize,
			&DownloadAddr,
			CpuIsBigEndian
			) == FALSE)
	{
        PlxRegisterWrite(
            hPlx,
            EndianReg,
            OldEndian 
            );

		AfxMessageBox(
			"ERROR: PCI data download failed",
			MB_OK | MB_ICONSTOP   
			);

        bRet = FALSE;
	}

    PlxRegisterWrite(
        hPlx,
        EndianReg,
        OldEndian 
        );

    Sleep(300);

    if (StartIopRamApp(
            RamEntryPoint
            ) == FALSE)
	{

		AfxMessageBox(
			"ERROR: Unable to start the RAM application",
			MB_OK | MB_ICONSTOP     
			);

        bRet = FALSE;
	}

    return bRet;
}




/******************************************************************************
 *  FUNCTION    : PrepareDownloadIopRamApp();
 *
 *  Description : This function will execute the protocol to prepare the IOP
 *                for a download.
 *
 *  Return      : TRUE   - IOP is ready
 *                FALSE  - Error in executing protocol
 *
 *****************************************************************************/
BOOL
CElfLoader::PrepareDownloadIopRamApp(
	void
	)
{
    U32         ulLoopCounter;
    RETURN_CODE rc;


    if (PlxRegisterMailboxWrite(
            hPlx,
            DOWNLOAD_PROTOCOL_REG1,
            IOP_PREPARE_FOR_DWLD
            ) != ApiSuccess)
    {
        return FALSE;
    }

    if (!ResetIop(FALSE))
        return FALSE;

    ulLoopCounter = 40;
    do
    {
        Sleep(200);

        if (PlxRegisterMailboxRead(
                hPlx,
                DOWNLOAD_PROTOCOL_REG1,
                &rc) == IOP_READY)
        {
            return TRUE;
        }
    }
    while (ulLoopCounter--);

    return FALSE;
}






/******************************************************************************
 *
 * Function:    RamDownLoad (...)
 *
 * Description: 
 *
 *****************************************************************************/
BOOL 
CElfLoader::RamDownload(
    U8		*pCbinBuf,
    U32		CbinSize,
    U32		*DownloadAddr,
    BOOL	BigEndian
    )

{
	U8  *pMarker;
	U8	*pMaxBlock;
    U32  blockOffset;
    U32  blockSize;
    U32  blockCount;
	U32  maxBlockSize;


    /* check input arguments */
    if (pCbinBuf == NULL)
        return FALSE;

    pMarker			= pCbinBuf;
    blockCount		= 0;
	maxBlockSize    = 0;

    do
    {
        if (BigEndian)
        {
            blockOffset = EndianSwap32(((U32*)pMarker)[0]);
            blockSize   = EndianSwap32(((U32*)pMarker)[1]);
        }
        else
        {
            blockOffset = ((U32*)pMarker)[0];
            blockSize   = ((U32*)pMarker)[1];
        }

        if (blockOffset != 0 && blockSize != 0)
        {
            pMarker += CBIN_SIZE_HEADER;

            blockCount++;

            /* record the maximum block size */
            if (maxBlockSize < blockSize)
			{
                maxBlockSize = blockSize;
			}
            
            /* increment to the next block which must be on a U32 boundary */
            pMarker += blockSize;
            while ((U32)pMarker & 0x3)
                pMarker++;
        }
    }
    while ((blockOffset != 0x0) || (blockSize != 0x0));

	while ((U32)maxBlockSize & 0x3)
        maxBlockSize++;

    pMaxBlock = (U8*)malloc(maxBlockSize);
    if (pMaxBlock == NULL)
        return FALSE;

    pMarker = pCbinBuf;

    while (blockCount--)
    {
        if (BigEndian)
        {
            blockOffset = EndianSwap32(((U32*)pMarker)[0]);
            blockSize   = EndianSwap32(((U32*)pMarker)[1]);
        }
        else
        {
            blockOffset = ((U32*)pMarker)[0];
            blockSize   = ((U32*)pMarker)[1];
        }

        pMarker += CBIN_SIZE_HEADER;

        CopyMemory(
            pMaxBlock,
            pMarker,
            blockSize
            );

		if (PlxBusIopWrite(
                hPlx, 
				IopSpace0,
				blockOffset,
				TRUE,
				(U32*)pMaxBlock,
				blockSize,
				BitSize8
                ) != ApiSuccess)
		{
			AfxMessageBox(
				"ERROR: PCI data download failed",
				MB_OK | MB_ICONSTOP
				);
			return FALSE;
		}

        /* increment to the next block which must be on a U32 boundary */
        pMarker += blockSize;
        while ((U32)pMarker & 0x3)
            pMarker++;     
    }

    free (pMaxBlock);

    return TRUE;
}




/******************************************************************************
 *  FUNCTION    : StartIopRamApp
 *
 *  Description : This function execute the protocol to signal the IOP
 *                to begin execution of downloaded RAM image.
 *
 *  Return      : TRUE   - IOP should be executing RAM image
 *                FALSE  - Error in executing protocol
 *
 *****************************************************************************/
BOOL 
CElfLoader::StartIopRamApp(
    U32 RamEntryPoint
	)
{
    if (PlxRegisterMailboxWrite(
            hPlx,
            DOWNLOAD_PROTOCOL_REG2,
            RamEntryPoint
            ) != ApiSuccess)
    {
        return FALSE;
    }

    if (PlxRegisterMailboxWrite(
            hPlx,
            DOWNLOAD_PROTOCOL_REG1,
            IOP_START_APP
            ) != ApiSuccess)
    {
        return FALSE;
    }

    return TRUE;
}



/******************************************************************************
* Function   : ElfToCbin
* Description: Converts a Elf image to a PLX CBin format
******************************************************************************/
U32 
CElfLoader::ElfToCBin(
	U8   *pBufIn,
	U32   BufferSize,
	U8  **pCbin,
	U32  *pCbinSize,
	U32  *RamEntryPoint
	)
{

	Elf32_Ehdr		*ehdr;
    Elf32_Phdr		*phdr;
	Elf32_Addr	    addr;
    BOOL            bigEndian;
	BOOL            Machine_32bit;
    U8             *pMarker;
	U32             dataSize;
	U32             i;
	U32             value32bit;
    U32 		    bytes;


	U32	objFileType;

	objFileType  =  OBJ_FILE_TYPE_EXECUTABLE;
	pMarker = pBufIn;

    ehdr = (Elf32_Ehdr *) pBufIn;

	pMarker += sizeof(Elf32_Ehdr);

    if (ehdr->e_ident[0] != ELFMAG0 ||
		ehdr->e_ident[1] != ELFMAG1 ||
		ehdr->e_ident[2] != ELFMAG2 ||
		ehdr->e_ident[3] != ELFMAG3) 
	{
		return FALSE;  //invalid ELF format
	}

	if(ehdr->e_ident[5] == ELFDATA2MSB)
		bigEndian = TRUE;
	else if(ehdr->e_ident[5] == ELFDATA2LSB)
		bigEndian = FALSE;
	else
		return FALSE;  //invalid data encoding


	if(ehdr->e_ident[4] == ELFCLASS32)
		Machine_32bit = TRUE;
	else if(ehdr->e_ident[4] == ELFCLASS64)
		Machine_32bit = FALSE;
	else
		return FALSE; //invalid machine type


	if(bigEndian)
	{
		BYTESWAP(ehdr->e_type);
		BYTESWAP(ehdr->e_machine);
		BYTESWAP(ehdr->e_entry);
		BYTESWAP(ehdr->e_phoff);
		BYTESWAP(ehdr->e_shoff);
		BYTESWAP(ehdr->e_flags);
		BYTESWAP(ehdr->e_ehsize);
		BYTESWAP(ehdr->e_phentsize);
		BYTESWAP(ehdr->e_phnum);	
		BYTESWAP(ehdr->e_shentsize);
		BYTESWAP(ehdr->e_shnum);
		BYTESWAP(ehdr->e_shstrndx);
	}

    *RamEntryPoint = ehdr->e_entry;
		
    if (ehdr->e_type != ET_EXEC) 
	{
		//if it is not a executable file, Transfer entire buffer to local.
		objFileType = OBJ_FILE_TYPE_UNKNOWN;
		return 2;  //Non executable file
	}

    if (ehdr->e_phnum == 0)  
	{
		//this indicates that no program header table
		//so that this is not an executable file
		objFileType = OBJ_FILE_TYPE_UNKNOWN;
		return 2;  //Non executable file
	}

    if (ehdr->e_phentsize != sizeof(Elf32_Phdr)) 
	{
		//invalid program header size;
		return FALSE;
	}


	dataSize = 0;

    for (i = 0; i < ehdr->e_phnum; i++) 
	{
		phdr		= (Elf32_Phdr *) pMarker;
		value32bit	= EndianSwap32(phdr-> p_type);

		if (value32bit == PT_LOAD) 
		{
			if(bigEndian)
			{
				 BYTESWAP(phdr->p_type);
				 BYTESWAP(phdr->p_offset);
				 BYTESWAP(phdr->p_vaddr);
				 BYTESWAP(phdr->p_paddr);
				 BYTESWAP(phdr->p_filesz);
				 BYTESWAP(phdr->p_memsz);
				 BYTESWAP(phdr->p_flags);
				 BYTESWAP(phdr->p_align);
			}

			if (phdr->p_memsz > phdr->p_filesz)
			{
				dataSize += phdr->p_memsz;
			}
			else
			{
				dataSize += phdr->p_filesz;
			}

		}
		pMarker += sizeof(Elf32_Phdr);
	}

//compose the cbin file

	U8				*pElfDataBuffer;
	U8				*pSectionMarker;

	*pCbin = (U8*)malloc(dataSize + CBIN_SIZE_HEADER * ehdr->e_phnum + CBIN_SIZE_TAIL);

	pSectionMarker = *pCbin;
        
	pMarker = pBufIn + ehdr->e_phoff;

    for (i = 0; i < ehdr->e_phnum; i++) 
	{
		phdr		= (Elf32_Phdr *) pMarker;

		if(phdr -> p_type == PT_LOAD) 
		{
			pElfDataBuffer = pBufIn + phdr->p_offset;

			addr = (phdr->p_vaddr != 0 && phdr->p_paddr == 0)
			? phdr->p_vaddr
			: phdr->p_paddr;

			bytes = phdr->p_filesz;
		
			// Get image download address and size
			((U32*)pSectionMarker)[0] = EndianSwap32(addr);
			((U32*)pSectionMarker)[1] = EndianSwap32(bytes);

			pSectionMarker += CBIN_SIZE_HEADER;

			// Copy raw data to CBin
			memcpy(pSectionMarker, pElfDataBuffer, bytes);
			pSectionMarker += bytes;

			if(phdr->p_memsz > phdr->p_filesz)
			{
				memset((void*)pSectionMarker, 0,  phdr->p_memsz - phdr->p_filesz);
			}

			pSectionMarker += phdr->p_memsz - phdr->p_filesz;
		}

		pMarker += sizeof(Elf32_Phdr);

	}

	/* now append 8 bytes of 0s to signal the end of buffer */
	((U32*)pSectionMarker)[0] = 0x0;
	((U32*)pSectionMarker)[1] = 0x0;

	pSectionMarker += CBIN_SIZE_TAIL;

	*pCbinSize = (pSectionMarker-*pCbin);

	while ((pSectionMarker -  *pCbin) & 3)
	{
		/* must add 0s to align to quadword */
		pSectionMarker[0] = 0x0;
		pSectionMarker++;
		*pCbinSize = (pSectionMarker-*pCbin);
	}


	return TRUE;
}


/******************************************************************************
* Function   : ResetIop
* Description: Issue a reset command to the IOP
*******************************************************************************/
BOOL
CElfLoader::ResetIop(
	BOOL	KeepCpuInReset
	)
{
    if (KeepCpuInReset)
    {
        CpuStateReset(
            TRUE
            );

        if (uPlxChipType != 0x480)
        {
            return TRUE;
        }
    }

    PlxPciBoardReset(
        hPlx
        );

    if (KeepCpuInReset == FALSE)
    {
        CpuStateReset(
            FALSE
            );
    }

    return TRUE;
}




/************************************************
* Function: 
*
* Abstract:
************************************************/
void 
CElfLoader::CpuStateReset(
    BOOL   reset
    )
{
    U32 Value;


    switch (uPlxChipType)
    {
        case 0x9080:
            /* If RDK is a 401B, then CPU can be put in reset */
            if ((pBsp->device.DeviceId == 0x0401) &&
			    (pBsp->device.VendorId == 0x10B5))
            {
                if (reset)
                    Value = 0x1;
                else
                    Value = 0x0;

                PlxBusIopWrite(
                    hPlx,
                    IopSpace0,
                    RESET_401B_ADDR,
                    TRUE,
                    &Value,
                    1,
                    BitSize8
                    );
            }
            break;

        case 0x9054:
		case 0x9056:
		case 0x9656:
        default:
            // CPU Reset not supported
            break;
    }
}
