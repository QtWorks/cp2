#include "Bsp9X56.h"






/************************************CPlx9056RdkLite**************************/


/************************************************************************
 *  Function    :   BuildTestVector   (virtual function)
 *
 *  Abstract    :   This function will set the 32-bit mask that defines 
 *                  the test that are support for the particular RDK
 ************************************************************************/
void
CPlx9056RdkLite::BuildTestVector(
    void
    )
{
    CPlx9054Lite::BuildTestVector();
}




/************************************************************************
 *  Function    :   CPlx9056RdkLite
 *
 *  Abstract    :   class constructor. This function will call the base 
 *                  class constructor, set the logFile name and add 
 *                  the specific test that are supported by the derieved 
 *                  class.
 ************************************************************************/
CPlx9056RdkLite::CPlx9056RdkLite(
    HANDLE          pPlx,
    DEVICE_LOCATION dev,
    CString         szFile
    )
    :   CPlx9054Lite(pPlx,dev,szFile)
{
    LogFileName =   "MT_9056Lite.log";    
    BuildTestVector();
}





/************************************************************************
 *  Function    :   InitBspDefault (virtual function)
 *
 *  Abstract    :   This function sets the Rdk memory map, which is 
 *                  defined by default.
 ************************************************************************/
void
CPlx9056RdkLite::InitBspDefault(
    void
    )
{
    pBsp->PlxChipType       =   0x9056;
    pBsp->PlxChipBase       =   0x30000000;
    pBsp->Ram0Base          =   0x00000000;
    pBsp->Ram0Size          =   0x00020000;
    pBsp->Ram1Base          =   0xFFFFFFFF;
    pBsp->Ram1Size          =   0X00000000;
    pBsp->Ram2Base          =   0xFFFFFFFF;
    pBsp->Ram2Size          =   0x00000000;
    pBsp->Flash0Base        =   0xFFFFFFFF;
    pBsp->Flash0Size        =   0x00000000;
    pBsp->Flash0Type        =   0;
    pBsp->Flash1Base        =   0xFFFFFFFF;
    pBsp->Flash1Size        =   0x00000000;
    pBsp->Flash1Type        =   0;
    pBsp->InterruptBase     =   0xFFFFFFFF;
    pBsp->SwResetBase       =   0xFFFFFFFF;
}





/************************************CPlx9656RdkLite**************************/


/************************************************************************
 *  Function    :   BuildTestVector   (virtual function)
 *
 *  Abstract    :   This function will set the 32-bit mask that defines 
 *                  the test that are support for the particular RDK
 ************************************************************************/
void
CPlx9656RdkLite::BuildTestVector(
    void
    )
{
    CPlx9054Lite::BuildTestVector();
}




/************************************************************************
 *  Function    :   CPlx9656RdkLite
 *
 *  Abstract    :   class constructor. This function will call the base 
 *                  class constructor, set the logFile name and add 
 *                  the specific test that are supported by the derieved 
 *                  class.
 ************************************************************************/
CPlx9656RdkLite::CPlx9656RdkLite(
    HANDLE          pPlx,
    DEVICE_LOCATION dev,
    CString         szFile
    )
    :   CPlx9054Lite(pPlx,dev,szFile)
{
    BuildTestVector();
    LogFileName =   "MT_9656Lite.log";
}





/************************************************************************
 *  Function    :   InitBspDefault (virtual function)
 *
 *  Abstract    :   This function sets the Rdk memory map, which is 
 *                  defined by default.
 ************************************************************************/
void
CPlx9656RdkLite::InitBspDefault(
    void
    )
{
    pBsp->PlxChipType       =   0x9656;
    pBsp->PlxChipBase       =   0x30000000;
    pBsp->Ram0Base          =   0x00000000;
    pBsp->Ram0Size          =   0x00020000;
    pBsp->Ram1Base          =   0xFFFFFFFF;
    pBsp->Ram1Size          =   0X00000000;
    pBsp->Ram2Base          =   0xFFFFFFFF;
    pBsp->Ram2Size          =   0x00000000;
    pBsp->Flash0Base        =   0xFFFFFFFF;
    pBsp->Flash0Size        =   0x00000000;
    pBsp->Flash0Type        =   0;
    pBsp->Flash1Base        =   0xFFFFFFFF;
    pBsp->Flash1Size        =   0x00000000;
    pBsp->Flash1Type        =   0;
    pBsp->InterruptBase     =   0xFFFFFFFF;
    pBsp->SwResetBase       =   0xFFFFFFFF;
}







/************************************CPlx9056Rdk860**************************/

/************************************************************************
 *  Function    :   BuildTestVector     (virtual function)
 *
 *  Abstract    :   This function will set the 32-bit mask that defines 
 *                  the test that are support for the particular RDK
 ************************************************************************/
void
CPlx9056Rdk860::BuildTestVector(
    void
    )
{
    CPlx9054Rdk860::BuildTestVector();
    uTestVector |=  HOST_FLASH_1_TEST;
               
}




/************************************************************************
 *  Function    :   CPlx9056Rdk860      (class constructor)      
 *
 *  Abstract    :   This function will call the base class constructor, 
 *                  set the logFile name and add the specific test that 
 *                  are supported by the derieved class.
 ************************************************************************/
CPlx9056Rdk860::CPlx9056Rdk860(
    HANDLE          pPlx,
    DEVICE_LOCATION dev,
    CString         szFile
    )
    :   CPlx9054Rdk860(pPlx,dev,szFile)
{
    BuildTestVector();
    LogFileName =   "MT_9656Rdk860.log";

}






/************************************************************************
 *  Function    :   InitBspDefault      (virtual function)
 *  Abstract    :   This function sets the Rdk memory map, which is 
 *                  defined by default.
 ************************************************************************/
void
CPlx9056Rdk860::InitBspDefault(
    void
    )
{
    pBsp->PlxChipType       =   0x9056;
    pBsp->PlxChipBase       =   0x30000000;
    pBsp->Ram0Base          =   0x00000000;
    pBsp->Ram0Size          =   0x04000000;
    pBsp->Ram1Base          =   0x20000000;
    pBsp->Ram1Size          =   0X00080000;
    pBsp->Ram2Base          =   0xFFFFFFFF;
    pBsp->Ram2Size          =   0x00000000;
    pBsp->Flash0Base        =   0xFFF00000;
    pBsp->Flash0Size        =   0x00080000;
    pBsp->Flash0Type        =   0;
    pBsp->Flash1Base        =   0xF0000000;
    pBsp->Flash1Size        =   0x00800000;
    pBsp->Flash1Type        =   0;
    pBsp->InterruptBase     =   0xFFFFFFFF;
    pBsp->SwResetBase       =   0xFFFFFFFF;
}




/************************************************************************
 *  Function    :   HostTestFlash1      (virtual function)
 *  Abstract    :   The function will implement the logic needed to test 
 *                  the secondary flash on this RDK
 ************************************************************************/
BOOL
CPlx9056Rdk860::HostTestFlash1(
    void
    )
{
    if(!IsTestSupported(HOST_FLASH_1_TEST))
        return FALSE;
    
    return  FALSE;

}




/************************************CPlx9656Rdk860**************************/

 
/************************************************************************
 *  Function    :   BuildTestVector     (virtual function)
 *
 *  Abstract    :   This function will set the 32-bit mask that defines 
 *                  the test that are support for the particular RDK
 ************************************************************************/
void
CPlx9656Rdk860::BuildTestVector(
    void
    )
{

    CPlx9054Rdk860::BuildTestVector();
    uTestVector |=  HOST_FLASH_1_TEST;
               

}




/************************************************************************
 *  Function    :   CPlx9656Rdk860      (class constructor)
 *
 *  Abstract    :   class constructor. This function will call the base 
 *                  class constructor, set the logFile name and add 
 *                  the specific test that are supported by the derieved 
 *                  class.
 ************************************************************************/
CPlx9656Rdk860::CPlx9656Rdk860(
    HANDLE          pPlx,
    DEVICE_LOCATION dev,
    CString         szFile
    )
    :   CPlx9054Rdk860(pPlx,dev,szFile)
{
    BuildTestVector();
    LogFileName =   "MT_9656Rdk860.log";
}





/************************************************************************
 *  Function    :   InitBspDefault      (virtual function)
 *
 *  Abstract    :   This function sets the Rdk memory map, which is 
 *                  defined by default.
 ************************************************************************/
void
CPlx9656Rdk860::InitBspDefault(
    void
    )
{
    pBsp->PlxChipType       =   0x9656;
    pBsp->PlxChipBase       =   0x30000000;
    pBsp->Ram0Base          =   0x00000000;
    pBsp->Ram0Size          =   0x04000000;
    pBsp->Ram1Base          =   0x20000000;
    pBsp->Ram1Size          =   0X00080000;
    pBsp->Ram2Base          =   0xFFFFFFFF;
    pBsp->Ram2Size          =   0x00000000;
    pBsp->Flash0Base        =   0xFFF00000;
    pBsp->Flash0Size        =   0x00080000;
    pBsp->Flash0Type        =   0;
    pBsp->Flash1Base        =   0xF0000000;
    pBsp->Flash1Size        =   0x00800000;
    pBsp->Flash1Type        =   0;
    pBsp->InterruptBase     =   0xFFFFFFFF;
    pBsp->SwResetBase       =   0xFFFFFFFF;
}




/************************************************************************
 *  Function    :   HostTestFlash1      (virtual function)
 *
 *  Abstract    :   The function will implement the logic needed to test 
 *                  the secondary flash on this RDK
 ************************************************************************/
BOOL
CPlx9656Rdk860::HostTestFlash1(
    void
    )
{
    if(!IsTestSupported(HOST_FLASH_1_TEST))
        return FALSE;
    
    return  FALSE;

}






