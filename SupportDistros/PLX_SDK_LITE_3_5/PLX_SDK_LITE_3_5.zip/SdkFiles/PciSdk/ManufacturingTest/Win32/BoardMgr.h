#ifndef __BOARD_MGR_H__
#define __BOARD_MGR_H__



/*
 **************************************************************************************************
 *  BEGIN : Class CBoardMgr
 *  
 *  This class manages the different boards that are plugged into the system.  The board manager
 *  is used to access the specific CBsp object for the different boards.  It uses an internal 
 *  CMAP type to track the different CBsp objects that have been allocated.
 *
 *  When a CBoardMgr is created the initBSPMgr () function must be called before the object can
 *  be used.  The different CBsp objects can be retrieved by the GetBsp () function.  This functions
 *  returns a CBsp base class pointer, which points to a derieved type.  All derieved types can
 *  be treated as a CBsp type.  The CBsp pointer is allocate on the heap by the CBoardMgr Object.
 *  The GetBsp functions returns this pointer, but the CBoardMgr does not give up ownership of the 
 *  object.  Once the CBoardMgr is destroyed, it deallocates the memory it allocates on the heap 
 *  during its lifetime, therefore the CBsp pointer retrieved through GetBsp must not be deleted by
 *  any clients of CBoardMgr.
 *
 **************************************************************************************************
 */

#include "Def.h"
#include "Plx.h"
#include "PlxInit.h"
#include "BspConfig.h"


class CBoardMgr
{
private:
    
    DEVICE_LIST     CurrentDeviceList[MAX_PCI_DEV];
    S8              DevIndex;
    HANDLE          PlxHandle;
    CMapStringToPtr BspMap;

public:
    
    CBoardMgr(
        void
        );


    ~CBoardMgr(
        void
        );

    BOOL
    InitBspMgr(
        void
        );


    CBsp* 
    GetBsp(
        CString     szBoardSelected = ""
        );

    DEVICE_LIST*
    GetDevList()
    {
        return CurrentDeviceList;
    }

    S8
    GetDevIndex()
    {
        return DevIndex;
    }

};

#endif