/*******************************************************************************
 * Copyright (c) 2000 PLX Technology, Inc.
 *
 * PLX Technology Inc. licenses this software under specific terms and
 * conditions.  Use of any of the software or derviatives thereof in any
 * product without a PLX Technology chip is strictly prohibited.
 *
 * PLX Technology, Inc. provides this software AS IS, WITHOUT ANY WARRANTY,
 * EXPRESS OR IMPLIED, INCLUDING, WITHOUT LIMITATION, ANY WARRANTY OF
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  PLX makes no guarantee
 * or representations regarding the use of, or the results of the use of,
 * the software and documentation in terms of correctness, accuracy,
 * reliability, currentness, or otherwise; and you rely on the software,
 * documentation and results solely at your own risk.
 *
 * IN NO EVENT SHALL PLX BE LIABLE FOR ANY LOSS OF USE, LOSS OF BUSINESS,
 * LOSS OF PROFITS, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES
 * OF ANY KIND.  IN NO EVENT SHALL PLX'S TOTAL LIABILITY EXCEED THE SUM
 * PAID TO PLX FOR THE PRODUCT LICENSED HEREUNDER.
 *
 ******************************************************************************/

/**********************************************************************
 *                                                                    *
 * Module Name:                                                       *
 *                                                                    *
 *     PlxInitialize.c                                                *
 *                                                                    *
 * Abstract:                                                          *
 *                                                                    *
 *     This module supports detection of mulitple PLX devices.        *
 *                                                                    *
 * Revision History:                                                  *
 *     02-15-00 : Modified to support PCI9030                         *
 *     07-22-99 : Modified to support IOP480                          *
 *     09-04-98 : Modified to support 9054 hot swap                   *
 *     07-09-98 : Support for SDK 2.0                                 *
 *     10-07-97 : Modified to support IOP programs                    *
 *     09-25-97 : Created                                             *
 *                                                                    *
 *********************************************************************/


#include "StdAfx.h"
#include "PlxInit.h"




/*****************************************************
 *
 * Function   :  SelectDevices
 *
 * Description:  
 *
 ****************************************************/
U32
FindDevice(
    HANDLE      *drvHandle,
    DEVICE_LIST *DeviceList
    )
{
    U32             TotalDeviceNum;
    U32             DeviceNum;
    RETURN_CODE     rc;
    DEVICE_LOCATION device;


    TotalDeviceNum = FIND_AMOUNT_MATCHED;

    device.BusNumber  = (U8)-1;
    device.SlotNumber = (U8)-1;
    device.VendorId   = (U16)-1;
    device.DeviceId   = (U16)-1;
    device.SerialNumber[0] = '\0';

    rc =
        PlxPciDeviceFind(
            &device,
            &TotalDeviceNum
            );

    if (rc != ApiSuccess)
    {
        printf("Not working\n");
        return 0;
    }

    for (DeviceNum = 0; DeviceNum < TotalDeviceNum; DeviceNum++)
    {
        device.BusNumber  = (U8)-1;
        device.SlotNumber = (U8)-1;
        device.VendorId   = (U16)-1;
        device.DeviceId   = (U16)-1;
        device.SerialNumber[0] = '\0';

        PlxPciDeviceFind(
            &device,
            &DeviceNum
            );

        sprintf(
            DeviceList[DeviceNum].DevStr, 
            "DeviceID  %.4x  VendorID  %.4x   Slot %.2x  Bus %.2x", 
            device.DeviceId, device.VendorId,
            device.SlotNumber, device.BusNumber
            );

        DeviceList[DeviceNum].device.DeviceId   = device.DeviceId;
        DeviceList[DeviceNum].device.VendorId   = device.VendorId;
        DeviceList[DeviceNum].device.SlotNumber = device.SlotNumber;
        DeviceList[DeviceNum].device.BusNumber  = device.BusNumber;
    }

    return DeviceNum;       
}




/*****************************************************
*   Procedure:  SelectDevices
*   Abstract :  Asks the user which PLX device to use
*   Arguments:  drvHandle, handle of the PCI device
*               device,    pointer to device selected
*   Returns  :  Total Plx devices found
*               -1,  if user cancelled the selection
******************************************************/
char
SelectDevice(
    HANDLE      *drvHandle,
    DEVICE_LIST *DeviceList
    )
{
    U8           bus;
    U8           slot;
    U8           deviceNum;
    U32          regData;
    RETURN_CODE  rc;


    deviceNum = 0;

    // Search for PLX Devices
    for (bus=0; bus <=3; bus++)
    {
        for (slot=0; slot<MAX_PCI_DEV; slot++)
        {
            // Read first pci config register
            regData =
                PlxPciConfigRegisterRead(
                    bus,
                    slot,
                    0,
                    &rc
                    );

            if (regData != 0xFFFFFFFF && IsPlxDevice(regData))
            {
                sprintf(
                    DeviceList[deviceNum].DevStr,
                    "DeviceID  %.4x  VendorID  %.4x   Slot %.2x  Bus %.2x",
                    (regData >> 16), (regData & 0xFFFF), slot, bus
                    );

                DeviceList[deviceNum].device.DeviceId   = (U16)(regData >> 16);
                DeviceList[deviceNum].device.VendorId   = (U16)regData;
                DeviceList[deviceNum].device.SlotNumber = slot;
                DeviceList[deviceNum].device.BusNumber  = bus;
                deviceNum++;
            }
        }
    }

    return deviceNum;
}




/**************************************************************
*   Procedure:  IsPlxDevice
*   Abstract :  Adds a device to a list of devices
*   Arguments:  DevVenId, the Device & Vendor ID register value
*   Returns  :  TRUE, if PLX device
*               FALSE, if not a recognized PLX device
***************************************************************/
BOOLEAN
IsPlxDevice(
    U32 DevVenId
    )
{
    if ((U16)DevVenId != PLX_VENDOR_ID)
        return FALSE;

    switch ((U16)(DevVenId >> 16))
    {
        case PLX_9080_DEVICE_ID:
        case PLX_9080RDK_401B_DEVICE_ID:
        case PLX_9080RDK_860_DEVICE_ID:
        case PLX_9080RDK_960_DEVICE_ID:
        case PLX_9054RDK_860_DEVICE_ID:
        case PLX_CPCI9054RDK_860_DEVICE_ID:
        case PLX_IOP480RDK_DEVICE_ID:
        case PLX_9054RDK_LITE_DEVICE_ID:
        case PLX_9030RDK_LITE_DEVICE_ID:
        case PLX_CPCI9030RDK_LITE_DEVICE_ID:
        case PLX_9050RDK_LITE_DEVICE_ID:
        case PLX_9052RDK_LITE_DEVICE_ID:
        case PLX_9056RDK_LITE_DEVICE_ID:
        case PLX_9056RDK_860_DEVICE_ID:
        case PLX_9656RDK_LITE_DEVICE_ID:
        case PLX_9656RDK_860_DEVICE_ID:
            return TRUE;
    }

    return FALSE;
}
