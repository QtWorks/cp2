#include "Bsp9054.h"



/************************************CPlx9054Rdk860**************************/



/************************************************************************
 *
 *  Function    :   
 *
 *  Abstract    :   
 *
 ************************************************************************/
void
CPlx9054Rdk860::BuildTestVector(
    void
    )
{
    uTestVector =   HOST_RAM_0_TEST     |
                    HOST_RAM_1_TEST     |
                    HOST_FLASH_0_TEST   |
                    HOST_VPD_TEST       |
                    HOST_PLX_CHIP_TEST  |
                    LOCAL_RAM_0_TEST    |
                    LOCAL_RAM_1_TEST    |
                    LOCAL_FLASH_0_TEST  |
                    LOCAL_HOT_SWAP_TEST |
                    LOCAL_PLX_CHIP_TEST |
                    HOST_LED_TEST       |
                    LOCAL_LED_TEST;
}




/************************************************************************
 *
 *  Function    :   
 *
 *  Abstract    :   
 *
 ************************************************************************/
CPlx9054Rdk860::CPlx9054Rdk860(
        HANDLE          pPlx,
        DEVICE_LOCATION dev,
        CString         szFile
    )
    :   CBsp(pPlx,dev,szFile)
{


    LogFileName =   "MT_9054Rdk860.log";    

    BuildTestVector();
    RegisterOffset.VpdId   = PCI9054_VPD_CAP_ID;
    RegisterOffset.VpdData = PCI9054_VPD_DATA;
    RegisterOffset.PmCapId = PCI9054_PM_CAP_ID;
    RegisterOffset.PmCsr   = PCI9054_PM_CSR;
    RegisterOffset.HotSwap = PCI9054_HS_CAP_ID;
    //Use space0 for SDRAM, space1 for FLASH.
    RegisterOffset.Space0Remap = PCI9054_SPACE0_REMAP;
    RegisterOffset.Space0Range = PCI9054_SPACE0_RANGE;
    RegisterOffset.Space1Remap = PCI9054_SPACE1_REMAP;
    RegisterOffset.Space1Range = PCI9054_SPACE1_RANGE;
    RegisterOffset.DramBusDesc = PCI9054_SPACE1_DESC;

}





/************************************************************************
 *
 *  Function    :   
 *
 *  Abstract    :   
 *
 ************************************************************************/
void
CPlx9054Rdk860::InitBspDefault(
    void
    )
{
    pBsp->PlxChipType   = 0x9054;
    pBsp->PlxChipBase   = 0x30000000;
    pBsp->Ram0Base      = 0x00000000;
    pBsp->Ram0Size      = 0x02000000;
    pBsp->Ram1Base      = 0xFFFFFFFF;
    pBsp->Ram1Size      = 0X00000000;
    pBsp->Ram2Base      = 0xFFFFFFFF;
    pBsp->Ram2Size      = 0x00000000;
    pBsp->Flash0Base    = 0xFFF00000;
    pBsp->Flash0Size    = 0x00080000;
    pBsp->Flash0Type    = 0;
    pBsp->Flash1Base    = 0xFFFFFFFF;
    pBsp->Flash1Size    = 0x00000000;
    pBsp->Flash1Type    = 0;
    pBsp->InterruptBase = 0xFFFFFFFF;
    pBsp->SwResetBase   = 0xFFFFFFFF;
}







/************************************CPlx9054Lite**************************/


/************************************************************************
 *
 *  Function    :   
 *
 *  Abstract    :   
 *
 ************************************************************************/
void
CPlx9054Lite::BuildTestVector(
    void
    )
{
    uTestVector = HOST_RAM_0_TEST     |
                  HOST_VPD_TEST       |
                  HOST_PLX_CHIP_TEST;
}




/************************************************************************
 *
 *  Function    :   
 *
 *  Abstract    :   
 *
 ************************************************************************/
CPlx9054Lite::CPlx9054Lite(
    HANDLE          pPlx,
    DEVICE_LOCATION dev,
    CString         szFile
    )
    :   CBsp(pPlx,dev,szFile)
{
    LogFileName =   "MT_9054Lite.log";    
 
    BuildTestVector();
    RegisterOffset.VpdId   = PCI9054_VPD_CAP_ID;
    RegisterOffset.VpdData = PCI9054_VPD_DATA;
    RegisterOffset.PmCapId = PCI9054_PM_CAP_ID;
    RegisterOffset.PmCsr   = PCI9054_PM_CSR;
    RegisterOffset.HotSwap = PCI9054_HS_CAP_ID;
    //Use space0 for SDRAM, space1 for FLASH.
    RegisterOffset.Space0Remap = PCI9054_SPACE0_REMAP;
    RegisterOffset.Space0Range = PCI9054_SPACE0_RANGE;
    RegisterOffset.Space1Remap = PCI9054_SPACE1_REMAP;
    RegisterOffset.Space1Range = PCI9054_SPACE1_RANGE;
    RegisterOffset.DramBusDesc = PCI9054_SPACE1_DESC;

}






/************************************************************************
 *
 *  Function    :   
 *
 *  Abstract    :   
 *
 ************************************************************************/
void
CPlx9054Lite::InitBspDefault(
    void
    )
{
    pBsp->PlxChipType       =   0x9054;
    pBsp->PlxChipBase       =   0x30000000;
    pBsp->Ram0Base          =   0x00000000;
    pBsp->Ram0Size          =   0x02000000;
    pBsp->Ram1Base          =   0x20000000;
    pBsp->Ram1Size          =   0X00020000;
    pBsp->Ram2Base          =   0xFFFFFFFF;
    pBsp->Ram2Size          =   0x00000000;
    pBsp->Flash0Base        =   0xFFFFFFFF;
    pBsp->Flash0Size        =   0x00000000;
    pBsp->Flash0Type        =   0;
    pBsp->Flash1Base        =   0xFFFFFFFF;
    pBsp->Flash1Size        =   0x00000000;
    pBsp->Flash1Type        =   0;
    pBsp->InterruptBase     =   0xFFFFFFFF;
    pBsp->SwResetBase       =   0xFFFFFFFF;
}






/************************************CPlxCPci9054Rdk860**************************/


/************************************************************************
 *
 *  Function    :   
 *
 *  Abstract    :   
 *
 ************************************************************************/
void
CPlxCPci9054Rdk860::BuildTestVector(
    void
    )
{
    uTestVector =   HOST_RAM_0_TEST     |
                    HOST_RAM_1_TEST     |
                    HOST_FLASH_0_TEST   |
                    HOST_VPD_TEST       |
                    HOST_PLX_CHIP_TEST  |
                    LOCAL_RAM_0_TEST    |
                    LOCAL_FLASH_0_TEST  |
                    LOCAL_VPD_TEST      |
                    LOCAL_PLX_CHIP_TEST |
                    HOST_LED_TEST       |
                    LOCAL_LED_TEST;
}




/************************************************************************
 *
 *  Function    :   
 *
 *  Abstract    :   
 *
 ************************************************************************/
CPlxCPci9054Rdk860::CPlxCPci9054Rdk860(
    HANDLE          pPlx,
    DEVICE_LOCATION dev,
    CString         szFile
    )
    :   CBsp(pPlx,dev,szFile)
{
    BuildTestVector();
    LogFileName =   "MT_CPCI9054Rdk860.log";
    RegisterOffset.VpdId   = PCI9054_VPD_CAP_ID;
    RegisterOffset.VpdData = PCI9054_VPD_DATA;
    RegisterOffset.PmCapId = PCI9054_PM_CAP_ID;
    RegisterOffset.PmCsr   = PCI9054_PM_CSR;
    RegisterOffset.HotSwap = PCI9054_HS_CAP_ID;
    //Use space0 for SDRAM, space1 for FLASH.
    RegisterOffset.Space0Remap = PCI9054_SPACE0_REMAP;
    RegisterOffset.Space0Range = PCI9054_SPACE0_RANGE;
    RegisterOffset.Space1Remap = PCI9054_SPACE1_REMAP;
    RegisterOffset.Space1Range = PCI9054_SPACE1_RANGE;
    RegisterOffset.DramBusDesc = PCI9054_SPACE1_DESC;
}





/************************************************************************
 *
 *  Function    :   
 *
 *  Abstract    :   
 *
 ************************************************************************/
void
CPlxCPci9054Rdk860::InitBspDefault(
    void
    )
{
    pBsp->PlxChipType       =   0x9054;
    pBsp->PlxChipBase       =   0x30000000;
    pBsp->Ram0Base          =   0x00000000;
    pBsp->Ram0Size          =   0x02000000;
    pBsp->Ram1Base          =   0x20000000;
    pBsp->Ram1Size          =   0X00080000;
    pBsp->Ram2Base          =   0xFFFFFFFF;
    pBsp->Ram2Size          =   0x00000000;
    pBsp->Flash0Base        =   0xFFF00000;
    pBsp->Flash0Size        =   0x00080000;
    pBsp->Flash0Type        =   0;
    pBsp->Flash1Base        =   0xFFFFFFFF;
    pBsp->Flash1Size        =   0x00000000;
    pBsp->Flash1Type        =   0;
    pBsp->InterruptBase     =   0xFFFFFFFF;
    pBsp->SwResetBase       =   0xFFFFFFFF;
}

