// ManTest.cpp : implementation file
//

#include "stdafx.h"
#include "ManfGUI.h"
#include "ManTest.h"
#include "Bsp.h"
#include "BspConfig.h"
#include "Download.h"
#include "..\Iop\ManfComm.h"
#include "Support.h"
#include "BoardMgr.h"
#include "Log.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//////////////////

//extern HANDLE PlxHandle;

///////////////////////////////////////////////////////////
// CManTest dialog
extern BOOL    bAbort;

extern CManfGUIApp theApp;
extern CBoardMgr   *pMgr;




UINT
StartTest(
    LPVOID  pParm
    )
{
    return ((CManTest*)pParm)->OnStartThreadFunc(0);

}






CManTest::CManTest(
    CBsp*           ptheBsp,
    S8              DevIx,
    DEVICE_LIST*    dsList,
    CWnd* pParent /*=NULL*/
    )
	:   CDialog(CManTest::IDD, pParent),
        pDeviceList(dsList),
        DeviceIndex(DevIx)
{
	//{{AFX_DATA_INIT(CManTest)
	szCurrBsp = _T("");
	//}}AFX_DATA_INIT
    pTestThread =   0;
    pBsp        =   ptheBsp;
    hThread     =   0;
    uLoopCnt    =   1;
    
    

    hMutex      =   CreateMutex(
                        NULL,
                        FALSE,
                        NULL
                        );
  
}


void CManTest::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CManTest)
	DDX_CBString(pDX, IDC_COMBO_BSP, szCurrBsp);
	DDV_MaxChars(pDX, szCurrBsp, 75);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CManTest, CDialog)
	//{{AFX_MSG_MAP(CManTest)
	ON_BN_CLICKED(ID_CONFIG, OnConfig)
	ON_CBN_SELCHANGE(IDC_COMBO_BSP, OnEditchangeComboBsp)
	ON_BN_CLICKED(IDC_ENABLEALL_BUTTON, OnEnableallButton)
	ON_BN_CLICKED(IDC_CLEARALL_BUTTON, OnClearallButton)
	ON_BN_CLICKED(IDC_ENABLEPCI_BUTTON, OnEnablepciButton)
	ON_BN_CLICKED(IDC_ENABLEIOP_BUTTON, OnEnableiopButton)
	ON_BN_CLICKED(IDC_STARTEST_BUTTON, OnStartestButton)
	ON_BN_CLICKED(IDC_STOP_BUTTON, OnStopButton)
	ON_BN_CLICKED(IDC_PLXCHIP_CHECK, OnPlxchipCheck)
	ON_BN_CLICKED(IDC_LED_CHECK, OnLedCheck)
	ON_BN_CLICKED(IDC_FLASH0_CHECK, OnFlash0Check)
	ON_BN_CLICKED(IDC_FLASH1_CHECK, OnFlash1Check)
	ON_BN_CLICKED(IDC_HOTSWAP_CHECK, OnHotswapCheck)
	ON_BN_CLICKED(IDC_IOPFLASH0_CHECK, OnIopflash0Check)
	ON_BN_CLICKED(IDC_IOPFLASH1_CHECK, OnIopflash1Check)
	ON_BN_CLICKED(IDC_IOPHOTSWAP_CHECK, OnIophotswapCheck)
	ON_BN_CLICKED(IDC_IOPLED_CHECK, OnIopledCheck)
	ON_BN_CLICKED(IDC_IOPPLXCHIP_CHECK, OnIopplxchipCheck)
	ON_BN_CLICKED(IDC_IOPRAM0_CHECK, OnIopram0Check)
	ON_BN_CLICKED(IDC_IOPRAM1_CHECK, OnIopram1Check)
	ON_BN_CLICKED(IDC_IOPRAM2_CHECK, OnIopram2Check)
	ON_BN_CLICKED(IDC_IOPUART_CHECK, OnIopuartCheck)
	ON_BN_CLICKED(IDC_IOPVPD_CHECK, OnIopvpdCheck)
	ON_BN_CLICKED(IDC_LOG_CHECK, OnLogCheck)
	ON_BN_CLICKED(IDC_RAM0_CHECK, OnRam0Check)
	ON_BN_CLICKED(IDC_RAM1_CHECK, OnRam1Check)
	ON_BN_CLICKED(IDC_RAM2_CHECK, OnRam2Check)
	ON_BN_CLICKED(IDC_UART_CHECK, OnUartCheck)
	ON_BN_CLICKED(IDC_VPD_CHECK, OnVpdCheck)

    ON_BN_CLICKED(IDC_PLXCHIP_BUTTON, OnPlxchipCheck)
	ON_BN_CLICKED(IDC_LED_BUTTON, OnLedCheck)
	ON_BN_CLICKED(IDC_FLASH0_BUTTON, OnFlash0Check)
	ON_BN_CLICKED(IDC_FLASH1_BUTTON, OnFlash1Check)
	ON_BN_CLICKED(IDC_HOTSWAP_BUTTON, OnHotswapCheck)
	ON_BN_CLICKED(IDC_IOPFLASH0_BUTTON, OnIopflash0Check)
	ON_BN_CLICKED(IDC_IOPFLASH1_BUTTON, OnIopflash1Check)
	ON_BN_CLICKED(IDC_IOPHOTSWAP_BUTTON, OnIophotswapCheck)
	ON_BN_CLICKED(IDC_IOPLED_BUTTON, OnIopledCheck)
	ON_BN_CLICKED(IDC_IOPPLXCHIP_BUTTON, OnIopplxchipCheck)
	ON_BN_CLICKED(IDC_IOPRAM0_BUTTON, OnIopram0Check)
	ON_BN_CLICKED(IDC_IOPRAM1_BUTTON, OnIopram1Check)
	ON_BN_CLICKED(IDC_IOPRAM2_BUTTON, OnIopram2Check)
	ON_BN_CLICKED(IDC_IOPUART_BUTTON, OnIopuartCheck)
	ON_BN_CLICKED(IDC_IOPVPD_BUTTON, OnIopvpdCheck)
	ON_BN_CLICKED(IDC_LOG_CHECK, OnLogCheck)
	ON_BN_CLICKED(IDC_RAM0_BUTTON, OnRam0Check)
	ON_BN_CLICKED(IDC_RAM1_BUTTON, OnRam1Check)
	ON_BN_CLICKED(IDC_RAM2_BUTTON, OnRam2Check)
	ON_BN_CLICKED(IDC_UART_BUTTON, OnUartCheck)
	ON_BN_CLICKED(IDC_VPD_BUTTON, OnVpdCheck)
    
    ON_EN_CHANGE(IDC_LOOPCOUNT_EDIT,OnLoopChange)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CManTest message handlers

void CManTest::OnConfig() 
{
	// TODO: Add your control notification handler code here
    CBspConfig  dlg(pBsp);
    dlg.DoModal();
    InitDlgFromBsp();

}




void 
CManTest::OnEditchangeComboBsp(
    void
    ) 
{

    DWORD   dwExitCode;
    
    //if the thread handle is not null, check if the thread is still
    //active, if still active just return...else close the precious
    //handle
    if(pTestThread)
    {
        GetExitCodeThread(
            hThread,
            &dwExitCode
            );
        if(dwExitCode   ==  STILL_ACTIVE)
            OnStopButton();

    }


    CComboBox * pCombo = (CComboBox *)GetDlgItem(IDC_COMBO_BSP);
    CString     szBspName;
    pCombo->GetLBText(pCombo->GetCurSel(), szBspName); 

    CBsp    *pOldBsp    =   pBsp;

    if(!(pBsp =  pMgr->GetBsp(szBspName)))
    {
        pBsp    =   pOldBsp;
    }
    else
    {
        InitDlgFromBsp();
        ((CButton*)GetDlgItem(IDC_LOG_CHECK))->SetCheck(pBsp->ucLogTest);
    }
    SetText();	
}





    
BOOL 
CManTest::OnInitDialog(
    void
    ) 
{
    S8      i;
    CString szLoop;
    CString szBoardSelected;


    CDialog::OnInitDialog();

	gLog.Init((CEdit *)(GetDlgItem(IDC_LOG)));

    szLoop.Format("%d", uLoopCnt=1);
    ((CEdit*)GetDlgItem(IDC_LOOPCOUNT_EDIT))->SetWindowText(szLoop);

    CComboBox * pCombo = (CComboBox *)GetDlgItem(IDC_COMBO_BSP);

    if (DeviceIndex == 0)
    {
        szBoardSelected = "No supported PCI devices found.";

        return TRUE;
    }
    else
    {
        for (i=0; i<DeviceIndex; i++)
        {
            szBoardSelected = pDeviceList[i].DevStr;
            pCombo->AddString(szBoardSelected);
        }
        szCurrBsp   = pDeviceList[0].DevStr;
		UpdateData(FALSE);
    }

    InitDlgFromBsp();
	return TRUE;  
}



void
CManTest::SetText(
    void
    )
{
    SetDlgItemText(IDC_IOPUART_BUTTON,"Not Tested.");
    SetDlgItemText(IDC_IOPPLXCHIP_BUTTON,"Not Tested.");
    SetDlgItemText(IDC_IOPLED_BUTTON,"Not Tested.");
    SetDlgItemText(IDC_IOPVPD_BUTTON,"Not Tested.");
    SetDlgItemText(IDC_IOPHOTSWAP_BUTTON,"Not Tested.");
    SetDlgItemText(IDC_IOPFLASH1_BUTTON,"Not Tested.");
    SetDlgItemText(IDC_IOPFLASH0_BUTTON,"Not Tested.");
    SetDlgItemText(IDC_IOPRAM2_BUTTON,"Not Tested.");
    SetDlgItemText(IDC_IOPRAM1_BUTTON,"Not Tested.");
    SetDlgItemText(IDC_IOPRAM0_BUTTON,"Not Tested.");


    SetDlgItemText(IDC_UART_BUTTON,"Not Tested.");
    SetDlgItemText(IDC_PLXCHIP_BUTTON,"Not Tested.");
    SetDlgItemText(IDC_LED_BUTTON,"Not Tested.");
    SetDlgItemText(IDC_VPD_BUTTON,"Not Tested.");
    SetDlgItemText(IDC_HOTSWAP_BUTTON,"Not Tested.");
    SetDlgItemText(IDC_FLASH1_BUTTON,"Not Tested.");
    SetDlgItemText(IDC_FLASH0_BUTTON,"Not Tested.");
    SetDlgItemText(IDC_RAM2_BUTTON,"Not Tested.");
    SetDlgItemText(IDC_RAM1_BUTTON,"Not Tested.");
    SetDlgItemText(IDC_RAM0_BUTTON,"Not Tested.");


    SetDlgItemText(IDC_DETAILS_BUTTON,"Plx Manufacturing Test.");

}




void
CManTest::InitDlgFromBsp(
    void
    )
{

    U32                 *uTestVec;
    const BSP* const    ibsp    =   pBsp->GetBsp();

    BOOL                bHostTest(FALSE);
    BOOL                bLocalTest(FALSE);
    
    uTestVec    =   pBsp->GetTestVec();

    //begin local def
    if(*uTestVec & LOCAL_UART_TEST) // || *uTestVec & LOCAL_ISA_TEST)
    {
        bLocalTest  =   TRUE;
        ((CButton*)GetDlgItem(IDC_IOPUART_CHECK))->SetCheck(TRUE);
    }
    else
    {
        ((CButton*)GetDlgItem(IDC_IOPUART_CHECK))->SetCheck(FALSE);
    }

    if(*uTestVec & LOCAL_PLX_CHIP_TEST)
    {
        bLocalTest  =   TRUE;
        ((CButton*)GetDlgItem(IDC_IOPPLXCHIP_CHECK))->SetCheck(TRUE);
    }
    else
    {
        ((CButton*)GetDlgItem(IDC_IOPPLXCHIP_CHECK))->SetCheck(FALSE);
    }

    if(*uTestVec & LOCAL_LED_TEST)
    {
        bLocalTest  =   TRUE;
        ((CButton*)GetDlgItem(IDC_IOPLED_CHECK))->SetCheck(TRUE);
    }
    else
    {
        ((CButton*)GetDlgItem(IDC_IOPLED_CHECK))->SetCheck(FALSE);
    }
    if(*uTestVec & LOCAL_VPD_TEST)
    {
        bLocalTest  =   TRUE;
        ((CButton*)GetDlgItem(IDC_IOPVPD_CHECK))->SetCheck(TRUE);
    }
    else
    {
        ((CButton*)GetDlgItem(IDC_IOPVPD_CHECK))->SetCheck(FALSE);
    }
    if(*uTestVec & LOCAL_HOT_SWAP_TEST)
    {
        bLocalTest  =   TRUE;
        ((CButton*)GetDlgItem(IDC_IOPHOTSWAP_CHECK))->SetCheck(TRUE);
    }
    else
    {
        ((CButton*)GetDlgItem(IDC_IOPHOTSWAP_CHECK))->SetCheck(FALSE);
    }
    if(*uTestVec & LOCAL_FLASH_1_TEST)
    {
        bLocalTest  =   TRUE;
        ((CButton*)GetDlgItem(IDC_IOPFLASH1_CHECK))->SetCheck(TRUE);
    }
    else
    {
        ((CButton*)GetDlgItem(IDC_IOPFLASH1_CHECK))->SetCheck(FALSE);

    }
    if(*uTestVec & LOCAL_FLASH_0_TEST)
    {
        bLocalTest  =   TRUE;
        ((CButton*)GetDlgItem(IDC_IOPFLASH0_CHECK))->SetCheck(TRUE);

    }
    else
    {
        ((CButton*)GetDlgItem(IDC_IOPFLASH0_CHECK))->SetCheck(FALSE);

    }
    if(*uTestVec & LOCAL_RAM_2_TEST)
    {
        bLocalTest  =   TRUE;
        ((CButton*)GetDlgItem(IDC_IOPRAM2_CHECK))->SetCheck(TRUE);
    }
    else
    {
        ((CButton*)GetDlgItem(IDC_IOPRAM2_CHECK))->SetCheck(FALSE);

    }
    if(*uTestVec & LOCAL_RAM_1_TEST)
    {
        bLocalTest  =   TRUE;
        ((CButton*)GetDlgItem(IDC_IOPRAM1_CHECK))->SetCheck(TRUE);
    }
    else
    {
        ((CButton*)GetDlgItem(IDC_IOPRAM1_CHECK))->SetCheck(FALSE);

    }
    if(*uTestVec & LOCAL_RAM_0_TEST)
    {
        bLocalTest  =   TRUE;
        ((CButton*)GetDlgItem(IDC_IOPRAM0_CHECK))->SetCheck(TRUE);
    }
    else
    {
        ((CButton*)GetDlgItem(IDC_IOPRAM0_CHECK))->SetCheck(FALSE);

    }

    
    //begin Host def
    if(*uTestVec & HOST_PLX_CHIP_TEST)
    {
        bHostTest  =   TRUE;
        ((CButton*)GetDlgItem(IDC_PLXCHIP_CHECK))->SetCheck(TRUE);
    }
    else
    {
        ((CButton*)GetDlgItem(IDC_PLXCHIP_CHECK))->SetCheck(FALSE);

    }
    if(*uTestVec & HOST_LED_TEST)
    {
        bHostTest  =   TRUE;
        ((CButton*)GetDlgItem(IDC_LED_CHECK))->SetCheck(TRUE);
    }
    else
    {
        ((CButton*)GetDlgItem(IDC_LED_CHECK))->SetCheck(FALSE);

    }
    if(*uTestVec & HOST_UART_TEST || *uTestVec & HOST_ISA_TEST)
    {
        bHostTest  =   TRUE;
        ((CButton*)GetDlgItem(IDC_UART_CHECK))->SetCheck(TRUE);
    }
    else
    {
        ((CButton*)GetDlgItem(IDC_UART_CHECK))->SetCheck(FALSE);

    }
    if(*uTestVec & HOST_VPD_TEST)
    {
        bHostTest  =   TRUE;
        ((CButton*)GetDlgItem(IDC_VPD_CHECK))->SetCheck(TRUE);
    }
    else
    {
        ((CButton*)GetDlgItem(IDC_VPD_CHECK))->SetCheck(FALSE);

    }
    if(*uTestVec & HOST_HOT_SWAP_TEST)
    {
        bHostTest  =   TRUE;
        ((CButton*)GetDlgItem(IDC_HOTSWAP_CHECK))->SetCheck(TRUE);
    }
    else
    {
        ((CButton*)GetDlgItem(IDC_HOTSWAP_CHECK))->SetCheck(FALSE);

    }
    if(*uTestVec & HOST_FLASH_1_TEST)
    {
        bHostTest  =   TRUE;
        ((CButton*)GetDlgItem(IDC_FLASH1_CHECK))->SetCheck(TRUE);
    }
    else
    {
        ((CButton*)GetDlgItem(IDC_FLASH1_CHECK))->SetCheck(FALSE);

    }
    if(*uTestVec & HOST_FLASH_0_TEST)
    {
        bHostTest  =   TRUE;
        ((CButton*)GetDlgItem(IDC_FLASH0_CHECK))->SetCheck(TRUE);
    }
    else
    {
        ((CButton*)GetDlgItem(IDC_FLASH0_CHECK))->SetCheck(FALSE);

    }
    if(*uTestVec & HOST_RAM_2_TEST)
    {
        bHostTest  =   TRUE;
        ((CButton*)GetDlgItem(IDC_RAM2_CHECK))->SetCheck(TRUE);
    }
    else
    {
        ((CButton*)GetDlgItem(IDC_RAM2_CHECK))->SetCheck(FALSE);

    }
    if(*uTestVec & HOST_RAM_1_TEST)
    {
        bHostTest  =   TRUE;
        ((CButton*)GetDlgItem(IDC_RAM1_CHECK))->SetCheck(TRUE);
    }
    else
    {
        ((CButton*)GetDlgItem(IDC_RAM1_CHECK))->SetCheck(FALSE);

    }
    if(*uTestVec & HOST_RAM_0_TEST)
    {
        bHostTest  =   TRUE;
        ((CButton*)GetDlgItem(IDC_RAM0_CHECK))->SetCheck(TRUE);
    }
    else
    {
        ((CButton*)GetDlgItem(IDC_RAM0_CHECK))->SetCheck(FALSE);

    }
  
    CString szLoop;
    szLoop.Format("%d", uLoopCnt);
    ((CEdit*)GetDlgItem(IDC_LOOPCOUNT_EDIT))->SetWindowText(szLoop);


}


void CManTest::OnEnableallButton() 
{
    pBsp->EnableAllTest();
    SetText();
    InitDlgFromBsp();
}

void 
CManTest::OnClearallButton(
    void
    ) 
{
    pBsp->ClearTest();
    SetText();
    InitDlgFromBsp();
}

void CManTest::OnEnablepciButton() 
{
    pBsp->EnableAllPciTest();
    SetText();
    InitDlgFromBsp();
}

void CManTest::OnEnableiopButton() 
{
    pBsp->EnableAllLocalTest();
    InitDlgFromBsp();
    SetText();
}







UINT
CManTest::OnStartThreadFunc(
    LPVOID  pParam
    )
{

    U32         *uTestVec;
    CString     szDisplay;
    CButton     *pDetailsButton;
    U32         Cnt=0;
    
    bAbort      =   FALSE;

    pDetailsButton  =  (CButton*) GetDlgItem(IDC_DETAILS_BUTTON);
    

    CString szText;
    GetDlgItemText(IDC_LOOPCOUNT_EDIT,szText);
    uLoopCnt    =   atoi(szText);
    
	gLog.Clear();
    
    while(Cnt < uLoopCnt)
    {

        SetText();


        szDisplay   =   "Reseting BSP.";
        pDetailsButton->SetWindowText(szDisplay);

      //  PlxPciBoardReset(pBsp->hPlx);
        
        szDisplay.Format("%02d",Cnt+1);
        SetDlgItemText(IDC_CURRENTLOOP_BUTTON,szDisplay);

        uTestVec    =   pBsp->GetTestVec();

        szDisplay.Format("Starting Manufacturing Test: Loop %d",Cnt+1);
        pBsp->LogWrite(szDisplay);
        
        szDisplay   =   "/*----------------------------START------------------------------------*/";
        pBsp->LogWrite(szDisplay);
        szDisplay   =   "Device Id : " + pBsp->szBspLocator;
        pBsp->LogWrite(szDisplay);
  
        //begin Host def
        if(*uTestVec & HOST_PLX_CHIP_TEST)
        {
            CButton * pButton = (CButton *)GetDlgItem(IDC_PLXCHIP_BUTTON);
            szDisplay = "PCI Plx Chip Test";
            pDetailsButton->SetWindowText(szDisplay);
            
            pBsp->LogWrite(szDisplay);
            
            szDisplay = "Testing";
            pButton->SetWindowText(szDisplay);

            if (pBsp->HostTestPlxChip())
                szDisplay = "<Passed>";
            else
                szDisplay = "<Failed>";

            pButton->SetWindowText(szDisplay);
            szDisplay   =   "----> " + szDisplay; 
            pBsp->LogWrite(szDisplay);
            pBsp->LogWrite("\n\r");
        }
        if(*uTestVec & HOST_LED_TEST)
        {
            CButton * pButton = (CButton *)GetDlgItem(IDC_LED_BUTTON);
            szDisplay = "PCI Led Test";
            pDetailsButton->SetWindowText(szDisplay);
            
            pBsp->LogWrite(szDisplay);
            
            szDisplay = "Testing";
            pButton->SetWindowText(szDisplay);

            if (pBsp->HostTestLed())
                szDisplay = "<Passed>";
            else
                szDisplay = "<Failed>";

            pButton->SetWindowText(szDisplay);
            szDisplay   =   "----> " + szDisplay; 
            pBsp->LogWrite(szDisplay);
            pBsp->LogWrite("\n\r");
        }
        if(*uTestVec & HOST_FLASH_0_TEST)
        {
            CButton * pButton = (CButton *)GetDlgItem(IDC_FLASH0_BUTTON);
            szDisplay = "PCI Flash 0 Test";
            pDetailsButton->SetWindowText(szDisplay);

            pBsp->LogWrite(szDisplay);

            szDisplay = "Testing";
            pButton->SetWindowText(szDisplay);

            if (pBsp->HostTestFlash0())
                szDisplay = "<Passed>";
            else
                szDisplay = "<Failed>";

            pButton->SetWindowText(szDisplay);
            szDisplay   =   "----> " + szDisplay; 
            pBsp->LogWrite(szDisplay);
            pBsp->LogWrite("\n\r");
        }
        if(*uTestVec & HOST_FLASH_1_TEST)
        {
            CButton * pButton = (CButton *)GetDlgItem(IDC_FLASH1_BUTTON);
            szDisplay = "PCI Flash 1 Test";
            pDetailsButton->SetWindowText(szDisplay);
            
            pBsp->LogWrite(szDisplay);

            szDisplay = "Testing";
            pButton->SetWindowText(szDisplay);

            if (pBsp->HostTestFlash1())
                szDisplay = "<Passed>";
            else
                szDisplay = "<Failed>";

            Sleep(200);
            pButton->SetWindowText(szDisplay);
            szDisplay   =   "----> " + szDisplay; 
            pBsp->LogWrite(szDisplay);
            pBsp->LogWrite("\n\r");
        }
        if(*uTestVec & HOST_RAM_0_TEST)
        {
            CButton * pButton = (CButton *)GetDlgItem(IDC_RAM0_BUTTON);
            szDisplay = "PCI Ram 0 Test";
            pDetailsButton->SetWindowText(szDisplay);
            
            pBsp->LogWrite(szDisplay);

            szDisplay = "Testing";
            pButton->SetWindowText(szDisplay);
        
            if (pBsp->HostTestRam0())
                szDisplay = "<Passed>";
            else
                szDisplay = "<Failed>";
            pButton->SetWindowText(szDisplay);
            szDisplay   =   "----> " + szDisplay; 
            pBsp->LogWrite(szDisplay);
            pBsp->LogWrite("\n\r");
        }
        if(*uTestVec & HOST_RAM_1_TEST)
        {
            CButton * pButton = (CButton *)GetDlgItem(IDC_RAM1_BUTTON);
            szDisplay = "PCI Ram 1 Test";
            pDetailsButton->SetWindowText(szDisplay);
            
            pBsp->LogWrite(szDisplay);

            szDisplay = "Testing";
            pButton->SetWindowText(szDisplay);

            if (pBsp->HostTestRam1())
                szDisplay = "<Passed>";
            else
                szDisplay = "<Failed>";

            pButton->SetWindowText(szDisplay);
            szDisplay   =   "----> " + szDisplay; 
            pBsp->LogWrite(szDisplay);
            pBsp->LogWrite("\n\r");
        }
        if(0 &&( *uTestVec & HOST_RAM_2_TEST))
        {
            CButton * pButton = (CButton *)GetDlgItem(IDC_RAM2_BUTTON);
            szDisplay = "PCI Ram 2 Test";
            pDetailsButton->SetWindowText(szDisplay);
            
            pBsp->LogWrite(szDisplay);

            szDisplay = "Testing";
            pButton->SetWindowText(szDisplay);

            if (pBsp->HostTestRam2())
                szDisplay = "<Passed>";
            else
                szDisplay = "<Failed>";

            pButton->SetWindowText(szDisplay);
            szDisplay   =   "----> " + szDisplay; 
            pBsp->LogWrite(szDisplay);
            pBsp->LogWrite("\n\r");
        }
        if(*uTestVec & HOST_VPD_TEST)
        {
            CButton * pButton = (CButton *)GetDlgItem(IDC_VPD_BUTTON);
            szDisplay = "PCI VPD Test";
            pDetailsButton->SetWindowText(szDisplay);
            
            pBsp->LogWrite(szDisplay);

            szDisplay = "Testing";
            pButton->SetWindowText(szDisplay);

            if (pBsp->HostTestVpd())
                szDisplay = "<Passed>";
            else
                szDisplay = "<Failed>";

            pButton->SetWindowText(szDisplay);
            szDisplay   =   "----> " + szDisplay; 
            pBsp->LogWrite(szDisplay);
            pBsp->LogWrite("\n\r");
        }
        if(*uTestVec & HOST_UART_TEST)
        {
            CButton * pButton = (CButton *)GetDlgItem(IDC_UART_BUTTON);
            szDisplay = "PCI Uart Test";
            pDetailsButton->SetWindowText(szDisplay);
            
            pBsp->LogWrite(szDisplay);
            
            szDisplay = "Testing";
            pButton->SetWindowText(szDisplay);

            if (pBsp->HostTestUart())
                szDisplay = "<Passed>";
            else
                szDisplay = "<Failed>";

            pButton->SetWindowText(szDisplay);
            szDisplay   =   "----> " + szDisplay; 
            pBsp->LogWrite(szDisplay);
            pBsp->LogWrite("\n\r");
        }
        if(*uTestVec & HOST_ISA_TEST)
        {
            CButton * pButton = (CButton *)GetDlgItem(IDC_UART_BUTTON);
            szDisplay = "PCI ISA Test";
            pDetailsButton->SetWindowText(szDisplay);
            
            pBsp->LogWrite(szDisplay);
            
            szDisplay = "Testing";
            pButton->SetWindowText(szDisplay);

            if (pBsp->HostTestIsa())
                szDisplay = "<Passed>";
            else
                szDisplay = "<Failed>";

            pButton->SetWindowText(szDisplay);
            szDisplay   =   "----> " + szDisplay; 
            pBsp->LogWrite(szDisplay);
            pBsp->LogWrite("\n\r");
        }
        if(*uTestVec & HOST_HOT_SWAP_TEST)
        {
            CButton * pButton = (CButton *)GetDlgItem(IDC_HOTSWAP_BUTTON);
            szDisplay = "PCI Hot Swap Test";
            pDetailsButton->SetWindowText(szDisplay);
            
            pBsp->LogWrite(szDisplay);

            szDisplay = "Testing";
            pButton->SetWindowText(szDisplay);

            if (pBsp->HostTestHotSwap())
                szDisplay = "<Passed>";
            else
                szDisplay = "<Failed>";

            pButton->SetWindowText(szDisplay);
            szDisplay   =   "----> " + szDisplay; 
            pBsp->LogWrite(szDisplay);
            pBsp->LogWrite("\n\r");
        }


        if(*uTestVec & LOCAL_TEST_MASK)
        {
    
            szDisplay   =   "Downloading Ram Application.";
            pDetailsButton->SetWindowText(szDisplay);

            
            
            CElfLoader	elLoader(
				            pBsp->hPlx,
				            pBsp->pBsp
				            );

	        if (!elLoader.DownloadElfImage(0))
            {
                szDisplay   =   "Download Local Tests to RAM failed";
                pDetailsButton->SetWindowText(szDisplay);
                return 0;
            }



            //begin local def
            if(*uTestVec & LOCAL_PLX_CHIP_TEST)
            {
                CButton * pButton = (CButton *)GetDlgItem(IDC_IOPPLXCHIP_BUTTON);
                szDisplay   =   "Local PLX Chip Test";
                pDetailsButton->SetWindowText(szDisplay);
            
                pBsp->LogWrite(szDisplay);

                szDisplay = "Testing";
                pButton->SetWindowText(szDisplay);

                if(pBsp->LocalTestPlxChip())
                {   
                    szDisplay   =   "<Passed>";
                }
                else
                {
                    szDisplay   =   "<Failed>";
                }
                pButton->SetWindowText(szDisplay);

                szDisplay   =   "----> " + szDisplay; 
                pBsp->LogWrite(szDisplay);
                pBsp->LogWrite("\n\r");
            }
            if(*uTestVec & LOCAL_LED_TEST)
            {
                CButton * pButton = (CButton *)GetDlgItem(IDC_IOPLED_BUTTON);
                szDisplay = "Local Led Test";
                pDetailsButton->SetWindowText(szDisplay);

                pBsp->LogWrite(szDisplay);

                szDisplay = "Testing";
                pButton->SetWindowText(szDisplay);

                if (pBsp->LocalTestLed())
                    szDisplay = "<Passed>";
                else
                    szDisplay = "<Failed>";
                pButton->SetWindowText(szDisplay);

                szDisplay   =   "----> " + szDisplay; 
                pBsp->LogWrite(szDisplay);
                pBsp->LogWrite("\n\r");
            }
            if(*uTestVec & LOCAL_FLASH_0_TEST)
            {
                CButton * pButton = (CButton *)GetDlgItem(IDC_IOPFLASH0_BUTTON);
                szDisplay = "Local Flash 0 Test";
                pDetailsButton->SetWindowText(szDisplay);

                pBsp->LogWrite(szDisplay);

                szDisplay = "Testing";
                pButton->SetWindowText(szDisplay);

                if (pBsp->LocalTestFlash0())
                    szDisplay = "<Passed>";
                else
                    szDisplay = "<Failed>";
                pButton->SetWindowText(szDisplay);


                szDisplay   =   "----> " + szDisplay; 
                pBsp->LogWrite(szDisplay);
                pBsp->LogWrite("\n\r");
            }
            if(*uTestVec & LOCAL_FLASH_1_TEST)
            {
                CButton * pButton = (CButton *)GetDlgItem(IDC_IOPFLASH1_BUTTON);
                szDisplay = "Local Flash 1 Test";
                pDetailsButton->SetWindowText(szDisplay);

                pBsp->LogWrite(szDisplay);

                szDisplay = "Testing";
                pButton->SetWindowText(szDisplay);

                if (pBsp->LocalTestFlash1())
                    szDisplay = "<Passed>";
                else
                    szDisplay = "<Failed>";
                pButton->SetWindowText(szDisplay);
        

                szDisplay   =   "----> " + szDisplay; 
                pBsp->LogWrite(szDisplay);
                pBsp->LogWrite("\n\r");
            }
            if(*uTestVec & LOCAL_RAM_0_TEST)
            {
                CButton * pButton = (CButton *)GetDlgItem(IDC_IOPRAM0_BUTTON);
                szDisplay = "Local Ram 0 Test";
                pDetailsButton->SetWindowText(szDisplay);

                pBsp->LogWrite(szDisplay);

                szDisplay = "Testing";
                pButton->SetWindowText(szDisplay);

                if (pBsp->LocalTestRam0())
                    szDisplay = "<Passed>";
                else
                    szDisplay = "<Failed>";
                pButton->SetWindowText(szDisplay);


                szDisplay   =   "----> " + szDisplay; 
                pBsp->LogWrite(szDisplay);
                pBsp->LogWrite("\n\r");
            }
            if(*uTestVec & LOCAL_RAM_1_TEST)
            {
                CButton * pButton = (CButton *)GetDlgItem(IDC_IOPRAM1_BUTTON);
                szDisplay = "Local Ram 1 Test";
                pDetailsButton->SetWindowText(szDisplay);

                pBsp->LogWrite(szDisplay);

                szDisplay = "Testing";
                pButton->SetWindowText(szDisplay);

                if (pBsp->LocalTestRam1())
                    szDisplay = "<Passed>";
                else
                    szDisplay = "<Failed>";
                pButton->SetWindowText(szDisplay);

                szDisplay   =   "----> " + szDisplay; 
                pBsp->LogWrite(szDisplay);
                pBsp->LogWrite("\n\r");
            }
            if(*uTestVec & LOCAL_RAM_2_TEST)
            {
                CButton * pButton = (CButton *)GetDlgItem(IDC_IOPRAM2_BUTTON);
                szDisplay = "Local Ram 2 Test";
                pDetailsButton->SetWindowText(szDisplay);

                pBsp->LogWrite(szDisplay);

                szDisplay = "Testing";
                pButton->SetWindowText(szDisplay);

                if (pBsp->LocalTestRam0())
                    szDisplay = "<Passed>";
                else
                    szDisplay = "<Failed>";
                pButton->SetWindowText(szDisplay);

                szDisplay   =   "----> " + szDisplay; 
                pBsp->LogWrite(szDisplay);
                pBsp->LogWrite("\n\r");
            }
            if(*uTestVec & LOCAL_VPD_TEST)
            {
                CButton * pButton = (CButton *)GetDlgItem(IDC_IOPVPD_BUTTON);
                szDisplay = "Local VPD Test";
                pDetailsButton->SetWindowText(szDisplay);

                pBsp->LogWrite(szDisplay);

                szDisplay = "Testing";
                pButton->SetWindowText(szDisplay);

                if (pBsp->LocalTestVpd())
                    szDisplay = "<Passed>";
                else
                    szDisplay = "<Failed>";
                pButton->SetWindowText(szDisplay);

                szDisplay   =   "----> " + szDisplay; 
                pBsp->LogWrite(szDisplay);
        
                pBsp->LogWrite("\n\r");
            }
            if(*uTestVec & LOCAL_UART_TEST)
            {
                CButton * pButton = (CButton *)GetDlgItem(IDC_IOPUART_BUTTON);
                szDisplay = "Local Uart Test";
                pDetailsButton->SetWindowText(szDisplay);

                pBsp->LogWrite(szDisplay);

                szDisplay = "Testing";
                pButton->SetWindowText(szDisplay);

                if (pBsp->LocalTestUart())
                    szDisplay = "<Passed>";
                else
                    szDisplay = "<Failed>";
                pButton->SetWindowText(szDisplay);


                szDisplay   =   "----> " + szDisplay; 
                pBsp->LogWrite(szDisplay);
                pBsp->LogWrite("\n\r");
            }
            if(*uTestVec & LOCAL_HOT_SWAP_TEST)
            {
                CButton * pButton = (CButton *)GetDlgItem(IDC_IOPHOTSWAP_BUTTON);
                szDisplay = "Local Hot Swap Test";
                pDetailsButton->SetWindowText(szDisplay);

                pBsp->LogWrite(szDisplay);

                szDisplay = "Testing";
                pButton->SetWindowText(szDisplay);

                if (pBsp->LocalTestHotSwap())
                    szDisplay = "<Passed>";
                else
                    szDisplay = "<Failed>";
                pButton->SetWindowText(szDisplay);

                szDisplay   =   "----> " + szDisplay; 
                pBsp->LogWrite(szDisplay);
                pBsp->LogWrite("\n\r");
            }

        }
        szDisplay   =   "/*---------------------------FINISH-----------------------------------*/\n\r\n\r";
        pBsp->LogWrite(szDisplay);

        Cnt++;
    } 

    pBsp->WriteLogFile();
    pDetailsButton->SetWindowText("Finished Manufacturing Test!\n\r");

 
    return 0;
}





void 
CManTest::OnStartestButton(
    void
    ) 
{
    
    DWORD   dwExitCode;
    
    if(!uLoopCnt) return;

    SetText();
   
    //if the thread handle is not null, check if the thread is still
    //active, if still active just return...else close the precious
    //handle
    if(pTestThread)
    {
        GetExitCodeThread(
            hThread,
            &dwExitCode
            );
        if(dwExitCode   ==  STILL_ACTIVE)
            return;
        else
            CloseHandle(pTestThread);
    }
    
    pTestThread =   AfxBeginThread(
                        StartTest,
                        this,
                        THREAD_PRIORITY_NORMAL,
                        0,
                        CREATE_SUSPENDED
                        );
    hThread     =   pTestThread->m_hThread;
    
    pTestThread->ResumeThread();
    

}

/**************************************************************************************************
 *
 *  Function    :
 *
 *  Abstract    :
 *
 *************************************************************************************************/
void 
CManTest::OnStopButton() 
{


    if(hThread)
    {
        TerminateThread(
            hThread,    
            THREAD_TERMINATE   
            );
        hThread     =   0;
        pTestThread =   0;
    }
    
    Sleep(1);
    SetDlgItemText(IDC_DETAILS_BUTTON,"Plx Manufacturing Test.");
}





/**************************************************************************************************
 *
 *  Function    :
 *
 *  Abstract    :
 *
 *************************************************************************************************/
void 
CManTest::OnOK(
    void
    ) 
{
    if(hThread)
    {
        TerminateThread(
            hThread,    
            THREAD_TERMINATE   
            );
        hThread     =   0;
        pTestThread =   0;
    }
	
	CDialog::OnOK();
}






/**************************************************************************************************
 *
 *  Function    :
 *
 *  Abstract    :
 *
 *************************************************************************************************/
void 
CManTest::OnPlxchipCheck(
    void
    ) 
{
    U32     *pTest  =   pBsp->GetTestVec();
    U32     uMask(HOST_PLX_CHIP_TEST);
	if(!(*pTest & uMask))
    {
        *pTest |=   uMask;
    }
    else
    {
        *pTest &=   ~uMask;
        ((CButton*)GetDlgItem(IDC_PLXCHIP_CHECK))->SetCheck(FALSE);
    }
}







/**************************************************************************************************
 *
 *  Function    :
 *
 *  Abstract    :
 *
 *************************************************************************************************/
void 
CManTest::OnLedCheck(
    void
    ) 
{
    U32     *pTest  =   pBsp->GetTestVec();
    U32     uMask(HOST_LED_TEST);
	if(!(*pTest & uMask))
    {
        *pTest |=   uMask;
    }
    else
    {
        *pTest &=   ~uMask;
        ((CButton*)GetDlgItem(IDC_LED_CHECK))->SetCheck(FALSE);
    }
}








/**************************************************************************************************
 *
 *  Function    :
 *
 *  Abstract    :
 *
 *************************************************************************************************/
void 
CManTest::OnFlash0Check(
    void
    ) 
{
    U32     *pTest  =   pBsp->GetTestVec();
    U32     uMask(HOST_FLASH_0_TEST);
	if(!(*pTest & uMask))
    {
        *pTest |=   uMask;
    }
    else
    {
        *pTest &=   ~uMask;
        ((CButton*)GetDlgItem(IDC_FLASH0_CHECK))->SetCheck(FALSE);

    }
}








/**************************************************************************************************
 *
 *  Function    :
 *
 *  Abstract    :
 *
 *************************************************************************************************/
void 
CManTest::OnFlash1Check(
    void
    ) 
{
    U32     *pTest  =   pBsp->GetTestVec();
    U32     uMask(HOST_FLASH_1_TEST);
	if(!(*pTest & uMask))
    {
        *pTest |=   uMask;
    }
    else
    {
        *pTest &=   ~uMask;
        ((CButton*)GetDlgItem(IDC_FLASH1_CHECK))->SetCheck(FALSE);
    }
}








/**************************************************************************************************
 *
 *  Function    :
 *
 *  Abstract    :
 *
 *************************************************************************************************/
void 
CManTest::OnHotswapCheck(
    void
    ) 
{
    U32     *pTest  =   pBsp->GetTestVec();
    U32     uMask(HOST_HOT_SWAP_TEST);

    //always set the hot swap test to false, not supported from host side
    *pTest &=   ~uMask;

    ((CButton*)GetDlgItem(IDC_HOTSWAP_CHECK))->SetCheck(FALSE);
}







/**************************************************************************************************
 *
 *  Function    :
 *
 *  Abstract    :
 *
 *************************************************************************************************/
void 
CManTest::OnIopflash0Check(
    void
    ) 
{
    U32     *pTest  =   pBsp->GetTestVec();
    U32     uMask(LOCAL_FLASH_0_TEST);
	if(!(*pTest & uMask))
    {
        *pTest |=   uMask;
    }
    else
    {
        *pTest &=   ~uMask;
    }
}





/**************************************************************************************************
 *
 *  Function    :
 *
 *  Abstract    :
 *
 *************************************************************************************************/
void 
CManTest::OnIopflash1Check(
    void
    ) 
{
    U32     *pTest  =   pBsp->GetTestVec();
    U32     uMask(LOCAL_FLASH_1_TEST);
	if(!(*pTest & uMask))
    {
        *pTest |=   uMask;
    }
    else
    {
        *pTest &=   ~uMask;
    }
}





/**************************************************************************************************
 *
 *  Function    :
 *
 *  Abstract    :
 *
 *************************************************************************************************/
void 
CManTest::OnIophotswapCheck(
    void
    ) 
{
    U32     *pTest  =   pBsp->GetTestVec();
    U32     uMask(LOCAL_HOT_SWAP_TEST);
	if(!(*pTest & uMask))
    {
        *pTest |=   uMask;
    }
    else
    {
        *pTest &=   ~uMask;
    }
}






/**************************************************************************************************
 *
 *  Function    :
 *
 *  Abstract    :
 *
 *************************************************************************************************/
void 
CManTest::OnIopledCheck(
    void
    ) 
{
    U32     *pTest  =   pBsp->GetTestVec();
    U32     uMask(LOCAL_LED_TEST);
	if(!(*pTest & uMask))
    {
        *pTest |=   uMask;
    }
    else
    {
        *pTest &=   ~uMask;
    }
}





/**************************************************************************************************
 *
 *  Function    :
 *
 *  Abstract    :
 *
 *************************************************************************************************/
void 
CManTest::OnIopplxchipCheck(
    void
    ) 
{
    U32     *pTest  =   pBsp->GetTestVec();
    U32     uMask(LOCAL_PLX_CHIP_TEST);
	if(!(*pTest & uMask))
    {
        *pTest |=   uMask;
    }
    else
    {
        *pTest &=   ~uMask;
    }
}





/**************************************************************************************************
 *
 *  Function    :
 *
 *  Abstract    :
 *
 *************************************************************************************************/
void 
CManTest::OnIopram0Check(
    void
    ) 
{
    U32     *pTest  =   pBsp->GetTestVec();
    U32     uMask(LOCAL_RAM_0_TEST);
	if(!(*pTest & uMask))
    {
        *pTest |=   uMask;
    }
    else
    {
        *pTest &=   ~uMask;
    }
}





/**************************************************************************************************
 *
 *  Function    :
 *
 *  Abstract    :
 *
 *************************************************************************************************/
void 
CManTest::OnIopram1Check(
    void
    ) 
{
    U32     *pTest  =   pBsp->GetTestVec();
    U32     uMask(LOCAL_RAM_1_TEST);
	if(!(*pTest & uMask))
    {
        *pTest |=   uMask;
    }
    else
    {
        *pTest &=   ~uMask;
    }

}






/**************************************************************************************************
 *
 *  Function    :
 *
 *  Abstract    :
 *
 *************************************************************************************************/
void 
CManTest::OnIopram2Check(
    void
    ) 
{
    U32     *pTest  =   pBsp->GetTestVec();
    U32     uMask(LOCAL_RAM_2_TEST);
	if(!(*pTest & uMask))
    {
        *pTest |=   uMask;
    }
    else
    {
        *pTest &=   ~uMask;
    }

}






/**************************************************************************************************
 *
 *  Function    :
 *
 *  Abstract    :
 *
 *************************************************************************************************/
void 
CManTest::OnIopuartCheck(
    void
    ) 
{
    U32     *pTest  =   pBsp->GetTestVec();
    U32     uMask(LOCAL_UART_TEST);
	if(!(*pTest & uMask))
    {
        *pTest |=   uMask;
    }
    else
    {
        *pTest &=   ~uMask;
    }
}





void 
CManTest::OnIopvpdCheck(
    void
    ) 
{
    U32     *pTest  =   pBsp->GetTestVec();
    U32     uMask(LOCAL_VPD_TEST);
	if(!(*pTest & uMask))
    {
        *pTest |=   uMask;
    }
    else
    {
        *pTest &=   ~uMask;
    }
}

void CManTest::OnLogCheck() 
{
    pBsp->ucLogTest   = (pBsp->ucLogTest&0x01) ^ 0x01;   	
}

void 
CManTest::OnRam0Check(
    void
    ) 
{
    U32     *pTest  =   pBsp->GetTestVec();
    U32     uMask(HOST_RAM_0_TEST);
	if(!(*pTest & uMask))
    {
        *pTest |=   uMask;
    }
    else
    {
        *pTest &=   ~uMask;
        ((CButton*)GetDlgItem(IDC_RAM0_CHECK))->SetCheck(FALSE);
    }
}





void
CManTest::OnRam1Check(
    void
    ) 
{
    U32     *pTest  =   pBsp->GetTestVec();
    U32     uMask(HOST_RAM_1_TEST);
	if(!(*pTest & uMask))
    {
        *pTest |=   uMask;
    }
    else
    {
        *pTest &=   ~uMask;
        ((CButton*)GetDlgItem(IDC_RAM1_CHECK))->SetCheck(FALSE);
    }
}

void 
CManTest::OnRam2Check(
    void
    ) 
{   
    U32     *pTest  =   pBsp->GetTestVec();
    U32     uMask(HOST_RAM_2_TEST);
	if(!(*pTest & uMask))
    {
        *pTest |=   uMask;
    }
    else
    {
        *pTest &=   ~uMask;
        ((CButton*)GetDlgItem(IDC_RAM2_CHECK))->SetCheck(FALSE);
    }

}





void 
CManTest::OnUartCheck(
    void
    ) 
{
    U32     *pTest  =   pBsp->GetTestVec();
    U32     uMask(HOST_ISA_TEST);
    //U32     uMask(HOST_UART_TEST);

	if(!(*pTest & uMask))
    {
        *pTest |=   uMask;
    }
    else
    {
        *pTest &=   ~uMask;
        ((CButton*)GetDlgItem(IDC_RAM2_CHECK))->SetCheck(FALSE);
    }
}





void 
CManTest::OnVpdCheck(
    void
    ) 
{
    U32     *pTest  =   pBsp->GetTestVec();
    U32     uMask(HOST_VPD_TEST);
	if(!(*pTest & uMask))
    {
        *pTest |=   uMask;
    }
    else
    {
        *pTest &=   ~uMask;
        ((CButton*)GetDlgItem(IDC_VPD_CHECK))->SetCheck(FALSE);
    }
}





void
CManTest::OnLoopChange(
    void
    )
{
   
    CString szText;
    GetDlgItemText(IDC_LOOPCOUNT_EDIT,szText);
    uLoopCnt    =   atoi(szText);
}


