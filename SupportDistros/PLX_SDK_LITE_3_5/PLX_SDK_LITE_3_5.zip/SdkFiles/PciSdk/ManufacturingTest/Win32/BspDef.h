#ifndef ____BSP_DEF_H___
#define ____BSP_DEF_H___

#include "PlxTypes.h"


#define BSP_ELEMENT_CNT 16      // Total element - 1, not  counting the DEV_ID
#define BSP_TEST_CNT    20



typedef enum
{
    ST_COMMENT,
    ST_ELEMENT,
    ST_BEGIN,
    ST_END,
    ST_UNKNOWN,
    ST_EOF
}FP_STATE;      //File Parse state





class CBspDef{
private:
	CFile		hFile;
	CString		szFileName;
	CString		szBuffer;
    FP_STATE    fpCurr;
    BOOL        bTest;

	BOOL
	ReadBspFile(
		void
		);

	BOOL
	WriteBspFile(
		void
		);

    BOOL
    GoToNextState(
        void
        );

    U32 
    GetNextElement(
        void
        );

public:
	CBspDef(
		CString	szFName
		);

	BOOL
	InitBspFromFile(
		U32		*pBsp,
		U8		*pTestVec,
        U32&    UDevID

		);

	
    BOOL
	WriteBspFile(
	    const U32* const    pBsp,
	    char                *pTestVec,
        U32                 Devid

		);
};








#endif