#ifndef _PLXINITIALIZE_H
#define _PLXINITIALIZE_H

/*******************************************************************************
 * Copyright (c) 2000 PLX Technology, Inc.
 *
 * PLX Technology Inc. licenses this software under specific terms and
 * conditions.  Use of any of the software or derviatives thereof in any
 * product without a PLX Technology chip is strictly prohibited.
 *
 * PLX Technology, Inc. provides this software AS IS, WITHOUT ANY WARRANTY,
 * EXPRESS OR IMPLIED, INCLUDING, WITHOUT LIMITATION, ANY WARRANTY OF
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  PLX makes no guarantee
 * or representations regarding the use of, or the results of the use of,
 * the software and documentation in terms of correctness, accuracy,
 * reliability, currentness, or otherwise; and you rely on the software,
 * documentation and results solely at your own risk.
 *
 * IN NO EVENT SHALL PLX BE LIABLE FOR ANY LOSS OF USE, LOSS OF BUSINESS,
 * LOSS OF PROFITS, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES
 * OF ANY KIND.  IN NO EVENT SHALL PLX'S TOTAL LIABILITY EXCEED THE SUM
 * PAID TO PLX FOR THE PRODUCT LICENSED HEREUNDER.
 *
 ******************************************************************************/

/**********************************************************************
 *                                                                    *
 * Module Name:                                                       *
 *                                                                    *
 *     PlxInitialize.h                                                *
 *                                                                    *
 * Abstract:                                                          *
 *                                                                    *
 *     Header file for the PlxInitialize.c module                     *
 *                                                                    *
 * Revision History:                                                  *
 *                                                                    *
 *     04-19-00 : Support 9030                                        * 
 *     07-09-98 : Support SDK 2.0                                     *
 *     06-19-98 : Removed much unnecessary functionality.  Revised    *
 *                to include just needed functions.                   *
 *     10-02-97 : Added Support for selecting which device to use     *
 *                when more than one PLX device is found.  Also added *
 *                descriptions to DEVICE_LIST structure.              *
 *     09-25-97 : Version 1.0                                         *
 *                                                                    *
 *********************************************************************/


#ifdef __cplusplus
extern "C" {
#endif


#define PlxPrint                printf


#if defined(PCI_CODE)
    #include <stdio.h>
#endif
#include "PlxApi.h"
#include "Plx.h"
#include "Def.h"
#include "Reg9080.h"
#include "Reg9054.h"




typedef struct _DEVICE_LIST
{
    char            DevStr[70];
    DEVICE_LOCATION device;
} DEVICE_LIST;



/***********************************************/
/*            PROCEDURE PROTOTYPES             */
/***********************************************/
char     SelectDevice(HANDLE *, DEVICE_LIST * );
BOOLEAN  IsPlxDevice(ULONG);
U32      FindDevice(HANDLE *, DEVICE_LIST *);


                     
#ifdef __cplusplus
}
#endif

#endif