// Log.h: interface for the CLog class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LOG_H__4A64F189_156A_469E_B851_6AC9B0A04000__INCLUDED_)
#define AFX_LOG_H__4A64F189_156A_469E_B851_6AC9B0A04000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CLog  
{
public:
	void Clear(void);
	CLog();
	virtual ~CLog();

	void Init(CEdit *hEditBox);

	void Log(CString msg);
	void Log(_TCHAR *msg);
	void Display(CString msg);
	void Display(_TCHAR *msg);

private:
	CEdit * m_EditLog;

	void WriteLog(_TCHAR *msg);

};

extern CLog gLog;

#endif // !defined(AFX_LOG_H__4A64F189_156A_469E_B851_6AC9B0A04000__INCLUDED_)
