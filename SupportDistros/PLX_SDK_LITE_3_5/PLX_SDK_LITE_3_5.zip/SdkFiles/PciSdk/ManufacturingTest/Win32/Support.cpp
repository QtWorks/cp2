#include "StdAfx.h"
#include "support.h"



BOOL    bAbort;

BOOL
CheckAbort()
{
    return bAbort;
}




int
GetHex(
    char ch
    )
{
    switch(ch)
    {
    case '0':case '1':case '2':case '3':case '4':
    case '5':case '6':case '7':case '8':case '9':
        return ch - '0';
        break;
    case 'a':case 'b':case 'c':case 'd':case 'e':case 'f':
        return ch - 'a' + 10;
        break;

    case 'A':case 'B':case 'C':case 'D':case 'E':case 'F':
        return ch - 'A' + 10;
        break;
    }

    return 0;
}






U32
StrToU32(
    CString  szStr
    )
{
    U32     uRetVal(0);
    U32     nLen(0);
    U32     nCnt(0);
    char    ch;

    nLen    =   szStr.GetLength();
    
    if(nLen > 8) return -1;

    while(nCnt < nLen)
    {
        uRetVal <<= 4; 
        ch  =   szStr.GetAt(nCnt);
        if (!isxdigit(ch))
            return -1;
        uRetVal += GetHex(ch);
        nCnt++;
    }
    return uRetVal;

}

