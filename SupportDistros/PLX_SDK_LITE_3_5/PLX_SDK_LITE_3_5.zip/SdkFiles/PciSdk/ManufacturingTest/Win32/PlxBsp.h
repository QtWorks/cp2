#ifndef _PLXBSP_H_
#define _PLXBSP_H_
/*******************************************************************************
 * Copyright (c) 2000 PLX Technology, Inc.
 *
 * PLX Technology Inc. licenses this software under specific terms and
 * conditions.  Use of any of the software or derviatives thereof in any
 * product without a PLX Technology chip is strictly prohibited.
 *
 * PLX Technology, Inc. provides this software AS IS, WITHOUT ANY WARRANTY,
 * EXPRESS OR IMPLIED, INCLUDING, WITHOUT LIMITATION, ANY WARRANTY OF
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  PLX makes no guarantee
 * or representations regarding the use of, or the results of the use of,
 * the software and documentation in terms of correctness, accuracy,
 * reliability, currentness, or otherwise; and you rely on the software,
 * documentation and results solely at your own risk.
 *
 * IN NO EVENT SHALL PLX BE LIABLE FOR ANY LOSS OF USE, LOSS OF BUSINESS,
 * LOSS OF PROFITS, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES
 * OF ANY KIND.  IN NO EVENT SHALL PLX'S TOTAL LIABILITY EXCEED THE SUM
 * PAID TO PLX FOR THE PRODUCT LICENSED HEREUNDER.
 *
 ******************************************************************************/

/**********************************************************************
 *                                                                    *
 * Module Name:                                                       *
 *                                                                    *
 *     PlxBsp.h                                                       *
 *                                                                    *
 * Abstract:                                                          *
 *                                                                    *
 *     Include file for BSP                                           *
 *                                                                    *
 * Revision History:                                                  *
 *                                                                    *
 *     04-19-00 : Support 9030                                        * 
 *     07-09-98 : Support for SDK 2.0                                 *
 *     06-03-98 : Created                                             *
 *                                                                    *
 *********************************************************************/

#ifdef __cplusplus
extern "C" {
#endif



#include <stdio.h>
#include "PciApi.h"
#include "Plx.h"


/******************************
*        Definitions          *
******************************/
#define FLASH_TYPE_8_BIT     8
#define FLASH_TYPE_16_BIT    16
#define FLASH_TYPE_NONE      0

#define MEM_TYPE_32_BIT      4
#define MEM_TYPE_16_BIT      2
#define MEM_TYPE_8_BIT       1

typedef struct _BSP
{
    U32             PlxChipBase;
    U32             DramBase;
    U32             DramSize;
	U8				MemType;
    U32             SramBase;
    U32             SramSize;
    U32             FlashBase;
    U8              FlashType;
    U32             FlashOffset;
    U32             FlashUseSize;
    U32             FlashSize;
    U32             UartBase;
    U32             InterruptBase;
    U32             SwResetBase;
    U32             PomBase;
    DEVICE_LOCATION device;
}BSP;


/******************************
*   Procedure Prototypes      *
******************************/
extern BOOLEAN InitializeBsp(BSP*);


#ifdef __cplusplus
}
#endif

#endif