#ifndef ___SUPPORT__H__MT01___
#define ___SUPPORT__H__MT01___



#include "PlxTypes.h"



int
GetHex(
    char ch
    );


U32
StrToU32(
    CString
    );



BOOL
CheckAbort(
    void
    );



#endif
