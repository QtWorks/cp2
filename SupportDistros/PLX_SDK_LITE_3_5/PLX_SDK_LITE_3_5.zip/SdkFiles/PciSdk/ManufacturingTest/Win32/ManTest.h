#if !defined(AFX_MANTEST_H__521195A4_934F_11D5_8B50_00105A27137C__INCLUDED_)
#define AFX_MANTEST_H__521195A4_934F_11D5_8B50_00105A27137C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// mantest.h : header file
//

#include "Bsp.h"

/////////////////////////////////////////////////////////////////////////////
// CManTest dialog


class CManTest : public CDialog
{
// Construction
public:
	CManTest(
        CBsp*           ptheBsp,
        S8              DevIx,
        DEVICE_LIST*     dsList,
        CWnd* pParent /*=NULL*/
        );




    UINT
    OnStartThreadFunc(
        LPVOID  pParam
        );

// Dialog Data
	//{{AFX_DATA(CManTest)
	enum { IDD = IDD_MAN_TEST };
	CString	szCurrBsp;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CManTest)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
    
    
    
    CBsp            *pBsp;    
    DEVICE_LIST*    pDeviceList;
    S8              DeviceIndex;
    CWinThread*     pTestThread;
    HANDLE          hThread;
    HANDLE          hMutex;
    U32             uLoopCnt;
    






    void
    InitDlgFromBsp(
        void
        );


    
    void
    SetText(
        void
        );


	// Generated message map functions
	//{{AFX_MSG(CManTest)
	afx_msg void OnConfig();
	afx_msg void OnEditchangeComboBsp();
	virtual BOOL OnInitDialog();
	afx_msg void OnEnableallButton();
	afx_msg void OnClearallButton();
	afx_msg void OnEnablepciButton();
	afx_msg void OnEnableiopButton();
	afx_msg void OnStartestButton();
	afx_msg void OnStopButton();
	virtual void OnOK();
	afx_msg void OnLogCheck();
	afx_msg void OnPlxchipCheck();
	afx_msg void OnLedCheck();
	afx_msg void OnFlash0Check();
	afx_msg void OnFlash1Check();
	afx_msg void OnHotswapCheck();
	afx_msg void OnIopflash0Check();
	afx_msg void OnIopflash1Check();
	afx_msg void OnIophotswapCheck();
	afx_msg void OnIopledCheck();
	afx_msg void OnIopplxchipCheck();
	afx_msg void OnIopram0Check();
	afx_msg void OnIopram1Check();
	afx_msg void OnIopram2Check();
	afx_msg void OnIopuartCheck();
	afx_msg void OnIopvpdCheck();
	afx_msg void OnRam0Check();
	afx_msg void OnRam1Check();
	afx_msg void OnRam2Check();
	afx_msg void OnUartCheck();
	afx_msg void OnVpdCheck();
    afx_msg void OnLoopChange();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MANTEST_H__521195A4_934F_11D5_8B50_00105A27137C__INCLUDED_)
