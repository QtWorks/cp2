#if !defined(AFX_BSPCONFIG_H__B52D0B31_90F7_11D5_8B4D_00105A27137C__INCLUDED_)
#define AFX_BSPCONFIG_H__B52D0B31_90F7_11D5_8B4D_00105A27137C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// BspConfig.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CBspConfig dialog


#include "stdafx.h"
#include "Bsp.h"
#include "resource.h"

class CBsp;


class CBspConfig : public CDialog
{

//Private member functions
private:

    DEVICE_LIST     CurrentDeviceList[MAX_PCI_DEV];
    CBsp            *pBsp;
        
    
    BOOL
    OpenDevice(
        void
        );

    void
    InitBspFromDlg(
        void
        );



    BOOL
    InitBspFromFile(
        void
        );


    void
    InitDlgFromBsp(
        void
        );

    void
    InitTestFormBsp(
        void
        );

    char*
    MakeTestVecArray(
        void
        );

//Public Members
public:

	CBspConfig(
        CBsp    *theBsp,
        CWnd    *pParent = NULL
        );   // standard constructor



// Dialog Data
	//{{AFX_DATA(CBspConfig)
	enum { IDD = IDD_BSP_CONFIG };
	CComboBox	ComboFlashType0;
	CComboBox	ComboFlashType1;
	CString	szBoardSelected;
	CString	szFlashBase0;
	CString	szFlashSize0;
	CString	szFlashBase1;
	CString	szFlashSize1;
	CString	szRamBase0;
	CString	szRamSize0;
	CString	szRamBase1;
	CString	szRamSize1;
	CString	szRamBase2;
	CString	szRamSize2;
	CString	szInterrupt;
	CString	szSWReset;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBspConfig)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL


// Protected Message handlers and commands
protected:

	// Generated message map functions
	//{{AFX_MSG(CBspConfig)
	afx_msg void OnSave();
	afx_msg void OnOpen();
	afx_msg void OnTest();
	virtual void OnCancel();
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnHtChip();
	afx_msg void OnHtLed();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BSPCONFIG_H__B52D0B31_90F7_11D5_8B4D_00105A27137C__INCLUDED_)
