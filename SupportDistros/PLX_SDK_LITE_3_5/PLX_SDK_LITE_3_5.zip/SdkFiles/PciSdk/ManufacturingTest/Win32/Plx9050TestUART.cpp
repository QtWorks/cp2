// Plx9050TestUART.cpp: implementation of the CPlx9050TestUART class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ManfGUI.h"
#include "PlxInit.h"
#include "Plx9050TestUART.h"
#include "Log.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif



#define	PLX9050_LOC_SPACE1_RANGE_REG	(0x04)
#define	PLX9050_LOC_SPACE1_REMAP_REG	(0x18)
#define	PLX9050_LOC_SPACE1_BUS_DESC_REG	(0x2c)
#define	PLX9050_LOC_SPACE1_CS_REG		(0x40)
#define	PLX9050_LOC_SPACE1_IRQ_REG		(0x4c)

#define UART8250_TRANSMIT_REG			(0x00)
#define UART8250_RECEIVE_REG			(0x00)
#define UART8250_IRQ_CTRL_REG			(0x01)
#define UART8250_IRQ_STATUS_REG			(0x02)
#define UART8250_LINE_CTRL_REG			(0x03)
#define UART8250_MODEM_CTRL_REG			(0x04)
#define UART8250_LINE_STATUS_REG		(0x05)
#define UART8250_MODEM_STATUS_REG		(0x06)
#define UART8250_SCRATCH_PAD_REG		(0x07)
#define UART8250_LSB_DIVISOR_REG		(0x00)
#define UART8250_MSB_DIVISOR_REG		(0x01)

#define UART8250_DIVISOR_DLAB			(0x80)
#define UART8250_LSB_DIVISOR_2400BPS	(0x30)
#define UART8250_MSB_DIVISOR_2400BPS	(0x00)
#define UART8250_8BIT1STOP_FORMAT		(0x03)


struct COM_IO_RESOURCE
{
	WORD Align;
	WORD nPorts;
	WORD Min;
	WORD Max;
	WORD Flags;
	WORD Alias;
	WORD Decode;
};

#define COM_IO_COUNT (4)


COM_IO_RESOURCE ComPortsData[] = 
	{
		// {Align, nPorts, Min, Max, Flags, Alias, Decode}
		// For standard COM ports...
		{(WORD)~0x07, 0x08, 0x03f8, 0x03ff, 0, 4, 3},
		{(WORD)~0x07, 0x08, 0x02f8, 0x02ff, 0, 4, 3},
		{(WORD)~0x07, 0x08, 0x03e8, 0x03ef, 0, 4, 3},
		{(WORD)~0x07, 0x08, 0x02e8, 0x02ef, 0, 4, 3},
	};




//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CPlx9050TestUART::CPlx9050TestUART(HANDLE hPlx,DWORD DeviceId,DWORD dwPCIBaseAddress)
{
	m_DeviceId			=DeviceId;
	m_hPlx				=hPlx;
	m_dwPCIBaseAddress	=dwPCIBaseAddress;

}

CPlx9050TestUART::~CPlx9050TestUART()
{

}


///////////////////////////////////////////////////////////////////////////////
BOOL CPlx9050TestUART::IsComport(DWORD port)
{	// Test port -- is it a COM (8250 UART) port?
	// Based on the upper bits of the Interrupt Enable Register always being zero:
	// First, see if it's just empty space
	CString out;

	BYTE byte;
	PlxIoPortRead(m_hPlx,port+UART8250_IRQ_CTRL_REG,BitSize8,&byte);
	BYTE old_val=byte;
	out.Format(_T("Read %X from port %X (UART's IRQ CTRL REG)"),byte,port+UART8250_IRQ_CTRL_REG);
	gLog.Display(out);
	if (byte > 0x0f)
	{
		return FALSE;	// Probably empty space
	}

	// Now set upper IER bits - they should stay reset
	byte=0xff;
	PlxIoPortWrite(m_hPlx,port+UART8250_IRQ_CTRL_REG,BitSize8,&byte);
	out.Format(_T("Write %X to port %X (UART's IRQ CTRL REG)"),byte,port+UART8250_IRQ_CTRL_REG);
	gLog.Display(out);

	byte=0;
	PlxIoPortRead(m_hPlx,port+UART8250_IRQ_CTRL_REG,BitSize8,&byte);
	out.Format(_T("Read %X from port %X (UART's IRQ CTRL REG)"),byte,port+UART8250_IRQ_CTRL_REG);
	gLog.Display(out);

	// Now restore old value
	PlxIoPortWrite(m_hPlx,port+UART8250_IRQ_CTRL_REG,BitSize8,&old_val);
	out.Format(_T("Restore value %X to port %X (UART's IRQ CTRL REG)"),old_val,port+UART8250_IRQ_CTRL_REG);
	gLog.Display(out);

	return (byte == 0x0f);
}

///////////////////////////////////////////////////////////////////////////////
BOOL CPlx9050TestUART::SetupLocalIO(WORD LocBase, WORD LocRange)
{	// Setup PCI9050 local IO space (for local address space 1)
	// Lcr9050Base: PCI address of PCI 9050 Local Config Regs
	// LocBase: I/O address of your card piggybacked on SDK
	// LocRange: Range mask for your card (8250 UART is ~0x07)
	// Note - bits 0 and 1 of LocBase and LocRange must be clear! (9050 requirement)
	WORD ii;
	CString out;

 	// Setup 9050 local-side registers:
	// Set range (LAS1RR)
	PlxRegisterWrite(m_hPlx,PLX9050_LOC_SPACE1_RANGE_REG,(DWORD)(LocRange | 0xffff0001));
	out.Format(_T("Set 9050 range (LAS1RR) to %X"),(LocRange | 0xffff0001));
	gLog.Display(out);

	// Set base address re-map (LAS1BA)
	PlxRegisterWrite(m_hPlx,PLX9050_LOC_SPACE1_REMAP_REG, (DWORD)(LocBase | 0x03000001));
	out.Format(_T("Set 9050 base address re-map (LAS1BA) to %X"),(LocBase | 0x03000001));
	gLog.Display(out);

	// Set chip select base (CS1BASE) (Tricky! See 9050 spec)
	for (ii = 1; ii < (1 << 16); ii <<= 1)
	{	// Find first set bit in the local base address
		if (LocBase & ii)
		{
			break;	// Found the first bit!
		}
	}
	PlxRegisterWrite(m_hPlx,PLX9050_LOC_SPACE1_CS_REG, (DWORD)(LocBase | (ii >> 1) | 0x03000001));
	out.Format(_T("Set 9050 chip select base (CS1BASE) to %X"),(LocBase | (ii >> 1) | 0x03000001));
	gLog.Display(out);

	// Set bus region descriptor (LAS1BRD) (see 9050 spec)
	PlxRegisterWrite(m_hPlx,PLX9050_LOC_SPACE1_BUS_DESC_REG, 0x40000022);
	out.Format(_T("Set 9050 bus region descriptor (LAS1BRD) to %X"),0x40000022);
	gLog.Display(out);

	// Set interrupts (INTCSR)
	PlxRegisterWrite(m_hPlx,PLX9050_LOC_SPACE1_IRQ_REG, 0x00001041);
	out.Format(_T("Set 9050 interrupts (INTCSR) to %X"),0x00001041);
	gLog.Display(out);

	return TRUE;
}

///////////////////////////////////////////////////////////////////////////////
BOOL CPlx9050TestUART::SetupLocComport()
{	// Find and setup the first comm port of piggybacked comm card

	m_UartBasePort=0;

	CString out;

	for (int ii = 0; ii < COM_IO_COUNT; ii++)
	{	
		out.Format(_T("Looking for UART on local ISA port %X (%X)"),ComPortsData[ii].Min, ComPortsData[ii].Align);
		gLog.Display(out);

		SetupLocalIO(ComPortsData[ii].Min, ComPortsData[ii].Align);
		if (IsComport(m_dwPCIBaseAddress))
		{
			out.Format(_T("Found UART on local ISA port %X"),ComPortsData[ii].Min);
			gLog.Display(out);

			m_UartBasePort=ComPortsData[ii].Min;
			return TRUE;
		}
	}

	gLog.Display(_T("No UART Found!!!"));

	return FALSE;
}

BOOL CPlx9050TestUART::TestUART(BOOL bIsModem)
{
    RETURN_CODE		rc;

	// Save current values of all registers we might change
    DWORD dwOldRemapValue	= PlxRegisterRead(m_hPlx, PLX9050_LOC_SPACE1_REMAP_REG, &rc);
	DWORD dwOldCSValue		= PlxRegisterRead(m_hPlx, PLX9050_LOC_SPACE1_CS_REG, &rc);
	DWORD dwOldRangeValue	= PlxRegisterRead(m_hPlx, PLX9050_LOC_SPACE1_RANGE_REG, &rc);
	DWORD dwOldBusValue		= PlxRegisterRead(m_hPlx, PLX9050_LOC_SPACE1_BUS_DESC_REG, &rc);
	DWORD dwOldIrqValue		= PlxRegisterRead(m_hPlx, PLX9050_LOC_SPACE1_IRQ_REG, &rc);


	// Find the presence of a UART -> this will return false if none found
	BOOL retval=SetupLocComport();

	if(retval && bIsModem)
	{
		CString out;
		out.Format(_T("Testing modem on local ISA port %X"),m_UartBasePort);
		gLog.Display(out);

		// Test modem
		SendToModem("ATM1L3DT0123456789\r\n");
	}

	// Restore original values of all registers we might have changed
    PlxRegisterWrite(m_hPlx, PLX9050_LOC_SPACE1_REMAP_REG, dwOldRemapValue);
    PlxRegisterWrite(m_hPlx, PLX9050_LOC_SPACE1_CS_REG, dwOldCSValue);
    PlxRegisterWrite(m_hPlx, PLX9050_LOC_SPACE1_RANGE_REG, dwOldRangeValue);
    PlxRegisterWrite(m_hPlx, PLX9050_LOC_SPACE1_BUS_DESC_REG, dwOldBusValue);
    PlxRegisterWrite(m_hPlx, PLX9050_LOC_SPACE1_IRQ_REG, dwOldIrqValue);

	return retval;
}

void CPlx9050TestUART::SendToModem(CString out)
{

	for(int i=0;i<out.GetLength();i++)
	{
		BYTE byte=out[i];

		CString tmp=byte;
		gLog.Display(tmp);


		PlxIoPortWrite(m_hPlx,m_dwPCIBaseAddress+UART8250_TRANSMIT_REG,BitSize8,&byte);
		Sleep(100);
	}

}

CString CPlx9050TestUART::GetFromModem()
{
	CString out;

	return out;

}

