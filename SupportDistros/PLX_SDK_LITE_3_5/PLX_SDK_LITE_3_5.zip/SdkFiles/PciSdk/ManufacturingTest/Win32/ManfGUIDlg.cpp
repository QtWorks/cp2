/*******************************************************************************
 * Copyright (c) 2000 PLX Technology, Inc.
 *
 * PLX Technology Inc. licenses this software under specific terms and
 * conditions.  Use of any of the software or derviatives thereof in any
 * product without a PLX Technology chip is strictly prohibited.
 *
 * PLX Technology, Inc. provides this software AS IS, WITHOUT ANY WARRANTY,
 * EXPRESS OR IMPLIED, INCLUDING, WITHOUT LIMITATION, ANY WARRANTY OF
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  PLX makes no guarantee
 * or representations regarding the use of, or the results of the use of,
 * the software and documentation in terms of correctness, accuracy,
 * reliability, currentness, or otherwise; and you rely on the software,
 * documentation and results solely at your own risk.
 *
 * IN NO EVENT SHALL PLX BE LIABLE FOR ANY LOSS OF USE, LOSS OF BUSINESS,
 * LOSS OF PROFITS, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES
 * OF ANY KIND.  IN NO EVENT SHALL PLX'S TOTAL LIABILITY EXCEED THE SUM
 * PAID TO PLX FOR THE PRODUCT LICENSED HEREUNDER.
 *
 ******************************************************************************/

// ManfGUIDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ManfGUI.h"
#include "ManfGUIDlg.h"
#include "ManfTest.h"
#include "RamTest.h"
#include "PlxInit.h"
#include "DownLoad.h"
#include "Reg480.h"
#include "Reg9054.h"



#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/***************Global variables*****************/     
BOOL            EnableAll;  
BOOL            ClearAll;
BOOL            EnablePci;  
BOOL            EnableIop;
BOOL            BoardIn;
BOOL            AbortTest = FALSE;
BOOL            Failed = FALSE; 

HANDLE          PlxHandle;
DEVICE_LIST     CurrentDeviceList[MAX_PCI_DEV];
BSP             DeviceBsp;
CHAR            LogFileName[15];
CHAR            Buffer[80];
BOOL            DoLog = TRUE;
U32             loop;
U32             TimerCheck;
U32             DevIndex;
U32				CurrentTotalDeviceNum;
DEVICE_LOCATION CPci9054device;
REGISTEROFFSET  RegisterOffset;

/************************************************/

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CManfGUIDlg dialog

CManfGUIDlg::CManfGUIDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CManfGUIDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CManfGUIDlg)
	m_FlashCheck = FALSE;
	m_IopFlashCheck = FALSE;
	m_IopLedCheck = FALSE;
	m_IopPomCheck = FALSE;
	m_IopPlxChipCheck = FALSE;
	m_IopUartCheck = FALSE;
	m_LedCheck = FALSE;
	m_PomCheck = FALSE;
	m_PlxChipCheck = FALSE;
	m_UartCheck = FALSE;
	m_LogCheck = FALSE;
	m_LoopCount = 0.0;
	m_DeviceString = _T("");
	m_HotSwapCheck = FALSE;
	m_IopHotSwapCheck = FALSE;
	m_IopPowerMCheck = FALSE;
	m_IopVpdCheck = FALSE;
	m_PowerMCheck = FALSE;
	m_VpdCheck = FALSE;
	m_IopSdramCheck = FALSE;
	m_SdramCheck = FALSE;
	m_IopSbsramCheck = FALSE;
	m_SbsramCheck = FALSE;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CManfGUIDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CManfGUIDlg)
	DDX_Control(pDX, IDC_LOOPCOUNT_SPIN, m_Spin);
	DDX_Check(pDX, IDC_FLASH_CHECK, m_FlashCheck);
	DDX_Check(pDX, IDC_IOPFLASH_CHECK, m_IopFlashCheck);
	DDX_Check(pDX, IDC_IOPLED_CHECK, m_IopLedCheck);
	DDX_Check(pDX, IDC_IOPPOM_CHECK, m_IopPomCheck);
	DDX_Check(pDX, IDC_IOPPLXCHIP_CHECK, m_IopPlxChipCheck);
	DDX_Check(pDX, IDC_IOPUART_CHECK, m_IopUartCheck);
	DDX_Check(pDX, IDC_LED_CHECK, m_LedCheck);
	DDX_Check(pDX, IDC_POM_CHECK, m_PomCheck);
	DDX_Check(pDX, IDC_PLXCHIP_CHECK, m_PlxChipCheck);
	DDX_Check(pDX, IDC_UART_CHECK, m_UartCheck);
	DDX_Check(pDX, IDC_LOG_CHECK, m_LogCheck);
	DDX_Text(pDX, IDC_LOOPCOUNT_EDIT, m_LoopCount);
	DDV_MinMaxDouble(pDX, m_LoopCount, 1., 1000000.);
	DDX_CBString(pDX, IDC_DEVICE_COMBO, m_DeviceString);
	DDX_Check(pDX, IDC_HOTSWAP_CHECK, m_HotSwapCheck);
	DDX_Check(pDX, IDC_IOPHOTSWAP_CHECK, m_IopHotSwapCheck);
	DDX_Check(pDX, IDC_IOPPOWERM_CHECK, m_IopPowerMCheck);
	DDX_Check(pDX, IDC_IOPVPD_CHECK, m_IopVpdCheck);
	DDX_Check(pDX, IDC_POWERM_CHECK, m_PowerMCheck);
	DDX_Check(pDX, IDC_VPD_CHECK, m_VpdCheck);
	DDX_Check(pDX, IDC_IOPSDRAM_CHECK, m_IopSdramCheck);
	DDX_Check(pDX, IDC_SDRAM_CHECK, m_SdramCheck);
	DDX_Check(pDX, IDC_IOPSBSRAM_CHECK, m_IopSbsramCheck);
	DDX_Check(pDX, IDC_SBSRAM_CHECK, m_SbsramCheck);
	//}}AFX_DATA_MAP

}

BEGIN_MESSAGE_MAP(CManfGUIDlg, CDialog)
	//{{AFX_MSG_MAP(CManfGUIDlg)
	ON_BN_CLICKED(IDC_ENABLEALL_BUTTON, OnEnableallButton)
	ON_BN_CLICKED(IDC_CLEARALL_BUTTON, OnClearallButton)
	ON_BN_CLICKED(IDC_ENABLEPCI_BUTTON, OnEnablepciTest)
	ON_BN_CLICKED(IDC_ENABLEIOP_BUTTON, OnEnableiopTest)
	ON_BN_CLICKED(IDC_STARTEST_BUTTON, OnStartestButton)
	ON_CBN_CLOSEUP(IDC_DEVICE_COMBO, OnOpenDevice)
	ON_BN_CLICKED(IDC_STOP_BUTTON, OnStopButton)
	ON_BN_DOUBLECLICKED(IDC_STOP_BUTTON, OnDoubleclickedStopButton)
	ON_BN_CLICKED(IDC_BOARD_CONFIG_BUTTON, OnBoardConfigButton)
	ON_BN_CLICKED(IDC_COF_ELF, OnCofElf)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CManfGUIDlg message handlers

BOOL CManfGUIDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

    //Print the dialog title
    sprintf(Buffer, "Manufacturing Test");
    SetWindowText(Buffer);

    ButtonInitialization();

    //Find all plx devices and list them in combo list box.
    CComboBox * pCombo = (CComboBox *)GetDlgItem(IDC_DEVICE_COMBO);
    CButton * pDetailsButton = (CButton*)GetDlgItem(IDC_DETAILS_BUTTON);

    DevIndex = SelectDevice(&PlxHandle, CurrentDeviceList);
    if (DevIndex == 0)
    {
        m_DeviceString = "No supported PCI devices found.";
        pDetailsButton->SetWindowText(m_DeviceString);
        //Disable the GUI window.
        UpdateData(FALSE);
        GuiDisable();
        return TRUE;
    }
    else
    {
        for (UINT i=0; i<DevIndex; i++)
        {
            m_DeviceString = CurrentDeviceList[i].DevStr;
            pCombo->AddString(m_DeviceString);
        }
		UpdateData(FALSE);
    }

    OnOpenDevice();

    OnEnableallButton();
  
    UpdateData(FALSE);


	return TRUE;  // return TRUE unless you set the focus to a control
}




void CManfGUIDlg::RdkPciTest(unsigned long RdkId)
{
	if (RdkId == PLX_CPCI9054RDK_860_DEVICE_ID)
	{
		m_PlxChipCheck = TRUE;
        m_LedCheck = TRUE;
        m_FlashCheck = TRUE;
        m_SdramCheck = TRUE;
		m_SbsramCheck = TRUE; 
        m_VpdCheck = TRUE;
        m_PowerMCheck = TRUE;

		//m_HotSwapCheck = TRUE; 

		EnablePciButtons();

	    GetDlgItem(IDC_HOTSWAP_CHECK)->EnableWindow(FALSE);
        GetDlgItem(IDC_HOTSWAP_BUTTON)->EnableWindow(FALSE);
        GetDlgItem(IDC_UART_BUTTON)->EnableWindow(FALSE);
        GetDlgItem(IDC_UART_CHECK)->EnableWindow(FALSE);
		GetDlgItem(IDC_POM_BUTTON)->EnableWindow(FALSE);
		GetDlgItem(IDC_POM_CHECK)->EnableWindow(FALSE);
        GetDlgItem(IDC_COF_ELF)->EnableWindow(FALSE);

        EnableAll = TRUE;
        EnablePci = TRUE;
        ClearAll = FALSE;
	}
    else if (RdkId == PLX_9080RDK_401B_DEVICE_ID)
    {
		m_PlxChipCheck = TRUE;
        m_LedCheck = TRUE;
        m_FlashCheck = TRUE;
        m_SdramCheck = TRUE;
		m_SbsramCheck = TRUE; 
        m_VpdCheck = TRUE;
        m_PowerMCheck = TRUE;
		m_HotSwapCheck = TRUE; 

		EnablePciButtons();

        GetDlgItem(IDC_UART_BUTTON)->EnableWindow(FALSE);
        GetDlgItem(IDC_UART_CHECK)->EnableWindow(FALSE);
		GetDlgItem(IDC_POM_BUTTON)->EnableWindow(FALSE);
		GetDlgItem(IDC_POM_CHECK)->EnableWindow(FALSE);
        GetDlgItem(IDC_COF_ELF)->EnableWindow(FALSE);

        EnableAll = TRUE;
        EnablePci = TRUE;
        ClearAll = FALSE;
    
    }


	else if (RdkId == PLX_9054RDK_860_DEVICE_ID
		||RdkId	==	PLX_9656RDK_860_DEVICE_ID
		||RdkId == PLX_9056RDK_860_DEVICE_ID)
	{
        m_PlxChipCheck = TRUE;
        m_LedCheck = TRUE;
        m_FlashCheck = TRUE;
        m_SdramCheck = TRUE;
        m_VpdCheck = TRUE;
        m_PowerMCheck = TRUE;

		EnablePciButtons();

        GetDlgItem(IDC_SBSRAM_CHECK)->EnableWindow(FALSE);
        GetDlgItem(IDC_SBSRAM_BUTTON)->EnableWindow(FALSE);
	    GetDlgItem(IDC_HOTSWAP_CHECK)->EnableWindow(FALSE);
        GetDlgItem(IDC_HOTSWAP_BUTTON)->EnableWindow(FALSE);
        GetDlgItem(IDC_UART_BUTTON)->EnableWindow(FALSE);
        GetDlgItem(IDC_UART_CHECK)->EnableWindow(FALSE);
		GetDlgItem(IDC_POM_BUTTON)->EnableWindow(FALSE);
		GetDlgItem(IDC_POM_CHECK)->EnableWindow(FALSE);
        GetDlgItem(IDC_COF_ELF)->EnableWindow(FALSE);
	}
	else if (RdkId == PLX_IOP480RDK_DEVICE_ID)
	{
        m_PlxChipCheck = TRUE;
        m_LedCheck = TRUE;
        m_FlashCheck = TRUE;
        m_SdramCheck = TRUE;
        m_VpdCheck = TRUE;
        m_PowerMCheck = TRUE;

 		EnablePciButtons();

        GetDlgItem(IDC_SBSRAM_CHECK)->EnableWindow(FALSE);
        GetDlgItem(IDC_SBSRAM_BUTTON)->EnableWindow(FALSE);
 	    GetDlgItem(IDC_HOTSWAP_CHECK)->EnableWindow(FALSE);
        GetDlgItem(IDC_HOTSWAP_BUTTON)->EnableWindow(FALSE);
        GetDlgItem(IDC_UART_BUTTON)->EnableWindow(FALSE);
        GetDlgItem(IDC_UART_CHECK)->EnableWindow(FALSE);
		GetDlgItem(IDC_POM_BUTTON)->EnableWindow(FALSE);
		GetDlgItem(IDC_POM_CHECK)->EnableWindow(FALSE);
        
	}
    else if (RdkId == PLX_9054RDK_LITE_DEVICE_ID
		||RdkId == PLX_9056RDK_LITE_DEVICE_ID
		||RdkId == PLX_9656RDK_LITE_DEVICE_ID)
	{
        m_PlxChipCheck = TRUE;
        m_SbsramCheck = TRUE;
        m_VpdCheck = TRUE;
        m_PowerMCheck = TRUE;

		EnablePciButtons();

		GetDlgItem(IDC_LED_BUTTON)->EnableWindow(FALSE);
		GetDlgItem(IDC_LED_CHECK)->EnableWindow(FALSE);
		GetDlgItem(IDC_FLASH_BUTTON)->EnableWindow(FALSE);
		GetDlgItem(IDC_FLASH_CHECK)->EnableWindow(FALSE);
        GetDlgItem(IDC_SDRAM_CHECK)->EnableWindow(FALSE);
        GetDlgItem(IDC_SDRAM_BUTTON)->EnableWindow(FALSE);
	    GetDlgItem(IDC_HOTSWAP_CHECK)->EnableWindow(FALSE);
        GetDlgItem(IDC_HOTSWAP_BUTTON)->EnableWindow(FALSE);
        GetDlgItem(IDC_UART_BUTTON)->EnableWindow(FALSE);
        GetDlgItem(IDC_UART_CHECK)->EnableWindow(FALSE);
		GetDlgItem(IDC_POM_BUTTON)->EnableWindow(FALSE);
		GetDlgItem(IDC_POM_CHECK)->EnableWindow(FALSE);

	}
    else if ((RdkId == PLX_9030RDK_LITE_DEVICE_ID)||
		     (RdkId == PLX_CPCI9030RDK_LITE_DEVICE_ID))
	{
        m_PlxChipCheck = TRUE;
        m_SdramCheck = TRUE;
        m_VpdCheck = TRUE;
        m_PowerMCheck = TRUE;

		EnablePciButtons();

		GetDlgItem(IDC_LED_BUTTON)->EnableWindow(FALSE);
		GetDlgItem(IDC_LED_CHECK)->EnableWindow(FALSE);
		GetDlgItem(IDC_FLASH_BUTTON)->EnableWindow(FALSE);
		GetDlgItem(IDC_FLASH_CHECK)->EnableWindow(FALSE);
        GetDlgItem(IDC_SBSRAM_CHECK)->EnableWindow(FALSE);
        GetDlgItem(IDC_SBSRAM_BUTTON)->EnableWindow(FALSE);
 	    GetDlgItem(IDC_HOTSWAP_CHECK)->EnableWindow(FALSE);
        GetDlgItem(IDC_HOTSWAP_BUTTON)->EnableWindow(FALSE);
        GetDlgItem(IDC_UART_BUTTON)->EnableWindow(FALSE);
        GetDlgItem(IDC_UART_CHECK)->EnableWindow(FALSE);
		GetDlgItem(IDC_POM_BUTTON)->EnableWindow(FALSE);
		GetDlgItem(IDC_POM_CHECK)->EnableWindow(FALSE);
	}
}




void CManfGUIDlg::RdkIopTest(unsigned long RdkId)
{
	if (RdkId == PLX_CPCI9054RDK_860_DEVICE_ID)
	{
        m_IopPlxChipCheck = TRUE;
        m_IopLedCheck = TRUE;
        m_IopFlashCheck = TRUE;
	    m_IopSdramCheck = TRUE;
	    m_IopSbsramCheck = TRUE;
        m_IopUartCheck = TRUE;

		EnableIopButtons();

        GetDlgItem(IDC_IOPVPD_CHECK)->EnableWindow(FALSE);
        GetDlgItem(IDC_IOPVPD_BUTTON)->EnableWindow(FALSE);
        GetDlgItem(IDC_IOPPOWERM_BUTTON)->EnableWindow(FALSE);
        GetDlgItem(IDC_IOPPOWERM_CHECK)->EnableWindow(FALSE);
	    GetDlgItem(IDC_IOPHOTSWAP_CHECK)->EnableWindow(FALSE);
        GetDlgItem(IDC_IOPHOTSWAP_BUTTON)->EnableWindow(FALSE);
 		GetDlgItem(IDC_IOPPOM_BUTTON)->EnableWindow(FALSE);
		GetDlgItem(IDC_IOPPOM_CHECK)->EnableWindow(FALSE);
        GetDlgItem(IDC_COF_ELF)->EnableWindow(FALSE);

        EnableAll = TRUE;
        EnableIop = TRUE;
        ClearAll = FALSE;
	}
    else if (RdkId == PLX_9080RDK_401B_DEVICE_ID)
    {
        m_IopPlxChipCheck = TRUE;
        m_IopLedCheck = TRUE;
        m_IopFlashCheck = TRUE;
	    m_IopSdramCheck = TRUE;
	    m_IopSbsramCheck = TRUE;
        m_IopUartCheck = TRUE;


		EnableIopButtons();

        GetDlgItem(IDC_IOPVPD_CHECK)->EnableWindow(FALSE);
        GetDlgItem(IDC_IOPVPD_BUTTON)->EnableWindow(FALSE);
        GetDlgItem(IDC_IOPPOWERM_BUTTON)->EnableWindow(FALSE);
        GetDlgItem(IDC_IOPPOWERM_CHECK)->EnableWindow(FALSE);
	    GetDlgItem(IDC_IOPHOTSWAP_CHECK)->EnableWindow(FALSE);
        GetDlgItem(IDC_IOPHOTSWAP_BUTTON)->EnableWindow(FALSE);
 		GetDlgItem(IDC_IOPPOM_BUTTON)->EnableWindow(FALSE);
		GetDlgItem(IDC_IOPPOM_CHECK)->EnableWindow(FALSE);
        GetDlgItem(IDC_COF_ELF)->EnableWindow(FALSE);

        EnableAll = TRUE;
        EnableIop = TRUE;
        ClearAll = FALSE;
    
    }

	else if (RdkId == PLX_9054RDK_860_DEVICE_ID	
		||RdkId == PLX_9656RDK_860_DEVICE_ID
		||RdkId == PLX_9056RDK_860_DEVICE_ID)
	{
        m_IopPlxChipCheck = TRUE;
        m_IopLedCheck = TRUE;
        m_IopFlashCheck = TRUE;
	    m_IopSdramCheck = TRUE;
        m_IopUartCheck = TRUE;

		EnableIopButtons();

        GetDlgItem(IDC_IOPVPD_CHECK)->EnableWindow(FALSE);
        GetDlgItem(IDC_IOPVPD_BUTTON)->EnableWindow(FALSE);
        GetDlgItem(IDC_IOPPOWERM_BUTTON)->EnableWindow(FALSE);
        GetDlgItem(IDC_IOPPOWERM_CHECK)->EnableWindow(FALSE);
    	GetDlgItem(IDC_IOPSBSRAM_CHECK)->EnableWindow(FALSE);
        GetDlgItem(IDC_IOPSBSRAM_BUTTON)->EnableWindow(FALSE);
	    GetDlgItem(IDC_IOPHOTSWAP_CHECK)->EnableWindow(FALSE);
        GetDlgItem(IDC_IOPHOTSWAP_BUTTON)->EnableWindow(FALSE);
		GetDlgItem(IDC_IOPPOM_BUTTON)->EnableWindow(FALSE);
		GetDlgItem(IDC_IOPPOM_CHECK)->EnableWindow(FALSE);
        GetDlgItem(IDC_COF_ELF)->EnableWindow(FALSE);
	}
	else if (RdkId == PLX_IOP480RDK_DEVICE_ID)
	{
        m_IopPlxChipCheck = TRUE;
        m_IopLedCheck = TRUE;
        m_IopFlashCheck = TRUE;
	    m_IopSdramCheck = TRUE;
        m_IopUartCheck = TRUE;

		EnableIopButtons();

        GetDlgItem(IDC_IOPVPD_CHECK)->EnableWindow(FALSE);
        GetDlgItem(IDC_IOPVPD_BUTTON)->EnableWindow(FALSE);
        GetDlgItem(IDC_IOPPOWERM_BUTTON)->EnableWindow(FALSE);
        GetDlgItem(IDC_IOPPOWERM_CHECK)->EnableWindow(FALSE);
    	GetDlgItem(IDC_IOPSBSRAM_CHECK)->EnableWindow(FALSE);
        GetDlgItem(IDC_IOPSBSRAM_BUTTON)->EnableWindow(FALSE);
	    GetDlgItem(IDC_IOPHOTSWAP_CHECK)->EnableWindow(FALSE);
        GetDlgItem(IDC_IOPHOTSWAP_BUTTON)->EnableWindow(FALSE);
 		GetDlgItem(IDC_IOPPOM_BUTTON)->EnableWindow(FALSE);
		GetDlgItem(IDC_IOPPOM_CHECK)->EnableWindow(FALSE);
	}
}




void CManfGUIDlg::OnEnableallButton() 
{
	DisableAll();
	RdkPciTest(DeviceBsp.device.DeviceId);
	RdkIopTest(DeviceBsp.device.DeviceId);
  
    UpdateData(FALSE);
}




void CManfGUIDlg::OnClearallButton() 
{
	// TODO: Add your control notification handler code here
    
    UpdateData(TRUE);

    m_PlxChipCheck = FALSE;
    m_LedCheck = FALSE;
    m_FlashCheck = FALSE;
    m_SdramCheck = FALSE;
    m_SbsramCheck = FALSE;
    m_VpdCheck = FALSE;
    m_UartCheck = FALSE;
    m_PowerMCheck = FALSE;
	m_HotSwapCheck = FALSE;
    //m_InterruptCheck = FALSE;
    //m_PomCheck = FALSE;

    m_IopPlxChipCheck = FALSE;
    m_IopLedCheck = FALSE;
    m_IopFlashCheck = FALSE;
    m_IopSdramCheck = FALSE;
    m_IopSbsramCheck = FALSE;
    m_IopUartCheck = FALSE;
    //m_IopInterruptCheck = FALSE;
    //m_IopPomCheck = FALSE;

    EnableAll = FALSE;
    EnableIop = FALSE;
    EnablePci = FALSE;
    ClearAll = TRUE;

    ResetButtonText();

    UpdateData(FALSE);
}




void CManfGUIDlg::OnEnablepciTest() 
{
    UpdateData(TRUE);

	RdkPciTest(DeviceBsp.device.DeviceId);

    EnablePci = TRUE;

    UpdateData(FALSE);
}




void CManfGUIDlg::OnEnableiopTest() 
{
   
    UpdateData(TRUE);
	RdkIopTest(DeviceBsp.device.DeviceId);

    EnableIop = TRUE;

    UpdateData(FALSE);
}



void CManfGUIDlg::OnStartestButton() 
{
 
  RETURN_CODE  rc;
  BOOL         IopReset = FALSE;
  U32          ReturnValue;
  U32          RegValue;
  U32		   StartOffset;
  char         buf[10];


  RegisterSwitch(&DeviceBsp);

  // Get data from Dlg
  UpdateData(TRUE);

  if (AbortTest == TRUE)
  {
      loop = 1;
      AbortTest = FALSE;  
  }

  //Open a log file for test results.
  if (m_LogCheck == TRUE)
  {
      sprintf(LogFileName, "Mft%x%x.log", DeviceBsp.device.DeviceId, DeviceBsp.device.SlotNumber);
      DeleteFile(LogFileName);
      DoLog = TRUE;
  }
  else
      DoLog = FALSE;


  CButton * pDetailsButton = (CButton *)GetDlgItem(IDC_DETAILS_BUTTON);  

    for (loop = 1; loop <= m_LoopCount; loop++)
    {
        if (DoLog)
        LogWriteSection(loop);

	    //Display the current loop number.
	    _itoa(loop, Buffer, 10);
	    CButton * pCurrentLoopButton = (CButton *)GetDlgItem(IDC_CURRENTLOOP_BUTTON);  
	    pCurrentLoopButton->SetWindowText(Buffer);

	    CheckAbort();
	    if (AbortTest == TRUE)
            return;
      
        // If any PCI tests, put Local CPU in reset state
        if (EnableAll == TRUE      || EnablePci==TRUE      ||
            m_PlxChipCheck == TRUE || m_LedCheck == TRUE   ||
            m_FlashCheck == TRUE   || m_SdramCheck == TRUE ||
            m_SbsramCheck == TRUE  || m_VpdCheck == TRUE   ||
		    m_PowerMCheck == TRUE  || m_HotSwapCheck == TRUE)
          {
            //Plx chip test
            if (m_PlxChipCheck == TRUE)
            {
                CButton * pPlxChipButton = (CButton *)GetDlgItem(IDC_PLXCHIP_BUTTON);
                m_TestResultEdit = "PCI Plx Chip Test";
                pDetailsButton->SetWindowText(m_TestResultEdit);

                m_PlxChipEdit = "Testing";
                pPlxChipButton->SetWindowText(m_PlxChipEdit);

                if (HostPlxChipTest(&DeviceBsp) == TRUE)
                    m_PlxChipEdit = "Passed";
                else
                    m_PlxChipEdit = "Failed";
                pPlxChipButton->SetWindowText(m_PlxChipEdit);
            }

            // PCI LED test
            if (m_LedCheck == TRUE)
            {
                CheckAbort();
                if(AbortTest == TRUE)
                   return;

			    CButton * pLedButton = (CButton *)GetDlgItem(IDC_LED_BUTTON);
            
                m_TestResultEdit = "PCI Led Test";
                pDetailsButton->SetWindowText(m_TestResultEdit);

                m_LedEdit = "Testing";
                pLedButton->SetWindowText(m_LedEdit);
                HostLedTest();

                m_LedEdit = "Tested";
                pLedButton->SetWindowText(m_LedEdit);     
            }

            // PCI flash test
            if (m_FlashCheck == TRUE)
            {
                CheckAbort();
                if(AbortTest == TRUE)
                   return;

			    CButton * pFlashButton = (CButton *)GetDlgItem(IDC_FLASH_BUTTON);
            
                m_TestResultEdit = "PCI Flash Test";
                pDetailsButton->SetWindowText(m_TestResultEdit);

                m_FlashEdit = "Testing";
                pFlashButton->SetWindowText(m_FlashEdit);
                HostFlashTest(&DeviceBsp);

                m_FlashEdit = "Passed";
                pFlashButton->SetWindowText(m_FlashEdit);
            }

            // PCI RAM 0 test
            if (m_SdramCheck == TRUE)
            {
                CheckAbort();
                if(AbortTest == TRUE)
                   return;
			    
			    CButton * pSdramButton = (CButton *)GetDlgItem(IDC_SDRAM_BUTTON);
                m_TestResultEdit = "PCI RAM 0 Test";
                pDetailsButton->SetWindowText(m_TestResultEdit);

                m_SdramEdit = "Testing";
                pSdramButton->SetWindowText(m_SdramEdit);
 
			    if ((DeviceBsp.device.DeviceId == PLX_9030RDK_LITE_DEVICE_ID)||
				    (DeviceBsp.device.DeviceId == PLX_CPCI9030RDK_LITE_DEVICE_ID)||
                    (DeviceBsp.device.DeviceId == PLX_9056RDK_LITE_DEVICE_ID))
			    {
				    StartOffset = 0;
			    }
			    else //other RDKs
			    {
				    StartOffset = 0x100000;
			    }

			    LogWrite("Host RAM 0 Test         : Start\n\r");

			    ReturnValue =
                    NewMemTest(
                        "Host RAM 0 Test: 0x", 
						DeviceBsp.DramBase + StartOffset,
						DeviceBsp.DramBase + (DeviceBsp.DramSize),
						100
                        );

                if (ReturnValue != 0)
                {
                    LogWrite("Host SDRAM Test         : Failed\n\r");
                    m_SdramEdit = "Failed";
                }
                else
                {
                    LogWrite("Host RAM 0 Test         : Passed\n\r");
                    m_SdramEdit = "Passed";
                }
                pSdramButton->SetWindowText(m_SdramEdit);
            }

            // PCI RAM 1 test
            if (m_SbsramCheck == TRUE)
            {
                CheckAbort();
                if(AbortTest == TRUE)
                   return;
			    
			    CButton * pSbsramButton = (CButton *)GetDlgItem(IDC_SBSRAM_BUTTON);
                m_TestResultEdit = "PCI RAM 1 Test";
                pDetailsButton->SetWindowText(m_TestResultEdit);

                m_SbsramEdit = "Testing";
                pSbsramButton->SetWindowText(m_SbsramEdit);
            
                LogWrite("Host RAM 1 Test         : Start\n\r");

			    // Enable BTERM#
			    RegValue =
                    PlxRegisterRead(
                        PlxHandle,
                        PCI9054_SPACE0_ROM_DESC,
                        &rc
                        );

			    PlxRegisterWrite(
                    PlxHandle,
                    PCI9054_SPACE0_ROM_DESC,
                    RegValue | (1 << 7)
                    );

                ReturnValue =
                    NewMemTest(
                        "Host RAM 1 Test: 0x", 
						DeviceBsp.SramBase,
						DeviceBsp.SramBase + DeviceBsp.SramSize,
						0x100
                        );

                if (ReturnValue != 0)
                {
                    LogWrite("Host RAM 1 Test         : Failed\n\r");
                    m_SbsramEdit = "Failed";
                }
                else
                {
                    LogWrite("Host RAM 1 Test         : Passed\n\r");
                    m_SbsramEdit = "Passed";
                }
                pSbsramButton->SetWindowText(m_SbsramEdit);

			    // Disable BTERM#
			    PlxRegisterWrite(
                    PlxHandle,
                    PCI9054_SPACE0_ROM_DESC,
                    RegValue & ~(1 << 7)
                    );
            }

            // PCI VPD test
            if (m_VpdCheck == TRUE)
            {
                CButton * pVpdButton = (CButton *)GetDlgItem(IDC_VPD_BUTTON);
                m_TestResultEdit = "PCI VPD Test";
                pDetailsButton->SetWindowText(m_TestResultEdit);

                m_VpdEdit = "Testing";
                pVpdButton->SetWindowText(m_VpdEdit);
                LogWrite("Host VPD Test           : Start\n\r");

                if (HostVpdTest(&DeviceBsp)==FALSE)
                {
                    LogWrite("Host VPD Test           : Failed\n\r");
                    m_VpdEdit = "Failed";
                }
                else
                {
                    LogWrite("Host VPD Test           : Passed\n\r");
                    m_VpdEdit = "Passed";
                }
                pVpdButton->SetWindowText(m_VpdEdit);
            }

		    // Host Power Management test
            if (m_PowerMCheck == TRUE)
            {
                CButton * pPowerMButton = (CButton *)GetDlgItem(IDC_POWERM_BUTTON);
                m_TestResultEdit = "PCI Power Mngment Test";
                pDetailsButton->SetWindowText(m_TestResultEdit);

                m_PowerMEdit = "Testing";
                pPowerMButton->SetWindowText(m_PowerMEdit);

                LogWrite("Host Power Mngmnt Test  : Start\n\r");

                if (HostPowerMTest(&DeviceBsp)==FALSE)
                {
                    LogWrite("Host Power Mngmnt Test  : Failed\n\r");
                    m_PowerMEdit = "Failed";
                }
                else
                {
                    LogWrite("Host Power Mngmnt Test  : Passed\n\r");
                    m_PowerMEdit = "Passed";
                }
                pPowerMButton->SetWindowText(m_PowerMEdit);
            }

        }

        
        /**************************************************
         *          Start Local Tests
         **************************************************/

        // If any Local tests,initialize message transport and download Local test code
        if (EnableAll         == TRUE ||
            EnableIop         == TRUE ||
            m_IopPlxChipCheck == TRUE ||
            m_IopLedCheck     == TRUE ||
            m_IopFlashCheck   == TRUE ||
            m_IopSdramCheck   == TRUE ||
            m_IopSbsramCheck  == TRUE ||
            m_IopUartCheck    == TRUE
            )
        {
            CheckAbort();
            if(AbortTest == TRUE)
               return;

		    // Initialize message transport
            MsgInitialize(
                PlxHandle
                );

            // Download IOP Test Application
            m_TestResultEdit="Download Local Tests to RAM...";
            pDetailsButton->SetWindowText(m_TestResultEdit);
			
			CElfLoader	elLoader(
							PlxHandle,
							&DeviceBsp
							);

			if (!elLoader.DownloadElfImage(0))
            {
                m_TestResultEdit="Download Local Tests to RAM failed";
                pDetailsButton->SetWindowText(m_TestResultEdit);
                return;
            }

            // IOP PLX Chip Test
            if (m_IopPlxChipCheck == TRUE)
            {
			    CButton * pIopPlxChipButton = (CButton *)GetDlgItem(IDC_IOPPLXCHIP_BUTTON);
                m_TestResultEdit="Local PLX Chip Test...";
                pDetailsButton->SetWindowText(m_TestResultEdit);

                m_IopPlxChipEdit = "Testing";
                pIopPlxChipButton->SetWindowText(m_IopPlxChipEdit);

                if (IopTest(
                        "Local PLX Chip Test     : ",
                        MSG_CMD_TEST_PLX_CHIP,
                        MSG_DATA_NONE,
                        TIMEOUT_TEST_PLX_CHIP
                        ) == TRUE)
                {
                    m_IopPlxChipEdit = "Passed";
                }
                else
                {
                    m_IopPlxChipEdit = "Failed";
				    Failed = TRUE;
                }
                pIopPlxChipButton->SetWindowText(m_IopPlxChipEdit);

			    CheckAbort();
			    if(AbortTest == TRUE)
    			    return;
            }

            if (m_IopLedCheck == TRUE)
            {
			    CButton * pIopLedButton = (CButton *)GetDlgItem(IDC_IOPLED_BUTTON);
                m_TestResultEdit="Local LED Test...";
                pDetailsButton->SetWindowText(m_TestResultEdit);

                m_IopLedEdit = "Testing";
                pIopLedButton->SetWindowText(m_IopLedEdit);

                if (IopTest(
                        "Local LED Test          : ",
                        MSG_CMD_TEST_LED,
                        MSG_DATA_NONE,
                        TIMEOUT_TEST_LED
                        ) == TRUE)
                {
                    m_IopLedEdit = "Passed";
                }
                else
                {
                    m_IopLedEdit = "Failed";
				    Failed = TRUE;
                }
                pIopLedButton->SetWindowText(m_IopLedEdit);

			    CheckAbort();
			    if(AbortTest == TRUE)
    			    return;
            }

            if (m_IopFlashCheck == TRUE)
            {
                CButton * pIopFlashButton = (CButton *)GetDlgItem(IDC_IOPFLASH_BUTTON);
                m_TestResultEdit="Local Flash Test...";
                pDetailsButton->SetWindowText(m_TestResultEdit);

                m_IopFlashEdit = "Testing";
                pIopFlashButton->SetWindowText(m_IopFlashEdit);

                if (IopTest(
                        "Local Flash Test        : ",
                        MSG_CMD_TEST_FLASH,
                        MSG_DATA_NONE,
                        TIMEOUT_TEST_FLASH
                        ) == TRUE)
                {
                    m_IopFlashEdit = "Passed";
                }
                else
                {
                    m_IopFlashEdit = "Failed";
				    Failed = TRUE;
                }
                pIopFlashButton->SetWindowText(m_IopFlashEdit);

			    CheckAbort();
			    if (AbortTest == TRUE)
    			    return;
            }

            if (m_IopSdramCheck == TRUE)
            {
			    CButton * pIopSdramButton = (CButton *)GetDlgItem(IDC_IOPSDRAM_BUTTON);
                m_TestResultEdit="Local RAM 0 Test...";
                pDetailsButton->SetWindowText(m_TestResultEdit);

                m_IopSdramEdit = "Testing";
                pIopSdramButton->SetWindowText(m_IopSdramEdit);

                if (IopTest(
                        "Local RAM 0 Test        : ",
                        MSG_CMD_TEST_DRAM,
                        MSG_DATA_NONE,
                        TIMEOUT_TEST_DRAM
                        ) == TRUE)
                {
                    m_IopSdramEdit = "Passed";
                }
                else
                {
                    m_IopSdramEdit = "Failed";
				    Failed = TRUE;
                }
                pIopSdramButton->SetWindowText(m_IopSdramEdit);

			    CheckAbort();
                if (AbortTest == TRUE)
                    return;
            }

		    if (m_IopSbsramCheck == TRUE)
            {
			    CButton * pIopSbsramButton = (CButton *)GetDlgItem(IDC_IOPSBSRAM_BUTTON);
                m_TestResultEdit="Local RAM 1 Test...";
                pDetailsButton->SetWindowText(m_TestResultEdit);

                m_IopSbsramEdit = "Testing";
                pIopSbsramButton->SetWindowText(m_IopSbsramEdit);

                if (IopTest(
                        "Local RAM 1 Test        : ",
                        MSG_CMD_TEST_SRAM,
                        MSG_DATA_NONE,
                        TIMEOUT_TEST_SRAM
                        ) == TRUE)
                {
                    m_IopSbsramEdit = "Passed";
                }
                else
                {
                    m_IopSbsramEdit = "Failed";
				    Failed = TRUE;
                }
                pIopSbsramButton->SetWindowText(m_IopSbsramEdit);

			    CheckAbort();
                if(AbortTest == TRUE)
                    return;
            }

            if (m_IopUartCheck == TRUE)
            {
                CButton * pIopUartButton = (CButton *)GetDlgItem(IDC_IOPUART_BUTTON);
                m_TestResultEdit="Local Serial Port Test...";
                pDetailsButton->SetWindowText(m_TestResultEdit);

                m_IopUartEdit = "Testing";
                pIopUartButton->SetWindowText(m_IopUartEdit);

                if (IopTest(
                        "Local Serial Port 0 Test: ",
                        MSG_CMD_TEST_UART,
                        MSG_DATA_NONE,
                        TIMEOUT_TEST_UART
                        ) == TRUE)
                {
                    m_IopUartEdit = "Passed";
                }
                else
                {
                    m_IopUartEdit = "Failed";
				    Failed = TRUE;
                }
                pIopUartButton->SetWindowText(m_IopUartEdit);
            }
        }

        //Hot Swap test
        if (m_HotSwapCheck == TRUE)
        {
		    CheckAbort();
            if(AbortTest == TRUE)
               return;
        
		    CButton * pHotSwapButton = (CButton *)GetDlgItem(IDC_HOTSWAP_BUTTON);
            m_TestResultEdit = "PCI Hot Swap Test";
            pDetailsButton->SetWindowText(m_TestResultEdit);

            m_HotSwapEdit = "Testing";
            pHotSwapButton->SetWindowText(m_HotSwapEdit);

            LogWrite("Host Hot Swap Test      : Start\n\r");

            if (HotSwapTest()==FALSE)
            {
                TimerCheck = PlxRegisterRead(PlxHandle, PCI9054_MAILBOX6, &rc);
			    if(TimerCheck == 0x00abcdef)
			    {
				    LogWrite("Host Hot Swap Test      : Timeout\n\r");
				    m_HotSwapEdit = "Timeout";
				    pHotSwapButton->SetWindowText(m_HotSwapEdit);
			    }
			    else
			    {
				    LogWrite("Host Hot Swap Test   : Failed\n\r");
				    m_HotSwapEdit = "Failed";
				    pHotSwapButton->SetWindowText(m_HotSwapEdit);
				    m_TestResultEdit = "Failed to reopen the device";
                    pDetailsButton->SetWindowText(m_TestResultEdit);
				    Sleep(5000);
				    Failed = TRUE;
				    return;
			    }
            }
            else
            {
                LogWrite("Host Hot Swap Test      : Passed\n\r");
                m_HotSwapEdit = "Passed";
                pHotSwapButton->SetWindowText(m_HotSwapEdit);
			    Sleep(2000);
            }
        }
    }

    //Tests complete
	_itoa(loop-1, buf, 10);
    sprintf(Buffer, "Manufacture Test Complete.  LoopCount ");
	strcat(Buffer, buf);

    pDetailsButton->SetWindowText(Buffer);
    UpdateData(FALSE);
    ResetBoard(&DeviceBsp);
}




S32 CManfGUIDlg::NewMemTest(CHAR *text, U32 StartAddr, U32 EndAddr, U32 MaxErrors)
{
    U32                totalErrors = 0;
    U32                InBlockStartAddr;
    U32                LocalAddress;
    U32                ValueRead;
    U32                CurOffset;
    U32                CurAddr;
    U32                blockSize;
    U32                oldRemap;
    char               buffer[20];
	BOOL			   Error = FALSE;
    RETURN_CODE        rc;
    VIRTUAL_ADDRESSES  virtualAddr;


    // Save current register 
    oldRemap =
        PlxRegisterRead(
            PlxHandle,
            RegisterOffset.Space0Remap,
            &rc
            );

	// Get Space0 Base Address 
    PlxPciBaseAddressesGet(
        PlxHandle,
        &virtualAddr
        );

    // Get block size from range register
    blockSize =
        ~PlxRegisterRead(
             PlxHandle,
             RegisterOffset.Space0Range,
             &rc
             );

	if ((blockSize & 0xf0000000) &&	
	    ((DeviceBsp.device.DeviceId == PLX_9030RDK_LITE_DEVICE_ID) ||
		 (DeviceBsp.device.DeviceId == PLX_CPCI9030RDK_LITE_DEVICE_ID)))
	{
		blockSize &= 0x0fffffff;
	}

    InBlockStartAddr = (blockSize & StartAddr),

	// Map to test memory address
	PlxRegisterWrite(
        PlxHandle,
        RegisterOffset.Space0Remap,
        (StartAddr & ~blockSize) | SPACE_ENABLE
        );

    if (DeviceBsp.device.DeviceId == PLX_IOP480RDK_DEVICE_ID)
    {
        CurAddr = virtualAddr.Va1 + InBlockStartAddr; // & blockSize);
    }
    else
    {
        CurAddr = virtualAddr.Va2 + InBlockStartAddr; // & blockSize);
    }


    CButton * pDisplay = (CButton *)GetDlgItem(IDC_DETAILS_BUTTON);
    
    totalErrors = 0;
    EndAddr = EndAddr - StartAddr;

    for (CurOffset=0; CurOffset<EndAddr; CurOffset+=DeviceBsp.MemType, CurAddr+=DeviceBsp.MemType)
    {
        LocalAddress = InBlockStartAddr + CurOffset;
		Error = FALSE;

		if ((!(LocalAddress & blockSize))&(CurOffset != 0))
		{
			PlxRegisterWrite(PlxHandle, RegisterOffset.Space0Remap, (LocalAddress) | SPACE_ENABLE);
			if(DeviceBsp.device.DeviceId == PLX_IOP480RDK_DEVICE_ID)
            {       
                // IOP480 BAR1 point to space1
                CurAddr = virtualAddr.Va1;
            }
            else
            {
                CurAddr = virtualAddr.Va2;
            }
		}

		if (!(LocalAddress & 0xffff))
		{
			CheckAbort();
			if(AbortTest == TRUE)
                return 0;	

			_itoa(LocalAddress, buffer, 16);
			sprintf(LogBuffer, "Ram Test : 0x");
			strcat(LogBuffer, buffer);
			pDisplay->SetWindowText(LogBuffer);
		}

		if(DeviceBsp.MemType == MEM_TYPE_32_BIT)
		{
			*(U32 *)CurAddr = LocalAddress;
			ValueRead = *(U32 *)CurAddr;
			if(ValueRead != LocalAddress)
			{
				Error = TRUE;
				totalErrors++;
				
			}
			else
			{
				*(U32 *)CurAddr = ~LocalAddress;
				ValueRead = *(U32 *)CurAddr;
				if(ValueRead != ~LocalAddress)
				{
					Error = TRUE;
					totalErrors++;
				}
				else
				{
					*(U32 *)CurAddr = LocalAddress;
				}
			}
		}
		else if(DeviceBsp.MemType == MEM_TYPE_16_BIT)
		{
			*(U16 *)CurAddr = (U16)LocalAddress;
			ValueRead = *(U16 *)CurAddr;
			if(ValueRead != LocalAddress)
			{
				Error = TRUE;
				totalErrors++;
			}
			else
			{
				*(U16 *)CurAddr = ~(U16)LocalAddress;
				ValueRead = *(U16 *)CurAddr;
				if(ValueRead << 16  != ~LocalAddress << 16)
				{
					Error = TRUE;
					totalErrors++;
				}
				else
				{
					*(U16 *)CurAddr = (U16)LocalAddress;
				}
			}
		}
		else if(DeviceBsp.MemType == MEM_TYPE_8_BIT)
		{
			*(U8 *)CurAddr = (U8)LocalAddress;
			ValueRead = *(U8 *)CurAddr;
			if(ValueRead != LocalAddress)
			{
				Error = TRUE;
				totalErrors++;
			}
			else
			{
				*(U8 *)CurAddr = ~(U8)LocalAddress;
				ValueRead = *(U16 *)CurAddr;
				if((U8)ValueRead != ~(U8)LocalAddress)
				{
					Error = TRUE;
					totalErrors++;
				}
				else
				{
					*(U8 *)CurAddr = (U8)LocalAddress;
				}
			}
		}

		if(Error && (totalErrors < MaxErrors))
		{
			LogError(text, ValueRead, oldRemap, LocalAddress);
		}
		else if(totalErrors >= MaxErrors)
			break;
    }

	// Map to test memory address
	PlxRegisterWrite(
        PlxHandle,
        RegisterOffset.Space0Remap,
        (StartAddr & ~blockSize) | SPACE_ENABLE
        );

    if (DeviceBsp.device.DeviceId == PLX_IOP480RDK_DEVICE_ID)
    {
        //IOP480 BAR1 point to space1
        CurAddr = virtualAddr.Va1 + InBlockStartAddr;
    }
    else
    {
        CurAddr = virtualAddr.Va2 + InBlockStartAddr;
    }

	pDisplay->SetWindowText("Data comparision");

    for (CurOffset=0; CurOffset<EndAddr; CurOffset+=DeviceBsp.MemType, CurAddr+=DeviceBsp.MemType)
    {
        LocalAddress = InBlockStartAddr + CurOffset;
		Error = FALSE;

			if ((!(LocalAddress & blockSize))&(CurOffset != 0))
			{
				PlxRegisterWrite(PlxHandle, RegisterOffset.Space0Remap, (LocalAddress) | SPACE_ENABLE);
				if(DeviceBsp.device.DeviceId == PLX_IOP480RDK_DEVICE_ID)
                {       
                     CurAddr = virtualAddr.Va1;
                }
                else
                {
                    CurAddr = virtualAddr.Va2;
                }
			}

			if(DeviceBsp.MemType == MEM_TYPE_32_BIT)
			{
				ValueRead = *(U32 *)CurAddr;
				if(ValueRead != LocalAddress)
				{
					Error = TRUE;
					totalErrors++;
				}
			}
			else if(DeviceBsp.MemType == MEM_TYPE_16_BIT)
			{
				ValueRead = *(U16 *)CurAddr;
				if(ValueRead != LocalAddress)
				{
					Error = TRUE;
					totalErrors++;
				}
			}
			else if(DeviceBsp.MemType == MEM_TYPE_8_BIT)
			{
				ValueRead = *(U8 *)CurAddr;
				if(ValueRead != LocalAddress)
				{
					Error = TRUE;
					totalErrors++;
				}
			}

			if(Error && (totalErrors < MaxErrors))
			{
				LogError(text, ValueRead, oldRemap, LocalAddress);
			}
			else if(totalErrors >= MaxErrors)
				break;

	}

    PlxRegisterWrite(
        PlxHandle,
        RegisterOffset.Space0Remap,
        oldRemap
        );

    return totalErrors;
}



void CManfGUIDlg::LogError(char* text, U32 ValueRead, U32 oldRemap, U32 LocalAddress)
{
    sprintf(LogBuffer, "%s%08x - Failed!      W: %08x  R: %08x\n\r",
            text, LocalAddress, LocalAddress, ValueRead);
    LogWrite(LogBuffer);
}




void CManfGUIDlg::GuiDisable(void)
{
    //Disable all the controls but Exit.
    GetDlgItem(IDC_ENABLEALL_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_CLEARALL_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_ENABLEPCI_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_ENABLEIOP_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_STARTEST_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_STOP_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_LOOPCOUNT_SPIN)->EnableWindow(FALSE);
    GetDlgItem(IDC_LOOPCOUNT_EDIT)->EnableWindow(FALSE);
    GetDlgItem(IDC_LOG_CHECK)->EnableWindow(FALSE);
    
    GetDlgItem(IDC_PLXCHIP_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_LED_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_FLASH_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_SDRAM_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_SBSRAM_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_VPD_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_UART_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_POWERM_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_POM_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_HOTSWAP_BUTTON)->EnableWindow(FALSE);

    GetDlgItem(IDC_IOPPLXCHIP_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPLED_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPFLASH_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPSDRAM_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPSBSRAM_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPVPD_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPUART_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPPOWERM_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPPOM_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPHOTSWAP_BUTTON)->EnableWindow(FALSE);

    GetDlgItem(IDC_PLXCHIP_CHECK)->EnableWindow(FALSE);
    GetDlgItem(IDC_LED_CHECK)->EnableWindow(FALSE);
    GetDlgItem(IDC_FLASH_CHECK)->EnableWindow(FALSE);
    GetDlgItem(IDC_SDRAM_CHECK)->EnableWindow(FALSE);
	GetDlgItem(IDC_SBSRAM_CHECK)->EnableWindow(FALSE);
    GetDlgItem(IDC_VPD_CHECK)->EnableWindow(FALSE);
    GetDlgItem(IDC_POWERM_CHECK)->EnableWindow(FALSE);
    GetDlgItem(IDC_HOTSWAP_CHECK)->EnableWindow(FALSE);

    GetDlgItem(IDC_IOPPLXCHIP_CHECK)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPLED_CHECK)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPFLASH_CHECK)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPSDRAM_CHECK)->EnableWindow(FALSE);
	GetDlgItem(IDC_IOPSBSRAM_CHECK)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPVPD_CHECK)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPUART_CHECK)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPPOWERM_CHECK)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPHOTSWAP_CHECK)->EnableWindow(FALSE);
}




void CManfGUIDlg::OnOpenDevice() 
{
    //Read selected device
 
    UpdateData(TRUE);

    //ResetButtonText();

    CComboBox * pCombo = (CComboBox *)GetDlgItem(IDC_DEVICE_COMBO);
    CButton * pDetailsButton = (CButton*)GetDlgItem(IDC_DETAILS_BUTTON);
    for (UINT i=0; i<DevIndex; i++)
    {
        if (strcmp(CurrentDeviceList[i].DevStr, m_DeviceString)==0)
        {
            DeviceBsp.device.VendorId   = CurrentDeviceList[i].device.VendorId;
            DeviceBsp.device.DeviceId   = CurrentDeviceList[i].device.DeviceId;
            DeviceBsp.device.BusNumber  = CurrentDeviceList[i].device.BusNumber;
            DeviceBsp.device.SlotNumber = CurrentDeviceList[i].device.SlotNumber;
            strcpy((char*)DeviceBsp.device.SerialNumber, "");
            
            if (PlxPciDeviceOpen(&DeviceBsp.device, &PlxHandle) == ApiSuccess)
            {
                if ((DeviceBsp.device.DeviceId == PLX_9054RDK_860_DEVICE_ID) &&
                     (DeviceBsp.device.VendorId == PLX_VENDOR_ID))
                {
					OnEnableallButton();
					
					pDetailsButton->SetWindowText("Press board reset button to reset board, led blinks twice");       
                    UpdateData(FALSE);
                }
				else if((DeviceBsp.device.DeviceId == PLX_CPCI9054RDK_860_DEVICE_ID) &&
                     (DeviceBsp.device.VendorId == PLX_VENDOR_ID))
                {
					OnEnableallButton();
					pDetailsButton->SetWindowText("Press board reset button to reset board, led blinks twice");
                    UpdateData(FALSE);
                }
                //Disable the tests if the selected board is 401B.
                else if ((DeviceBsp.device.DeviceId == PLX_9080RDK_401B_DEVICE_ID) &&
                    (DeviceBsp.device.VendorId == PLX_VENDOR_ID))
                {
					OnEnableallButton();
					pDetailsButton->SetWindowText("Press board reset button to reset board, led blinks twice");
                    UpdateData(FALSE);
                }
				
                else if ((DeviceBsp.device.DeviceId == PLX_IOP480RDK_DEVICE_ID) &&
                    (DeviceBsp.device.VendorId == PLX_VENDOR_ID)) 
				{
					OnEnableallButton();
                    pDetailsButton->SetWindowText("Device IOP480 opened");
                    UpdateData(FALSE);
				}
				else if ((DeviceBsp.device.DeviceId == PLX_9054RDK_LITE_DEVICE_ID) &&
                    (DeviceBsp.device.VendorId == PLX_VENDOR_ID)) 
				{
					OnEnableallButton();
					pDetailsButton->SetWindowText("Device PCI9054 opened");
                    UpdateData(FALSE);
				}
				else if ((DeviceBsp.device.DeviceId == PLX_9030RDK_LITE_DEVICE_ID) ||
					     (DeviceBsp.device.DeviceId == PLX_CPCI9030RDK_LITE_DEVICE_ID) &&
						 (DeviceBsp.device.VendorId == PLX_VENDOR_ID)) 
				{
					OnEnableallButton();
					pDetailsButton->SetWindowText("Device PCI9030 opened");
                    UpdateData(FALSE);
				}
            	else if ((DeviceBsp.device.DeviceId == PLX_9056RDK_LITE_DEVICE_ID
						||  DeviceBsp.device.DeviceId ==PLX_9056RDK_860_DEVICE_ID) &&
						 (DeviceBsp.device.VendorId == PLX_VENDOR_ID)) 
				{
					OnEnableallButton();
					pDetailsButton->SetWindowText("Device PCI9056 opened");
                    UpdateData(FALSE);
				}
                else if ((DeviceBsp.device.DeviceId == PLX_9656RDK_LITE_DEVICE_ID
						||DeviceBsp.device.DeviceId == PLX_9656RDK_860_DEVICE_ID) &&
						 (DeviceBsp.device.VendorId == PLX_VENDOR_ID)) 
                {
					OnEnableallButton();
					pDetailsButton->SetWindowText("Device PCI9656 opened");
                    UpdateData(FALSE);

                }

            }
        }
    }

	ResetButtonText();
    InitializeBsp(&DeviceBsp);
}



BOOL CManfGUIDlg::HostLedTest()
{
    SHORT          NumOfLedBlinks;
    ULONG          oldStatus, NewStatus;
    RETURN_CODE    rc; 

    LogWrite("Host LED Test           : Start\n\r");

    if(DeviceBsp.device.DeviceId == PLX_IOP480RDK_DEVICE_ID)
    {
        oldStatus = PlxRegisterRead(PlxHandle, IOP480_LOCAL_BUS_CTL, &rc);
        //Select and set USER0# direction
        NewStatus = oldStatus|0x0000006;
        PlxRegisterWrite(PlxHandle, IOP480_LOCAL_BUS_CTL, NewStatus);
    }

    NumOfLedBlinks = 1;

    while ((NumOfLedBlinks < 10) && (NumOfLedBlinks > 0))
    {
        if( (DeviceBsp.device.DeviceId == PLX_CPCI9054RDK_860_DEVICE_ID) || 
            (DeviceBsp.device.DeviceId == PLX_9054RDK_860_DEVICE_ID)||
            (DeviceBsp.device.DeviceId == PLX_9080RDK_860_DEVICE_ID) || 
            (DeviceBsp.device.DeviceId == PLX_9080RDK_401B_DEVICE_ID) ||
            (DeviceBsp.device.DeviceId == PLX_9056RDK_LITE_DEVICE_ID) ||
            (DeviceBsp.device.DeviceId == PLX_9656RDK_860_DEVICE_ID) ||
            (DeviceBsp.device.DeviceId == PLX_9656RDK_LITE_DEVICE_ID) ||
            (DeviceBsp.device.DeviceId == PLX_9056RDK_860_DEVICE_ID))

        {
            PlxRegisterWrite(
                PlxHandle,
                PCI9054_EEPROM_CTRL_STAT,
                    PlxRegisterRead(
                        PlxHandle,
                        PCI9054_EEPROM_CTRL_STAT,
                        &rc) & ~((ULONG)1<<16)
                );
	        Sleep(200);
            PlxRegisterWrite(
                PlxHandle,
                PCI9054_EEPROM_CTRL_STAT,
                PlxRegisterRead(
                    PlxHandle,
                    PCI9054_EEPROM_CTRL_STAT,
                    &rc) | (1<<16)
                );
        }
        else
        {
            // LED ON
            PlxRegisterWrite(
                PlxHandle,
                IOP480_LOCAL_BUS_CTL,
                NewStatus | 0x0000008
                );

            Sleep(200);

            // LED Off
            PlxRegisterWrite(
                PlxHandle,
                IOP480_LOCAL_BUS_CTL,
                NewStatus & 0xFFFFFFF7
                );
        }

        Sleep(200);
    
 	    CheckAbort();
	    if (AbortTest == TRUE)
	    {   
            sprintf(LogBuffer, "Host LED Test           : Aborted - flashed LED %i times\n\r", NumOfLedBlinks);
            LogWrite(LogBuffer);
	        return FALSE;	
	    }

	    NumOfLedBlinks++;
    }

    // Return register to old value
    if(DeviceBsp.device.DeviceId == PLX_IOP480RDK_DEVICE_ID)
        PlxRegisterWrite(PlxHandle, IOP480_LOCAL_BUS_CTL, oldStatus);

    if (NumOfLedBlinks > 0)
    {
        sprintf(LogBuffer, "Host LED Test           : Flashed LED %i times\n\r", NumOfLedBlinks);
    }
    else
    {
        sprintf(LogBuffer, "Host LED Test           : Aborted - flashed LED %i times\n\r", -NumOfLedBlinks);
    }

    LogWrite(LogBuffer);
    
    return TRUE;
}




BOOL CManfGUIDlg::HotSwapTest() 
{
    U32		            PciRegisterBlock[0x80];
	U32		            LocRegisterBlock[0x100];
    U8*                 PciReadBuffer;
    U32					bytesWritten;
	U32					RegValue;
    U32					RegOffset;
	UINT			    CurrentDevIndex, i;
	U32					ParityErrClear = 0x80000000;
	U32                 LoopCount = 0;
	RETURN_CODE         rc;
	VIRTUAL_ADDRESSES	virtualAddr;
	HANDLE				hFile;
	clock_t             Timeout = 100;
	char                RegFileName[20];

	CButton * pDetailsButton = (CButton *)GetDlgItem(IDC_DETAILS_BUTTON);  
 
 	// Save all PCI configuration registers 
	for (RegOffset = 0x0; RegOffset < 0x50; RegOffset += 4)
	{
		RegValue =
            PlxPciConfigRegisterRead(
                DeviceBsp.device.BusNumber,
                DeviceBsp.device.SlotNumber,
                RegOffset,
                &rc
                );

	    PciRegisterBlock[RegOffset / 4] = RegValue;

        // Check Hot Swap control register value
        if (RegOffset == PCI9054_HS_CAP_ID)
        {
           RegValue = RegValue | (1 << 23);

           PlxPciConfigRegisterWrite(
               DeviceBsp.device.BusNumber,
               DeviceBsp.device.SlotNumber,
               RegOffset,
               &RegValue
               );

            RegValue =
                PlxPciConfigRegisterRead(
                    DeviceBsp.device.BusNumber,
                    DeviceBsp.device.SlotNumber,
                    RegOffset,
                    &rc
                    );
        }
	}

	// Save Lcr, Rtr, Ldr, Mqr Registers
	PlxPciBaseAddressesGet(
        PlxHandle,
        &virtualAddr
        );

	for (i = 0x0; i<0x100; i+=4)
	{
		LocRegisterBlock[i] = *(U32*)virtualAddr.Va0;
		virtualAddr.Va0 += 4;
	}

	SaveRegs(
        PciRegisterBlock,
        LocRegisterBlock
        );

	// set up time out limit
	Timeout = (clock_t)(Timeout * CLOCKS_PER_SEC) + clock();

	while (BoardIn == TRUE)  //Loop for board removing process.
    {
        //Check hot swap control register bit 23
        RegValue =
            PlxPciConfigRegisterRead(
                DeviceBsp.device.BusNumber,
                DeviceBsp.device.SlotNumber,
                PCI9054_HS_CAP_ID,
                &rc
                );

        if (BoardIn == TRUE && ((BoardOutBitMask & RegValue)!=0)) //Board in and switch is set
        {
            // Turn on LED
            RegValue |= (LedOnMask | BoardOutBitMask);

            PlxPciConfigRegisterWrite(
                DeviceBsp.device.BusNumber,
                DeviceBsp.device.SlotNumber,
                PCI9054_HS_CAP_ID,
                &RegValue
                );

			m_TestResultEdit = "Ready for board remove";
            pDetailsButton->SetWindowText(m_TestResultEdit);
		}
		else if (BoardIn == TRUE && (BoardInBitMask & RegValue)!= 0)
        {
            // Turn off Led
            RegValue &= ~(LedOnMask | BoardInBitMask);
            PlxPciConfigRegisterWrite(
                DeviceBsp.device.BusNumber,
                DeviceBsp.device.SlotNumber,
                PCI9054_HS_CAP_ID,
                &RegValue
                );

            m_TestResultEdit = "Hot Swap Test";
            pDetailsButton->SetWindowText(m_TestResultEdit);
		}

		// Scan bus 0 and 1, make a plx device list. Compare the CurrentDeviceList to the FirstDeviceList

        if ((CurrentDevIndex = SelectDevice(&PlxHandle, CurrentDeviceList)) == DevIndex-1)
        {
            m_TestResultEdit = "Board is removed";
            pDetailsButton->SetWindowText(m_TestResultEdit);
            BoardIn = FALSE;
        }

		if (Timeout <= clock())
		{
			PlxRegisterWrite(
                PlxHandle,
                PCI9054_MAILBOX6,
                0x00abcdef
                );
			return FALSE;
		}
    }

    // Loop for board insertion process
    do
    {
		if ((CurrentDevIndex = SelectDevice(&PlxHandle, CurrentDeviceList)) == DevIndex)
        {
		    for (i=0; i<CurrentDevIndex; i++)
		    {
			    if ((CurrentDeviceList[i].device.DeviceId == PLX_CPCI9054RDK_860_DEVICE_ID) &&
				    (CurrentDeviceList[i].device.VendorId == PLX_VENDOR_ID))
			    {
				    DeviceBsp.device.VendorId   = CurrentDeviceList[i].device.VendorId;
				    DeviceBsp.device.DeviceId   = CurrentDeviceList[i].device.DeviceId;
				    DeviceBsp.device.BusNumber  = CurrentDeviceList[i].device.BusNumber;
				    DeviceBsp.device.SlotNumber = CurrentDeviceList[i].device.SlotNumber;
				    strcpy((char*)DeviceBsp.device.SerialNumber, "");

                    /* Open device */
				    rc =
                        PlxPciDeviceOpen(
                            &DeviceBsp.device,
                            &PlxHandle
                            );
                }
            }

            if (rc != ApiSuccess)
            {
		        m_TestResultEdit = "Device Open Failed ";
                pDetailsButton->SetWindowText(m_TestResultEdit);
                Failed = TRUE;
				return FALSE;
            }
        
            RegValue = PlxPciConfigRegisterRead(DeviceBsp.device.BusNumber, DeviceBsp.device.SlotNumber, PCI9054_HS_CAP_ID, &rc);

            // Turn on LED
            RegValue |= LedOnMask;
            PlxPciConfigRegisterWrite(
                DeviceBsp.device.BusNumber,
                DeviceBsp.device.SlotNumber,
                PCI9054_HS_CAP_ID,
                &RegValue
                );

            //Check if the stored register values are valid
            //If last saved register values are invalid, read from the file Regs9054.val         		    
            sprintf(RegFileName, "Regs9054.val");
            hFile =
                CreateFile(
                    RegFileName,
         			GENERIC_READ,
	    	        0,
					NULL,
					OPEN_EXISTING,
					FILE_ATTRIBUTE_NORMAL,
					NULL
                    );

            PciReadBuffer = (U8*)malloc(0x50*4);
            ReadFile(hFile, PciReadBuffer, 0x50*4, &bytesWritten, NULL);

            for (i=0; i<0x50; i++)
	        {
		        PciRegisterBlock[i] =
                        (U32)PciReadBuffer[4*i]          |
                       ((U32)PciReadBuffer[4*i+1]) <<  8 |
                       ((U32)PciReadBuffer[4*i+2]) << 16 |
                       ((U32)PciReadBuffer[4*i+3]) << 24;
            }

            PciReadBuffer = (U8*)malloc(0x100*4);
            ReadFile(
                hFile,
                PciReadBuffer,
                0x100*4,
                &bytesWritten,
                NULL
                );

            CloseHandle(
                hFile
                );

            for (i=0; i<0x100; i++)
            {
                LocRegisterBlock[i] =
                     (U32)PciReadBuffer[4*i]          |
                    ((U32)PciReadBuffer[4*i+1]) <<  8 |
                    ((U32)PciReadBuffer[4*i+2]) << 16 |
                    ((U32)PciReadBuffer[4*i+3]) << 24;
            }
    	
            //Restore PCI ocnfiguration registers 
            for (RegOffset = 0x50; RegOffset >0x0; RegOffset -= 4)
            {
                //Clear the parity error bit
			    if (RegOffset == 0x4)
			    {
				    PlxPciConfigRegisterWrite(
                        DeviceBsp.device.BusNumber, 
		   				DeviceBsp.device.SlotNumber, 
						RegOffset, 
						&ParityErrClear
                        );

                    PlxPciConfigRegisterWrite(
                        DeviceBsp.device.BusNumber,
                        DeviceBsp.device.SlotNumber,
                        RegOffset,
                        &PciRegisterBlock[RegOffset/4]
                        );
			    }

			    //Keep blue led on
			    else if (RegOffset == 0x48)
			    {
				    PciRegisterBlock[RegOffset/4] |= LedOnMask;
				    PlxPciConfigRegisterWrite(
                        DeviceBsp.device.BusNumber, 
						DeviceBsp.device.SlotNumber, 
						RegOffset, 
						& PciRegisterBlock[RegOffset/4]
                        );
			    }
			    else
			    {
				    rc = PlxPciConfigRegisterWrite(
                             DeviceBsp.device.BusNumber,
                             DeviceBsp.device.SlotNumber,
                             RegOffset,
                             &PciRegisterBlock[RegOffset/4]
                             );

   					if (rc != ApiSuccess)
		            {
                        m_TestResultEdit = "Insertion:Configuration Register Write Failed";
                        pDetailsButton->SetWindowText(m_TestResultEdit);
						Failed = TRUE;
		            }
			    }
            }
		 
            //Restore local registers
            PlxPciBaseAddressesGet(
                PlxHandle,
                &virtualAddr
                );

            for (i = 0x0; i<0x100; i+=4)
            {
                *(U32*)virtualAddr.Va0 = LocRegisterBlock[i];
                virtualAddr.Va0 += 4;
            }
	             
            //Turn off Led
            RegValue &= ~(LedOnMask);
            PlxPciConfigRegisterWrite(
                DeviceBsp.device.BusNumber,
                DeviceBsp.device.SlotNumber,
                PCI9054_HS_CAP_ID,
                &RegValue
                );

            m_TestResultEdit = "Board is inserted";
            pDetailsButton->SetWindowText(m_TestResultEdit);
            BoardIn = TRUE;
        }
    }
    while (BoardIn == FALSE);

	return TRUE;
}



void CManfGUIDlg::CheckAbort() 
{
    MSG message;


    if (::PeekMessage(&message, NULL, 0,  0, PM_REMOVE))
    {
        ::TranslateMessage(&message);
        ::DispatchMessage(&message);
    }
}




void CManfGUIDlg::OnStopButton() 
{
	char buf[10];

    
	CButton * pDetailsButton = (CButton *)GetDlgItem(IDC_DETAILS_BUTTON); 
    AbortTest = TRUE;
    
	_itoa(loop-1, buf, 10);
	sprintf(Buffer, "Test aborted.  Loop# ");
	strcat(Buffer, buf);
	
	if(Failed == TRUE)
	{
		sprintf(buf, "    Failed.");
        strcat(Buffer, buf);
	}
	else
	{
		sprintf(buf, "    Passed.");
        strcat(Buffer, buf);
	}

    pDetailsButton->SetWindowText(Buffer);
}




void CManfGUIDlg::OnDoubleclickedStopButton() 
{
	char buf[10];


	CButton * pDetailsButton = (CButton *)GetDlgItem(IDC_DETAILS_BUTTON); 
    AbortTest = TRUE;

	_itoa(loop-1, buf, 10);
    sprintf(Buffer, "Test aborted.  Loop# ");
	strcat(Buffer, buf);
    
	if(Failed == TRUE)
	{
		sprintf(buf, "    Failed.");
        strcat(Buffer, buf);
	}
	else
	{
		sprintf(buf, "    Passed.");
        strcat(Buffer, buf);
	}

    pDetailsButton->SetWindowText(Buffer);
}




void CManfGUIDlg::OnBoardConfigButton() 
{
	m_dlg.DoModal();
}



void CManfGUIDlg::ResetButtonText()
{
    m_PlxChipEdit = "Not Tested"; 
    CButton *pPlxChipButton = (CButton *)GetDlgItem(IDC_PLXCHIP_BUTTON);
    pPlxChipButton->SetWindowText(m_PlxChipEdit);
    m_LedEdit = "Not Tested";
    CButton * pLedButton  = (CButton *)GetDlgItem(IDC_LED_BUTTON) ;
    pLedButton->SetWindowText(m_LedEdit);
    m_FlashEdit = "Not Tested";
    CButton *  pFlashButton = (CButton *)GetDlgItem(IDC_FLASH_BUTTON);  
    pFlashButton->SetWindowText(m_FlashEdit);
    m_SdramEdit = "Not Tested";
    CButton *pSdramButton = (CButton *)GetDlgItem(IDC_SDRAM_BUTTON);
    pSdramButton->SetWindowText(m_SdramEdit);
    m_SbsramEdit = "Not Tested";
    CButton * pSbsramButton = (CButton *)GetDlgItem(IDC_SBSRAM_BUTTON);
    pSbsramButton->SetWindowText(m_SbsramEdit);
	m_VpdEdit = "Not Tested";
    CButton *pVpdButton = (CButton *)GetDlgItem(IDC_VPD_BUTTON);
    pVpdButton->SetWindowText(m_VpdEdit);

    m_UartEdit = "N/A";
    m_PowerMEdit = "Not Tested";
    CButton *pPmButton = (CButton *)GetDlgItem(IDC_POWERM_BUTTON);
    pPmButton->SetWindowText(m_PowerMEdit);
    m_HotSwapEdit = "Not Tested";
    CButton *pHsButton = (CButton *)GetDlgItem(IDC_HOTSWAP_BUTTON);
    pHsButton->SetWindowText(m_HotSwapEdit);
    m_PomEdit = "N/A";

    m_IopPlxChipEdit = "Not Tested";
    CButton *pIopChipButton = (CButton *)GetDlgItem(IDC_IOPPLXCHIP_BUTTON);
    pIopChipButton->SetWindowText(m_IopPlxChipEdit);
    m_IopLedEdit = "Not Tested";
    CButton * pIopLedButton = (CButton *)GetDlgItem(IDC_IOPLED_BUTTON);
    pIopLedButton->SetWindowText(m_IopLedEdit);
    m_IopFlashEdit = "Not Tested";
    CButton * pIopFlashButton = (CButton *)GetDlgItem(IDC_IOPFLASH_BUTTON);
    pIopFlashButton->SetWindowText(m_IopFlashEdit);
    m_IopSdramEdit = "Not Tested";
    CButton * pIopSdramButton = (CButton *)GetDlgItem(IDC_IOPSDRAM_BUTTON);
    pIopSdramButton->SetWindowText(m_IopSdramEdit);
    m_IopSbsramEdit = "Not Tested";
    CButton * pIopSbsramButton = (CButton *)GetDlgItem(IDC_IOPSBSRAM_BUTTON);
    pIopSbsramButton->SetWindowText(m_IopSbsramEdit);

    m_IopUartEdit = "Not Tested";
    CButton * pIopUartButton = (CButton *)GetDlgItem(IDC_IOPUART_BUTTON);
	pIopUartButton->SetWindowText(m_IopUartEdit);

    if ((DeviceBsp.device.DeviceId == PLX_9030RDK_LITE_DEVICE_ID)||
		(DeviceBsp.device.DeviceId == PLX_CPCI9030RDK_LITE_DEVICE_ID))
	{
		SetDlgItemText(IDC_DRAM_STATIC,  "DPRAM");
	}
	else
	{
		SetDlgItemText(IDC_DRAM_STATIC,  "DRAM");
	}
}




void CManfGUIDlg::OnCofElf() 
{
}




void CManfGUIDlg::DisableIopTests()
{
    //Disable all IOP tests. 
    GetDlgItem(IDC_IOPPLXCHIP_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPLED_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPFLASH_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPSDRAM_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPSBSRAM_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPVPD_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPUART_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPPOWERM_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPPOM_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPHOTSWAP_BUTTON)->EnableWindow(FALSE);

    GetDlgItem(IDC_IOPPLXCHIP_CHECK)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPLED_CHECK)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPFLASH_CHECK)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPSDRAM_CHECK)->EnableWindow(FALSE);
	GetDlgItem(IDC_IOPSBSRAM_CHECK)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPVPD_CHECK)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPUART_CHECK)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPPOWERM_CHECK)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPHOTSWAP_CHECK)->EnableWindow(FALSE);
}




void CManfGUIDlg::ButtonInitialization()
{
    //Initialize the test edit boxes before test
    m_PlxChipEdit = "Not Tested"; 
    m_LedEdit = "Not Tested";
    m_FlashEdit = "Not Tested";
    m_SdramEdit = "Not Tested";
    m_SbsramEdit = "Not Tested";
	m_VpdEdit = "Not Tested";
    m_UartEdit = "N/A";
    m_PowerMEdit = "Not Tested";
    m_HotSwapEdit = "Not Tested";
    m_PomEdit = "N/A";

    m_IopPlxChipEdit = "Not Tested"; 
    m_IopLedEdit = "Not Tested";
    m_IopFlashEdit = "Not Tested";
    m_IopSdramEdit = "Not Tested";
    m_IopSbsramEdit = "Not Tested"; 
    m_IopVpdEdit = "Not Tested";
    m_IopUartEdit = "Not Tested";
    m_IopPowerMEdit = "N/A"; 
    m_IopPomEdit = "N/A";

    //Disable not available tests
    GetDlgItem(IDC_UART_CHECK)->EnableWindow(FALSE);
    GetDlgItem(IDC_POM_CHECK)->EnableWindow(FALSE);
    
    GetDlgItem(IDC_IOPVPD_CHECK)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPHOTSWAP_CHECK)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPPOWERM_CHECK)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPPOM_CHECK)->EnableWindow(FALSE);

    //Set loop counter
    m_LoopCount = 1;
    CSpinButtonCtrl* pSpin = (CSpinButtonCtrl*)GetDlgItem(IDC_LOOPCOUNT_SPIN);
    pSpin->SetRange(1, 1000000);
    
    //Set log to file
    m_LogCheck = TRUE;
}




void CManfGUIDlg::EnablePciButtons()
{
	GetDlgItem(IDC_PLXCHIP_BUTTON)->EnableWindow(TRUE);
    GetDlgItem(IDC_LED_BUTTON)->EnableWindow(TRUE);
    GetDlgItem(IDC_FLASH_BUTTON)->EnableWindow(TRUE);
    GetDlgItem(IDC_SDRAM_BUTTON)->EnableWindow(TRUE);
    GetDlgItem(IDC_SBSRAM_BUTTON)->EnableWindow(TRUE);
    GetDlgItem(IDC_VPD_BUTTON)->EnableWindow(TRUE);
    GetDlgItem(IDC_UART_BUTTON)->EnableWindow(TRUE);
    GetDlgItem(IDC_POWERM_BUTTON)->EnableWindow(TRUE);
    GetDlgItem(IDC_POM_BUTTON)->EnableWindow(TRUE);
    GetDlgItem(IDC_HOTSWAP_BUTTON)->EnableWindow(TRUE);

    GetDlgItem(IDC_PLXCHIP_CHECK)->EnableWindow(TRUE);
    GetDlgItem(IDC_LED_CHECK)->EnableWindow(TRUE);
    GetDlgItem(IDC_FLASH_CHECK)->EnableWindow(TRUE);
    GetDlgItem(IDC_SDRAM_CHECK)->EnableWindow(TRUE);
	GetDlgItem(IDC_SBSRAM_CHECK)->EnableWindow(TRUE);
    GetDlgItem(IDC_VPD_CHECK)->EnableWindow(TRUE);
    GetDlgItem(IDC_POWERM_CHECK)->EnableWindow(TRUE);
    GetDlgItem(IDC_HOTSWAP_CHECK)->EnableWindow(TRUE);
    GetDlgItem(IDC_UART_CHECK)->EnableWindow(TRUE);
    GetDlgItem(IDC_POM_CHECK)->EnableWindow(TRUE);
}




void CManfGUIDlg::EnableIopButtons()
{
    GetDlgItem(IDC_IOPPLXCHIP_BUTTON)->EnableWindow(TRUE);
    GetDlgItem(IDC_IOPLED_BUTTON)->EnableWindow(TRUE);
    GetDlgItem(IDC_IOPFLASH_BUTTON)->EnableWindow(TRUE);
    GetDlgItem(IDC_IOPSDRAM_BUTTON)->EnableWindow(TRUE);
    GetDlgItem(IDC_IOPSBSRAM_BUTTON)->EnableWindow(TRUE);
    GetDlgItem(IDC_IOPVPD_BUTTON)->EnableWindow(TRUE);
    GetDlgItem(IDC_IOPUART_BUTTON)->EnableWindow(TRUE);
    GetDlgItem(IDC_IOPPOWERM_BUTTON)->EnableWindow(TRUE);
    GetDlgItem(IDC_IOPPOM_BUTTON)->EnableWindow(TRUE);
    GetDlgItem(IDC_IOPHOTSWAP_BUTTON)->EnableWindow(TRUE);

    GetDlgItem(IDC_IOPPLXCHIP_CHECK)->EnableWindow(TRUE);
    GetDlgItem(IDC_IOPLED_CHECK)->EnableWindow(TRUE);
    GetDlgItem(IDC_IOPFLASH_CHECK)->EnableWindow(TRUE);
    GetDlgItem(IDC_IOPSDRAM_CHECK)->EnableWindow(TRUE);
	GetDlgItem(IDC_IOPSBSRAM_CHECK)->EnableWindow(TRUE);
    GetDlgItem(IDC_IOPUART_CHECK)->EnableWindow(TRUE);
    GetDlgItem(IDC_IOPPOWERM_CHECK)->EnableWindow(TRUE);
    GetDlgItem(IDC_IOPHOTSWAP_CHECK)->EnableWindow(TRUE);
    GetDlgItem(IDC_IOPVPD_CHECK)->EnableWindow(TRUE);
    GetDlgItem(IDC_IOPPOM_CHECK)->EnableWindow(TRUE);
}




void CManfGUIDlg::DisableAll()
{
	GetDlgItem(IDC_PLXCHIP_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_LED_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_FLASH_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_SDRAM_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_SBSRAM_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_VPD_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_UART_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_POWERM_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_POM_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_HOTSWAP_BUTTON)->EnableWindow(FALSE);

    GetDlgItem(IDC_IOPPLXCHIP_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPLED_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPFLASH_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPSDRAM_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPSBSRAM_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPVPD_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPUART_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPPOWERM_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPPOM_BUTTON)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPHOTSWAP_BUTTON)->EnableWindow(FALSE);

    GetDlgItem(IDC_PLXCHIP_CHECK)->EnableWindow(FALSE);
    GetDlgItem(IDC_LED_CHECK)->EnableWindow(FALSE);
    GetDlgItem(IDC_FLASH_CHECK)->EnableWindow(FALSE);
    GetDlgItem(IDC_SDRAM_CHECK)->EnableWindow(FALSE);
	GetDlgItem(IDC_SBSRAM_CHECK)->EnableWindow(FALSE);
    GetDlgItem(IDC_VPD_CHECK)->EnableWindow(FALSE);
    GetDlgItem(IDC_POWERM_CHECK)->EnableWindow(FALSE);
    GetDlgItem(IDC_HOTSWAP_CHECK)->EnableWindow(FALSE);
    GetDlgItem(IDC_UART_CHECK)->EnableWindow(FALSE);
    GetDlgItem(IDC_POM_CHECK)->EnableWindow(FALSE);

    GetDlgItem(IDC_IOPPLXCHIP_CHECK)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPLED_CHECK)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPFLASH_CHECK)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPSDRAM_CHECK)->EnableWindow(FALSE);
	GetDlgItem(IDC_IOPSBSRAM_CHECK)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPUART_CHECK)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPPOWERM_CHECK)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPHOTSWAP_CHECK)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPVPD_CHECK)->EnableWindow(FALSE);
    GetDlgItem(IDC_IOPPOM_CHECK)->EnableWindow(FALSE);

    m_PlxChipCheck = FALSE;
    m_LedCheck     = FALSE;
    m_FlashCheck   = FALSE;
    m_SdramCheck   = FALSE;
    m_SbsramCheck  = FALSE;
    m_VpdCheck     = FALSE;
    m_PowerMCheck  = FALSE;
	m_UartCheck    = FALSE;
	m_PomCheck     = FALSE;
	m_HotSwapCheck = FALSE;

    m_IopPlxChipCheck = FALSE;
    m_IopLedCheck     = FALSE;
    m_IopFlashCheck   = FALSE;
	m_IopSdramCheck   = FALSE;
    m_IopSbsramCheck  = FALSE;
    m_IopVpdCheck     = FALSE;
    m_IopPowerMCheck  = FALSE;
	m_IopUartCheck    = FALSE;
	m_IopPomCheck     = FALSE;
	m_IopHotSwapCheck = FALSE;
}
