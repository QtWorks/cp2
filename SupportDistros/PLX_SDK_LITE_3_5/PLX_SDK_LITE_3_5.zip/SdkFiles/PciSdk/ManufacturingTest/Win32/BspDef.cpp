#include "stdafx.h"
#include "plxtypes.h"
#include "BspDef.h"




    
BOOL
CBspDef::ReadBspFile(
    void
    )
{
    DWORD   dwFileSize(0);
    char    *pBuffer;
    
    if(!hFile.Open(
                szFileName,
                CFile::modeRead
                ))
    {
        return FALSE;
    }

    dwFileSize      =   hFile.GetLength();
    
    if(!dwFileSize) return FALSE;

    pBuffer     =   new char[dwFileSize];

    if(hFile.Read(
                pBuffer,
                dwFileSize
                ) != dwFileSize)
    {
        delete [] pBuffer;
        hFile.Close();
        return FALSE;
    }

    szBuffer    =   pBuffer;
    delete [] pBuffer;
    hFile.Close();
    return TRUE;
}

BOOL
CBspDef::WriteBspFile(
	void
	)
{
    return TRUE;
}




CBspDef::CBspDef(
	CString	szFName
	)
    :   szFileName(szFName),
        fpCurr(ST_UNKNOWN),
        bTest(FALSE)
{


}

BOOL
CBspDef::InitBspFromFile(
	U32		*pBsp,
	U8		*pTestVec,
    U32&    UDevID
	)
{
    
    U32     uCurrVal(0);
    U32     nBoardIndex(0);
    U32     uTestIndex(0);


    if(!ReadBspFile())
        return FALSE;

    UDevID   =   GetNextElement();
    
    if(fpCurr   !=  ST_ELEMENT)
        return FALSE;
    

    while(1)
    {
        uCurrVal    =   GetNextElement();

        if(fpCurr   ==  ST_EOF)
        {
            return TRUE;
        }
        else if(fpCurr   !=  ST_ELEMENT)
        {
            return FALSE;
        }


        switch(bTest)
        {
        case 0:
            if(nBoardIndex < BSP_ELEMENT_CNT)
            {
                *(pBsp+nBoardIndex) = uCurrVal;
                nBoardIndex++;
                if(nBoardIndex > 0xf)
                    bTest = TRUE;
            }
            else
                return FALSE;
            break;

        case 1:
            if(uTestIndex < BSP_TEST_CNT)
            {
                *(pTestVec+uTestIndex)  =   (U8)(uCurrVal & 0xFF);
                uTestIndex++;
            }
            else
            {
                return FALSE;
            }
            break;
        }
    }



}




BOOL
CBspDef::WriteBspFile(
	const U32* const    pBsp,
	char                *pTestVec,
    U32                 Devid
	)
{
    
    CString     szTemp;
    CString     nl;         //new line
    int         nIndex(0);
    int         nFLen(0);    

    //init variables before their use
    szBuffer    =   CString();  
    nl          +=   char(10);
    nl          +=  char(13);


    //try to open the file 
    if(!hFile.Open(
            szFileName,
            CFile::modeWrite | CFile::modeCreate
            ))
    {
        return FALSE;
    }

    //buffer the Bsp definetion
    szBuffer    +=  ";this file contains the Plx Board diffinetion for the Plx Manufacturing test.";
    szBuffer    +=  nl;

    szBuffer    +=  ";begin bsp definetion" +   nl;
    
    szBuffer    +=  "#BEGIN" + nl;

    szTemp.Format("%010d",Devid);
    szBuffer    +=  "DevId=" + szTemp + nl;
    szBuffer    +=  "PlxChipType=";
    szTemp.Format("%010d",pBsp[nIndex++]);
    szBuffer    +=   szTemp + nl;
    
    szBuffer    +=  "PlxChipBase=";
    szTemp.Format("%010d",pBsp[nIndex++]);
    szBuffer    +=   szTemp + nl;

    szBuffer    +=  "Ram_0_Base=";
    szTemp.Format("%010d",pBsp[nIndex++]);
    szBuffer    +=  szTemp + nl;

    szBuffer    +=  "Ram_0_Size=";
    szTemp.Format("%010d",pBsp[nIndex++]);
    szBuffer    +=  szTemp + nl;

    szBuffer    +=  "Ram_1_Base=";
    szTemp.Format("%010d",pBsp[nIndex++]);
    szBuffer    +=  szTemp + nl;

    szBuffer    +=  "Ram_1_Size=";
    szTemp.Format("%010d",pBsp[nIndex++]);
    szBuffer    +=  szTemp + nl;

    szBuffer    +=  "Ram_2_Base=";
    szTemp.Format("%010d",pBsp[nIndex++]);
    szBuffer    +=  szTemp + nl;

    szBuffer    +=  "Ram_2_Size=";
    szTemp.Format("%010d",pBsp[nIndex++]);
    szBuffer    +=  szTemp + nl;

    szBuffer    +=  "Flash_0_Base=";
    szTemp.Format("%010d",pBsp[nIndex++]);
    szBuffer    +=  szTemp + nl;

    szBuffer    +=  "Flash_0_Type=";
    szTemp.Format("%010d",pBsp[nIndex++]);
    szBuffer    +=  szTemp + nl;

    szBuffer    +=  "Flash_0_Size=";
    szTemp.Format("%010d",pBsp[nIndex++]);
    szBuffer    +=  szTemp + nl;

    szBuffer    +=  "Flash_1_Base=";
    szTemp.Format("%010d",pBsp[nIndex++]);
    szBuffer    +=  szTemp + nl;

    szBuffer    +=  "Flash_1_Type=";
    szTemp.Format("%010d",pBsp[nIndex++]);
    szBuffer    +=  szTemp + nl;

    szBuffer    +=  "Flash_1_Size=";
    szTemp.Format("%010d",pBsp[nIndex++]);
    szBuffer    +=  szTemp + nl;

    szBuffer    +=  "Interrupt_Base=";
    szTemp.Format("%010d",pBsp[nIndex++]);
    szBuffer    +=  szTemp + nl;

    szBuffer    +=  "Sw_Reset_Base=";
    szTemp.Format("%010d",pBsp[nIndex++]);
    szBuffer    +=  szTemp + nl;

    szBuffer    +=  "#END" + nl;
    szBuffer    +=  ";end bsp def" + nl;



    //Buffer the test definetions
    nIndex  =   0;

    szBuffer    +=  ";begin Host Test Enables" + nl;
    szBuffer    +=  "#BEGIN H_TEST" + nl;
    szBuffer    +=  "H_Plx_Chip=";
    szBuffer    +=  (pTestVec[nIndex++] ?  "1" : "0") + nl;

    szBuffer    +=  "H_Led=";
    szBuffer    +=  (pTestVec[nIndex++] ?  "1" : "0") + nl;

    szBuffer    +=  "H_RAM0=";
    szBuffer    +=  (pTestVec[nIndex++] ?  "1" : "0") + nl;

    szBuffer    +=  "H_RAM1=";
    szBuffer    +=  (pTestVec[nIndex++] ?  "1" : "0") + nl;

    szBuffer    +=  "H_RAM2=";
    szBuffer    +=  (pTestVec[nIndex++] ?  "1" : "0") + nl;

    szBuffer    +=  "H_Flash_0=";
    szBuffer    +=  (pTestVec[nIndex++] ?  "1" : "0") + nl;

    szBuffer    +=  "H_Flash_1=";
    szBuffer    +=  (pTestVec[nIndex++] ?  "1" : "0") + nl;

    szBuffer    +=  "H_VPD=";
    szBuffer    +=  (pTestVec[nIndex++] ?  "1" : "0") + nl;

    szBuffer    +=  "H_Hot_Swap=";
    szBuffer    +=  (pTestVec[nIndex++] ?  "1" : "0") + nl;

    szBuffer    +=  "H_UART=";
    szBuffer    +=  (pTestVec[nIndex++] ?  "1" : "0") + nl;

    szBuffer    +=  "#END" + nl;
    szBuffer    +=  ";end host def" + nl;

    szBuffer    +=  ";begin Local Test Enables" + nl;
    szBuffer    +=  "#BEGIN L_TEST" + nl;
    szBuffer    +=  "L_Plx_Chip=";
    szBuffer    +=  (pTestVec[nIndex++] ?  "1" : "0") + nl;

    szBuffer    +=  "L_Led=";
    szBuffer    +=  (pTestVec[nIndex++] ?  "1" : "0") + nl;

    szBuffer    +=  "L_RAM0=";
    szBuffer    +=  (pTestVec[nIndex++] ?  "1" : "0") + nl;

    szBuffer    +=  "L_RAM1=";
    szBuffer    +=  (pTestVec[nIndex++] ?  "1" : "0") + nl;

    szBuffer    +=  "L_RAM2=";
    szBuffer    +=  (pTestVec[nIndex++] ?  "1" : "0") + nl;

    szBuffer    +=  "L_Flash_0=";
    szBuffer    +=  (pTestVec[nIndex++] ?  "1" : "0") + nl;

    szBuffer    +=  "L_Flash_1=";
    szBuffer    +=  (pTestVec[nIndex++] ?  "1" : "0") + nl;

    szBuffer    +=  "L_VPD=";
    szBuffer    +=  (pTestVec[nIndex++] ?  "1" : "0") + nl;

    szBuffer    +=  "L_Hot_Swap=";
    szBuffer    +=  (pTestVec[nIndex++] ?  "1" : "0") + nl;

    szBuffer    +=  "L_UART=";
    szBuffer    +=  (pTestVec[nIndex++] ?  "1" : "0") + nl;

    szBuffer    +=  "#END" + nl;

    //'~' is used to signify end of file
    szBuffer    +=  "~end local test def" + nl;

    nFLen   =   szBuffer.GetLength();


    //Now write the file
    hFile.Write(
            szBuffer,
            nFLen
            );
    
    //sucessful write, final clean up
    hFile.Close();
    return TRUE;
}



BOOL
CBspDef::GoToNextState(
    void
    )
{

    S32     nIndex(0);
    char    ch(0);
    
    ch = szBuffer.GetAt(nIndex);

    switch(fpCurr)
    {
    case ST_COMMENT:
    case ST_BEGIN:
    case ST_END:
    case ST_UNKNOWN:
        while(!((ch == 13) ||(fpCurr == ST_ELEMENT && ch == 32)))
        {
            nIndex++;
            if(nIndex   ==  szBuffer.GetLength())
            {
                fpCurr  =   ST_EOF;
                return FALSE;
            }
            ch = szBuffer.GetAt(nIndex);
        }
        szBuffer    =   szBuffer.Mid(nIndex + 1);
        nIndex      =   0;
        ch = szBuffer.GetAt(nIndex);
        
        
        switch(ch)
        {
        case '#':
            if(nIndex + 1== szBuffer.Find("BEGIN"))
            {
                fpCurr  =   ST_BEGIN;
                nIndex  =   szBuffer.Find("\n\r");
                szBuffer=   szBuffer.Mid(nIndex);
                nIndex  =   0;
            }
            else if(nIndex + 1 == szBuffer.Find("END"))
            {
                fpCurr  =   ST_END;
                nIndex  =   szBuffer.Find("\n\r");
                szBuffer=   szBuffer.Mid(nIndex);
                nIndex  =   0;
            }
            else fpCurr  =   ST_UNKNOWN;
            break;
        case ';':
            fpCurr  =   ST_COMMENT;
            nIndex  =   szBuffer.Find("\n\r");
            szBuffer=   szBuffer.Mid(nIndex);
            nIndex  =   0;
            break;
        case '~':
            fpCurr  =   ST_EOF;
            return FALSE;
        default:
            fpCurr  =   ST_ELEMENT;
            break;
        }
        break;

    case ST_EOF:
            return FALSE;
        break;
    }

    return TRUE;
}





U32 
CBspDef::GetNextElement(
    void
    )
{
    
    S32     nRetVal;
    S32     nStart(0);
    S32     nEnd(0);

    fpCurr      =   ST_UNKNOWN;

    while(fpCurr  != ST_EOF && fpCurr != ST_ELEMENT)
        GoToNextState();

    if(fpCurr  == ST_ELEMENT)
    {
        nStart  =   szBuffer.Find('=');
        if(nStart   ==  -1)
        {
            fpCurr  =   ST_UNKNOWN;
            return -1;
        }

        szBuffer    =   szBuffer.Mid(nStart+1);
        nEnd        =   szBuffer.Find(char(10));
        if(nEnd   ==  -1){
            fpCurr  =   ST_UNKNOWN;
            return -1;
        }
        nRetVal     =   atoi(szBuffer.Mid(0,nEnd+1));
        szBuffer    =   szBuffer.Mid(nEnd+1);

    }
    else
    {
        nRetVal =   -1;
    }
    return nRetVal;


}





