/*******************************************************************************
 * Copyright (c) 2000 PLX Technology, Inc.
 *
 * PLX Technology Inc. licenses this software under specific terms and
 * conditions.  Use of any of the software or derviatives thereof in any
 * product without a PLX Technology chip is strictly prohibited.
 *
 * PLX Technology, Inc. provides this software AS IS, WITHOUT ANY WARRANTY,
 * EXPRESS OR IMPLIED, INCLUDING, WITHOUT LIMITATION, ANY WARRANTY OF
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  PLX makes no guarantee
 * or representations regarding the use of, or the results of the use of,
 * the software and documentation in terms of correctness, accuracy,
 * reliability, currentness, or otherwise; and you rely on the software,
 * documentation and results solely at your own risk.
 *
 * IN NO EVENT SHALL PLX BE LIABLE FOR ANY LOSS OF USE, LOSS OF BUSINESS,
 * LOSS OF PROFITS, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES
 * OF ANY KIND.  IN NO EVENT SHALL PLX'S TOTAL LIABILITY EXCEED THE SUM
 * PAID TO PLX FOR THE PRODUCT LICENSED HEREUNDER.
 *
 ******************************************************************************/

// MemConfigDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ManfGUI.h"
#include "PlxBsp.h"
#include "MemConfigDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern   BSP  DeviceBsp;

char   *strPtr;
char   Mem0Buf[10];
char   Mem1Buf[10];
char   Mem0SizeBuf[10];
char   Mem1SizeBuf[10];
char   FlashBuf[10];
char   FlashOffsetBuf[10];
char   PlxRegsBuf[10];
U32    Mem0Base;
U32    Mem1Base;
U32    Mem0Size;
U32    Mem1Size;
U32    FlashBase;
U32    FlashOffset;
U32    PlxRegsBase;


/////////////////////////////////////////////////////////////////////////////
// CMemConfigDlg dialog


CMemConfigDlg::CMemConfigDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMemConfigDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMemConfigDlg)
	m_FlashBase = _T("FFFFFFFF");
	m_Memory0 = _T("FFFFFFFF");
	m_Memory1 = _T("FFFFFFFF");
	m_PlxRegBase = _T("FFFFFFFF");
	m_FlashOffset = _T("");
	m_Mem0Size = _T("");
	m_Mem1Size = _T("");
	//}}AFX_DATA_INIT
}


void CMemConfigDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMemConfigDlg)
	DDX_Text(pDX, IDC_FLASH_BASE_EDIT, m_FlashBase);
	DDV_MaxChars(pDX, m_FlashBase, 8);
	DDX_Text(pDX, IDC_MEMORY_0_EDIT, m_Memory0);
	DDV_MaxChars(pDX, m_Memory0, 8);
	DDX_Text(pDX, IDC_MEMORY_1_EDIT, m_Memory1);
	DDV_MaxChars(pDX, m_Memory1, 8);
	DDX_Text(pDX, IDC_PLX_REGISTER_BASE_EDIT, m_PlxRegBase);
	DDV_MaxChars(pDX, m_PlxRegBase, 8);
	DDX_Text(pDX, IDC_FLASH_OFFSET_EDIT, m_FlashOffset);
	DDV_MaxChars(pDX, m_FlashOffset, 8);
	DDX_Text(pDX, IDC_MEMORY_0_SIZE_EDIT, m_Mem0Size);
	DDV_MaxChars(pDX, m_Mem0Size, 8);
	DDX_Text(pDX, IDC_MEMORY_1_SIZE_EDIT, m_Mem1Size);
	DDV_MaxChars(pDX, m_Mem1Size, 8);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMemConfigDlg, CDialog)
	//{{AFX_MSG_MAP(CMemConfigDlg)
	ON_EN_CHANGE(IDC_MEMORY_0_EDIT, OnChangeMemory0Edit)
	ON_EN_CHANGE(IDC_MEMORY_1_EDIT, OnChangeMemory1Edit)
	ON_EN_CHANGE(IDC_FLASH_BASE_EDIT, OnChangeFlashBaseEdit)
	ON_EN_CHANGE(IDC_PLX_REGISTER_BASE_EDIT, OnChangePlxRegisterBaseEdit)
	ON_EN_CHANGE(IDC_MEMORY_0_SIZE_EDIT, OnChangeMemory0SizeEdit)
	ON_EN_CHANGE(IDC_MEMORY_1_SIZE_EDIT, OnChangeMemory1SizeEdit)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMemConfigDlg message handlers


BOOL CMemConfigDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

// Initialize Memory map variables
	char  Buffer[60];

	CButton *pSelectedDeviceButton = (CButton*)GetDlgItem(IDC_SELECTED_DEVICE_BUTTON);

	sprintf (Buffer, 
	        "DeviceID %.4x  VendoeID %.4x  Slot %.2x  Bus %.2x",
			 DeviceBsp.device.DeviceId,
			 DeviceBsp.device.VendorId,
			 DeviceBsp.device.SlotNumber,
			 DeviceBsp.device.BusNumber);

	pSelectedDeviceButton->SetWindowText(Buffer);

	if(DeviceBsp.device.DeviceId == 0xc860 || 0x1860 || 0x401 || 0x960 || 0x3001 || 0x30c1)
	{
		m_Memory0     = _strupr((_itoa(DeviceBsp.DramBase, Mem0Buf, 16)));
		m_Mem0Size    = _strupr((_itoa(DeviceBsp.DramSize, Mem0SizeBuf, 16)));
		m_Memory1     = _strupr((_itoa(DeviceBsp.SramBase, Mem1Buf, 16)));
		m_Mem1Size    = _strupr((_itoa(DeviceBsp.SramSize, Mem1SizeBuf, 16)));
		m_FlashBase   = _strupr ((_itoa(DeviceBsp.FlashBase, FlashBuf, 16)));
		m_FlashOffset = _strupr ((_itoa(DeviceBsp.FlashOffset, FlashOffsetBuf, 16)));
		m_PlxRegBase  = _strupr ((_itoa(DeviceBsp.PlxChipBase, PlxRegsBuf, 16)));
	}

	UpdateData(FALSE);

	return TRUE;

}

void CMemConfigDlg::OnChangeMemory0Edit() 
{
	UpdateData(TRUE);

	Mem0Base = strtoul(m_Memory0, &strPtr, 16);

	DeviceBsp.DramBase = Mem0Base;
}

void CMemConfigDlg::OnChangeMemory0SizeEdit() 
{
	UpdateData(TRUE);

	Mem0Size = strtoul(m_Mem0Size, &strPtr, 16);

	DeviceBsp.DramSize = Mem0Size;
	
}

void CMemConfigDlg::OnChangeMemory1Edit() 
{
	UpdateData(TRUE);

	Mem1Base = strtoul(m_Memory1, &strPtr, 16);

	DeviceBsp.SramBase = Mem1Base;
}

void CMemConfigDlg::OnChangeMemory1SizeEdit() 
{
	UpdateData(TRUE);

	Mem1Size = strtoul(m_Mem1Size, &strPtr, 16);

	DeviceBsp.SramSize = Mem1Size;
	
}

void CMemConfigDlg::OnChangeFlashBaseEdit() 
{
	UpdateData(TRUE);

	FlashBase = strtoul(m_FlashBase, &strPtr, 16);

	DeviceBsp.FlashBase = FlashBase;
	
}

void CMemConfigDlg::OnChangePlxRegisterBaseEdit() 
{
	UpdateData(TRUE);

	PlxRegsBase = strtoul(m_PlxRegBase, &strPtr, 16);

	DeviceBsp.PlxChipBase = PlxRegsBase;

}



