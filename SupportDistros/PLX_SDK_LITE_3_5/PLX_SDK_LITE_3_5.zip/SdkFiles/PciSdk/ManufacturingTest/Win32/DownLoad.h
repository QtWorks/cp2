/*******************************************************************************
 * Copyright (c) 2000 PLX Technology, Inc.
 *
 * PLX Technology Inc. licenses this software under specific terms and
 * conditions.  Use of any of the software or derviatives thereof in any
 * product without a PLX Technology chip is strictly prohibited.
 *
 * PLX Technology, Inc. provides this software AS IS, WITHOUT ANY WARRANTY,
 * EXPRESS OR IMPLIED, INCLUDING, WITHOUT LIMITATION, ANY WARRANTY OF
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  PLX makes no guarantee
 * or representations regarding the use of, or the results of the use of,
 * the software and documentation in terms of correctness, accuracy,
 * reliability, currentness, or otherwise; and you rely on the software,
 * documentation and results solely at your own risk.
 *
 * IN NO EVENT SHALL PLX BE LIABLE FOR ANY LOSS OF USE, LOSS OF BUSINESS,
 * LOSS OF PROFITS, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES
 * OF ANY KIND.  IN NO EVENT SHALL PLX'S TOTAL LIABILITY EXCEED THE SUM
 * PAID TO PLX FOR THE PRODUCT LICENSED HEREUNDER.
 *
 ******************************************************************************/

/**********************************************************************
 *                                                                    *
 * Module Name:                                                       *
 *                                                                    *
 *     DownLoad.h                                                     *
 *                                                                    *
 * Abstract:                                                          *
 *                                                                    *
 *                                                                    *
 * Revision History:                                                  *
 *                                                                    *
 *	   08-03-01 : Created                                             *
 *                                                                    *
 *********************************************************************/

#ifndef	__DOWNLOAD_ELF_H___
#define __DOWNLOAD_ELF_H___

#include "Plxtypes.h"
#include "Def.h"


#define CBIN_SIZE_HEADER			(2 * sizeof(U32))
#define CBIN_SIZE_TAIL				(2 * sizeof(U32))

#define MAXLINE						256         // Length of longest input line + 1 (S-Record)
#define FLASH_SIZE					0x80000    //  512k
#define OBJ_FILE_TYPE_EXECUTABLE	1
#define OBJ_FILE_TYPE_UNKNOWN		0
#define RESET_401B_ADDR	            0x80000000 
#define EndianSwap32(value)     ( (((value >>  0) & 0xff) << 24) | \
                                  (((value >>  8) & 0xff) << 16) | \
                                  (((value >> 16) & 0xff) <<  8) | \
                                  (((value >> 24) & 0xff) <<  0) )

#define BYTESWAP(n)					byteswap((char *)&n,sizeof(n))



void byteswap(
    char *p,
    int   n
    );





class CElfLoader
{

private:

	U32 
	FileRead(
		const char *pFileName,
		U8         *pBuffer,
		U32         MaxSize
		);


	void 
	CpuStateReset(
		BOOL   reset
		);


	BOOL 
	ConvertToCbin(
		U8             *pBufIn,
		U32             Size,
		U8            **pCbinBuffer,
		U32            *pCbinSize,
		U32            *RamEntryPoint
		);


	U32 ElfToCBin(
		U8   *pBufIn,
		U32   BufferSize,
		U8  **pCbin,
		U32  *pCbinSize,
		U32  *RamEntryPoint
		);



	BOOL 
	DownloadToIop(
		U8          *pBuffer,
		U32          BufferSize,
		U32          DownloadAddr,
		U32          RamEntryPoint,
		BOOL		CpuIsBigEndian
		);
	BOOL 
	PrepareDownloadIopRamApp(
		void
		);




	BOOL 
	RamDownload(
		U8   *pCbinBuf,
		U32   CbinSize,
		U32  *DownloadAddr,
		BOOL  BigEndian
		);

	BOOL 
	StartIopRamApp(
		U32    RamEntryPoint
		);

	BOOL
	ResetIop(
		BOOL	KeepCpuInReset
		);
  




public:
	CElfLoader(
		HANDLE	hPlxDev,
		BSP*	bsp
		);

	BOOL 
	DownloadElfImage(
		U32		loadAddr
		);

private:
	HANDLE	hPlx;
	BSP*	pBsp;
	U32		uPlxChipType;
    U32     DownloadAddr;
	U32		Offset;

};


#endif