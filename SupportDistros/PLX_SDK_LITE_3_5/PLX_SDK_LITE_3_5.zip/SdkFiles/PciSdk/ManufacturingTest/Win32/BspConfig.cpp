// BspConfig.cpp : implementation file
//

#include "stdafx.h"
#include "BspConfig.h"
#include "ManfGUI.h"
#include "Def.h"
#include "BspDef.h"
#include "Bsp.h"

#include "PlxInit.h"
#include "DownLoad.h"
#include "PciApi.h"
#include "Plx.h"
#include "reg9080.h"
#include "reg9054.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif



/////////////////////////////////////////////////////////////////////////////
// CBspConfig dialog





/************************************************************************
 *  Function    :   CBspConfig      (Dialog constructor)
 *  Abstract    :   The fuction will initialize all the members
 ************************************************************************/
CBspConfig::CBspConfig(
        CBsp    *ptheBsp,
        CWnd    *pParent 
        )   // standard constructor
	    :   CDialog(CBspConfig::IDD, pParent),
            pBsp(ptheBsp)
{
	//{{AFX_DATA_INIT(CBspConfig)
	szBoardSelected = _T("");
	szFlashBase0 = _T("");
	szFlashSize0 = _T("");
	szFlashBase1 = _T("");
	szFlashSize1 = _T("");
	szRamBase0 = _T("");
	szRamSize0 = _T("");
	szRamBase1 = _T("");
	szRamSize1 = _T("");
	szRamBase2 = _T("");
	szRamSize2 = _T("");
	szInterrupt = _T("");
	szSWReset = _T("");
	//}}AFX_DATA_INIT
}





/************************************************************************
 *  Function    :   DoDataExchange
 *  Abstract    :   
 ************************************************************************/
void 
CBspConfig::DoDataExchange(
    CDataExchange* pDX
    )
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CBspConfig)
	DDX_Control(pDX, IDC_FLASH0_TYPE, ComboFlashType0);
	DDX_Control(pDX, IDC_FLASH1_TYPE, ComboFlashType1);
	DDX_Text(pDX, IDC_FLASH0_BASE, szFlashBase0);
	DDV_MaxChars(pDX, szFlashBase0, 8);
	DDX_Text(pDX, IDC_FLASH0_SIZE, szFlashSize0);
	DDV_MaxChars(pDX, szFlashSize0, 8);
	DDX_Text(pDX, IDC_FLASH1_BASE, szFlashBase1);
	DDV_MaxChars(pDX, szFlashBase1, 8);
	DDX_Text(pDX, IDC_FLASH1_SIZE, szFlashSize1);
	DDV_MaxChars(pDX, szFlashSize1, 8);
	DDX_Text(pDX, IDC_RAM0_BASE, szRamBase0);
	DDV_MaxChars(pDX, szRamBase0, 8);
	DDX_Text(pDX, IDC_RAM0_SIZE, szRamSize0);
	DDV_MaxChars(pDX, szRamSize0, 8);
	DDX_Text(pDX, IDC_RAM1_BASE, szRamBase1);
	DDV_MaxChars(pDX, szRamBase1, 8);
	DDX_Text(pDX, IDC_RAM1_SIZE, szRamSize1);
	DDV_MaxChars(pDX, szRamSize1, 8);
	DDX_Text(pDX, IDC_RAM2_BASE, szRamBase2);
	DDV_MaxChars(pDX, szRamBase2, 8);
	DDX_Text(pDX, IDC_RAM2_SIZE, szRamSize2);
	DDV_MaxChars(pDX, szRamSize2, 8);
	DDX_Text(pDX, IDC_INTERRUPT, szInterrupt);
	DDV_MaxChars(pDX, szInterrupt, 8);
	DDX_Text(pDX, IDC_SW_RESET, szSWReset);
	DDV_MaxChars(pDX, szSWReset, 8);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CBspConfig, CDialog)
	//{{AFX_MSG_MAP(CBspConfig)
	ON_BN_CLICKED(ID_SAVE, OnSave)
	ON_BN_CLICKED(ID_OPEN, OnOpen)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBspConfig message handlers




/************************************************************************
 *  Function    :   OnSave          (Dialog message handler)
 *  Abstract    :   function is called when the user clicks on the save
 *                  as dialog button. This function will query the user 
 *                  on the file name for the configuration file and 
 *                  then save the config file.
 ************************************************************************/
void 
CBspConfig::OnSave(
    void
    ) 
{
    CFileDialog FileDialogT(FALSE);              // File Save As Dialog
    CString     FileExt;
    char        *pTstVec;

    FileDialogT.m_ofn.lpstrFilter =
                "Bsp Config Files (*.bsp)\0*.bsp\0"
                "Text Files (*.txt)\0*.txt\0"
                "All Files (*.*)\0*.*\0";

	FileDialogT.m_ofn.lpstrDefExt = ".bsp";
    if (FileDialogT.DoModal() == IDOK)
    {
        pBsp->szConfigFileName = FileDialogT.GetPathName();
		int npos(pBsp->szConfigFileName.ReverseFind('.'));
		if (pBsp->szConfigFileName[npos - 1] == '.')
            pBsp->szConfigFileName = pBsp->szConfigFileName.Left(npos - 1);
        
        //create the CBspDef object and use it to write the 
        //file using the CBsp object
        CBspDef     bspDef(pBsp->szConfigFileName);
        pTstVec =   MakeTestVecArray();
        InitBspFromDlg();
        if(!bspDef.WriteBspFile(
                (const U32* const)pBsp->GetBsp(),
                pTstVec,
                pBsp->pBsp->device.DeviceId))
        {
            AfxMessageBox(
                "Error : Unable to write Bsp Cofiguration File",
                MB_OK | MB_ICONSTOP
                );
        }
    }
}





/************************************************************************
 *  Function    :   OnOpen          (Dialog message handler)
 *  Abstract    :   this function will query the user for the config. 
 *                  filename and then create an object of CBspDef class
 *                  and have that object initialize the CBsp object
 ************************************************************************/
void 
CBspConfig::OnOpen(
    void
    ) 
{

    CFileDialog     FileDialogT(TRUE);              // File Open Dialog
    CString         szFName;
    int             nIndex(0);
    U32             nDevId(-1);    
    BSP             *bsp;
    char            ucTstVec[BSP_TEST_CNT];

    FileDialogT.m_ofn.lpstrFilter =
        "Bsp Config Files (*.bsp)\0*.bsp\0"
        "Text Files (*.txt)\0*.txt\0"
		"All Files (*.*)\0*.*\0";

    FileDialogT.m_ofn.lpstrInitialDir = NULL;
    if (FileDialogT.DoModal() == IDOK)
    {
        pBsp->szConfigFileName = FileDialogT.GetPathName();
        szFName =   pBsp->szConfigFileName;
        //search for the first director seprator and extract the file name
        nIndex  =   szFName.ReverseFind('\\');
        if(nIndex   !=  -1)
        {
            szFName =   szFName.Mid(nIndex+1);
        }
        GetDlgItem(IDC_CONFIGFILENAME)->SetWindowText(szFName);

        /*
         *  now that the file name has been retieved from
         *  the dialog box, create the CBspDef object adn 
         *  allocate the BSP struct. Then use the CBspDef
         *  object to define the BSP using the file. If
         *  that is successful set the BSP into the CBsp*. 
         */

        CBspDef bspDef(szFName);
        bsp    =   new BSP;
        if(bspDef.InitBspFromFile(
                        (U32*) bsp,
                        (PU8)ucTstVec,
                        nDevId
                        ) == TRUE)
        {
            if(nDevId   !=    pBsp->pBsp->device.DeviceId)
            {
                AfxMessageBox(
                      "Configuration File is not valid for this device",
                      MB_OK | MB_ICONSTOP
                      );
                delete bsp;
                return;
            }
            else
            {
                pBsp->SetBsp(bsp);
                InitDlgFromBsp();
            }
        }
        else
        {   
            delete bsp;
        }   
    }

}





/************************************************************************
 *  Function    :   OnCancel        (Dialog message handler)
 *  Abstract    :   function will simply exit
 ************************************************************************/
void 
CBspConfig::OnCancel(
    void
    ) 
{
	
	CDialog::OnCancel();
}




/************************************************************************
 *  Function    :   OnInitDialog    (Dialog message handler)    
 *  Abstract    :   this functions will initialize the dialog box by using
 *                  the BSp object properties
 ************************************************************************/
BOOL 
CBspConfig::OnInitDialog(
    void
    ) 
{
    CDialog::OnInitDialog();
    InitDlgFromBsp();
	return TRUE;  
}





/************************************************************************
 *  Function    :   OpenDevice      (private member function)
 *  Abstract    :   this fuction will init the bsp from file and then 
 *                  it will initialize the dlg from the bsp
 ************************************************************************/
BOOL
CBspConfig::OpenDevice(
    void
    )
{
    UpdateData(TRUE);
    InitBspFromFile();
    InitDlgFromBsp();
    return TRUE;
}




/************************************************************************
 *  Function    :   InitBspFromFile (private member function)     
 *  Abstract    :   this function initializes the CBsp object from the 
 *                  configuration file. This is achieved by using the 
 *                  CBspDef object.
 ************************************************************************/
BOOL
CBspConfig::InitBspFromFile(
    void
    )
{
    CBspDef     BspDef(pBsp->szConfigFileName);
    U32         DevId(0);
    char        *pBuf;
    BSP*        theBsp;
    BOOL        bRetVal(FALSE);

    /*
     *  create the CBspDef object and use it 
     *  set the member of the BSP struct. if
     *  the definetion is successful then set
     *  the BSP struct in the CBsp object.
     */
    theBsp  =   new BSP;
    pBuf    =   new char[BSP_TEST_CNT];
    if(!BspDef.InitBspFromFile(
                    (U32*) theBsp,
                    (U8*)pBuf,
                    DevId))
    {
        delete theBsp;
    }
    else
    {
        pBsp->SetBsp(theBsp);
        pBsp->ParseTestVector(pBuf);
    }
    delete [] pBuf;
    return TRUE;
}




/************************************************************************
 *  Function    :   InitDlgFromBsp  (private member function)   
 *  Abstract    :   this function will use the CBsp Object properties to
 *                  initialize the Dialog Box
 ************************************************************************/
void
CBspConfig::InitDlgFromBsp(
    void
    )
{
    CString     szFName(pBsp->szConfigFileName);
    int         nIndex(0);

    //search for the first director seprator and extract the file name
    nIndex  =   szFName.ReverseFind('\\');
    if(nIndex   !=  -1)
    {
        szFName =   szFName.Mid(nIndex+1);
    }

    /*
     *  The next sequence will read each of the the
     *  CBsp->pbsp memeber and then set the associating
     *  dialog items. After that has been set, the Test
     *  item will be set through a function call.
     */
    
    szBoardSelected =   pBsp->szBspLocator;
    GetDlgItem(IDC_TITLES)->SetWindowText(szBoardSelected);

    GetDlgItem(IDC_CONFIGFILENAME)->SetWindowText(szFName);

    szFlashBase0.Format("%08x",pBsp->pBsp->Flash0Base);
    GetDlgItem(IDC_FLASH0_BASE)->SetWindowText(szFlashBase0);

    szFlashSize0.Format("%08x",pBsp->pBsp->Flash0Size);
    GetDlgItem(IDC_FLASH0_SIZE)->SetWindowText(szFlashSize0);

    szFlashBase1.Format("%08x",pBsp->pBsp->Flash1Base);
    GetDlgItem(IDC_FLASH1_BASE)->SetWindowText(szFlashBase1);

    szFlashSize1.Format("%08x",pBsp->pBsp->Flash1Size);
    GetDlgItem(IDC_FLASH1_SIZE)->SetWindowText(szFlashSize1);

    szRamBase0.Format("%08x",pBsp->pBsp->Ram0Base);
    GetDlgItem(IDC_RAM0_BASE)->SetWindowText(szRamBase0);

    szRamSize0.Format("%08x",pBsp->pBsp->Ram0Size);
    GetDlgItem(IDC_RAM0_SIZE)->SetWindowText(szRamSize0);

    szRamBase1.Format("%08x",pBsp->pBsp->Ram1Base);
    GetDlgItem(IDC_RAM1_BASE)->SetWindowText(szRamBase1);

    szRamSize1.Format("%08x",pBsp->pBsp->Ram1Size);
    GetDlgItem(IDC_RAM1_SIZE)->SetWindowText(szRamSize1);

    szRamBase2.Format("%08x",pBsp->pBsp->Ram2Base);
    GetDlgItem(IDC_RAM2_BASE)->SetWindowText(szRamBase2);

    szRamSize2.Format("%08x",pBsp->pBsp->Ram2Size);
    GetDlgItem(IDC_RAM2_SIZE)->SetWindowText(szRamSize2);


    szInterrupt.Format("%08x",pBsp->pBsp->InterruptBase);
    GetDlgItem(IDC_INTERRUPT)->SetWindowText(szInterrupt);

    szSWReset.Format("%08x",pBsp->pBsp->SwResetBase);
    GetDlgItem(IDC_SW_RESET)->SetWindowText(szSWReset);
   
    ComboFlashType0.SetCurSel(pBsp->pBsp->Flash0Type);
    ComboFlashType1.SetCurSel(pBsp->pBsp->Flash1Type);
    
    InitTestFormBsp();

}





/************************************************************************
 *  Function    :   OnOk
 *  Abstract    :   simply sets the pBsp test vectors
 ************************************************************************/
void CBspConfig::OnOK() 
{
	// TODO: Add extra validation here
	
	CDialog::OnOK();
    pBsp->ParseTestVector(MakeTestVecArray());
}





/************************************************************************
 *  Function    :   MakeTestVecArray    (private member function)     
 *  Abstract    :   this function will read the dialog box item and build
 *                  an array that represents the test to be performed on
 *                  bsp
 ************************************************************************/
char*
CBspConfig::MakeTestVecArray(
    void
    )
{

    char    *pRetBuf;
    int     i(0);

    pRetBuf =   new char[BSP_TEST_CNT];
    memset(pRetBuf,0,BSP_TEST_CNT);

    pRetBuf[i++]    =((CButton*)GetDlgItem(IDC_HT_CHIP))->GetCheck();
    pRetBuf[i++]    =((CButton*)GetDlgItem(IDC_HT_LED))->GetCheck();
    pRetBuf[i++]    =((CButton*)GetDlgItem(IDC_HT_RAM0))->GetCheck();
    pRetBuf[i++]    =((CButton*)GetDlgItem(IDC_HT_RAM1))->GetCheck();
    pRetBuf[i++]    =((CButton*)GetDlgItem(IDC_HT_RAM2))->GetCheck();
    pRetBuf[i++]    =((CButton*)GetDlgItem(IDC_HT_FLASH0))->GetCheck();
    pRetBuf[i++]    =((CButton*)GetDlgItem(IDC_HT_FLASH1))->GetCheck();
    pRetBuf[i++]    =   0;  //((CButton*)GetDlgItem(IDC_HT_HOT))->GetCheck();
    pRetBuf[i++]    =((CButton*)GetDlgItem(IDC_HT_VPD))->GetCheck();
    pRetBuf[i++]    =   0;  //((CButton*)GetDlgItem(IDC_HT_UART))->GetCheck();
    pRetBuf[i++]    =((CButton*)GetDlgItem(IDC_LT_CHIP))->GetCheck();
    pRetBuf[i++]    =((CButton*)GetDlgItem(IDC_LT_LED))->GetCheck();
    pRetBuf[i++]    =((CButton*)GetDlgItem(IDC_LT_FLASH0))->GetCheck();
    pRetBuf[i++]    =((CButton*)GetDlgItem(IDC_LT_FLASH1))->GetCheck();
    pRetBuf[i++]    =((CButton*)GetDlgItem(IDC_LT_RAM0))->GetCheck();
    pRetBuf[i++]    =((CButton*)GetDlgItem(IDC_LT_RAM1))->GetCheck();
    pRetBuf[i++]    =((CButton*)GetDlgItem(IDC_LT_RAM2))->GetCheck();
    pRetBuf[i++]    =((CButton*)GetDlgItem(IDC_LT_HOT))->GetCheck();
    pRetBuf[i++]    =   0;   //((CButton*)GetDlgItem(IDC_LT_VPD))->GetCheck();
    pRetBuf[i++]    =((CButton*)GetDlgItem(IDC_LT_UART))->GetCheck();
    return pRetBuf;
}





/************************************************************************
 *  Function    :   MakeTestVecArray    (private member function)     
 *  Abstract    :   this function will read the dialog box items and set
 *                  the bsp accordingly.
 ************************************************************************/
void
CBspConfig::InitBspFromDlg(
    void
    )
{


    //read the values from the dialog box and update the pBsp
    GetDlgItemText(IDC_FLASH0_BASE,szFlashBase0);
    pBsp->pBsp->Flash0Base  =   StrToU32(szFlashBase0);

    GetDlgItemText(IDC_FLASH0_SIZE,szFlashSize0);
    pBsp->pBsp->Flash0Size  =   StrToU32(szFlashSize0);
    
    GetDlgItemText(IDC_FLASH1_BASE,szFlashBase1);
    pBsp->pBsp->Flash1Base  =   StrToU32(szFlashBase1);

    GetDlgItemText(IDC_FLASH1_SIZE,szFlashSize1);
    pBsp->pBsp->Flash1Size  =   StrToU32(szFlashSize1);

    GetDlgItemText(IDC_INTERRUPT,szFlashSize1);
    pBsp->pBsp->Flash1Size=   StrToU32(szFlashSize1);

    GetDlgItemText(IDC_RAM0_BASE,szRamBase0);
    pBsp->pBsp->Ram0Base=   StrToU32(szRamBase0);

    GetDlgItemText(IDC_RAM0_SIZE,szRamSize0);
    pBsp->pBsp->Ram0Size=   StrToU32(szRamSize0);

    GetDlgItemText(IDC_RAM1_BASE,szRamBase1);
    pBsp->pBsp->Ram1Base=   StrToU32(szRamBase1);

    GetDlgItemText(IDC_RAM1_SIZE,szRamSize1);
    pBsp->pBsp->Ram1Size=   StrToU32(szRamSize1);

    GetDlgItemText(IDC_RAM2_BASE,szRamBase2);
    pBsp->pBsp->Ram2Base=   StrToU32(szRamBase2);

    GetDlgItemText(IDC_RAM2_SIZE,szRamSize2);
    pBsp->pBsp->Ram2Size=   StrToU32(szRamSize2);

    GetDlgItemText(IDC_SW_RESET,szSWReset);
    pBsp->pBsp->SwResetBase=   StrToU32(szSWReset);

}




/************************************************************************
 *  Function    :   InitTestFormBsp     (private member function) 
 *  Abstract    :   this function will use the CBsp Object to initialize 
 *                  dialog box test representation for the bsp.
 ************************************************************************/
void
CBspConfig::InitTestFormBsp(
    void
    )
{
    U32     *uTestVec;
    
    uTestVec    =   pBsp->GetTestVec();
    //begin local def
    if(*uTestVec & LOCAL_UART_TEST)
        ((CButton*)GetDlgItem(IDC_LT_UART))->SetCheck(TRUE);

    if(*uTestVec & LOCAL_PLX_CHIP_TEST)
        ((CButton*)GetDlgItem(IDC_LT_CHIP))->SetCheck(TRUE);
    
    if(*uTestVec & LOCAL_LED_TEST)
        ((CButton*)GetDlgItem(IDC_LT_LED))->SetCheck(TRUE);
    
    if(*uTestVec & LOCAL_VPD_TEST)
        ((CButton*)GetDlgItem(IDC_LT_VPD))->SetCheck(TRUE);
    
    if(*uTestVec & LOCAL_HOT_SWAP_TEST)
        ((CButton*)GetDlgItem(IDC_LT_HOT))->SetCheck(TRUE);
    
    if(*uTestVec & LOCAL_FLASH_1_TEST)
        ((CButton*)GetDlgItem(IDC_LT_FLASH1))->SetCheck(TRUE);
    
    if(*uTestVec & LOCAL_FLASH_0_TEST)
        ((CButton*)GetDlgItem(IDC_LT_FLASH0))->SetCheck(TRUE);
    
    if(*uTestVec & LOCAL_RAM_2_TEST)
        ((CButton*)GetDlgItem(IDC_LT_RAM2))->SetCheck(TRUE);
    
    if(*uTestVec & LOCAL_RAM_1_TEST)
        ((CButton*)GetDlgItem(IDC_LT_RAM1))->SetCheck(TRUE);
    
    if(*uTestVec & LOCAL_RAM_0_TEST)
        ((CButton*)GetDlgItem(IDC_LT_RAM0))->SetCheck(TRUE);

    
    //begin Host def
    if(*uTestVec & HOST_PLX_CHIP_TEST)
        ((CButton*)GetDlgItem(IDC_HT_CHIP))->SetCheck(TRUE);
    
    if(*uTestVec & HOST_LED_TEST)
        ((CButton*)GetDlgItem(IDC_HT_LED))->SetCheck(TRUE);
    
    if(*uTestVec & HOST_UART_TEST)
        ((CButton*)GetDlgItem(IDC_HT_UART))->SetCheck(TRUE);

    if(*uTestVec & HOST_VPD_TEST)
        ((CButton*)GetDlgItem(IDC_HT_VPD))->SetCheck(TRUE);
    
    if(*uTestVec & HOST_HOT_SWAP_TEST)
        ((CButton*)GetDlgItem(IDC_HT_HOT))->SetCheck(TRUE);

    if(*uTestVec & HOST_FLASH_1_TEST)
        ((CButton*)GetDlgItem(IDC_HT_FLASH1))->SetCheck(TRUE);
    
    if(*uTestVec & HOST_FLASH_0_TEST)
        ((CButton*)GetDlgItem(IDC_HT_FLASH0))->SetCheck(TRUE);
    
    if(*uTestVec & HOST_RAM_2_TEST)
        ((CButton*)GetDlgItem(IDC_HT_RAM2))->SetCheck(TRUE);
    
    if(*uTestVec & HOST_RAM_1_TEST)
        ((CButton*)GetDlgItem(IDC_HT_RAM1))->SetCheck(TRUE);
    
    if(*uTestVec & HOST_RAM_0_TEST)
        ((CButton*)GetDlgItem(IDC_HT_RAM0))->SetCheck(TRUE);
}