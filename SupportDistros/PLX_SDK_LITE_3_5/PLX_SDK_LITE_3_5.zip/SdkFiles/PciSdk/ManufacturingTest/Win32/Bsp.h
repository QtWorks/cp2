/********************************************************************************
 *  FileName:   Bsp.h
 *
 *  Abstract:   This file contains the definetions for the classes in the BSP
 *              Hierarchy.
 *
 *******************************************************************************/



#ifndef __BSP_HEADER_H__
#define __BSP_HEADER_H__



#define     HOST_PLX_CHIP_TEST  0X00000001
#define     HOST_LED_TEST       0x00000002
#define     HOST_RAM_0_TEST     0x00000004
#define     HOST_RAM_1_TEST     0X00000008
#define     HOST_RAM_2_TEST     0X00000010
#define     HOST_FLASH_0_TEST   0X00000020
#define     HOST_FLASH_1_TEST   0X00000040
#define     HOST_VPD_TEST       0X00000080
#define     HOST_HOT_SWAP_TEST  0X00000100
#define     HOST_UART_TEST      0X00000200
#define     HOST_ISA_TEST		0X00000400

#define     LOCAL_PLX_CHIP_TEST 0X00010000
#define     LOCAL_LED_TEST      0x00020000 
#define     LOCAL_RAM_0_TEST    0X00040000
#define     LOCAL_RAM_1_TEST    0X00080000
#define     LOCAL_RAM_2_TEST    0X00100000
#define     LOCAL_FLASH_0_TEST  0X00200000
#define     LOCAL_FLASH_1_TEST  0X00400000
#define     LOCAL_VPD_TEST      0X00800000
#define     LOCAL_HOT_SWAP_TEST 0X01000000
#define     LOCAL_UART_TEST     0X02000000
//#define     LOCAL_ISA_TEST		0X04000000


#define     PCI_TEST_MASK       0x0000FFFF
#define     LOCAL_TEST_MASK     0xFFFF0000






#include "stdafx.h"
#include "Def.h"
//include "BspConfig.h"
#include "PlxInit.h"
//#include "ManTest.h"


class CManTest;
class CBoardMgr;
class CBspConfig;



/*
 ********************************************************************************************
 *  BEGIN DEFINETIONS   :   CBsp Class 
 *  The following is the definetions of the CBsp.  This class is the Abstract base class
 *  for the all Bsp types. This class defines the interface that is used to access all
 *  derieved types of CBsp.  This class aslo provides default implementations for many
 *  of the functions that are used by all Bsp Types.
 *
 *  There are two pure virtual functions that must be implementd in the derived class.
 *
 ********************************************************************************************
 *  PURE VIRTUAL FUNCTIONS:
 *
 *  The pure virtual function BuildTestVector (), defines the test that are valid for a 
 *  specific BSP and must be implemented by a derieved type if it is to become a concrete
 *  class.
 *
 *  The other pure virtual function is InitBspDefault(), this function initializes the 
 *  internal BSP struct accordingly in the derieved class.  This function is called if the 
 *  Bsp cannot be defined from a file.  The InitBsp () function call this function after it 
 *  fails to initialize the BSP object from a specified file.
 *
 ********************************************************************************************
 *
 *  All the default implemetations for the different tests that can be performed on a BSp are 
 *  also virtual functions, therefore a derieved class is free to override the default 
 *  implementation.
 ********************************************************************************************
 */





BOOL
HostFlashTestIntel28(
    U32     uVirtAddr
    );




class CBsp
{
friend class CBoardMgr;
friend class CBspConfig;
friend class CManTest;

//private members to CBSP
private:
    BOOL
    HostRamTest(
        U8  Ram
        );



	CEdit *m_EditLog;



//protected member variables and member functions
protected:
    BSP             *pBsp;
    HANDLE          hPlx;
    CString         szConfigFileName;
    CString         szBspLocator;
    CString         LogBuffer;
    CString         szFileLog;
    CString         LogFileName;
    U32             uTestVector;
    U8              ucLogTest;
    REGISTEROFFSET  RegisterOffset;



    BOOL 
    IopTest(
        CString LogString,
        U16     Command,
        U16     MsgData,
        double  TimeOut
        );


    BOOL
    InitBspFromFile(
        void
        );


    BOOL
    InitBspFromUser(
        void
        );

    void
    ParseTestVector(
        char    *pbuf
        );


    void
    SetBsp(
        BSP* newBsp
        );


    char*
    GetTestVecArray(
        void
        );



    void
    WriteLogFile(
        void
        );



    void
    ClearTest(
        void
        )
    {
        uTestVector =   0;
    }

    void
    EnableAllTest(
        void
        )
    {
        uTestVector =   0xFFFFFFFF 
                        & ~HOST_HOT_SWAP_TEST 
                        & ~HOST_UART_TEST
                        & ~LOCAL_VPD_TEST;
    }

    void
    EnableAllPciTest(
        void
        )
    {
        uTestVector |=  PCI_TEST_MASK 
                        & ~HOST_HOT_SWAP_TEST 
                        & ~HOST_UART_TEST;
    }

    void
    EnableAllLocalTest(
        void
        )
    {
        uTestVector |=  LOCAL_TEST_MASK & ~LOCAL_VPD_TEST;
    }
    



    
    inline
    BOOL
    TestIsValid(
        U32 uMask
        )
    {
        return  uTestVector & uMask;
    }

//protected Virtual Member functions
protected:

    virtual
    void
    BuildTestVector(
        void
        )   =   0;


    virtual
    void
    InitBspDefault(
        void
        )   =   0;

    
    

//Static Members
public:

    static 
    CManTest* pDlg;

    static
    void
    SetDlg(CManTest* p);






//Public Member functions 
public:

    CBsp(
        HANDLE          pPlx,
        DEVICE_LOCATION dev,
        CString         szFile
        );

    CBsp(
        const CBsp& rhs
        );

    CBsp&
    operator=(
        const CBsp& rhs
        );

    ~CBsp(
        void
        );

    void
    LogWrite(
        CString pBuffer
        );

    BOOL
    InitBsp(
        void
        );
   
    inline
    CString
    GetBspConfigFileName(
        void
        )
    {
        return szConfigFileName;
    }

    inline
    CString
    GetBspLocator(
        void
        )
    {
        return szBspLocator;
    }

    inline
    U32*
    GetTestVec(
        void
        )
    {
        return  &uTestVector;
    }
    
    inline
    const BSP* const
    GetBsp(
        void
        ) 
    {
        return pBsp; 
    }

//public virtual functions
public:
    /*
     *  The following functions are the tests that can be performed on a BSP.
     *  The IsTestSupported function recieves a MASK for the test and checks 
     *  against the uTestVector (which was initialized in the derived class)
     *  if the test was supported.
     *
     *  All the virtual test functions that follow serve two different purposes.
     *  These functions can be polled to check if the test is supported. This is 
     *  achieved by passing in a TRUE booleen value.  When the functions is polled
     *  it return TRUE to indicate the test is supported else it returns FALSE.
     *  If no booleen value is specifed the default paramater of FALSE is used to 
     *  indicate that a test is to be run on the BSP.
     */

    virtual
    BOOL
    IsTestSupported(
        U32     uTestCode
        )
    {
        return uTestVector & uTestCode;
    }


    /*
     *  BEGIN : HOST TEST DECLARATIONS
     */

    virtual 
    BOOL
    HostTestRam0(
        void
        );

    virtual 
    BOOL
    HostTestLed(
        void
        );

    virtual 
    BOOL
    HostTestRam1(
        void
        );

    virtual 
    BOOL
    HostTestRam2(
        void
        );

    virtual 
    BOOL
    HostTestFlash0(
        void
        );

    virtual
    BOOL
    HostTestFlash1(
        void
        );

    virtual
    BOOL
    HostTestVpd(
        void
        );

    virtual 
    BOOL
    HostTestHotSwap(
        void
        );
    
    virtual
    BOOL
    HostTestUart(
        void
        );

	virtual
	BOOL
	HostTestIsa(
		void
		);

    virtual
    BOOL
    HostTestPlxChip(
        void
        );



    /*
     *  BEGIN : LOCAL TEST DECLARATIONS
     */
    virtual 
    BOOL
    LocalTestLed(
        void
        );

    virtual 
    BOOL
    LocalTestRam0(
        void
        );

    virtual 
    BOOL
    LocalTestRam1(
        void
        );

    virtual 
    BOOL
    LocalTestRam2(
        void
        );

    virtual 
    BOOL
    LocalTestFlash0(
        void
        );

    virtual
    BOOL
    LocalTestFlash1(
        void
        );

    virtual
    BOOL
    LocalTestVpd(
        void
        );

    virtual 
    BOOL
    LocalTestHotSwap(
        void
        );
    
    virtual
    BOOL
    LocalTestUart(
        void
        );
        
    virtual
    BOOL
    LocalTestPlxChip(
        void
        );

};






#endif