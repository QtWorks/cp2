#ifndef ___DEF__H__MT01___
#define ___DEF__H__MT01___

#include "PlxApi.h"
#include "PlxInit.h"

#define SPACE_ENABLE                0x1
#define SPACE_DESCRIPTOR_8_BIT      0x40
#define SPACE_DESCRIPTOR_16_BIT     0x41

#define WAIT_STATE_LOOP             600
#define FLASH_POWERPC_RESET_LOC     (0x80000000 | SPACE_ENABLE)         /* 401B board only */
#define MaxErrors                   0x100



typedef struct _BSP
{
	U32				PlxChipType;
    U32             PlxChipBase;
    U32             Ram0Base;
    U32             Ram0Size;
    U32             Ram1Base;
    U32             Ram1Size;
    U32             Ram2Base;
    U32             Ram2Size;
    U32             Flash0Base;
    U32             Flash0Type;
    U32             Flash0Size;
    U32             Flash1Base;
    U32             Flash1Type;
    U32             Flash1Size;
    U32             InterruptBase;
    U32             SwResetBase;
    DEVICE_LOCATION device;
}BSP;


typedef struct _REGISTEROFFSET
{
    U16 VpdId;
    U16 VpdData;
    U16 PmCapId;
    U16 PmCsr;
    U16 HotSwap;
    U16 Space0Remap;
    U16 Space0Range;
    U16 Space1Remap;
    U16 Space1Range;
    U16 DramBusDesc;
} REGISTEROFFSET;





U32
StrToU32(
    CString
    );




#endif