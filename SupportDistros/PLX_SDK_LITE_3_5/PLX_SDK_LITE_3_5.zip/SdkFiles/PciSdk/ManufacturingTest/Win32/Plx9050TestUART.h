// Plx9050TestUART.h: interface for the CPlx9050TestUART class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_PLX9050TESTUART_H__2C293ED8_3F79_4181_B294_5CFFD3D5BC22__INCLUDED_)
#define AFX_PLX9050TESTUART_H__2C293ED8_3F79_4181_B294_5CFFD3D5BC22__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CPlx9050TestUART  
{
public:
	BOOL TestUART(BOOL bIsModem=TRUE);
	CPlx9050TestUART(HANDLE hPlx,DWORD DeviceId,DWORD dwPCIBaseAddress);
	virtual ~CPlx9050TestUART();

private:
	DWORD m_dwPCIBaseAddress;
	CString GetFromModem(void);
	void SendToModem(CString out);
	DWORD m_UartBasePort;
	DWORD m_DeviceId;
	HANDLE m_hPlx;
	BOOL IsComport(DWORD port);
	BOOL SetupLocalIO(WORD LocBase, WORD LocRange);
	BOOL SetupLocComport();
};

#endif // !defined(AFX_PLX9050TESTUART_H__2C293ED8_3F79_4181_B294_5CFFD3D5BC22__INCLUDED_)
