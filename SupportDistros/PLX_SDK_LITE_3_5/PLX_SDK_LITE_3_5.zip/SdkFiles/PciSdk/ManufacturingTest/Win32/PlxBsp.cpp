/*******************************************************************************
 * Copyright (c) 2000 PLX Technology, Inc.
 *
 * PLX Technology Inc. licenses this software under specific terms and
 * conditions.  Use of any of the software or derviatives thereof in any
 * product without a PLX Technology chip is strictly prohibited.
 *
 * PLX Technology, Inc. provides this software AS IS, WITHOUT ANY WARRANTY,
 * EXPRESS OR IMPLIED, INCLUDING, WITHOUT LIMITATION, ANY WARRANTY OF
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  PLX makes no guarantee
 * or representations regarding the use of, or the results of the use of,
 * the software and documentation in terms of correctness, accuracy,
 * reliability, currentness, or otherwise; and you rely on the software,
 * documentation and results solely at your own risk.
 *
 * IN NO EVENT SHALL PLX BE LIABLE FOR ANY LOSS OF USE, LOSS OF BUSINESS,
 * LOSS OF PROFITS, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES
 * OF ANY KIND.  IN NO EVENT SHALL PLX'S TOTAL LIABILITY EXCEED THE SUM
 * PAID TO PLX FOR THE PRODUCT LICENSED HEREUNDER.
 *
 ******************************************************************************/

/**********************************************************************
 *                                                                    *
 * Module Name:                                                       *
 *                                                                    *
 *     PlxBsp.c                                                       *
 *                                                                    *
 * Abstract:                                                          *
 *                                                                    *
 *                                                                    *
 * Revision History:                                                  *
 *                                                                    *
 *     04-19-00 : Support 9030                                        *  
 *     07-09-98 : Support SDK 2.0                                     *
 *     06-20-98 : Created                                             *
 *                                                                    *
 *********************************************************************/
#include "StdAfx.h"
#include "PlxBsp.h"

extern   U32  Mem0Base;
extern   U32  Mem1Base;
extern   U32  Mem0Size;
extern   U32  Mem1Size;
extern   U32  PlxRegsBase;
extern   U32  FlashBase;
extern   U32  FlashOffset; 
 

BOOLEAN InitializeBsp(BSP *board)
{
    switch (board->device.DeviceId)
    {
        case PLX_9080RDK_401B_DEVICE_ID:
            board->PlxChipBase   = 0x20000000;
            board->DramBase      = 0x00000000;
            board->DramSize      = 0x01000000;
			board->MemType		 = MEM_TYPE_32_BIT;
            board->SramBase      = 0x10000000;
            board->SramSize      = 0x00080000;
            board->FlashBase     = 0xFFF80000;
            board->FlashOffset   = 0x00060000;
            board->FlashUseSize  = 0x00020000;
            board->FlashSize     = 0x00080000;
            board->FlashType     = FLASH_TYPE_8_BIT;
            board->UartBase      = 0x7E000000;
            board->InterruptBase = 0x7E000400;
            board->SwResetBase   = 0x80000000;
            board->PomBase       = 0xC0000000;
            return TRUE;

        case PLX_9080RDK_960_DEVICE_ID:
            board->PlxChipBase   = 0x30000000;
            board->DramBase      = 0x10001000;
            board->DramSize      = 0x01000000;
			board->MemType		 = MEM_TYPE_32_BIT;
            board->SramBase      = 0x20000000;
            board->SramSize      = 0x00080000;
            board->FlashBase     = 0xE0000000;
            board->FlashOffset   = 0x00060000;
            board->FlashUseSize  = 0x00020000;
            board->FlashSize     = 0x00080000;
            board->FlashType     = FLASH_TYPE_8_BIT;
            board->UartBase      = 0xD0000000;
            board->InterruptBase = 0xFFFFFFFF;
            board->SwResetBase   = 0xFFFFFFFF;
            board->PomBase       = 0xFFFFFFFF;
            return TRUE;

        case PLX_9080RDK_860_DEVICE_ID:
            board->PlxChipBase   = 0xC0000000;
            board->DramBase      = 0x10000000;
            board->DramSize      = 0x01000000;
			board->MemType		 = MEM_TYPE_32_BIT;
            board->SramBase      = 0x00000000;
            board->SramSize      = 0x00080000;
            board->FlashBase     = 0xFFF00000;
            board->FlashOffset   = 0x00000000;
            board->FlashUseSize  = 0x00020000;
            board->FlashSize     = 0x00080000;
            board->FlashType     = FLASH_TYPE_8_BIT;
            board->UartBase      = 0xFFFFFFFF;
            board->InterruptBase = 0xFFFFFFFF;
            board->SwResetBase   = 0xFFFFFFFF;
            board->PomBase       = 0xFFFFFFFF;
            return TRUE;

        /**************************************/

		// PLX_9054RDK_860 PCI board:
		case PLX_9054RDK_860_DEVICE_ID:
            board->PlxChipBase   = 0x30000000;
            board->DramBase      = 0x00000000;
            board->DramSize      = 0x02000000;
			board->MemType		 = MEM_TYPE_32_BIT;
            board->SramBase      = 0x00000000;          //Sram only for cpci board.
            board->SramSize      = 0x00000000;
            board->FlashBase     = 0xFFF00000;
            board->FlashOffset   = 0x00000000;
            board->FlashUseSize  = 0x00020000;
            board->FlashSize     = 0x00080000;
            board->FlashType     = FLASH_TYPE_8_BIT;
            board->UartBase      = 0xFFFFFFFF;
            board->InterruptBase = 0xFFFFFFFF;
            board->SwResetBase   = 0xFFFFFFFF;
            board->PomBase       = 0xFFFFFFFF;
            return TRUE;


        // PLX_9054RDK_860 cPCI board:
		case PLX_CPCI9054RDK_860_DEVICE_ID:
            board->PlxChipBase   = 0x30000000;
            board->DramBase      = 0x00000000;
            board->DramSize      = 0x02000000;
			board->MemType		 = MEM_TYPE_32_BIT;
            board->SramBase      = 0x20000000;          
            board->SramSize      = 0x00080000;
            board->FlashBase     = 0xFFF00000;
            board->FlashOffset   = 0x00000000;
            board->FlashUseSize  = 0x00020000;
            board->FlashSize     = 0x00080000;
            board->FlashType     = FLASH_TYPE_8_BIT;
            board->UartBase      = 0xFFFFFFFF;
            board->InterruptBase = 0xFFFFFFFF;
            board->SwResetBase   = 0xFFFFFFFF;
            board->PomBase       = 0xFFFFFFFF;
            return TRUE;

        /****************************************/
		case PLX_9054RDK_LITE_DEVICE_ID:
            board->PlxChipBase   = 0x30000000;
            board->DramBase      = 0x00000000;  //No DRAM
            board->DramSize      = 0x02000000;
			board->MemType		 = MEM_TYPE_32_BIT;
            board->SramBase      = 0x20000000;          
            board->SramSize      = 0x00020000;
            board->FlashBase     = 0xFFF00000;  //No FLASH
            board->FlashOffset   = 0x00000000;
            board->FlashUseSize  = 0x00020000;
            board->FlashSize     = 0x00080000;
            board->FlashType     = FLASH_TYPE_8_BIT;
            board->UartBase      = 0xFFFFFFFF;
            board->InterruptBase = 0xFFFFFFFF;
            board->SwResetBase   = 0xFFFFFFFF;
            board->PomBase       = 0xFFFFFFFF;
            return TRUE;
        // PLX_IOP480RDK board:
		case PLX_IOP480RDK_DEVICE_ID:
            board->PlxChipBase   = 0x30000000;
            board->DramBase      = 0x00000000;
            board->DramSize      = 0x02000000;
			board->MemType		 = MEM_TYPE_32_BIT;
            board->SramBase      = 0x00000000;          //Sram only for cpci board.
            board->SramSize      = 0x00000000;
            board->FlashBase     = 0xFFF80000;
            board->FlashOffset   = 0x00060000;
            board->FlashUseSize  = 0x00020000;
            board->FlashSize     = 0x00080000;
            board->FlashType     = FLASH_TYPE_8_BIT;
            board->UartBase      = 0xFFFFFFFF;
            board->InterruptBase = 0xFFFFFFFF;
            board->SwResetBase   = 0xFFFFFFFF;
            board->PomBase       = 0xFFFFFFFF;
            return TRUE;
        /****************************************/
		case PLX_9030RDK_LITE_DEVICE_ID:
            board->PlxChipBase   = 0x30000000;
            board->DramBase      = 0x00000000; 
            board->DramSize      = 0x00002000;
			board->MemType		 = MEM_TYPE_16_BIT;
            board->SramBase      = 0xFFFFFFFF;          
            board->SramSize      = 0xFFFFFFFF;
            board->FlashBase     = 0xFFFFFFFF;  //No FLASH
            board->FlashOffset   = 0xFFFFFFFF;
            board->FlashUseSize  = 0xFFFFFFFF;
            board->FlashSize     = 0xFFFFFFFF;
            board->FlashType     = FLASH_TYPE_NONE;
            board->UartBase      = 0xFFFFFFFF;
            board->InterruptBase = 0xFFFFFFFF;
            board->SwResetBase   = 0xFFFFFFFF;
            board->PomBase       = 0xFFFFFFFF;
            return TRUE;
		/****************************************/
		case PLX_CPCI9030RDK_LITE_DEVICE_ID:
            board->PlxChipBase   = 0x30000000;
            board->DramBase      = 0x00000000; 
            board->DramSize      = 0x00002000;
			board->MemType		 = MEM_TYPE_16_BIT;
            board->SramBase      = 0xFFFFFFFF;          
            board->SramSize      = 0xFFFFFFFF;
            board->FlashBase     = 0xFFFFFFFF;  //No FLASH
            board->FlashOffset   = 0xFFFFFFFF;
            board->FlashUseSize  = 0xFFFFFFFF;
            board->FlashSize     = 0xFFFFFFFF;
            board->FlashType     = FLASH_TYPE_NONE;
            board->UartBase      = 0xFFFFFFFF;
            board->InterruptBase = 0xFFFFFFFF;
            board->SwResetBase   = 0xFFFFFFFF;
            board->PomBase       = 0xFFFFFFFF;
            return TRUE;

		/****************************************/
        case PLX_9656RDK_LITE_DEVICE_ID:
		case (PLX_9056RDK_LITE_DEVICE_ID):
            board->PlxChipBase   = 0x30000000;
            board->DramBase      = 0x00000000; //no Dram
            board->DramSize      = 0x00020000;
			board->MemType		 = MEM_TYPE_32_BIT;
            board->SramBase      = 0x00000000;          
            board->SramSize      = 0x00020000;
            board->FlashBase     = 0xFFFFFFFF;
            board->FlashOffset   = 0xFFFFFFFF;
            board->FlashUseSize  = 0x00000000;
            board->FlashSize     = 0x00000000;
            board->FlashType     = FLASH_TYPE_NONE;
            board->UartBase      = 0xFFFFFFFF;
            board->InterruptBase = 0xFFFFFFFF;
            board->SwResetBase   = 0xFFFFFFFF;
            board->PomBase       = 0xFFFFFFFF;
            return TRUE;
        /****************************************/

        case PLX_9056RDK_860_DEVICE_ID:
        case PLX_9656RDK_860_DEVICE_ID:
            board->PlxChipBase   = 0x30000000;
            board->DramBase      = 0x00000000; 
            board->DramSize      = 0x04000000;
			board->MemType		 = MEM_TYPE_32_BIT;
            board->SramBase      = 0x20000000;          
            board->SramSize      = 0x00080000;
            board->FlashBase     = 0xFFF00000;  //No FLASH
            board->FlashOffset   = 0x00000000;  //CHECK this value ?
            board->FlashUseSize  = 0x00080000;
            board->FlashSize     = 0x00080000;
            board->FlashType     = FLASH_TYPE_8_BIT;//CHECK this value ?
            board->UartBase      = 0xFFFFFFFF;
            board->InterruptBase = 0xFFFFFFFF;
            board->SwResetBase   = 0xFFFFFFFF;
            board->PomBase       = 0x10000000;
            return TRUE;
            
        //fill in the correct values for the rest of the 
        //bsp's.
        


        /****************************************/
        /****************************************/
        /****************************************/
		default:
	        board->PlxChipBase   = PlxRegsBase;
            board->DramBase      = Mem0Base;
            board->DramSize      = Mem0Size;
			board->MemType		 = MEM_TYPE_32_BIT;
            board->SramBase      = Mem1Base;
            board->SramSize      = Mem1Size;
            board->FlashBase     = FlashBase;
            board->FlashOffset   = FlashOffset;
            board->FlashUseSize  = 0x00020000;
            board->FlashSize     = 0x00080000;
            board->FlashType     = FLASH_TYPE_NONE;
            board->UartBase      = 0xFFFFFFFF;
            board->InterruptBase = 0xFFFFFFFF;
            board->SwResetBase   = 0xFFFFFFFF;
            board->PomBase       = 0xFFFFFFFF;

    }

    return FALSE;
}
