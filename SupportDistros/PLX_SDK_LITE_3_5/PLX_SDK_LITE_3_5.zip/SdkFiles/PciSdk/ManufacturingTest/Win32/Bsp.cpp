
#include "stdafx.h"
#include "Bsp.h"
#include "ManfGUI.h"
#include "BspDef.h"
#include "support.h"
#include "..\Iop\ManfComm.h"
#include "Plx9050TestUART.h"
#include "Log.h"

CManTest* CBsp::pDlg;




/************************************************************************
 *  Function    :   HostFlashTestIntel28
 *  Abstract    :   This function will check test the flash device by 
 *                  reading the flash id and verfiying it is correct.
 ************************************************************************/
BOOL
HostFlashTestIntel28(
    U32 uVirtAddr
    )
{
    U8  ucCode;
    U16 usData;


    // read the manufacturer and Device ID
    * (PU8) (uVirtAddr) = 0x90;
    ucCode  = * (PU8) (uVirtAddr);
    usData  = ucCode << 8;
    ucCode  = * (PU8) (uVirtAddr + 2);
    usData += ucCode;
    
    //verify that the data read matches the device ID, else Error and return 0
    if (usData != 0x8917)
    {
        *(PU8)uVirtAddr = 0x50;
        *(PU8)uVirtAddr = 0xFF;
        return FALSE;
    }

    return TRUE;
}




/************************************************************************
 *  Function    :   SetDlg          (Static Member function)
 *  Abstract    :   The function sets the static pointer, which points
 *                  to the CManTest dialog box.
 ************************************************************************/
void
CBsp::SetDlg(CManTest* p)
{
    pDlg = p;
}




/************************************************************************
 *  Function    :   LogWrite        (public member function)
 *  Abstract    :   The function will add the new string to the buffer
 *                  that will be written to the log file after the test
 *                  completes.
 ************************************************************************/
void
CBsp::LogWrite(
    CString   pBuffer
    )
{

	gLog.Display(pBuffer);

    if (ucLogTest)
    {
        szFileLog += pBuffer;
        szFileLog += 10;
        szFileLog += 13;
    }
}




/************************************************************************
 *  Function    :   InitBspFromFile (protected member function)
 *  Abstract    :   The function will create a CBspDef object and use
 *                  this object to read the definetion file and initialize
 *                  its internal BSP struct.
 ************************************************************************/
BOOL
CBsp::InitBspFromFile(
    void
    )
{
    CBspDef     BspDef(szConfigFileName);
    U32         DevId(0);
    char        *pBuf;


    pBuf = new char[BSP_TEST_CNT];

    memset(
        pBuf,
        0,
        BSP_TEST_CNT
        );

    if (!BspDef.InitBspFromFile(
            (U32*)pBsp,
            (U8*)pBuf,
            DevId
            ))
    {
        if (DevId != pBsp->device.DeviceId)
            return FALSE;
    }

    ParseTestVector(pBuf);

    delete  []   pBuf;

    return TRUE;
}




/************************************************************************
 *  Function    :   ParseTestVector (protected member function)
 *  Abstract    :   This function will iterate through the buffer passed
 *                  in and set the uTest accordingly
 ************************************************************************/
void
CBsp::ParseTestVector(
    char *pbuf
    )
{
    uTestVector = 0;

    for (U32 i = 0; i < BSP_TEST_CNT; i++)
    {
        // if the char has a non-zero value, the test is supported
        if (pbuf[i])
            uTestVector |= 1<< i; 
    }
}




/************************************************************************
 *  Function    :   InitBsp     (public member function)
 *  Abstract    :   This function will initialize the object. First it 
 *                  try to read to init. from a file, else use the default
 *                  memory map.
 ************************************************************************/
BOOL
CBsp::InitBsp(
    void
    )
{
    if (!InitBspFromFile())
        InitBspDefault();

    return TRUE;
}




/************************************************************************
 *  Function    :   CBsp        (class construtor)
 *  Abstract    :   The function will initialize its member variables,
 *                  allocated memory for the BSP struct.
 ************************************************************************/
CBsp::CBsp(
    HANDLE          pPlx,
    DEVICE_LOCATION dev,
    CString         szFile
    )
    :   hPlx(pPlx),
        uTestVector(0),
        szConfigFileName(szFile)
{
    pBsp            = new BSP;
    pBsp->device    = dev;
    ucLogTest       = 0;
	m_EditLog		= 0;
}




/************************************************************************
 *  Function    :   CBsp        (copy constructor)
 *  Abstract    :   This is the copy constructor for the CBsp class. This
 *                  class will simply make a deep copy of its elements when
 *                  an object is created using this constructor.
 ************************************************************************/
CBsp::CBsp(
    const CBsp& rhs
    )
    :   hPlx(rhs.hPlx),
        LogBuffer(rhs.LogBuffer),
        szBspLocator(rhs.szBspLocator),
        szConfigFileName(rhs.szConfigFileName),
        uTestVector(rhs.uTestVector)
{
	m_EditLog		= 0;
    pBsp    =   new BSP;
    memcpy(
        pBsp,
        rhs.pBsp,
        sizeof(BSP)
        );
}




/************************************************************************
 *  Function    :   operator=   (assignment operator)
 *  Abstract    :   The class assignment operator, the CBsp class makes a 
 *                  deep copy on assignment.          
 ************************************************************************/
CBsp&
CBsp::operator=(
    const CBsp& rhs
    )
{
    hPlx                =   rhs.hPlx;
    LogBuffer           =   rhs.LogBuffer;
    szBspLocator        =   rhs.szBspLocator;
    szConfigFileName    =   rhs.szConfigFileName;
    uTestVector         =   rhs.uTestVector;
    pBsp                =   new BSP;

    memcpy(
        pBsp,
        rhs.pBsp,
        sizeof(BSP)
        );

    return *this;
}




/************************************************************************
 *  Function    :   CBsp        (desctructor)
 *  Abstract    :   This function will clean up memory allocated on the
 *                  heap.
 ************************************************************************/
CBsp::~CBsp(
    void
    )
{
    PlxPciDeviceClose(
        hPlx
        );

    WriteLogFile();

    delete pBsp;
}




/************************************************************************
 *  Function    :   Setbsp      (public member function)
 *  Abstract    :   functions deletes the old BSP struct and assigns a 
 *                  address to the BSP pointer. The new BSP must have 
 *                  been allocated on the stack, because it will be 
 *                  later by this class only
 ************************************************************************/
void
CBsp::SetBsp(
    BSP *newBsp
    )
{
    if (newBsp == pBsp)
        return;

    delete pBsp;

    pBsp = newBsp;
}




/************************************************************************
 *  Function    :   HostRamTest (private member function)
 *  Abstract    :   function is a generic function for the Ram tests.
 *                  the byte passed in specifies the ram to test.
 ************************************************************************/
BOOL
CBsp::HostRamTest(
    U8  Ram
    )
{
    U16                 uRemap;
    U16                 uRange;
    U32                 totalErrors = 0;
    U32                 InBlockStartAddr;
    U32                 LocalAddress;
    U32                 ValueRead;
    U32                 CurOffset;
    U32                 CurAddr;
    U32                 blockSize;
    U32                 oldRemap;
    U32                 StartAddr;
    U32                 EndAddr; 
    U32                 Va;
    VIRTUAL_ADDRESSES   virtualAddr;
    RETURN_CODE         rc;
    char                buffer[20];
    BOOL                Error = FALSE;
    CString             szBuffer;
    U32                 uMask(0); 
    

    CButton*           pDisplay = (CButton *)(((CDialog*)pDlg)->GetDlgItem(IDC_DETAILS_BUTTON));
	m_EditLog = (CEdit *)(((CDialog*)pDlg)->GetDlgItem(IDC_LOG));

    
    switch(Ram)
    {
        case 0:
            StartAddr = pBsp->Ram0Base;    
            EndAddr   = StartAddr + pBsp->Ram0Size;
            uMask     = HOST_RAM_0_TEST;
            uRemap    = RegisterOffset.Space0Remap;
            uRange    = RegisterOffset.Space0Range;
            break;

        case 1:
            StartAddr = pBsp->Ram1Base;    
            EndAddr   = StartAddr + pBsp->Ram1Size;
            uMask     = HOST_RAM_1_TEST;
            uRemap    = RegisterOffset.Space1Remap;
            uRange    = RegisterOffset.Space1Range;
            break;

        case 2:
            StartAddr = pBsp->Ram0Base;    
            EndAddr   = StartAddr + pBsp->Ram0Size;
            uMask     = HOST_RAM_2_TEST;
            uRemap    = RegisterOffset.Space0Remap;
            uRange    = RegisterOffset.Space0Range;
            break;

        default:
            return FALSE;
    }

    oldRemap = PlxRegisterRead(hPlx, uRemap, &rc);

    // Get Space0 Base Address 
    PlxPciBaseAddressesGet(
        hPlx,
        &virtualAddr
        );

    // Get block size from range register
    blockSize = ~PlxRegisterRead(hPlx, uRange, &rc);

    switch (pBsp->device.DeviceId)
    {
        case PLX_9050RDK_LITE_DEVICE_ID:
        case PLX_9052RDK_LITE_DEVICE_ID:
            Va = virtualAddr.Va4;
            blockSize &= ~(0xF0000000);
            break;

        default:
            Va = virtualAddr.Va2;
            break;
    }

    InBlockStartAddr = (blockSize & StartAddr),

    // Map to test memory address
    PlxRegisterWrite(
        hPlx,
        uRemap,
        (StartAddr & ~blockSize) | SPACE_ENABLE
        );

    CurAddr = Va + InBlockStartAddr; 

    totalErrors = 0;
    EndAddr     = EndAddr - StartAddr;

    for (CurOffset=0; CurOffset<EndAddr; CurOffset+=4, CurAddr+=4)
    {
        LocalAddress = InBlockStartAddr + CurOffset;
        Error = FALSE;

        if ((!(LocalAddress & blockSize)) & (CurOffset != 0))
        {
            PlxRegisterWrite(
                hPlx,
                uRemap,
                (LocalAddress) | SPACE_ENABLE
                );

            CurAddr = Va;
        }

        if (!(LocalAddress & 0xffff))
        {
            if(!TestIsValid(uMask))
                return FALSE;   

            _itoa(LocalAddress, buffer, 16);
            szBuffer  =  "Ram Test : 0x";
            szBuffer +=  buffer;
            pDisplay->SetWindowText(szBuffer);
        }

        *(U32 *)CurAddr = LocalAddress;
        ValueRead = *(U32 *)CurAddr;
        if (ValueRead != LocalAddress)
        {
            Error = TRUE;
            totalErrors++;
        }
        else
        {
            *(U32 *)CurAddr = ~LocalAddress;
            ValueRead = *(U32 *)CurAddr;
            if(ValueRead != ~LocalAddress)
            {
                Error = TRUE;
                totalErrors++;
            }
            else
            {
                *(U32 *)CurAddr = LocalAddress;
            }
        }

        if (Error && (totalErrors < MaxErrors))
        {
            LogBuffer.Format(
                "ValueRead %08x OldRemap %08x LocalAddress %08x",
                ValueRead, oldRemap, LocalAddress
                );
            LogWrite(LogBuffer);
        }
        else if (totalErrors >= MaxErrors)
            break;
    }

    // Map to test memory address
    PlxRegisterWrite(
        hPlx,
        uRemap,
        (StartAddr & ~blockSize) | SPACE_ENABLE
        );

    CurAddr  = Va + InBlockStartAddr; 
    szBuffer = "Data comparision";

    pDisplay->SetWindowText(szBuffer);

    for (CurOffset=0; CurOffset<EndAddr; CurOffset+=4, CurAddr+=4)
    {
        LocalAddress = InBlockStartAddr + CurOffset;
        Error = FALSE;

        if (!(LocalAddress & 0xffff) && (!TestIsValid(uMask)))
            return FALSE;

        if ((!(LocalAddress & blockSize)) & (CurOffset != 0))
        {
            PlxRegisterWrite(
                hPlx,
                uRemap,
                LocalAddress | SPACE_ENABLE
                );

            CurAddr = Va;
        }

        ValueRead = *(U32 *)CurAddr;
        if (ValueRead != LocalAddress)
        {
            Error = TRUE;
            totalErrors++;
        }

        if (Error && (totalErrors < MaxErrors))
        {
            LogBuffer.Format(
                "ValueRead %08x OldRemap %08x LocalAddress %08x",
                ValueRead, oldRemap, LocalAddress
                );
            LogWrite(LogBuffer);
        }
        else if (totalErrors >= MaxErrors)
            return FALSE;
    }

    PlxRegisterWrite(
        hPlx,
        uRemap,
        oldRemap
        );

    return TRUE;
}




/************************************************************************
 *  Function    :   HostTestRam0        (virtual function)
 *  Abstract    :   This function can be polled to check if the BSP 
 *                  test is supported or the function can be asked to 
 *                  run the test on Ram0.
 ************************************************************************/
BOOL
CBsp::HostTestRam0(
    void
    )
{
    if (pBsp->Ram0Size == 0)
        return FALSE;

    if (!IsTestSupported(HOST_RAM_0_TEST))
        return FALSE;

    return HostRamTest(0);
}

 


/************************************************************************
 *  Function    :   HostTestRam1        (virtual function)        
 *  Abstract    :   This function can be polled to check if the BSP 
 *                  test is supported or the function can be asked to 
 *                  run the test on Ram1.
 ************************************************************************/
BOOL
CBsp::HostTestRam1(
    void
    )
{
    if (pBsp->Ram1Size == 0)
        return FALSE;

    if (!IsTestSupported(HOST_RAM_1_TEST))
        return FALSE;

    return HostRamTest(1);
}




/************************************************************************
 *  Function    :   HostTestRam2        (virtual function)
 *  Abstract    :   This function can be polled to check if the BSP 
 *                  test is supported or the function can be asked to 
 *                  run the test on Ram2.
 ************************************************************************/
BOOL
CBsp::HostTestRam2(
    void
    )
{
    if (pBsp->Ram2Size == 0)
        return FALSE;

    if (!IsTestSupported(HOST_RAM_2_TEST))
        return FALSE;

    return HostRamTest(2);
}




/************************************************************************
 *  Function    :   HostTestLed     (virtual function)
 *  Abstract    :   This function can be polled to check if the BSP 
 *                  test is supported or the function can be asked to 
 *                  run the test on Led. 
 ************************************************************************/
BOOL
CBsp::HostTestLed(
    void 
    )
{
    SHORT       NumOfLedBlinks;
    RETURN_CODE rc; 


    if (!IsTestSupported(HOST_LED_TEST))
        return FALSE;

    NumOfLedBlinks = 1;

    while ((NumOfLedBlinks < 10) && (NumOfLedBlinks > 0))
    {
        if ((pBsp->device.DeviceId == PLX_CPCI9054RDK_860_DEVICE_ID) || 
            (pBsp->device.DeviceId == PLX_9054RDK_860_DEVICE_ID)||
            (pBsp->device.DeviceId == PLX_9080RDK_860_DEVICE_ID) || 
            (pBsp->device.DeviceId == PLX_9080RDK_401B_DEVICE_ID) ||
            (pBsp->device.DeviceId == PLX_9056RDK_LITE_DEVICE_ID) ||
            (pBsp->device.DeviceId == PLX_9656RDK_860_DEVICE_ID) ||
            (pBsp->device.DeviceId == PLX_9656RDK_LITE_DEVICE_ID) ||
            (pBsp->device.DeviceId == PLX_9056RDK_860_DEVICE_ID))
        {

            PlxRegisterWrite(
                hPlx,
                PCI9054_EEPROM_CTRL_STAT,
                PlxRegisterRead(hPlx, PCI9054_EEPROM_CTRL_STAT, &rc) & ~((ULONG)1<<16)
                );

            Sleep(200);

            PlxRegisterWrite(
                hPlx,
                PCI9054_EEPROM_CTRL_STAT,
                PlxRegisterRead(hPlx, PCI9054_EEPROM_CTRL_STAT, &rc) | (1<<16)
                );
        }

        Sleep(200);

        if (!TestIsValid(HOST_LED_TEST))
        {   
            LogBuffer.Format("Host LED Test                        : Aborted - flashed LED %i times", NumOfLedBlinks);
            LogWrite(LogBuffer);
            return FALSE;   
        }

        NumOfLedBlinks++;
    }

    if (NumOfLedBlinks > 0)
    {
        LogBuffer.Format("Host LED Test                        : Flashed LED %i times", NumOfLedBlinks);
    }
    else
    {
        LogBuffer.Format("Host LED Test                        : Aborted - flashed LED %i times", -NumOfLedBlinks);
    }

    LogWrite(LogBuffer);

    return TRUE;        
}





/************************************************************************
 *  Function    :   HostTestFlash0      (virtual function)
 *  Abstract    :   This function can be polled to check if the BSP 
 *                  test is supported.
 ************************************************************************/
BOOL
CBsp::HostTestFlash0(
    void 
    )
{
    return IsTestSupported(
               HOST_FLASH_0_TEST
               );
}




/************************************************************************
 *  Function    :   HostTestFlash1      (virtual function)
 *  Abstract    :   This function can be polled to check if the BSP 
 *                  test is supported.
 ************************************************************************/
BOOL
CBsp::HostTestFlash1(
    void
    )
{
    return FALSE;
}




/************************************************************************
 *  Function    :   HostTestVpd         (virtual function)
 *  Abstract    :   This funciton test the VPD capabilities of the Plx 
 *                  chip
 ************************************************************************/
BOOL
CBsp::HostTestVpd(
    void
    )
{
    U32         EepromOffset;
    U32         EepValue;
    U32         Vpd_Cap_Id;
    U32         Done, check;
    U32         FailCount=0;
    RETURN_CODE rc;


    if (!IsTestSupported(HOST_VPD_TEST))
        return FALSE;
    
    for (EepromOffset = 0x0; EepromOffset < 0x80; EepromOffset+=4)
    {
        do
        {
            Vpd_Cap_Id = EepromOffset<<16 | 3;
            PlxPciConfigRegisterWrite(
                pBsp->device.BusNumber,
                pBsp->device.SlotNumber,
                RegisterOffset.VpdId,
                &Vpd_Cap_Id
                );

            Done =
                PlxPciConfigRegisterRead(
                    pBsp->device.BusNumber,
                    pBsp->device.SlotNumber,
                    RegisterOffset.VpdId,
                    &rc
                    );

            check = Done | 0x7FFFFFFF;
            if (check != 0xFFFFFFFF)
            {                   
                FailCount++;
                if (FailCount > 500)
                    return FALSE;
            }
        }
        while(check != 0xFFFFFFFF);

        EepValue =
            PlxPciConfigRegisterRead(
                pBsp->device.BusNumber,
                pBsp->device.SlotNumber,
                RegisterOffset.VpdData,
                &rc
                );

        FailCount = 0;
    }

    return TRUE;
}




/************************************************************************
 *  Function    :   HostTestHotSwap     (virtual function)
 *  Abstract    :   No default implementation
 ************************************************************************/
BOOL
CBsp::HostTestHotSwap(
    void
    )
{
    return  FALSE;
}





/************************************************************************
 *  Function    :   HostTestUart        (virtual function)
 *  Abstract    :   No default implementation
 ************************************************************************/
BOOL
CBsp::HostTestUart(
    void
    )
{
    return  FALSE;
}


#define MODEM_SPACE_REMAP	0x3f1
#define MODEM_CS_REMAP		0x3f9

#define MODEM_TRANSMIT_REG	0x8

/************************************************************************
 *  Function    :   HostTestIsa        (virtual function)
 *  Abstract    :   No default implementation
 ************************************************************************/
BOOL CBsp::HostTestIsa()
{
	BOOL		 bRetVal = TRUE;
    U16          RegOffset;
    DWORD		 dwBaseAddr;
    RETURN_CODE	 rc;
	CButton     *pDisplay;


    // Get the dialog item that will serve as a UI for this test. All output messages will be displayed there
	pDisplay = (CButton *)(((CDialog*)pDlg)->GetDlgItem(IDC_DETAILS_BUTTON));
    
	// Gather information about the initial environment of the board & chip
	switch(pBsp->device.DeviceId)
    {
		// Both the 9050 & 9052 are supported. But for the 9052, we have to make sure that the ISA interface is turned on
        case PLX_9050RDK_LITE_DEVICE_ID:
        case PLX_9052RDK_LITE_DEVICE_ID:
            RegOffset = 0x1c;		// 9050 & 9052 PCI Base Address 1 Register
            break;

		// No supported chip detected -> exit
        default:
            return FALSE;
    }


	// Get Base Address 1
	dwBaseAddr =
        PlxPciConfigRegisterRead(
		    pBsp->device.BusNumber,
		    pBsp->device.SlotNumber, 
		    RegOffset,
		    &rc
		    );

	if (rc != ApiSuccess)
	{
		CString LogBuffer;
		LogBuffer.Format("Host ISA Test: Error reading Config Register 0x%03x", RegOffset);
		LogWrite(LogBuffer);
		return FALSE;
	}

	// Remove first bit
	dwBaseAddr-=1;

	CPlx9050TestUART TestUART(hPlx,pBsp->device.DeviceId,dwBaseAddr);

	bRetVal = TestUART.TestUART(FALSE);

    return bRetVal;
}



/************************************************************************
 *  Function    :   HostTestPlxChip     (virtual function)
 *  Abstract    :   This function is used to test the plx chip on on the 
 *                  RDK, the base class implements the test for 9080, 9054
 *                  9056, 9656.
 ************************************************************************/
BOOL
CBsp::HostTestPlxChip(
    void
    )
{
    BOOL        bRetVal(TRUE);
    U8          j;
    U16         RegOffset;
    U32         TestData[] = {0xa5a5a5a5, 0x5a5a5a5a, 0xffffffff, 0x12345678};
    U32         ReadValue;
    RETURN_CODE rc; 

    struct
    {
        U16   first;
        U16   last;
    } PCI9054_Registers[] = {{       PCI9054_VENDOR_ID, PCI9054_INT_LINE},
                             {    PCI9054_SPACE0_RANGE, PCI9054_DM_PCI_IO_CONFIG},
                             {    PCI9054_SPACE1_RANGE, PCI9054_SPACE1_DESC},
                             {        PCI9054_MAILBOX2, PCI9054_REVISION_ID},
                             {       PCI9054_DMA0_MODE, PCI9054_DMA_THRESHOLD},
                             {PCI9054_OUTPOST_INT_STAT, PCI9054_OUTPOST_INT_MASK},
                             {       PCI9054_MU_CONFIG, PCI9054_FIFO_CTRL_STAT}};


    if (!IsTestSupported(HOST_PLX_CHIP_TEST))
        return FALSE;

    for (j=0; j<0x7; j++)
    {
        for (RegOffset=PCI9054_Registers[j].first; RegOffset<=PCI9054_Registers[j].last; RegOffset+=4)
        {
            if (j == 0)             /* Configuration Registers */
            {
                PlxPciConfigRegisterRead(
                    pBsp->device.BusNumber,
                    pBsp->device.SlotNumber, 
                    RegOffset,
                    &rc
                    );

                if (rc != ApiSuccess)
                {
                    LogBuffer.Format("Host PLX Chip Test: Error reading Config Register 0x%03x", RegOffset);
                    LogWrite(LogBuffer);
                    bRetVal = FALSE;
                }
            }
            else
            {
                PlxRegisterRead(
                    hPlx,
                    RegOffset,
                    &rc
                    );

                if (rc != ApiSuccess)
                {
                    LogBuffer.Format("Host PLX Chip Test: Error reading Local Register 0x%03x", RegOffset);
                    LogWrite(LogBuffer);
                    bRetVal = FALSE;
                }
            }
        }
    }

    /* Write to mailbox 5 and 7*/
    for (j = 0; j<4; j++)
    {
        PlxRegisterMailboxWrite(
            hPlx,
            MailBox5,
            TestData[j]
            );

        ReadValue =
            PlxRegisterMailboxRead(
                hPlx,
                MailBox5,
                &rc
                );

        if (ReadValue != TestData[j] || rc != ApiSuccess)
        {
            LogBuffer.Format("Host PLX Chip Test:      Mailbox 5 error    Wrote: 0x%08x    Read:0x%08x",
                              TestData[j], ReadValue);
            LogWrite(LogBuffer);
            bRetVal = FALSE;
        }

        PlxRegisterMailboxWrite(
            hPlx,
            MailBox7,
            TestData[j]
            );

        ReadValue =
            PlxRegisterMailboxRead(
                hPlx,
                MailBox7,
                &rc
                );

        if (ReadValue != TestData[j] || rc != ApiSuccess)
        {
            LogBuffer.Format("Host PLX Chip Test:      Mailbox 7 error    Wrote: 0x%08x    Read:0x%08x",
                             TestData[j], ReadValue);
            LogWrite(LogBuffer);
            bRetVal = FALSE;
        }

    }
    return  bRetVal;
}







/************************************************************************
 *  Function    :   LocalTestRam0       (virtual function)
 *  Abstract    :   The fuction a communication function which will 
 *                  communicate to the local application throught Plx chip 
 *                  to initaite the local test.
 ************************************************************************/
BOOL
CBsp::LocalTestRam0(
    void
    )
{
    if (!IsTestSupported(LOCAL_RAM_0_TEST))
        return FALSE;

    if (IopTest(
            "IOP Sdram Test                       ",
            MSG_CMD_TEST_DRAM,
            MSG_DATA_NONE,
            TIMEOUT_TEST_DRAM
            ) == TRUE)
    {
        return TRUE;
    }

    return  FALSE;
}

 



/************************************************************************
 *  Function    :   LocalTestRam1       (virtual function)
 *  Abstract    :   The fuction a communication function which will 
 *                  communicate to the local application throught Plx chip 
 *                  to initaite the local test.
 ************************************************************************/
BOOL
CBsp::LocalTestRam1(
    void
    )
{
    if(!IsTestSupported(LOCAL_RAM_1_TEST))
       return FALSE;

    if (IopTest(
            "IOP Sbsram Test                      ",
            MSG_CMD_TEST_SRAM,
            MSG_DATA_NONE,
            TIMEOUT_TEST_SRAM
            ) == TRUE)
    {
        return TRUE;
    }

    return  FALSE;
}





/************************************************************************
 *  Function    :   LocalTestRam2       (virtual function)
 *  Abstract    :   No default implemetation
 ************************************************************************/
BOOL
CBsp::LocalTestRam2(
    void
    )
{
    if(!IsTestSupported(LOCAL_RAM_2_TEST))
        return FALSE;

    return  FALSE;
}




/************************************************************************
 *  Function    :   LocalTestLed       (virtual function)
 *  Abstract    :   The fuction a communication function which will 
 *                  communicate to the local application throught Plx chip 
 *                  to initaite the local test.
 ************************************************************************/
BOOL
CBsp::LocalTestLed(
    void
    )
{
    if (!IsTestSupported(LOCAL_LED_TEST))
        return FALSE;

    if (IopTest(
            "IOP LED Test                         ",
            MSG_CMD_TEST_LED,
            MSG_DATA_NONE,
            TIMEOUT_TEST_LED
            ) == TRUE)
    {
        return TRUE;
    }

    return  FALSE;
}




/************************************************************************
 *  Function    :   LocalTestFlash0       (virtual function)
 *  Abstract    :   The fuction a communication function which will 
 *                  communicate to the local application throught Plx chip 
 *                  to initaite the local test.
 ************************************************************************/
BOOL
CBsp::LocalTestFlash0(
    void 
    )
{
    if (!IsTestSupported(LOCAL_FLASH_0_TEST))
        return FALSE;

    if (IopTest(
            "IOP Flash Test                       ",
            MSG_CMD_TEST_FLASH,
            MSG_DATA_NONE,
            TIMEOUT_TEST_FLASH
            ) == TRUE)
    {
        return TRUE;
    }

    return  FALSE;
}




/************************************************************************
 *  Function    :   LocalTestFlash1       (virtual function)
 *  Abstract    :   No default implementation
 ************************************************************************/
BOOL
CBsp::LocalTestFlash1(
    void
    )
{
    if (!IsTestSupported(LOCAL_FLASH_0_TEST))
        return FALSE;

    return  FALSE;
}




/************************************************************************
 *  Function    :   LocalTestHotSwap       (virtual function)
 *  Abstract    :   No default implementation
 ************************************************************************/
BOOL
CBsp::LocalTestVpd(
    void
    )
{
    return  FALSE;
}




/************************************************************************
 *  Function    :   LocalTestHotSwap       (virtual function)
 *  Abstract    :   No default implementation
 ************************************************************************/
BOOL
CBsp::LocalTestHotSwap(
    void
    )
{
    if (!IsTestSupported(LOCAL_HOT_SWAP_TEST))
        return FALSE;

    return  FALSE;
}




/************************************************************************
 *  Function    :   LocalTestUart       (virtual function)
 *  Abstract    :   The fuction a communication function which will 
 *                  communicate to the local application throught Plx chip 
 *                  to initaite the local test.
 ************************************************************************/
BOOL
CBsp::LocalTestUart(
    void
    )
{
    if (!IsTestSupported(LOCAL_UART_TEST))
        return FALSE;

    if (IopTest(
            "IOP Uart Test                        ",
            MSG_CMD_TEST_UART,
            MSG_DATA_NONE,
            TIMEOUT_TEST_UART
            ) == TRUE)
    {
        return TRUE;
    }

    return  FALSE;
}




/************************************************************************
 *  Function    :   LocalTestPlxChip       (virtual function)
 *  Abstract    :   The fuction a communication function which will 
 *                  communicate to the local application throught Plx chip 
 *                  to initaite the local test.
 ************************************************************************/
BOOL
CBsp::LocalTestPlxChip(
    void
    )
{
    if (!IsTestSupported(LOCAL_PLX_CHIP_TEST))
        return FALSE;

    if (IopTest(
            "Local PLX Chip Test     : ",
            MSG_CMD_TEST_PLX_CHIP,
            MSG_DATA_NONE,
            TIMEOUT_TEST_PLX_CHIP
            ) == TRUE)
    {
        return TRUE;
    }

    return  FALSE;
}




/************************************************************************
 *  Function    :   GetTestVecArray       (public member function)
 *  Abstract    :   The fuction will use the 32-bit mask that defines
 *                  the test that are supported by this RDK and expand
 *                  it into a array of 8-bit elements. The function that
 *                  call this function inherits the responsiblity of 
 *                  deallocating the dynamic array that is return using 
 *                  the delete [] operation.
 ************************************************************************/
char*
CBsp::GetTestVecArray(
    void
    )
{
    char *pRetBuf;


    pRetBuf = new char [BSP_TEST_CNT];

    memset(
        pRetBuf,
        0,
        BSP_TEST_CNT
        );

    for (int i = 0; i < BSP_TEST_CNT; i++)
        pRetBuf[i] = (uTestVector & (1 << i)) ? 1 : 0;

    return pRetBuf;
}




/************************************************************************
 *  Function    :   LocalTestPlxChip       (virtual function)
 *  Abstract    :   The function will write the log buffer to the log file.
 ************************************************************************/
void
CBsp::WriteLogFile(
    void
    )
{
    CFile hFile;


    if (szFileLog.GetLength() == 0)
        return;

    if (hFile.Open(
            LogFileName,
            CFile::modeCreate | CFile::modeWrite | CFile::typeText
            ))
    {
        hFile.Write(
            szFileLog,
            szFileLog.GetLength()
            );

        hFile.Close();
    }

    szFileLog = "";
}




BOOL 
CBsp::IopTest(  
    CString LogString,
    U16     Command,
    U16     MsgData,
    double  TimeOut
    )
{
    U16 RcvCmd;
    U16 RcvData;


    if (MsgSend(hPlx, MSG_CMD_READY, MsgData) == FALSE)
    {
        LogBuffer =  LogString + "Failed to send READY Message";
        LogWrite(LogBuffer);
        return FALSE;
    }

    if (MsgReceive(hPlx, &RcvCmd, &RcvData, TimeOut) == FALSE)
    {
        LogBuffer= "%s: Failed to receive TEST_COMPLETE Message";
        LogWrite(LogBuffer);
        return FALSE;
    }

    if (MsgSend(hPlx, Command, MsgData) == FALSE)
    {
        LogBuffer=  LogString+": Failed to send TEST_START Message";
        LogWrite(LogBuffer);
        return FALSE;
    }

    if (MsgReceive(hPlx, &RcvCmd, &RcvData, TimeOut) == FALSE)
    {
        LogBuffer=  LogString+": Failed to receive TEST_COMPLETE Message";
        LogWrite(LogBuffer);
        return FALSE;
    }

    if (RcvData == MSG_STATUS_PASSED)
    {
        return TRUE;
    }
    else
    {
        LogWrite(LogBuffer);
        return FALSE;
    }
}

