// Log.cpp: implementation of the CLog class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ManfGUI.h"
#include "Log.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CLog::CLog()
{
	m_EditLog=0;
}

CLog::~CLog()
{
	m_EditLog=0;
}

void CLog::Init(CEdit *hEditBox)
{
	m_EditLog=hEditBox;
}


void CLog::Log(CString msg)
{
	Log(msg.GetBuffer(0));
	msg.ReleaseBuffer(-1);
}

void CLog::Log(_TCHAR *msg)
{
	Display(msg);
	WriteLog(msg);
}


void CLog::Display(CString msg)
{
	Display(msg.GetBuffer(0));
	msg.ReleaseBuffer(-1);
}

void CLog::Display(_TCHAR *msg)
{
	if(m_EditLog) 
	{
		CTime t=CTime::GetCurrentTime();
		CString out=t.Format(_T(": "));
		m_EditLog->ReplaceSel(msg);
		m_EditLog->ReplaceSel(_T("\r\n"));
	}
}


void CLog::WriteLog(_TCHAR *msg)
{
	// Add code here to write to the log file
}


void CLog::Clear()
{

	m_EditLog->SetWindowText(_T(""));

}
