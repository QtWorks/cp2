#ifndef __SUPPORT_FUNC_H
#define __SUPPORT_FUNC_H

/*******************************************************************************
 * Copyright (c) 2002 PLX Technology, Inc.
 *
 * PLX Technology Inc. licenses this software under specific terms and
 * conditions.  Use of any of the software or derviatives thereof in any
 * product without a PLX Technology chip is strictly prohibited.
 *
 * PLX Technology, Inc. provides this software AS IS, WITHOUT ANY WARRANTY,
 * EXPRESS OR IMPLIED, INCLUDING, WITHOUT LIMITATION, ANY WARRANTY OF
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  PLX makes no guarantee
 * or representations regarding the use of, or the results of the use of,
 * the software and documentation in terms of correctness, accuracy,
 * reliability, currentness, or otherwise; and you rely on the software,
 * documentation and results solely at your own risk.
 *
 * IN NO EVENT SHALL PLX BE LIABLE FOR ANY LOSS OF USE, LOSS OF BUSINESS,
 * LOSS OF PROFITS, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES
 * OF ANY KIND.  IN NO EVENT SHALL PLX'S TOTAL LIABILITY EXCEED THE SUM
 * PAID TO PLX FOR THE PRODUCT LICENSED HEREUNDER.
 *
 ******************************************************************************/

/******************************************************************************
 *
 * File Name:
 *
 *      SupportFunc.h
 *
 * Description:
 *
 *      Header for additional support functions
 *
 * Revision History:
 *
 *      04-31-02 : PCI SDK v3.50
 *
 ******************************************************************************/


#include "DriverDefs.h"




/**********************************************
 *               Functions
 *********************************************/
BOOLEAN
PlxSynchronizedRegisterModify(
    PLX_REG_DATA *pRegData
    );

VOID
PlxRegistryInformationGet(
    UNICODE_STRING       *pRegistryPath,
    REGISTRY_INFORMATION *pRegistryInfo
    );

NTSTATUS
PlxSearchDevices(
    DEVICE_EXTENSION *pdx,
    DEVICE_LOCATION  *pDeviceCriteria,
    U32              *pAmountMatched
    );

VOID
PlxReportEvent(
    NTSTATUS ErrorCode,
    PVOID    pIoObject
    );

U8
GetBarIndex(
    PHYSICAL_ADDRESS   address,
    PCI_COMMON_CONFIG *pciRegs
    );

NTSTATUS
PlxCompleteIrp(
    PIRP     pIrp,
    NTSTATUS status
    );

NTSTATUS
PlxCompleteIrpWithInformation(
    PIRP     pIrp,
    NTSTATUS status,
    U32      Info
    );

VOID
PlxInterruptIrpCancel(
    DEVICE_EXTENSION *pdx,
    PIRP              pIrp
    );

VOID
OnCancelInterruptIrp(
    PDEVICE_OBJECT fdo,
    PIRP           pIrp
    );

VOID
PlxDmaChannelCleanup(
    DEVICE_EXTENSION *pdx,
    VOID             *pOwner
    );

VOID
OnCancelDmaIrp(
    PDEVICE_OBJECT fdo,
    PIRP           pIrp
    );

NTSTATUS
PlxPciBarResourceMap(
    DEVICE_EXTENSION *pdx,
    U8                BarIndex
    );

VOID
PlxPciBarResourcesUnmap(
    DEVICE_EXTENSION *pdx
    );

VOID
PlxPciBarSpaceUnmapAll_ByOwner(
    DEVICE_EXTENSION *pdx,
    VOID             *pOwner
    );

VOID
PlxPciPhysicalMemoryFreeAll_ByOwner(
    DEVICE_EXTENSION *pdx,
    VOID             *pOwner
    );

VOID
PlxPciPhysicalMemoryUnmapAll_ByOwner(
    DEVICE_EXTENSION *pdx,
    PLX_PHYSICAL_MEM *pMemObject,
    VOID             *pOwner
    );

PVOID
MapInUserSpace(
    PHYSICAL_ADDRESS AddrPhysical,
    U32              Size
    );

VOID
Plx_sleep(
    U32 delay
    );

PIRP
PlxBlockDmaTransferComplete(
    DEVICE_EXTENSION *pdx,
    U8                DmaIndex
    );

PIRP
PlxSglDmaTransferComplete(
    DEVICE_EXTENSION *pdx,
    U8                DmaIndex
    );

PVOID
PlxLockBufferAndBuildSgl(
    DEVICE_EXTENSION     *pdx,
    U8                    DmaIndex,
    DMA_TRANSFER_ELEMENT *pDma
    );

NTSTATUS
OnRequestComplete(
    PDEVICE_OBJECT fdo,
    PIRP           pIrp,
    PKEVENT        pKEvent
    );

NTSTATUS
ForwardAndWait(
    PDEVICE_OBJECT fdo,
    PIRP           pIrp
    );

NTSTATUS
GetBusSlotNumber(
    PDEVICE_OBJECT    pdo,
    DEVICE_EXTENSION *pdx
    );

BOOLEAN
IsSupportedDevice(
    U32                   DeviceVendorId,
    REGISTRY_INFORMATION *pRegistryInfo
    );



#endif
