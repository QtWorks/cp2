/*******************************************************************************
 * Copyright (c) 2002 PLX Technology, Inc.
 *
 * PLX Technology Inc. licenses this software under specific terms and
 * conditions.  Use of any of the software or derviatives thereof in any
 * product without a PLX Technology chip is strictly prohibited.
 *
 * PLX Technology, Inc. provides this software AS IS, WITHOUT ANY WARRANTY,
 * EXPRESS OR IMPLIED, INCLUDING, WITHOUT LIMITATION, ANY WARRANTY OF
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  PLX makes no guarantee
 * or representations regarding the use of, or the results of the use of,
 * the software and documentation in terms of correctness, accuracy,
 * reliability, currentness, or otherwise; and you rely on the software,
 * documentation and results solely at your own risk.
 *
 * IN NO EVENT SHALL PLX BE LIABLE FOR ANY LOSS OF USE, LOSS OF BUSINESS,
 * LOSS OF PROFITS, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES
 * OF ANY KIND.  IN NO EVENT SHALL PLX'S TOTAL LIABILITY EXCEED THE SUM
 * PAID TO PLX FOR THE PRODUCT LICENSED HEREUNDER.
 *
 ******************************************************************************/

/******************************************************************************
 *
 * File Name:
 *
 *      Driver.c
 *
 * Description:
 *
 *      This file initializes the necessary system resources for
 *      for the PLX device.
 *
 * Revision History:
 *
 *      04-31-02 : PCI SDK v3.50
 *
 *****************************************************************************/


#include <stdio.h>
#include "CommonApi.h"
#include "Driver.h"
#include "Dispatch.h"
#include "GlobalVars.h"
#include "Messages.h"
#include "PlxInterrupt.h"
#include "SupportFunc.h"

#if defined(DMA_SUPPORT)
    #include "Buffer.h"
#endif

#if defined(WDM_DRIVER)
    #include "PciSupport.h"
    #include "PlugPlay.h"
    #include "Power.h"
#endif


#if defined(ALLOC_PRAGMA) && !defined(PLX_DEBUG)
    #pragma alloc_text(INIT, DriverEntry)
#endif




/******************************************************************************
 *
 * Function   :  DriverEntry
 *
 * Description:  Entry point for the driver.
 *
 ******************************************************************************/
NTSTATUS
DriverEntry(
    PDRIVER_OBJECT  pDriverObject,
    PUNICODE_STRING pRegistryPath
    )
{
    S8                   MinorVersion;
    BOOLEAN              bVersionFound;
    NTSTATUS             status;
    REGISTRY_INFORMATION RegistryInfo;

    DebugPrintf_NoInfo(("\n<========================================================>\n"));
    DebugPrintf((
        "WDM v%x.%x Device Driver - built on %s %s\n",
        WDM_MAJORVERSION, WDM_MINORVERSION,
        __DATE__, __TIME__
        ));

    // Set flag to note that this is a WDM driver
    IsDriverWdm = TRUE;

    // Set starting version
    MinorVersion = 0x41;

    // Determine the highest WDM version supported
    do
    {
        // Decrement to lower version
        MinorVersion--;

        bVersionFound =
            IoIsWdmVersionAvailable(
                0x01,              // Just check for version 1.x for now
                MinorVersion
                );
    }
    while ((bVersionFound == FALSE) && (MinorVersion >= 0));

    // Display possible OS version
    DebugPrintf(("OS supports WDM 1.%02x ", MinorVersion));

    if (MinorVersion >= 0x20)
    {
        DebugPrintf_NoInfo(("(Windows XP or higher)\n"));
    }
    else if (MinorVersion >= 0x10)
    {
        DebugPrintf_NoInfo(("(Windows 2000 or higher)\n"));
    }
    else
    {
        DebugPrintf_NoInfo(("(Windows 98 or higher)\n"));
    }

    DebugPrintf((
        "Device Registry path = \"%ws\"\n",
        pRegistryPath->Buffer
        ));

    // Get configuration information from registry
    PlxRegistryInformationGet(
        pRegistryPath,
        &RegistryInfo
        );

    // Fill in the appropriate dispatch handlers
    pDriverObject->DriverUnload                         = DriverUnload;
    pDriverObject->MajorFunction[IRP_MJ_CREATE]         = Dispatch_Create;
    pDriverObject->MajorFunction[IRP_MJ_CLOSE]          = Dispatch_Close;
    pDriverObject->MajorFunction[IRP_MJ_READ]           = Dispatch_Read;
    pDriverObject->MajorFunction[IRP_MJ_WRITE]          = Dispatch_Write;
    pDriverObject->MajorFunction[IRP_MJ_CLEANUP]        = Dispatch_Cleanup;
    pDriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL] = Dispatch_IoControl;
    pDriverObject->MajorFunction[IRP_MJ_PNP]            = Dispatch_Pnp;
    pDriverObject->MajorFunction[IRP_MJ_POWER]          = Dispatch_Power;
    pDriverObject->MajorFunction[IRP_MJ_SYSTEM_CONTROL] = Dispatch_SystemControl;
    pDriverObject->DriverExtension->AddDevice           = AddDevice;

    // Set requested size
    Gbl_CommonBuffer.PciMem.Size = RegistryInfo.CommonBufferSize;

    // Allocate common buffer
    PlxPciPhysicalMemoryAllocate(
        NULL,                   // No device to assign buffer to
        &(Gbl_CommonBuffer.PciMem),
        TRUE,                   // Smaller buffer is ok
        pDriverObject           // Assign Driver object as owner
        );

#if defined(DMA_SUPPORT)
    if (RegistryInfo.MaxSglTransferSize != 0)
    {
        // Allocate a buffer for SGL descriptors
        if (DriverBufferInit(
                48 * ((RegistryInfo.MaxSglTransferSize >> PAGE_SHIFT) + 3)
                ))
        {
            DebugPrintf(("Allocated SGL descriptor buffer to support "));
            if (RegistryInfo.MaxSglTransferSize >= (1 << 10))
                DebugPrintf_NoInfo(("%d Kb transfers\n", RegistryInfo.MaxSglTransferSize >> 10));
            else
                DebugPrintf_NoInfo(("%d Byte transfers\n", RegistryInfo.MaxSglTransferSize));
        }
        else
            DebugPrintf(("ERROR - SGL descriptor buffer allocation failed\n"));
    }
#endif  // DMA_SUPPORT

    return STATUS_SUCCESS;
}




/******************************************************************************
 *
 * Function   :  DriverUnload
 *
 * Description:  Unload the driver.
 *
 ******************************************************************************/
VOID
DriverUnload(
    PDRIVER_OBJECT pDriverObject
    )
{
    DebugPrintf_NoInfo(("\n"));
    DebugPrintf(("Unloading Driver...\n"));

    // Release common buffer
    if (Gbl_CommonBuffer.PciMem.PhysicalAddr != (U32)NULL)
    {
        DebugPrintf((
            "De-allocating Common Buffer (%d Kb)...\n",
            (Gbl_CommonBuffer.PciMem.Size >> 10)
            ));

        // Free the MDL
        if (Gbl_CommonBuffer.pMdl != NULL)
        {
            IoFreeMdl(
                Gbl_CommonBuffer.pMdl
                );

            Gbl_CommonBuffer.pMdl = NULL;
        }

        // Release the buffer
        if (Gbl_CommonBuffer.pKernelVa != NULL)
        {
            MmFreeContiguousMemory(
                Gbl_CommonBuffer.pKernelVa
                );

            Gbl_CommonBuffer.pKernelVa = NULL;
        }
    }

#if defined(DMA_SUPPORT)
    DebugPrintf(("De-allocating SGL descriptor buffer...\n"));
    DriverBufferTerminate();
#endif

    DebugPrintf(("Driver unloaded\n"));
}




/******************************************************************************
 *
 * Function   :  AddDevice
 *
 * Description:  Add a new functional device object for a physical one
 *
 ******************************************************************************/
NTSTATUS
AddDevice(
    PDRIVER_OBJECT pDriverObject,
    PDEVICE_OBJECT pdo
    )
{
    U8                i;
    WCHAR             DeviceName[PLX_MAX_NAME_LENGTH];
    WCHAR             DeviceLinkName[PLX_MAX_NAME_LENGTH];
    NTSTATUS          status;
    POWER_STATE       powerState;
    UNICODE_STRING    DeviceName_Unicode;
    UNICODE_STRING    DeviceLinkName_Unicode;
    PDEVICE_OBJECT    fdo;
    DEVICE_EXTENSION *pdx;


    // Build a device name and attempt to create it
    for (i=0; i < 20; i++)
    {
        swprintf(
            DeviceName,
            L"\\Device\\" PLX_DRIVER_NAME_UNICODE L"-%d",
            i
            );

        RtlInitUnicodeString(
            &DeviceName_Unicode,
            DeviceName
            );

        // Create the device object
        status =
            IoCreateDevice(
                pDriverObject,
                sizeof(DEVICE_EXTENSION),
                &DeviceName_Unicode,
                FILE_DEVICE_UNKNOWN,
                0,
                FALSE,            // Shared by applications
                &fdo
                );

        // IoCreateDevice() will fail if the same object already exists
        if (NT_SUCCESS(status))
        {
            break;
        }
    }

    // Check if the creation succeeded
    if ( !NT_SUCCESS(status) )
    {
        DebugPrintf(("ERROR - Unable to create Device\n"));
        return status;
    }

    DebugPrintf((
        "Created Device (%ws)...\n",
        DeviceName
        ));

    // Link a Win32 name for user applications
    swprintf(
        DeviceLinkName,
        L"\\DosDevices\\" PLX_DRIVER_NAME_UNICODE L"-%d",
        i
        );

    RtlInitUnicodeString(
        &DeviceLinkName_Unicode,
        DeviceLinkName
        );

    DebugPrintf((
        "Creating Win32 symbolic link (%ws)...\n",
        DeviceLinkName
        ));

    status =
        IoCreateSymbolicLink(
            &DeviceLinkName_Unicode,
            &DeviceName_Unicode
            );

    if ( !NT_SUCCESS(status) )
    {
        DebugPrintf(("WARNING - Unable to create symbolic link for Win32 Apps\n"));
        swprintf(DeviceLinkName, L"");
    }

    // Initialize the device extension
    pdx = fdo->DeviceExtension;

    RtlZeroMemory(
        pdx,
        sizeof(DEVICE_EXTENSION)
        );

    pdx->pDeviceObject         = fdo;
    pdx->pPhysicalDeviceObject = pdo;
    pdx->usage                 = 1;          // Locked until RemoveDevice

    sprintf(
        pdx->Device.SerialNumber,
        PLX_DRIVER_NAME "-%d",
        i
        );

    wcscpy(
        pdx->LinkName,
        DeviceLinkName
        );

    // Initialize PCI BAR variables
    for (i = 0 ; i < PCI_NUM_BARS; i++)
    {
        pdx->PciBar[i].pVa               = NULL;
        pdx->PciBar[i].Physical.QuadPart = (U32)NULL;
        pdx->PciBar[i].Size              = 0;
        pdx->PciBar[i].IsIoMapped        = FALSE;
        pdx->PciBar[i].pMdl              = NULL;

        InitializeListHead(
            &(pdx->PciBar[i].List_Mappings)
            );

        KeInitializeSpinLock(
            &(pdx->PciBar[i].Lock_MappingsList)
            );
    }

    KeInitializeSpinLock(
        &(pdx->Lock_HwAccess)
        );

    InitializeListHead(
        &(pdx->List_InterruptWait)
        );

    KeInitializeSpinLock(
        &(pdx->Lock_InterruptWaitList)
        );

    InitializeListHead(
        &(pdx->List_PhysicalMem)
        );

    KeInitializeSpinLock(
        &(pdx->Lock_PhysicalMemList)
        );

    InitializeListHead(
        &(pdx->List_BarMappings)
        );

    KeInitializeSpinLock(
        &(pdx->Lock_BarMappingsList)
        );

    ExInitializeFastMutex(
        &(pdx->DispatchMutex)
        );

    // Initialize the interrupt DPC
    KeInitializeDpc(
        &(pdx->DpcForIsr),
        DpcForIsr,
        pdx
        );

#if defined(DMA_SUPPORT)
    // Initialize DMA management variables
    for (i = 0 ; i < NUMBER_OF_DMA_CHANNELS; i++)
    { 
        pdx->DmaInfo[i].state              = DmaStateClosed;
        pdx->DmaInfo[i].bLocalAddrConstant = FALSE;
    }

    KeInitializeSpinLock(
        &(pdx->Lock_DmaChannel)
        );
#endif  // DMA_SUPPORT

    KeInitializeEvent(
        &pdx->evRemove,
        NotificationEvent,
        FALSE
        );

    /*
     *  Since we must pass PNP requests down to the next device object in the
     *  chain (namely the physical device object created by the bus enumerator),
     *  we have to remember what that device is. That's why we defined the
     *  LowerDeviceObject member in our device extension.
     */
    pdx->pLowerDeviceObject =
        IoAttachDeviceToDeviceStack(
            fdo,
            pdo
            );

    DebugPrintf((
        "Attached device to stack\n"
        "            Functional DevObj: 0x%08x\n"
        "            Lower      DevObj: 0x%08x\n"
        "            Physical   DevObj: 0x%08x\n",
        fdo, pdx->pLowerDeviceObject, pdo
        ));

    // Notify the power manager of the initial power state
    pdx->Power             = PowerDeviceD0;      // Start device in full power state
    powerState.DeviceState = PowerDeviceD0;
    PoSetPowerState(
        fdo,
        DevicePowerState,
        powerState
        );

    // Indicate the I/O Manager buffer management method
    fdo->Flags |= DO_BUFFERED_IO;

    // Manually clear the Device Initialzing flag
    fdo->Flags &= ~DO_DEVICE_INITIALIZING;

    return STATUS_SUCCESS;
}




/******************************************************************************
 *
 * Function   :  RemoveDevice
 *
 * Description:  Remove a functional device object
 *
 ******************************************************************************/
VOID
RemoveDevice(
    PDEVICE_OBJECT fdo
    )
{
    NTSTATUS           status;
    UNICODE_STRING     DeviceLinkName_Unicode;
    DEVICE_EXTENSION  *pdx;


    pdx = fdo->DeviceExtension;

    // Remove Win32 link name
    if (wcslen(pdx->LinkName) != 0)
    {
        DebugPrintf((
            "Removing Win32 link (%ws)\n",
            pdx->LinkName
            ));

        RtlInitUnicodeString(
            &DeviceLinkName_Unicode,
            pdx->LinkName
            );

        status =
            IoDeleteSymbolicLink(
                &DeviceLinkName_Unicode
                );

        if ( !NT_SUCCESS(status) )
            DebugPrintf(("WARNING - Unable to remove Win32 link\n"));
    }

    // Detach device from the device object stack
    if (pdx->pLowerDeviceObject)
    {
        IoDetachDevice(
            pdx->pLowerDeviceObject
            );
    }

    DebugPrintf(("Deleting device object...\n"));

    // Delete the functional device object
    IoDeleteDevice(
        fdo
        );
}




/******************************************************************************
 *
 * Function   :  StartDevice
 *
 * Description:  Start a device
 *
 ******************************************************************************/
NTSTATUS
StartDevice(
    PDEVICE_OBJECT            fdo,
    PCM_PARTIAL_RESOURCE_LIST ResourceListRaw,
    PCM_PARTIAL_RESOURCE_LIST ResourceList
    )
{
    U8                               i;
    U8                               BarIndex;
    U32                              vector;
    KIRQL                            IrqL;
    BOOLEAN                          intPresent;
    NTSTATUS                         status;
    KAFFINITY                        affinity;
    KINTERRUPT_MODE                  mode;
    DEVICE_EXTENSION                *pdx;
    PCI_COMMON_CONFIG                pciRegs;
    PCM_PARTIAL_RESOURCE_DESCRIPTOR  ResourceRaw;
    PCM_PARTIAL_RESOURCE_DESCRIPTOR  Resource;


    pdx         = fdo->DeviceExtension;
    intPresent  = FALSE;
    ResourceRaw = ResourceListRaw->PartialDescriptors;
    Resource    = ResourceList->PartialDescriptors;

    // Get the PCI base addresses
    PciRegisterBufferRead(
        fdo,
        0,
        &pciRegs,
        sizeof(PCI_COMMON_CONFIG)
        );

    DebugPrintf((
        "Resource list contains %d descriptors\n",
        ResourceListRaw->Count
        ));

    for (i = 0; i < ResourceListRaw->Count; ++i, ++Resource, ++ResourceRaw)
    {
        DebugPrintf_NoInfo(("            Resource %02d\n", i));

        switch (ResourceRaw->Type)
        {
            case CmResourceTypeInterrupt:
                intPresent = TRUE;
                IrqL       = (KIRQL) Resource->u.Interrupt.Level;
                vector     = Resource->u.Interrupt.Vector;
                affinity   = Resource->u.Interrupt.Affinity;

                DebugPrintf_NoInfo((
                    "              Type    : Interrupt\n"
                    "              Vector  : 0x%02x        (Translated = 0x%02x)\n"
                    "              IRQL    : 0x%02x        (Translated = 0x%02x)\n"
                    "              Affinity: 0x%08x  (Translated = 0x%08x)\n",
                    ResourceRaw->u.Interrupt.Vector, vector,
                    ResourceRaw->u.Interrupt.Level, IrqL,
                    ResourceRaw->u.Interrupt.Affinity, affinity
                    ));

                if (ResourceRaw->Flags == CM_RESOURCE_INTERRUPT_LATCHED)
                {
                    mode = Latched;
                    DebugPrintf_NoInfo(("              Mode    : Latched\n"));
                }
                else
                {
                    mode = LevelSensitive;
                    DebugPrintf_NoInfo(("              Mode    : Level Sensitive\n"));
                }
                break;

            case CmResourceTypePort:
                DebugPrintf_NoInfo((
                    "              Type     : I/O Port\n"
                    "              Address  : 0x%08x  (Translated = 0x%08x)\n"
                    "              Size     : 0x%08x  ",
                    ResourceRaw->u.Port.Start.u.LowPart,
                    Resource->u.Port.Start.u.LowPart,
                    ResourceRaw->u.Port.Length
                    ));

                if (ResourceRaw->u.Port.Length >= (1 << 10))
                {
                    DebugPrintf_NoInfo((
                        "(%d Kb)\n",
                        ResourceRaw->u.Port.Length >> 10
                        ));
                }
                else
                {
                    DebugPrintf_NoInfo((
                        "(%d Bytes)\n",
                        ResourceRaw->u.Port.Length
                        ));
                }

                BarIndex =
                    GetBarIndex(
                        ResourceRaw->u.Port.Start,
                        &pciRegs
                        );

                if (BarIndex != (U8)-1)
                {
                    pdx->PciBar[BarIndex].Physical = ResourceRaw->u.Port.Start;
                    pdx->PciBar[BarIndex].Size     = ResourceRaw->u.Port.Length;

                    // Check if we need to map (usually on RISC platforms)
                    if (ResourceRaw->Flags & CM_RESOURCE_PORT_MEMORY)
                    {
                        pdx->PciBar[BarIndex].IsIoMapped = FALSE;

                        DebugPrintf_NoInfo(("              Kernel VA: "));

                        status =
                            PlxPciBarResourceMap(
                                pdx,
                                BarIndex
                                );

                        if ( NT_SUCCESS(status) )
                        {
                            DebugPrintf_NoInfo((
                                "0x%08x\n",
                                pdx->PciBar[BarIndex].pVa
                                ));
                        }
                        else
                        {
                            DebugPrintf_NoInfo((
                                "ERROR - Unable to map 0x%08x ==> Kernel VA\n",
                                ResourceRaw->u.Port.Start.u.LowPart
                                ));
                        }
                    }
                    else
                    {
                        pdx->PciBar[BarIndex].pVa        = NULL;
                        pdx->PciBar[BarIndex].IsIoMapped = TRUE;
                    }
                }
                break;

            case CmResourceTypeMemory:
                DebugPrintf_NoInfo((
                    "              Type     : Memory Space\n"
                    "              Address  : 0x%08x  (Translated = 0x%08x)\n"
                    "              Size     : 0x%08x  ",
                    ResourceRaw->u.Memory.Start.u.LowPart,
                    Resource->u.Memory.Start.u.LowPart,
                    ResourceRaw->u.Memory.Length
                    ));

                if (ResourceRaw->u.Memory.Length >= (1 << 10))
                {
                    DebugPrintf_NoInfo((
                        "(%d Kb)\n",
                        ResourceRaw->u.Memory.Length >> 10
                        ));
                }
                else
                {
                    DebugPrintf_NoInfo((
                        "(%d Bytes)\n",
                        ResourceRaw->u.Memory.Length
                        ));
                }

                BarIndex =
                    GetBarIndex(
                        ResourceRaw->u.Memory.Start,
                        &pciRegs
                        );

                if (BarIndex != (U8)-1)
                {
                    DebugPrintf_NoInfo(("              Kernel VA: "));

                    // Record resources
                    pdx->PciBar[BarIndex].Physical    = ResourceRaw->u.Memory.Start;
                    pdx->PciBar[BarIndex].Size        = ResourceRaw->u.Memory.Length;
                    pdx->PciBar[BarIndex].IsIoMapped  = FALSE;

                    status =
                        PlxPciBarResourceMap(
                            pdx,
                            BarIndex
                            );

                    if ( NT_SUCCESS(status) )
                    {
                        DebugPrintf_NoInfo((
                            "0x%08x\n",
                            pdx->PciBar[BarIndex].pVa
                            ));
                    }
                    else
                    {
                        DebugPrintf_NoInfo((
                            "ERROR - Unable to map 0x%08x ==> Kernel VA\n",
                            ResourceRaw->u.Memory.Start.u.LowPart
                            ));

                        // PCI BAR 0 is required for register access
                        if (BarIndex == 0)
                        {
                            DebugPrintf_NoInfo(("ERROR - BAR 0 mapping is required\n"));
                            return STATUS_INSUFFICIENT_RESOURCES;
                        }
                    }
                }
                break;

            case CmResourceTypeNull:
                DebugPrintf_NoInfo(("              Type: Null (unsupported)\n"));
                break;

            case CmResourceTypeDma:
                DebugPrintf_NoInfo(("              Type: DMA (unsupported)\n"));
                break;

            case CmResourceTypeDeviceSpecific:
                DebugPrintf_NoInfo(("              Type: Device Specific (unsupported)\n"));
                break;

            case CmResourceTypeBusNumber:
                DebugPrintf_NoInfo(("              Type: Bus Number (unsupported)\n"));
                break;

            // NonArbitrated & ConfigData are currently #defined as the same number
            case CmResourceTypeConfigData:
                DebugPrintf_NoInfo(("              Type: Non-Arbitrated or Config Data (unsupported)\n"));
                break;

            case CmResourceTypeDevicePrivate:
                DebugPrintf_NoInfo(("              Type: Device Private Data (unsupported)\n"));
                break;

            case CmResourceTypePcCardConfig:
                DebugPrintf_NoInfo(("              Type: PC Card Configuration (unsupported)\n"));
                break;

            case CmResourceTypeMfCardConfig:
                DebugPrintf_NoInfo(("              Type: Multi-function Card Configuration (unsupported)\n"));
                break;

            default:
                DebugPrintf_NoInfo(("              Type: ?Unknown Resource Type?\n"));
                break;
        }
    }

    // Make sure BAR 0 exists or the device can't be started
    if (pdx->PciBar[0].pVa == NULL)
    {
        ErrorPrintf(("ERROR - BAR 0 address not configured, unable to load driver\n"));
        return STATUS_INSUFFICIENT_RESOURCES;
    }

    if (intPresent)
    {
        // Disable the PCI interrupt
        PlxChipPciInterruptDisable(
            pdx
            );

        status =
            IoConnectInterrupt(
                &pdx->pInterruptObject,
                OnInterrupt,
                pdx,
                NULL,
                vector,
                IrqL,
                IrqL,
                mode,
                TRUE,
                affinity,
                FALSE
                );

        if ( !NT_SUCCESS(status) )
        {
            ErrorPrintf((
                "ERROR - IoConnectInterrupt() failed, status = 0x%08x\n",
                status
                ));

            PlxReportEvent(
                PLX_LOG_INVALID_INTERRUPT_CONNECTION,
                (PVOID)fdo
                );

            pdx->pInterruptObject = NULL;
        }
        else
        {
            DebugPrintf(("Connected to interrupt vector\n"));

            // Re-enable the PCI Interrupt
            KeSynchronizeExecution(
                pdx->pInterruptObject,
                PlxChipPciInterruptEnable,
                pdx
                );
        }
    }
    else
    {
        DebugPrintf(("No interrupt found\n"));
        pdx->pInterruptObject = NULL;
    }

#if defined(DMA_SUPPORT)
    //  Record Common buffer info into Mailbox registers

    // Write the Physical Address
    PLX_REG_WRITE(
        pdx,
        COMMON_BUFF_MBOX_ADDRESS,
        Gbl_CommonBuffer.PciMem.PhysicalAddr
        );

    // Write the Size
    PLX_REG_WRITE(
        pdx,
        COMMON_BUFF_MBOX_SIZE,
        Gbl_CommonBuffer.PciMem.Size
        );
#endif  // DMA_SUPPORT

    // Record the Vendor and Device ID
    pdx->Device.VendorId = pciRegs.VendorID;
    pdx->Device.DeviceId = pciRegs.DeviceID;

    // Get the bus number and the slot number
    status =
        GetBusSlotNumber(
            pdx->pPhysicalDeviceObject,
            pdx
            );

    if (!NT_SUCCESS(status))
    {
        DebugPrintf(("WARNING - Unable to get bus and slot number\n"));
    }

    return STATUS_SUCCESS;
}




/******************************************************************************
 *
 * Function   :  StopDevice
 *
 * Description:  Stop a device
 *
 ******************************************************************************/
VOID
StopDevice(
    PDEVICE_OBJECT fdo
    )
{
    DEVICE_EXTENSION *pdx;


    pdx = fdo->DeviceExtension;

    // Free all interrupt resources
    if (pdx->pInterruptObject != NULL)
    {
        // Disable the PCI interrupt
        KeSynchronizeExecution(
            pdx->pInterruptObject,
            (PKSYNCHRONIZE_ROUTINE)PlxChipPciInterruptDisable,
            (PVOID)pdx
            );

        // Remove the ISR
        IoDisconnectInterrupt(
            pdx->pInterruptObject
            );

        pdx->pInterruptObject = NULL;
    }

    // Unmap I/O regions from kernel space (No local register access after this)
    PlxPciBarResourcesUnmap(
        pdx
        );
}




/******************************************************************************
 *
 * Function   :  LockDevice
 *
 * Description:  Lock a device for operation, return FALSE if device is being
 *               removed.
 *
 ******************************************************************************/
BOOLEAN
LockDevice(
    DEVICE_EXTENSION *pdx
    )
{
    S32 usage;


    // Increment use count on our device object
    usage =
        InterlockedIncrement(
            &pdx->usage
            );

    DebugPrintf_NoInfo(("\n"));
    DebugPrintf((
        "LOCKING..... (usage = %d)\n",
        usage
        ));
 
    /* 
       If device is about to be removed, restore the use count and return FALSE.
       If a race exists with HandleRemoveDevice (maybe running on another CPU),
       the sequence we've followed is guaranteed to avoid a mistaken deletion of
       the device object. If we test "removing" after HandleRemoveDevice sets 
       it, we'll restore the use count and return FALSE. In the meantime, if
       HandleRemoveDevice decremented count to 0 before we did our increment,
       its thread will have set the remove event. Otherwise, we'll decrement to
       0 and set the event. Either way, HandleRemoveDevice will wake up to 
       finish removing the device, and we'll return FALSE to our caller.

       If, on the other hand, we test "removing" before HandleRemoveDevice sets
       it, we'll have already incremented the use count past 1 and will return 
       TRUE. Our caller will eventually call UnlockDevice, which will decrement
       the use count and might set the event HandleRemoveDevice is waiting on at
       that point.
    */
    if (pdx->removing)
    {
        // Removing device
        if (InterlockedDecrement(&pdx->usage) == 0)
        {
            KeSetEvent(
                &pdx->evRemove,
                0,
                FALSE
                );
        }

        return FALSE;
    }

    return TRUE;
}




/******************************************************************************
 *
 * Function   :  UnlockDevice
 *
 * Description:  Unlock a device.
 *
 ******************************************************************************/
VOID
UnlockDevice(
    DEVICE_EXTENSION *pdx
    )
{
    S32 usage;


    usage =
        InterlockedDecrement(
            &pdx->usage
            );

    DebugPrintf((
        "UNLOCKING... (usage = %d)\n",
        usage
        ));

    if (usage == 0)
    {
        // Removing device
        KeSetEvent(
            &pdx->evRemove,
            0,
            FALSE
            );
    }
}
