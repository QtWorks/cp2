/*******************************************************************************
 * Copyright (c) 2002 PLX Technology, Inc.
 *
 * PLX Technology Inc. licenses this software under specific terms and
 * conditions.  Use of any of the software or derviatives thereof in any
 * product without a PLX Technology chip is strictly prohibited.
 *
 * PLX Technology, Inc. provides this software AS IS, WITHOUT ANY WARRANTY,
 * EXPRESS OR IMPLIED, INCLUDING, WITHOUT LIMITATION, ANY WARRANTY OF
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  PLX makes no guarantee
 * or representations regarding the use of, or the results of the use of,
 * the software and documentation in terms of correctness, accuracy,
 * reliability, currentness, or otherwise; and you rely on the software,
 * documentation and results solely at your own risk.
 *
 * IN NO EVENT SHALL PLX BE LIABLE FOR ANY LOSS OF USE, LOSS OF BUSINESS,
 * LOSS OF PROFITS, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES
 * OF ANY KIND.  IN NO EVENT SHALL PLX'S TOTAL LIABILITY EXCEED THE SUM
 * PAID TO PLX FOR THE PRODUCT LICENSED HEREUNDER.
 *
 ******************************************************************************/

/******************************************************************************
 *
 * File Name:
 *
 *      PciSupport.c
 *
 * Description:
 *
 *      This file contains the PCI access functions.
 *
 * Revision History:
 *
 *      04-31-02 : PCI SDK v3.50
 *
 ******************************************************************************/


#include "PciSupport.h"
#include "PlxChip.h"
#include "SupportFunc.h"




/******************************************************************************
 *
 * Function   :  PlxPciRegisterRead
 *
 * Description:  Reads a configuration register given an offset.
 *
 ******************************************************************************/
U32
PlxPciRegisterRead(
    DEVICE_EXTENSION *pdx,
    U8                bus,
    U8                slot,
    U16               offset,
    RETURN_CODE      *pReturnCode
    )
{
    U32            RegisterValue;
    NTSTATUS       status;
    PDEVICE_OBJECT fdo;


    if (pdx->pDeviceObject == NULL)
    {
        if (pReturnCode != NULL)
            *pReturnCode = ApiNullParam;
        return (U32)-1;
    }

    if (pdx->pDeviceObject->DriverObject == NULL)
    {
        if (pReturnCode != NULL)
            *pReturnCode = ApiNullParam;
        return (U32)-1;
    }

    fdo = pdx->pDeviceObject->DriverObject->DeviceObject;

    // Now parse through all the functional devices objects
    while (fdo != NULL)
    {
        pdx = fdo->DeviceExtension;

        if (pdx == NULL)
        {
            DebugPrintf(("ERROR - ConfigRegisterRead() NULL driver object\n"));
            if (pReturnCode != NULL)
                *pReturnCode = ApiConfigAccessFailed;
            return (U32)-1;
        }

        // Compare the bus and slot numbers
        if ((bus  == pdx->Device.BusNumber) &&
            (slot == pdx->Device.SlotNumber))
        {
            // Read the register
            status =
                PciRegisterBufferRead(
                    fdo,
                    offset,
                    &RegisterValue,
                    sizeof(U32)
                    );

            if ( !NT_SUCCESS(status) )
            {
                DebugPrintf(("ERROR - Unable to read PCI Config Register\n"));
                if (pReturnCode != NULL)
                    *pReturnCode = ApiConfigAccessFailed;

                return (U32)-1;
            }

            if (pReturnCode != NULL)
                *pReturnCode = ApiSuccess;

            return RegisterValue;
        }

        // Increment to next device
        fdo = fdo->NextDevice;
    }

    // If we reach here, then the device was not located

    if (pReturnCode != NULL)
        *pReturnCode = ApiConfigAccessFailed;

    return (U32)-1;
}




/******************************************************************************
 *
 * Function   :  PlxPciRegisterWrite
 *
 * Description:  Writes a value to the offset provided.
 *
 ******************************************************************************/
RETURN_CODE
PlxPciRegisterWrite(
    DEVICE_EXTENSION *pdx,
    U8                bus,
    U8                slot,
    U16               offset,
    U32               value
    )
{
    NTSTATUS       status;
    PDEVICE_OBJECT fdo;


    if (pdx->pDeviceObject == NULL)
        return ApiNullParam;

    if (pdx->pDeviceObject->DriverObject == NULL)
        return ApiNullParam;

    fdo = pdx->pDeviceObject->DriverObject->DeviceObject;

    // Now parse through all the functional devices objects
    while (fdo != NULL)
    {
        pdx = fdo->DeviceExtension;

        if (pdx == NULL)
        {
            DebugPrintf(("ERROR - ConfigRegisterRead() NULL driver object\n"));
            return ApiConfigAccessFailed;
        }

        // Compare the bus and slot numbers
        if ((bus  == pdx->Device.BusNumber) &&
            (slot == pdx->Device.SlotNumber))
        {
            // Read the register
            status =
                PciRegisterBufferWrite(
                    fdo,
                    offset,
                    value
                    );

            if ( !NT_SUCCESS(status) )
            {
                DebugPrintf(("ERROR - Unable to write PCI Config Register\n"));
                return ApiConfigAccessFailed;
            }

            return ApiSuccess;
        }

        // Increment to next device
        fdo = fdo->NextDevice;
    }

    // If we reach here, then the device was not located

    return ApiConfigAccessFailed;
}




/******************************************************************************
 *
 * Function   :  PciRegisterBufferRead
 *
 * Description:  Read a config register
 *
 ******************************************************************************/
NTSTATUS
PciRegisterBufferRead(
    PDEVICE_OBJECT  fdo,
    U16             offset,
    VOID           *buffer,
    U16             size
    )
{
    PIRP               pIrp;
    KEVENT             event;
    NTSTATUS           status;
    PIO_STACK_LOCATION stack;


    /*
        Although it is not documented in the WDM DDK, it would appear that the
        correct way to access a PCI configuration register in Windows 98 is
        to send down a PnP packet to the bus driver.
        The bus driver, provided by Microsoft, will perform the actual PCI
        configuration access and return the value.
    */

    pIrp =
        IoAllocateIrp(
            fdo->StackSize,
            FALSE
            );

    if (pIrp == NULL)
    {
        DebugPrintf(("ERROR - ConfigRegisterBufferRead() unable to allocate IRP\n"));
        return STATUS_INSUFFICIENT_RESOURCES;
    }

    // Initialize kernel event
    KeInitializeEvent(
        &event,
        NotificationEvent,
        FALSE
        );

    stack =
        IoGetNextIrpStackLocation(
            pIrp
            );

    // Fill the IRP
    pIrp->IoStatus.Status                        = STATUS_NOT_SUPPORTED;
    stack->MajorFunction                         = IRP_MJ_PNP;
    stack->MinorFunction                         = IRP_MN_READ_CONFIG;
    stack->Parameters.ReadWriteConfig.WhichSpace = 0;
    stack->Parameters.ReadWriteConfig.Buffer     = buffer;
    stack->Parameters.ReadWriteConfig.Offset     = offset;
    stack->Parameters.ReadWriteConfig.Length     = size;

    IoSetCompletionRoutine(
        pIrp,
        (PIO_COMPLETION_ROUTINE)OnRequestComplete,
        (PVOID)&event,
        TRUE,
        TRUE,
        TRUE
        );

    // Send the packet
    status =
        IoCallDriver(
            ((DEVICE_EXTENSION *) fdo->DeviceExtension)->pLowerDeviceObject,
            pIrp
            );

    if (status == STATUS_PENDING)
    {
        // Wait for completion
        KeWaitForSingleObject(
            &event,
            Executive,
            KernelMode,
            FALSE,
            NULL
            );

        status = pIrp->IoStatus.Status;
    }

    // Release the IRP
    IoFreeIrp(
        pIrp
        );

    return status;
}




/******************************************************************************
 *
 * Function   :  PciRegisterBufferWrite
 *
 * Description:  Write to a config register of ourself
 *
 ******************************************************************************/
NTSTATUS
PciRegisterBufferWrite(
    PDEVICE_OBJECT  fdo,
    U16             offset,
    U32             value
    )
{
    PIRP               pIrp;
    KEVENT             event;
    NTSTATUS           status;
    PIO_STACK_LOCATION stack;


    /*
     * Although it is not documented in the WDM DDK, it would appear that the
     * correct way to access a PCI configuration register in Windows 98 is
     * to send down a PnP packet to the bus driver.
     * The bus driver, provided by Microsoft, will perform the actual PCI
     * configuration access and return the value.
     */

    pIrp = IoAllocateIrp(
               fdo->StackSize,
               FALSE
               );
    if (pIrp == NULL)
    {
        DebugPrintf(("ERROR - ConfigRegisterBufferWrite() unable to allocate IRP\n"));
        return STATUS_INSUFFICIENT_RESOURCES;
    }

    // Initialize kernel event
    KeInitializeEvent(
        &event,
        NotificationEvent,
        FALSE
        );

    stack =
        IoGetNextIrpStackLocation(
            pIrp
            );

    // Fill the IRP
    pIrp->IoStatus.Status                        = STATUS_NOT_SUPPORTED;
    stack->MajorFunction                         = IRP_MJ_PNP;
    stack->MinorFunction                         = IRP_MN_WRITE_CONFIG;
    stack->Parameters.ReadWriteConfig.WhichSpace = 0;
    stack->Parameters.ReadWriteConfig.Buffer     = &value;
    stack->Parameters.ReadWriteConfig.Offset     = offset;
    stack->Parameters.ReadWriteConfig.Length     = sizeof(U32);

    IoSetCompletionRoutine(
        pIrp,
        (PIO_COMPLETION_ROUTINE)OnRequestComplete,
        (PVOID)&event,
        TRUE,
        TRUE,
        TRUE
        );

    // Send the packet
    status =
        IoCallDriver(
            ((DEVICE_EXTENSION *)fdo->DeviceExtension)->pLowerDeviceObject,
            pIrp
            );

    if (status == STATUS_PENDING)
    {
        // Wait for completion
        KeWaitForSingleObject(
            &event,
            Executive,
            KernelMode,
            FALSE,
            NULL
            );
        status = pIrp->IoStatus.Status;
    }

    IoFreeIrp(
        pIrp
        );

    return STATUS_SUCCESS;
}




/******************************************************************************
 *
 * Function   :  PlxPciRegisterRead_Unsupported
 *
 * Description:  Unsupported function to read a value from a PCI configuration
 *               register of any device
 *
 ******************************************************************************/
U32
PlxPciRegisterRead_Unsupported(
    DEVICE_EXTENSION *pdx,
    U8                bus,
    U8                slot,
    U16               offset,
    RETURN_CODE      *pReturnCode
    )
{
    U32   RegSave;
    U32   RegValue;
    KIRQL IrqlSave;


    /***************************************************************
     * Access of a PCI register involves using  I/O addresses 0xcf8
     * and 0xcfc. These addresses must be used together and no other
     * process must interrupt.
     *
     * Note:  On Multi-Processor systems, the I/O ports may still be
     *        accessed by another CPU.  Raising the IRQL does not
     *        prevent other CPUs from accessing the ports since
     *        they are not a resource owned by this driver.
     **************************************************************/

    // Raise the IRQL to prevent context switches during access
    KeRaiseIrql(
        DISPATCH_LEVEL,
        &IrqlSave
        );

    // Save the content of the command register
    RegSave =
        IO_PORT_READ_32(
            0xcf8
            );

    // Configure the command register to access the desired location
    IO_PORT_WRITE_32(
        0xcf8,
        (1 << 31) | (bus << 16) | (slot << 11) | offset
        );

    // Read the register
    RegValue =
        IO_PORT_READ_32(
            0xcfc
            );

    // Restore the command register
    IO_PORT_WRITE_32(
        0xcf8,
        RegSave
        );

    // Restore IRQL
    KeLowerIrql(
        IrqlSave
        );

    if (pReturnCode != NULL)
        *pReturnCode = ApiSuccess;

    return RegValue;
}




/******************************************************************************
 *
 * Function   :  PlxPciRegisterWrite_Unsupported
 *
 * Description:  Unsupported function to writes a value to a PCI configuration
 *               register of any device
 *
 ******************************************************************************/
RETURN_CODE
PlxPciRegisterWrite_Unsupported(
    DEVICE_EXTENSION *pdx,
    U8                bus,
    U8                slot,
    U16               offset,
    U32               value
    )
{
    U32   RegSave;
    KIRQL IrqlSave;


    /***************************************************************
     * Access of a PCI register involves using  I/O addresses 0xcf8
     * and 0xcfc. These addresses must be used together and no other
     * process must interrupt.
     *
     * Note:  On Multi-Processor systems, the I/O ports may still be
     *        accessed by another CPU.  Raising the IRQL does not
     *        prevent other CPUs from accessing the ports since
     *        they are not a resource owned by this driver.
     **************************************************************/

    // Raise the IRQL to prevent context switches during access
    KeRaiseIrql(
        DISPATCH_LEVEL,
        &IrqlSave
        );

    // Save the content of the command register
    RegSave =
        IO_PORT_READ_32(
            0xcf8
            );

    // Configure the command register to access the desired location
    IO_PORT_WRITE_32(
        0xcf8,
        (1 << 31) | (bus << 16) | (slot << 11) | offset
        );

    // Write the register
    IO_PORT_WRITE_32(
        0xcfc,
        value
        );

    // Restore the command register
    IO_PORT_WRITE_32(
        0xcf8,
        RegSave
        );

    // Restore IRQL
    KeLowerIrql(
        IrqlSave
        );

    return ApiSuccess;
}
