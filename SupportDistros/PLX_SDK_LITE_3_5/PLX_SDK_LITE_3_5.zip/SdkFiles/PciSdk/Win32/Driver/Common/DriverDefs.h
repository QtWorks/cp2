#ifndef __DRIVER_DEFS_H
#define __DRIVER_DEFS_H

/*******************************************************************************
 * Copyright (c) 2002 PLX Technology, Inc.
 *
 * PLX Technology Inc. licenses this software under specific terms and
 * conditions.  Use of any of the software or derviatives thereof in any
 * product without a PLX Technology chip is strictly prohibited.
 *
 * PLX Technology, Inc. provides this software AS IS, WITHOUT ANY WARRANTY,
 * EXPRESS OR IMPLIED, INCLUDING, WITHOUT LIMITATION, ANY WARRANTY OF
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  PLX makes no guarantee
 * or representations regarding the use of, or the results of the use of,
 * the software and documentation in terms of correctness, accuracy,
 * reliability, currentness, or otherwise; and you rely on the software,
 * documentation and results solely at your own risk.
 *
 * IN NO EVENT SHALL PLX BE LIABLE FOR ANY LOSS OF USE, LOSS OF BUSINESS,
 * LOSS OF PROFITS, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES
 * OF ANY KIND.  IN NO EVENT SHALL PLX'S TOTAL LIABILITY EXCEED THE SUM
 * PAID TO PLX FOR THE PRODUCT LICENSED HEREUNDER.
 *
 ******************************************************************************/

/******************************************************************************
 *
 * File Name:
 *
 *      DriverDefs.h
 *
 * Description:
 *
 *      Common definitions used in the driver.
 *
 * Revision History:
 *
 *      04-31-02 : PCI SDK v3.50
 *
 ******************************************************************************/


#include "Plx.h"
#include "PlxTypes.h"
#include "PlxChip.h"




/**********************************************
 *               Definitions
 *********************************************/
#define PLX_MAX_NAME_LENGTH                 0x20  // Max length of registered device name
#define PCI_MAX_BUSES_TO_SCAN               10    // Maximum number of PCI buses to scan for valid devices (NT only)
#define MAX_NUMBER_OF_VALID_IDS             32    // Max number of Dev/Ven IDs in NT registry

#if defined(WDM_DRIVER)
    #define MIN_WORKING_POWER_STATE         PowerDeviceD2       // Minimum state required for local register access
#else
    #define MIN_WORKING_POWER_STATE         D2                  // Minimum state required for local register access
#endif

// Driver Version information
#define DRIVER_VERSION_MAJOR                3
#define DRIVER_VERSION_MINOR                5
#define DRIVER_VERSION_REVISION             0

// Used for build of SGL descriptors
#define SGL_DESC_IDX_PCI_ADDR               0
#define SGL_DESC_IDX_LOC_ADDR               1
#define SGL_DESC_IDX_COUNT                  2
#define SGL_DESC_IDX_NEXT_DESC              3



/***********************************************************
* The following definition is required for drivers
* requiring DMA functionality.  This includes allocation
* of a DMA buffer and DMA support functions.
***********************************************************/
#if defined(PCI9080) || defined(PCI9054)
    #define DMA_SUPPORT
#elif defined(PCI9056)  || defined(PCI9656)
    #define DMA_SUPPORT
#elif defined(PCI9050)  || defined(PCI9030)
    // No DMA support
#else
    #error DMA support not set properly for driver
#endif



// Macros to support Kernel-level logging in Debug builds
#if defined(PLX_DEBUG)
    #define ErrorPrintf(arg)                _Debug_Print_Macro(arg)
    #define DebugPrintf(arg)                _Debug_Print_Macro(arg)
    #define DebugPrintf_NoInfo(arg)         KdPrint(arg)
#else
    #define ErrorPrintf(arg)                _Debug_Print_Macro(arg)
    #define DebugPrintf(arg)
    #define DebugPrintf_NoInfo(arg)
#endif

#define _Debug_Print_Macro(arg)                     \
                do                                  \
                {                                   \
                    DbgPrint(PLX_DRIVER_NAME ": "); \
                    DbgPrint arg;                   \
                }                                   \
                while (0)




// Macros for Memory access to/from user-space addresses
#define DEV_MEM_TO_USER_8( VaUser, VaDev, count)    READ_REGISTER_BUFFER_UCHAR(  (UCHAR*)(VaDev),  (UCHAR*)(VaUser), (count))
#define DEV_MEM_TO_USER_16(VaUser, VaDev, count)    READ_REGISTER_BUFFER_USHORT((USHORT*)(VaDev), (USHORT*)(VaUser), (count) >> 1)
#define DEV_MEM_TO_USER_32(VaUser, VaDev, count)    READ_REGISTER_BUFFER_ULONG(  (ULONG*)(VaDev),  (ULONG*)(VaUser), (count) >> 2)
#define USER_TO_DEV_MEM_8( VaDev, VaUser, count)    WRITE_REGISTER_BUFFER_UCHAR(  (UCHAR*)(VaDev),  (UCHAR*)(VaUser), (count))
#define USER_TO_DEV_MEM_16(VaDev, VaUser, count)    WRITE_REGISTER_BUFFER_USHORT((USHORT*)(VaDev), (USHORT*)(VaUser), (count) >> 1)
#define USER_TO_DEV_MEM_32(VaDev, VaUser, count)    WRITE_REGISTER_BUFFER_ULONG(  (ULONG*)(VaDev),  (ULONG*)(VaUser), (count) >> 2)



// Macros for I/O port access (single-unit access)
#define IO_PORT_READ_8(port)                        READ_PORT_UCHAR (  (UCHAR*)(port))
#define IO_PORT_READ_16(port)                       READ_PORT_USHORT( (USHORT*)(port))
#define IO_PORT_READ_32(port)                       READ_PORT_ULONG (  (ULONG*)(port))
#define IO_PORT_WRITE_8(port, val)                  WRITE_PORT_UCHAR(  (UCHAR*)(port),  (UCHAR)(val))
#define IO_PORT_WRITE_16(port, val)                 WRITE_PORT_USHORT((USHORT*)(port), (USHORT)(val))
#define IO_PORT_WRITE_32(port, val)                 WRITE_PORT_ULONG(  (ULONG*)(port),  (ULONG)(val))

// Macros for I/O port access (multi-unit access)
#define IO_PORT_READ_8_BUFFER(port, buf, len)       READ_PORT_BUFFER_UCHAR (  (UCHAR*)(port),  (UCHAR*)(buf), (len))
#define IO_PORT_READ_16_BUFFER(port, buf, len)      READ_PORT_BUFFER_USHORT( (USHORT*)(port), (USHORT*)(buf), (len) >> 1)
#define IO_PORT_READ_32_BUFFER(port, buf, len)      READ_PORT_BUFFER_ULONG (  (ULONG*)(port),  (ULONG*)(buf), (len) >> 2)
#define IO_PORT_WRITE_8_BUFFER(port, val, len)      WRITE_PORT_BUFFER_UCHAR(  (UCHAR*)(port),  (UCHAR*)(buf), (len))
#define IO_PORT_WRITE_16_BUFFER(port, val, len)     WRITE_PORT_BUFFER_USHORT((USHORT*)(port), (USHORT*)(buf), (len) >> 1)
#define IO_PORT_WRITE_32_BUFFER(port, val, len)     WRITE_PORT_BUFFER_ULONG(  (ULONG*)(port),  (ULONG*)(buf), (len) >> 2)



// Macros for PLX chip register access
#define PLX_REG_READ(pdx, offset)                         \
    READ_REGISTER_ULONG(                                  \
        (U32*)(((U32)((pdx)->PciBar[0].pVa)) + (offset))  \
        )

#define PLX_REG_WRITE(pdx, offset, value)                 \
    WRITE_REGISTER_ULONG(                                 \
        (U32*)(((U32)((pdx)->PciBar[0].pVa)) + (offset)), \
        value                                             \
        )



#if defined(WDM_DRIVER)
    /*********************************************************
     * When running the Microsoft Driver Verifier, which is
     * provided in the DDK, for Windows 2000, it states that
     * the MmMapLockedPagesSpecifyCache() function should be used
     * instead of MmMapLockedPages().  However, since the PLX
     * WDM driver is used for both Win98 and Win2000, just
     * inclusion of the function MmMapLockedPagesSpecifyCache()
     * in the driver binary may actually prevent the driver from
     * loading in Win98, even if the function is not called.
     * As a result, the function is reverted to the original
     * through the use of the macro below.  This may change
     * in a future release.
     ********************************************************/

    #define MmMapLockedPagesSpecifyCache(pMdl, mode, cType, addr, chk, priority) \
        MmMapLockedPages(  \
            pMdl,          \
            mode           \
            )

    /************************************************************
     * The following function prototypes are missing from "Wdm.h".
     * They are included in "NtDdk.h", but including this file
     * conflicts with "Wdm.h" and results in compiler errors.
     * The prototypes are replicated here to be used by WDM drivers.
     ***********************************************************/
    NTKERNELAPI PVOID
    MmAllocateContiguousMemory (
        IN SIZE_T           NumberOfBytes,
        IN PHYSICAL_ADDRESS HighestAcceptableAddress
        );

    NTKERNELAPI VOID
    MmFreeContiguousMemory (
        IN PVOID BaseAddress
        );

    NTKERNELAPI PHYSICAL_ADDRESS
    MmGetPhysicalAddress (
        IN PVOID BaseAddress
        );

#endif // WDM_DRIVER


#if defined(NT_DRIVER)
    #define MmMapLockedPagesSpecifyCache(pMdl, mode, cType, addr, chk, priority) \
        MmMapLockedPages(  \
            pMdl,          \
            mode           \
            )

    #define MmGetSystemAddressForMdlSafe(pMdl, priority) \
        MmGetSystemAddressForMdl(  \
            (pMdl)                 \
            )

    #define LockDevice(pdx)
    #define UnlockDevice(pdx)

#endif // NT_DRIVER


// Information stored in Registry
typedef struct _REGISTRY_INFORMATION
{
    U32 CommonBufferSize;
    U32 MaxSglTransferSize;
 #if defined(NT_DRIVER)
    U32 ValidIdList[MAX_NUMBER_OF_VALID_IDS];
    U32 IdListSize;
 #endif
} REGISTRY_INFORMATION;


// PCI Interrupt Event Structure
typedef struct _INTR_WAIT_OBJECT
{
    LIST_ENTRY  ListEntry;
    VOID       *pOwner;
    PIRP        pIrpPending;
    U32         NotifyOnInterrupt;
} INTR_WAIT_OBJECT;


// Information about contiguous, page-locked buffers
typedef struct _PLX_PHYSICAL_MEM
{
    LIST_ENTRY   ListEntry;
    VOID        *pOwner;
    VOID        *pKernelVa;
    PMDL         pMdl;
    PCI_MEMORY   PciMem;
    LIST_ENTRY   List_Mappings;           // List of mappings for this physical memory
    KSPIN_LOCK   Lock_MappingsList;       // Spinlock for mappings list
} PLX_PHYSICAL_MEM;


// Physical memory user mapping
typedef struct _PLX_USER_MAPPING
{
    LIST_ENTRY  ListEntry;
    VOID       *pOwner;
    U8          BarIndex;
    VOID       *pUserVa;
} PLX_USER_MAPPING;


// PCI BAR Space information 
typedef struct _PCI_BAR_INFO
{
    U32              *pVa;                        // BAR Kernel Virtual Address
    PHYSICAL_ADDRESS  Physical;                   // BAR Physical Address
    U32               Size;                       // BAR size
    BOOLEAN           IsIoMapped;                 // Memory or I/O mapped?
    PMDL              pMdl;                       // MDL for the BAR space
    LIST_ENTRY        List_Mappings;              // List of mappings for this physical memory
    KSPIN_LOCK        Lock_MappingsList;          // Spinlock for mappings list
} PCI_BAR_INFO;


// DMA channel information 
typedef struct _DMA_CHANNEL_INFO
{
    DMA_STATE    state;                           // DMA Channel open state
    VOID        *pOwner;                          // Object that requested to open the channel
    BOOLEAN      bLocalAddrConstant;              // Flag to keep track if local address remains constant
    PIRP         pIrp;                            // Current IRP which requested a DMA
    PVOID        pSgl;                            // Address of the current SGL descriptor list
    PMDL         pMdl;                            // MDL of the user buffer for locking and unlocking
    BOOLEAN      IopDmaEnable;                    // Flag for IOP480 local DMA enable bit
} DMA_CHANNEL_INFO;


// Argument for interrupt synchronized register access functions
typedef struct _PLX_REG_DATA
{
    struct _DEVICE_EXTENSION *pdx;
    U16                       offset;
    U32                       BitsToSet;
    U32                       BitsToClear;
} PLX_REG_DATA;


#if defined(WDM_DRIVER)
typedef struct _POWER_INFO
{
    struct _DEVICE_EXTENSION *pdx;
    DEVICE_POWER_STATE        state;
} POWER_INFO;
#endif


// All relevant information about the device
typedef struct _DEVICE_EXTENSION
{
    PDEVICE_OBJECT      pDeviceObject;            // Device object this extension belongs to
#if defined(WDM_DRIVER)
    PDEVICE_OBJECT      pLowerDeviceObject;
    PDEVICE_OBJECT      pPhysicalDeviceObject;
    S32                 usage;
    KEVENT              evRemove;
    BOOLEAN             removing;
    DEVICE_POWER_STATE  Power;
#else
    PLX_POWER_LEVEL     Power;
#endif

    // Device information
    DEVICE_LOCATION     Device;
    WCHAR               LinkName[PLX_MAX_NAME_LENGTH];
    PCI_BAR_INFO        PciBar[PCI_NUM_BARS];

    // Hardware locking parameters
    KSPIN_LOCK          Lock_HwAccess;
    FAST_MUTEX          DispatchMutex;

    // Interrupt handling variables
    U32                 InterruptSource;
    U32                 IntrDoorbellValue;          // Last Doorbell interrupt value
    PKINTERRUPT         pInterruptObject;
    KDPC                DpcForIsr;

    LIST_ENTRY          List_InterruptWait;
    KSPIN_LOCK          Lock_InterruptWaitList;

    LIST_ENTRY          List_PhysicalMem;           // List of user-allocated physical memory
    KSPIN_LOCK          Lock_PhysicalMemList;       // Spinlock for physical memory list

    LIST_ENTRY          List_BarMappings;           // List of mappings to user space
    KSPIN_LOCK          Lock_BarMappingsList;       // Spinlock for user mappings list

#if defined(DMA_SUPPORT)                            // DMA channel information
    DMA_CHANNEL_INFO    DmaInfo[NUMBER_OF_DMA_CHANNELS];
    KSPIN_LOCK          Lock_DmaChannel;            // Spinlock for DMA channel access
#endif

} DEVICE_EXTENSION;




/**********************************************
 *               Functions
 *********************************************/
BOOLEAN
PlxChipPciInterruptEnable(
    DEVICE_EXTENSION *pdx
    );

BOOLEAN
PlxChipPciInterruptDisable(
    DEVICE_EXTENSION *pdx
    );

VOID
PlxPciBoardReset(
    DEVICE_EXTENSION *pdx
    );

VOID
PlxChipSetInterruptNotifyFlags(
    PLX_INTR         *pPlxIntr,
    INTR_WAIT_OBJECT *pWaitObject
    );

VOID
PlxChipGetSpace(
    DEVICE_EXTENSION *pdx,
    IOP_SPACE         IopSpace,
    U8               *BarIndex,
    U16              *Offset_RegRemap
    );

VOID
PlxChipRestoreAfterDma(
    DEVICE_EXTENSION *pdx,
    U8                DmaIndex
    );

BOOLEAN
PlxIsPowerLevelSupported(
    DEVICE_EXTENSION *pdx,
    PLX_POWER_LEVEL   PowerLevel
    );

BOOLEAN
PlxIsNewCapabilityEnabled(
    DEVICE_EXTENSION *pdx,
    U8                CapabilityToVerify
    );

U32
PlxHiddenRegisterRead(
    DEVICE_EXTENSION *pdx,
    U16               offset
    );




#endif
