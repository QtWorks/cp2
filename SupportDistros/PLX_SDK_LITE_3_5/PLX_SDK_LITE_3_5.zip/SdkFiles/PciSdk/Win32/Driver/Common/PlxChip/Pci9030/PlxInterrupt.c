/*******************************************************************************
 * Copyright (c) 2002 PLX Technology, Inc.
 *
 * PLX Technology Inc. licenses this software under specific terms and
 * conditions.  Use of any of the software or derviatives thereof in any
 * product without a PLX Technology chip is strictly prohibited.
 *
 * PLX Technology, Inc. provides this software AS IS, WITHOUT ANY WARRANTY,
 * EXPRESS OR IMPLIED, INCLUDING, WITHOUT LIMITATION, ANY WARRANTY OF
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  PLX makes no guarantee
 * or representations regarding the use of, or the results of the use of,
 * the software and documentation in terms of correctness, accuracy,
 * reliability, currentness, or otherwise; and you rely on the software,
 * documentation and results solely at your own risk.
 *
 * IN NO EVENT SHALL PLX BE LIABLE FOR ANY LOSS OF USE, LOSS OF BUSINESS,
 * LOSS OF PROFITS, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES
 * OF ANY KIND.  IN NO EVENT SHALL PLX'S TOTAL LIABILITY EXCEED THE SUM
 * PAID TO PLX FOR THE PRODUCT LICENSED HEREUNDER.
 *
 ******************************************************************************/

/******************************************************************************
 *
 * File Name:
 *
 *      PlxInterrupt.c
 *
 * Description:
 *
 *      This file handles interrupts for the PLX device
 *
 * Notes:
 *
 *      This driver handles interrupt sharing with other PCI device drivers.
 *      The PLX chip is checked to see if it is the true source of an interrupt.
 *      If an interrupt is truly active, the interrupt source is cleared and
 *      any waiting user-mode applications are notified.
 *
 * Revision History:
 *
 *      04-31-02 : PCI SDK v3.50
 *
 ******************************************************************************/


#include "DriverDefs.h"
#include "PlxInterrupt.h"
#include "SupportFunc.h"




/******************************************************************************
 *
 * Function   :  OnInterrupt
 *
 * Description:  The Interrupt Service Routine for the PLX device
 *
 ******************************************************************************/
BOOLEAN
OnInterrupt(
    PKINTERRUPT pInterrupt,
    PVOID       ServiceContext
    )
{
    U32               RegPciInt;
    U32               InterruptSource;
    DEVICE_EXTENSION *pdx;


    // Get the device extension
    pdx = (DEVICE_EXTENSION *)ServiceContext;

    // Read interrupt status register
    RegPciInt =
        PLX_REG_READ(
            pdx,
            PCI9030_INT_CTRL_STAT
            );

    // Check for master PCI interrupt enable
    if ((RegPciInt & (1 << 6)) == 0)
        return FALSE;

    // Verify that an interrupt is truly active

    // Clear the interrupt type flag
    InterruptSource = INTR_TYPE_NONE;

    // Check if Local Interrupt 1 is active and not masked
    if ((RegPciInt & (1 << 2)) && (RegPciInt & (1 << 0)))
    {
        InterruptSource |= INTR_TYPE_LOCAL_1;
    }

    // Check if Local Interrupt 2 is active and not masked
    if ((RegPciInt & (1 << 5)) && (RegPciInt & (1 << 3)))
    {
        InterruptSource |= INTR_TYPE_LOCAL_2;
    }

    // Software Interrupt
    if (RegPciInt & (1 << 7))
    {
        InterruptSource |= INTR_TYPE_SOFTWARE;
    }

    // Return if no interrupts are active
    if (InterruptSource == INTR_TYPE_NONE)
        return FALSE;

    // At this point, the device interrupt is verified

    // Mask the PCI Interrupt
    PLX_REG_WRITE(
        pdx,
        PCI9030_INT_CTRL_STAT,
        RegPciInt & ~(1 << 6)
        );

    //
    // Schedule deferred procedure (DPC) to complete interrupt processing
    //

    KeInsertQueueDpc(
        &(pdx->DpcForIsr),
        (VOID *)InterruptSource,
        (VOID *)NULL
        );

    return TRUE;
}




/******************************************************************************
 *
 * Function   :  DpcForIsr
 *
 * Description:  This routine will be triggered by the ISR to service an interrupt.
 *
 ******************************************************************************/
VOID
DpcForIsr(
    PKDPC pDpc,
    PVOID pContext,
    PVOID pArg1,
    PVOID pArg2
    )
{
    U32               RegValue;
    PIRP              pIrp;
    LIST_ENTRY        IrpsToCompleteList;
    PLIST_ENTRY       pNextEntry;
    PLIST_ENTRY       pCurrentEntry;
    PLX_REG_DATA      RegData;
    INTR_WAIT_OBJECT *pEvent;
    DEVICE_EXTENSION *pdx;


    pdx = (DEVICE_EXTENSION *)pContext;

    InitializeListHead(
        &IrpsToCompleteList
        );

    KeAcquireSpinLockAtDpcLevel(
        &(pdx->Lock_HwAccess)
        );

    // Local Interrupt 1
    if ((U32)pArg1 & INTR_TYPE_LOCAL_1)
    {
        // Setup to synchronize access to Interrupt Control/Status Register
        RegData.pdx         = pdx;
        RegData.offset      = PCI9030_INT_CTRL_STAT;
        RegData.BitsToSet   = 0;
        RegData.BitsToClear = 0;

        // Check if this is an edge-triggered interrupt
        RegValue =
            PLX_REG_READ(
                pdx,
                PCI9030_INT_CTRL_STAT
                );

        if ((RegValue & (1 << 1)) && (RegValue & (1 << 8)))
        {
            // Clear edge-triggered interrupt
            RegData.BitsToSet = (1 << 10);

            KeSynchronizeExecution(
                pdx->pInterruptObject,
                PlxSynchronizedRegisterModify,
                (VOID *)&RegData
                );
        }
        else
        {
            // Mask Local Interrupt 1
            RegData.BitsToClear = (1 << 0);

            KeSynchronizeExecution(
                pdx->pInterruptObject,
                PlxSynchronizedRegisterModify,
                (VOID *)&RegData
                );
        }
    }

    // Local Interrupt 2
    if ((U32)pArg1 & INTR_TYPE_LOCAL_2)
    {
        // Setup to synchronize access to Interrupt Control/Status Register
        RegData.pdx         = pdx;
        RegData.offset      = PCI9030_INT_CTRL_STAT;
        RegData.BitsToSet   = 0;
        RegData.BitsToClear = 0;

        // Check if this is an edge-triggered interrupt
        RegValue =
            PLX_REG_READ(
                pdx,
                PCI9030_INT_CTRL_STAT
                );

        if ((RegValue & (1 << 4)) && (RegValue & (1 << 9)))
        {
            // Clear edge-triggered interrupt
            RegData.BitsToSet = (1 << 11);

            KeSynchronizeExecution(
                pdx->pInterruptObject,
                PlxSynchronizedRegisterModify,
                (VOID *)&RegData
                );
        }
        else
        {
            // Mask Local Interrupt 2
            RegData.BitsToClear = (1 << 3);

            KeSynchronizeExecution(
                pdx->pInterruptObject,
                PlxSynchronizedRegisterModify,
                (VOID *)&RegData
                );
        }
    }

    // Software Interrupt
    if ((U32)pArg1 & INTR_TYPE_SOFTWARE)
    {
        // Setup to synchronize access to Interrupt Control/Status Register
        RegData.pdx       = pdx;
        RegData.offset    = PCI9030_INT_CTRL_STAT;
        RegData.BitsToSet = 0;

        // Clear the software interrupt
        RegData.BitsToClear = (1 << 7);

        KeSynchronizeExecution(
            pdx->pInterruptObject,
            PlxSynchronizedRegisterModify,
            (VOID *)&RegData
            );
    }

    // Save the interrupt sources
    pdx->InterruptSource = (U32)pArg1;

    KeReleaseSpinLockFromDpcLevel(
        &(pdx->Lock_HwAccess)
        );

    KeAcquireSpinLockAtDpcLevel(
        &(pdx->Lock_InterruptWaitList)
        );

    pNextEntry = pdx->List_InterruptWait.Flink;

    // Determine which interrupt IRPs need completion
    while (pNextEntry != &(pdx->List_InterruptWait))
    {
        pEvent =
            CONTAINING_RECORD(
                pNextEntry,
                INTR_WAIT_OBJECT,
                ListEntry
                );

        // Save current entry
        pCurrentEntry = pNextEntry;

        // Jump to next item in the list
        pNextEntry = pNextEntry->Flink;

        // Check if this IRP should be completed
        if (pEvent->NotifyOnInterrupt & (U32)pArg1)
        {
            // Record IRP for completion
            InsertTailList(
                &IrpsToCompleteList,
                &(pEvent->pIrpPending->Tail.Overlay.ListEntry)
                );

            DebugPrintf((
                "DPC signaling Event (IRP=0x%08x)\n",
                pEvent->pIrpPending
                ));

            // Remove the IRP pointer from list of pending IRPs
            RemoveEntryList(
                pCurrentEntry
                );

            // Free the memory
            ExFreePool(
                pEvent
                );
        }
    }

    KeReleaseSpinLockFromDpcLevel(
        &(pdx->Lock_InterruptWaitList)
        );

    // Complete the IRPs that were recorded
    while (!IsListEmpty(
                &IrpsToCompleteList
                ))
    {
        // Get the next entry
        pNextEntry =
            RemoveHeadList(
                &IrpsToCompleteList
                );

        // Get the IRP containing the list entry
        pIrp =
            CONTAINING_RECORD(
                pNextEntry,
                IRP,
                Tail.Overlay.ListEntry
                );

        // Clear the Cancel routine
        IoSetCancelRoutine(
            pIrp,
            NULL
            );

        // Complete the IRP
        pIrp->IoStatus.Status      = STATUS_SUCCESS;
        pIrp->IoStatus.Information = 0;

        IoCompleteRequest(
            pIrp,
            IO_NO_INCREMENT
            );
    }

    // Re-enable the PCI interrupt
    KeSynchronizeExecution(
        pdx->pInterruptObject,
        PlxChipPciInterruptEnable,
        (VOID *)((DEVICE_EXTENSION *)pContext)
        );
}
