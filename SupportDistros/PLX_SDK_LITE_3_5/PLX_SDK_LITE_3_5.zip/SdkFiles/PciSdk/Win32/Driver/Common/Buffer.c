/*******************************************************************************
 * Copyright (c) 2002 PLX Technology, Inc.
 *
 * PLX Technology Inc. licenses this software under specific terms and
 * conditions.  Use of any of the software or derviatives thereof in any
 * product without a PLX Technology chip is strictly prohibited.
 *
 * PLX Technology, Inc. provides this software AS IS, WITHOUT ANY WARRANTY,
 * EXPRESS OR IMPLIED, INCLUDING, WITHOUT LIMITATION, ANY WARRANTY OF
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  PLX makes no guarantee
 * or representations regarding the use of, or the results of the use of,
 * the software and documentation in terms of correctness, accuracy,
 * reliability, currentness, or otherwise; and you rely on the software,
 * documentation and results solely at your own risk.
 *
 * IN NO EVENT SHALL PLX BE LIABLE FOR ANY LOSS OF USE, LOSS OF BUSINESS,
 * LOSS OF PROFITS, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES
 * OF ANY KIND.  IN NO EVENT SHALL PLX'S TOTAL LIABILITY EXCEED THE SUM
 * PAID TO PLX FOR THE PRODUCT LICENSED HEREUNDER.
 *
 ******************************************************************************/

/***************************************************************************
 *
 * File Name:
 *
 *      Buffer.c
 *
 * Purpose: This file is used to allocate and deallocate small buffers.
 *          Their use is intended for SGLs. Therefore the small buffer 
 *          shall be on a 16-byte boundary. We also need the allocation 
 *          function to return the physical address.
 *
 * How: As recommended by some driver documentation, since several small
 *      buffers may be allocated, it is better to allocate a medium sized
 *      buffer and write our own allocation routines instead of calling
 *      ExAllocatePool, IoAllocateMdl, MmBuildMdlForNonPagedPool, IoFreeMdl
 *      and ExFreePool multiple times.
 *      First, a big chunk of memory is allocated. A mdl for that memory
 *      is also allocated with it so that we can compute the physical 
 *      address. We have to make sure that the big chunk is on a 16-bytes
 *      boundary.
 *      Second, this chunk is formated as a big available memory. Later,
 *      during use, this big available memory will be sectioned as
 *      multiple memory sections, all preceded by a 16-bytes section 
 *      header. Here is the format of a memory section:
 *
 *          HEADER:
 *            Header + 0:  Address of next section header
 *                         (NULL if none)
 *            Header + 4:  Size of the memory in this section,
 *                         excluding the header. (size)
 *            Header + 8:  State of this section:
 *                             0: Currently used
 *                             1: Available
 *            Header + 12: Address of the previous section header
 *                         (NULL if none)
 *          MEMORY (Header + 16):
 *              Memory intended for use by applications.
 *
 *          NEXT MEMORY SECTION (Header + 16 + size)
 *
 *        As an example, if at the beginning a big chunk of 0x1000 is
 *        allocated, it should look like this after formating:
 *
 *           Header: 0x00000000 0x00000ff0 0x00000001 0x00000000
 *
 *      DriverBufferMalloc uses the first big enough available section
 *      and subdivise it as necessary.
 *      Physical addresses are computed using a MDL allocated with the
 *      big chunk.
 *      DriverBufferFree makes sure that the freed section is merged with
 *      possibly already freed preceding and following sections.
 *
 * Revision History:
 *
 *      04-31-02 : PCI SDK v3.50
 *
 ***************************************************************************/


#include "Buffer.h"
#include "GlobalVars.h"


#ifdef ALLOC_PRAGMA
    #pragma alloc_text(INIT, DriverBufferInit)
#endif


/**********************************************
*               Globals
**********************************************/
PMDL gDriverBufferMdl                   = NULL;
static PVOID      realBaseAddress       = NULL;
static PVOID      startingBaseAddress   = NULL;
static KSPIN_LOCK gDriverBufferSpinLock;




/******************************************************************************
 *
 * Function   :  DriverBufferInit
 *
 * Description:  Allocate and initialize a buffer for which will be allocated
 *               small buffer for internal use, especially sgl elements.
 *
 ******************************************************************************/
BOOLEAN
DriverBufferInit(
    U32 size
    )
{
    if (size == 0)
        return FALSE;

    // Get a pool of memory
    realBaseAddress = ExAllocatePool(
                          NonPagedPool,
                          size
                          );

    if (realBaseAddress == NULL)
        return FALSE;

    // Clear the memory
    RtlZeroMemory(
        realBaseAddress,
        size
        );

    /* 
        We need a MDL for computing the physical addresses of the buffers
        allocated from the driver buffer pool.
    */
    gDriverBufferMdl = IoAllocateMdl(
                           realBaseAddress, 
                           size,
                           FALSE,
                           FALSE,
                           NULL
                           );

    if (gDriverBufferMdl == NULL)
    {
        ExFreePool(
            realBaseAddress
            );
        realBaseAddress = NULL;
        return FALSE;
    }

    // This will put in the physical pages after the MDL
    MmBuildMdlForNonPagedPool(
        gDriverBufferMdl
        );

    /*
        The driver buffer have to allocate memory located on a 16-bytes
        boundary. That why we must round up the starting virtual base address
        on a 16-bytes boundary. We will need also to setup the buffer length
        parameter the same way (maximum multiple of 16).
    */
    startingBaseAddress = (PVOID)(((U32)realBaseAddress + 0xF) & ~0xF);
    size -= ((U32)startingBaseAddress - (U32)realBaseAddress);
    size &= ~0xF;

    /* Verify that we still have some enough length */
    if (size <= 16)
    {
        IoFreeMdl(
            gDriverBufferMdl
            );
        ExFreePool(
            realBaseAddress
            );
        gDriverBufferMdl    = NULL;
        realBaseAddress     = NULL;
        startingBaseAddress = NULL;
        return FALSE;
    }

    /* Create the first header, the only one at the beginning */
    *(U32 *)((U32)startingBaseAddress)      = 0;
    *(U32 *)((U32)startingBaseAddress + 4)  = size - 16;
    *(U32 *)((U32)startingBaseAddress + 8)  = BUFFER_IS_FREE;
    *(U32 *)((U32)startingBaseAddress + 12) = 0;

    KeInitializeSpinLock(
        &gDriverBufferSpinLock
        );

    return TRUE;
}




/******************************************************************************
 *
 * Function   :  DriverBufferTerminate
 *
 * Description:  Undo everything that was done in DriverBufferInit and
 *               deallocate the resources.
 *
 * WARNING    :  This function Terminates the driver buffer even if some of it 
 *               is being used.
 *
 ******************************************************************************/
VOID
DriverBufferTerminate(
    VOID
    )
{
    // Verify that there is an MDL for the driver buffer
    if (gDriverBufferMdl != NULL)
    {
        IoFreeMdl(
            gDriverBufferMdl
            );
        gDriverBufferMdl = NULL;
    }

    // Verify that there is a driver buffer
    if (realBaseAddress != NULL)
    {
        ExFreePool(
            realBaseAddress
            );

        realBaseAddress     = NULL;
        startingBaseAddress = NULL;
    }
}




/***********************************************************************
 *
 * Function   :  DriverBufferMalloc
 *
 * Description:  Allocate a small buffer. 
 *
 * Note       :  All buffers are on a 16-bytes boundary, as required by
 *               PLX chips for scatter-gather lists.
 *
 ***********************************************************************/
VOID *
DriverBufferMalloc(
    U32 size
    )
{
    U32   pHeader;
    U32   BlockSize;
    KIRQL OriginalIrqL;


    // Verify the buffer and requested size
    if (startingBaseAddress == NULL  || size == 0)
        return NULL;

    // Make sure the buffer size is aligned on a 16-byte boundary
    size = (size + 0xF) & ~0xF;

    // Get the first header
    pHeader = (U32)startingBaseAddress;

    KeAcquireSpinLock(
        &gDriverBufferSpinLock,
        &OriginalIrqL
        );

    // Scan the memory for a block of sufficient size
    do
    {
        // Get the block size
        BlockSize = *(U32 *)(pHeader + 4);

        // Verify the block size
        if (BlockSize == 0)
        {
            DebugPrintf(("ERROR - DriverBuffer() - Invalid Block size (0)\n"));

            KeReleaseSpinLock(
                &gDriverBufferSpinLock,
                OriginalIrqL
                );

            return NULL;
        }

        // Check if this block is available
        if (*(U32 *)(pHeader + 8) == BUFFER_IS_FREE)
        {
            if (size == BlockSize)
            {
                // Just fits, use this block
                *(U32 *)(pHeader + 8) = BUFFER_IS_USED;
                break;
            }
            else if (BlockSize == (size + 16))
            {
                /* 
                    This block is only big enough for the request plus the
                    next block's header.  However, this would create a
                    subsequent block of size 0.  So this entire block
                    is allocated rather than splitting it up.
                */

                *(U32 *)(pHeader + 8) = BUFFER_IS_USED;
                break;
            }
            else if (BlockSize > (size + 16))
            {
                // This block is sufficient for the request

                // Create the new header for the following block
                *(U32 *)(pHeader + 16 + size +  0) = *(U32 *)pHeader;
                *(U32 *)(pHeader + 16 + size +  4) = BlockSize - (size + 16);
                *(U32 *)(pHeader + 16 + size +  8) = BUFFER_IS_FREE;
                *(U32 *)(pHeader + 16 + size + 12) = pHeader;

                // If a next header existed already, update its previous pointer
                if (*(U32 *)pHeader != 0)
                {
                    *(U32 *)(pHeader + 16 + BlockSize + 12) = pHeader + 16 + size;
                }

                // Update the current header of the block allocated
                *(U32 *)(pHeader + 0) = pHeader + 16 + size;
                *(U32 *)(pHeader + 4) = size;
                *(U32 *)(pHeader + 8) = BUFFER_IS_USED;
                break;
            }
        }

        // Jump to next block header
        pHeader = *(U32 *)pHeader;
    }
    while (pHeader != 0);

    KeReleaseSpinLock(
        &gDriverBufferSpinLock,
        OriginalIrqL
        );

    // If header pointer is 0, no memory block was found
    if (pHeader == 0)
    {
        return NULL;
    }

    DebugPrintf((
        "DriverBufferMalloc() allocated memory at 0x%08x (Size = %d bytes)\n", 
        (PVOID)(pHeader + 16), size
        ));

    // Return the address of the memory block, not the header
    return (PVOID)(pHeader + 16);
}




/***********************************************************************
 *
 * Function   :  DriverBufferFree
 *
 * Description:  Deallocate a previously allocated buffer.
 *
 ***********************************************************************/
VOID
DriverBufferFree(
    VOID *pBuffer
    )
{
    U32   pHeaderTemp;
    U32   pHeaderCurrent;
    U32   BlockSizeTemp;
    U32   BlockSizeCurrent;
    KIRQL OriginalIrqL;


    DebugPrintf(("DBFree(), freeing memory at 0x%08x\n", pBuffer));

    // Verify that there is a driver buffer
    if (startingBaseAddress == NULL)
        return;

    // Verify that the address is aligned on a 16-bytes boundary
    if ((U32)pBuffer & 0x0000000F)
        return;

    pHeaderCurrent = (U32)pBuffer - 16;

    // Verify that the address is valid
    if (pHeaderCurrent < (U32)startingBaseAddress)
        return;

    KeAcquireSpinLock(
        &gDriverBufferSpinLock,
        &OriginalIrqL
        );

    // Verify that the block is in use
    if (*(U32 *)(pHeaderCurrent + 8) != BUFFER_IS_USED)
    {
        KeReleaseSpinLock(
            &gDriverBufferSpinLock,
            OriginalIrqL
            );

        return;
    }

    // Get the buffer size
    BlockSizeCurrent = *(U32 *)(pHeaderCurrent + 4);

    // Mark the memory block free
    *(U32 *)(pHeaderCurrent + 8) = BUFFER_IS_FREE;

    // Now, the memory blocks must be merged to avoid fragmentation

    // Merge with next block if free
    pHeaderTemp = *(U32 *)pHeaderCurrent;

    if (pHeaderTemp != 0)
    {
        // Check if the next block is free
        if (*(U32 *)(pHeaderTemp + 8) == BUFFER_IS_FREE)
        {
            // Get its size
            BlockSizeTemp = *(U32 *)(pHeaderTemp + 4);

            // Verify block size
            if ((BlockSizeTemp == 0) || (BlockSizeTemp & 0xF))
            {
                KeReleaseSpinLock(
                    &gDriverBufferSpinLock,
                    OriginalIrqL
                    );

                return;
            }

            // Merge the blocks
            BlockSizeCurrent = BlockSizeCurrent + BlockSizeTemp + 16;

            // Update the current header block
            *(U32 *)(pHeaderCurrent + 0) = *(U32 *)pHeaderTemp;
            *(U32 *)(pHeaderCurrent + 4) = BlockSizeCurrent;

            // Update the next block's previous pointer
            if (*(U32 *)pHeaderTemp != 0)
            {
                *(U32 *)(pHeaderTemp + 16 + BlockSizeTemp + 12) = pHeaderCurrent;
            }
        }
    }

    // Merge with previous block if free
    pHeaderTemp = *(U32 *)(pHeaderCurrent + 12);

    if (pHeaderTemp != 0)
    {
        // Verify that the previous block is free
        if (*(U32 *)(pHeaderTemp + 8) == BUFFER_IS_FREE)
        {
            // Get the block size
            BlockSizeTemp = *(U32 *)(pHeaderTemp + 4);

            // Verify block size
            if ((BlockSizeTemp == 0) || (BlockSizeTemp & 0xF))
            {
                KeReleaseSpinLock(
                    &gDriverBufferSpinLock,
                    OriginalIrqL
                    );

                return;
            }

            // Update the previous block's header
            *(U32 *)(pHeaderTemp + 0) = *(U32 *)pHeaderCurrent;
            *(U32 *)(pHeaderTemp + 4) = 16 + BlockSizeTemp + BlockSizeCurrent;

            // Update the next block's previous pointer
            if (*(U32 *)pHeaderCurrent != 0)
            {
                *(U32 *)(pHeaderCurrent + 16 + BlockSizeCurrent + 12) = pHeaderTemp;
            }
        }
    }

    KeReleaseSpinLock(
        &gDriverBufferSpinLock,
        OriginalIrqL
        );
}
