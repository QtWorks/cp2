/*******************************************************************************
 * Copyright (c) 2002 PLX Technology, Inc.
 *
 * PLX Technology Inc. licenses this software under specific terms and
 * conditions.  Use of any of the software or derviatives thereof in any
 * product without a PLX Technology chip is strictly prohibited.
 *
 * PLX Technology, Inc. provides this software AS IS, WITHOUT ANY WARRANTY,
 * EXPRESS OR IMPLIED, INCLUDING, WITHOUT LIMITATION, ANY WARRANTY OF
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  PLX makes no guarantee
 * or representations regarding the use of, or the results of the use of,
 * the software and documentation in terms of correctness, accuracy,
 * reliability, currentness, or otherwise; and you rely on the software,
 * documentation and results solely at your own risk.
 *
 * IN NO EVENT SHALL PLX BE LIABLE FOR ANY LOSS OF USE, LOSS OF BUSINESS,
 * LOSS OF PROFITS, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES
 * OF ANY KIND.  IN NO EVENT SHALL PLX'S TOTAL LIABILITY EXCEED THE SUM
 * PAID TO PLX FOR THE PRODUCT LICENSED HEREUNDER.
 *
 ******************************************************************************/

/******************************************************************************
 *
 * File Name:
 *
 *      CommonApi.c
 *
 * Description:
 *
 *      API functions common to all PLX chips
 *
 * Revision History:
 *
 *      04-31-02 : PCI SDK v3.50
 *
 ******************************************************************************/


#include "ApiFunctions.h"
#include "CommonApi.h"
#include "GlobalVars.h"
#include "PciSupport.h"
#include "SupportFunc.h"




/*********************************************************************
 *
 * Function   :  PlxChipTypeGet
 *
 * Description:  Gets the PLX chip type and revision
 *
 *********************************************************************/
VOID
PlxChipTypeGet(
    DEVICE_EXTENSION *pdx,
    U32              *pChipType,
    U8               *pRevision
    )
{
    U32 RegValue;
    U32 RegValue_Original;


    /*********************************************************
     * The algorithm for determining chip type is as follows:
     *
     * - Read local register offset 0x4
     * - Write the register back with the upper byte set to 0xf
     * - Read reg and check upper byte.
     * - If still 0, then chip is 9030/9050/9052
     * - If set to 0xf, then chip is 9080/9054/480
     *
     * For 9080/9054/9656/9056/480:
     *   - Hard Coded ID determines chip type
     *   - Revision ID register determines revision
     *      - 9054 requires some additional tests
     *
     * For 9030/9050/9052:
     *   - If VPD lower byte is 0x3, chip is 9030
     *   - If not, revision register determines 9050 or 9052
     *
     ********************************************************/

    // Read register offset 0x4
    RegValue_Original =
        PLX_REG_READ(
            pdx,
            0x04
            );

    // Set upper byte to 0xff
    PLX_REG_WRITE(
        pdx,
        0x4,
        RegValue_Original | (0xFF << 24)
        );

    // Read register offset 0x4
    RegValue =
        PLX_REG_READ(
            pdx,
            0x04
            );

    // Restore register
    PLX_REG_WRITE(
        pdx,
        0x4,
        RegValue_Original
        );

    // If bits 24-27 are not written, a register access problem exists
    if ((RegValue >> 24) == 0)
    {
        // Unknown chip type
        *pChipType = 0x0;
        *pRevision = 0x0;
        return;
    }

    // Check if upper bits were set
    if ((RegValue >> 28) == 0xf)
    {
        // Check Hard-coded ID
        RegValue =
            PLX_REG_READ(
                pdx,
                0x70               // PERM_VENDOR_ID
                );

        // Check for 9080
        if (RegValue == 0x908010b5)
        {
            *pChipType = 0x9080;
            RegValue =
                PLX_REG_READ(
                    pdx,
                    0x74           // REVISION_ID
                    );

            *pRevision = (U8)RegValue;

            return;
        }

        // Check for 9054
        if (RegValue == 0x905410b5)
        {
            *pChipType = 0x9054;

            // Check the revision register
            RegValue =
                PLX_REG_READ(
                    pdx,
                    0x74           // REVISION_ID
                    );

            if (RegValue != 0xA)
            {
                *pRevision = (U8)RegValue;
                return;
            }

            PLX_PCI_REG_READ(
                pdx,
                CFG_REV_ID,
                &RegValue
                );

            if ((RegValue & 0xf) == 0xb)
                *pRevision = 0xAB;
            else
                *pRevision = 0xAA;

            return;
        }

        // Check for 9056
        if (RegValue == 0x905610b5)
        {
            *pChipType = 0x9056;

            RegValue =
                PLX_REG_READ(
                    pdx,
                    0x74           // REVISION_ID
                    );

            *pRevision = (U8)RegValue;

            return;
        }

        // Check for 9656
        if (RegValue == 0x965610b5)
        {
            *pChipType = 0x9656;

            RegValue =
                PLX_REG_READ(
                    pdx,
                    0x74           // REVISION_ID
                    );

            *pRevision = (U8)RegValue;

            return;
        }

        // Check for 480
        RegValue =
            PLX_REG_READ(
                pdx,
                0xe8               // IOP480_PERM_VENDOR_ID
                );

        if (RegValue == 0x048010b5)
        {
            *pChipType = 0x0480;
            RegValue =
                PLX_REG_READ(
                    pdx,
                    0xec           // REVISION_ID
                    );

            *pRevision = (U8)RegValue;

            return;
        }
    }
    else
    {
        // Read PCI next capabilites register
        PLX_PCI_REG_READ(
            pdx,
            0x34,                  // NEXT_CAP_PTR
            &RegValue
            );

        if (RegValue != 0x0)
        {
            *pChipType = 0x9030;
            *pRevision = 1;
            return;
        }

        // 9050/52 is final possibility
        *pChipType = 0x9050;

        // Read 9050/9052 PCI revision
        PLX_PCI_REG_READ(
            pdx,
            CFG_REV_ID,
            &RegValue
            );

        if ((RegValue & 0xF) == 0x2)
        {
            *pRevision = 2;
        }
        else
        {
            *pRevision = 1;
        }

        return;
    }

    *pChipType = 0x0;
    *pRevision = 0x0;
}




/******************************************************************************
 *
 * Function   :  PlxPciIntrAttach
 *
 * Description:  Registers a wait object for notification on interrupt(s)
 *
 ******************************************************************************/
RETURN_CODE
PlxPciIntrAttach(
    DEVICE_EXTENSION *pdx,
    PLX_INTR         *pPlxIntr,
    PIRP              pIrp,
    VOID             *pOwner
    )
{
    INTR_WAIT_OBJECT *pWaitObject;


    pWaitObject =
        ExAllocatePool(
            NonPagedPool,
            sizeof(INTR_WAIT_OBJECT)
            );

    if (pWaitObject == NULL)
    {
        DebugPrintf(("ERROR: Unable to save interrupt event, insufficient memory\n"));
        return ApiInsufficientResources;
    }

    // Record the IRP
    pWaitObject->pIrpPending = pIrp;

    // Record the owner
    pWaitObject->pOwner = pOwner;

    // Set interrupt notification flags
    PlxChipSetInterruptNotifyFlags(
        pPlxIntr,
        pWaitObject
        );

    // Setup a cancel routine for the IRP
    IoSetCancelRoutine(
        pIrp,
        OnCancelInterruptIrp
        );

    // Mark the IRP as pending
    IoMarkIrpPending(
        pIrp
        );

    // Add to list of waiting objects
    ExInterlockedInsertTailList(
        &(pdx->List_InterruptWait),
        &(pWaitObject->ListEntry),
        &(pdx->Lock_InterruptWaitList)
        );

    DebugPrintf((
        "Attached interrupt wait object (0x%08x) for IRP (0x%08x)\n",
        (U32)pWaitObject, (U32)pIrp
        ));

    return ApiSuccess;
}




/******************************************************************************
 *
 * Function   :  PlxPciIntrWait
 *
 * Description:  Put the process to sleep until wake-up event occurs or timeout
 *
 ******************************************************************************/
RETURN_CODE
PlxPciIntrWait(
    DEVICE_EXTENSION *pdx,
    U32               Tag,
    U32               Timeout_ms
    )
{
    // Not currently supported in Windows driver
    return ApiUnsupportedFunction;
}




/******************************************************************************
 *
 * Function   :  PlxPciBusMemTransfer
 *
 * Description:  Reads/Writes device memory to/from a buffer
 *
 ******************************************************************************/
RETURN_CODE
PlxPciBusMemTransfer(
    DEVICE_EXTENSION *pdx,
    IOP_SPACE         IopSpace,
    U32               LocalAddress,
    BOOLEAN           bRemap,
    VOID             *pBuffer,
    U32               ByteCount,
    ACCESS_TYPE       AccessType,
    BOOLEAN           bReadOperation
    )
{
    U8       BarIndex;
    U16      Offset_RegRemap;
    U32      SpaceVa;
    U32      RegValue;
    U32      SpaceRange;
    U32      SpaceOffset;
    U32      RemapOriginal;
    U32      BytesToTransfer;
    VOID    *pUserVa;
    PMDL     pMdl;
    BOOLEAN  bFlag;


    // Added to prevent compiler warnings
    RemapOriginal = 0;

    // Verify data alignment
    switch (AccessType)
    {
        case BitSize8:
            break;

        case BitSize16:
            if (LocalAddress & 0x1)
            {
                DebugPrintf(("ERROR - Local address not aligned\n"));
                return ApiInvalidAddress;
            }

            if (ByteCount & 0x1)
            {
                DebugPrintf(("ERROR - Byte count not aligned\n"));
                return ApiInvalidSize;
            }
            break;

        case BitSize32:
            if (LocalAddress & 0x3)
            {
                DebugPrintf(("ERROR - Local address not aligned\n"));
                return ApiInvalidAddress;
            }

            if (ByteCount & 0x3)
            {
                DebugPrintf(("ERROR - Byte count not aligned\n"));
                return ApiInvalidSize;
            }
            break;

        default:
            DebugPrintf(("ERROR - Invalid access type\n"));
            return ApiInvalidAccessType;
    }

    // Get and Verify the Local Space
    PlxChipGetSpace(
        pdx,
        IopSpace,
        &BarIndex,
        &Offset_RegRemap
        );

    if (BarIndex == (U8)-1)
    {
        return ApiInvalidIopSpace;
    }

    // Only memory spaces are supported by this function
    if (pdx->PciBar[BarIndex].IsIoMapped)
    {
        DebugPrintf(("ERROR - I/O spaces not supported by this function\n"));
        return ApiInvalidIopSpace;
    }

    // Get kernel virtual address for the space
    SpaceVa = (U32)pdx->PciBar[BarIndex].pVa;

    if (SpaceVa == (U32)NULL)
    {
        DebugPrintf((
            "ERROR - Invalid kernel VA (0x%08x) for PCI BAR\n",
            SpaceVa
            ));

        return ApiInvalidAddress;
    }

    // Get the size of the space
    SpaceRange = ~(pdx->PciBar[BarIndex].Size - 1);

    // Save the remap register
    if (bRemap)
    {
        RemapOriginal =
            PLX_REG_READ(
                pdx,
                Offset_RegRemap
                );
    }
    else
    {
        // Make sure requested area doesn't exceed our local space window boundary
        if ((LocalAddress + ByteCount) > ~SpaceRange)
        {
            DebugPrintf(("ERROR - requested area exceeds space range\n"));
            return ApiInvalidSize;
        }
    }

    // Build an MDL for the User-mode buffer
    pMdl =
        IoAllocateMdl(
            pBuffer,        // User-mode virtual address
            ByteCount,      // Size of buffer
            FALSE,          // Secondary buffer?
            FALSE,          // Charge quota?
            NULL            // IRP to associate
            );

    if (pMdl == NULL)
    {
        DebugPrintf(("ERROR - Unable to allocate MDL for user-mode buffer\n"));
        return ApiInsufficientResources;
    }

    bFlag = FALSE;

    // Lock the user-mode pages into memory
    try
    {
        if (bReadOperation)
        {
            MmProbeAndLockPages(
                pMdl,
                KernelMode,
                IoWriteAccess
                );
        }
        else
        {
            MmProbeAndLockPages(
                pMdl,
                KernelMode,
                IoReadAccess
                );
        }
    }
    except(EXCEPTION_EXECUTE_HANDLER)
    {
        // Flag the exception
        bFlag = TRUE;
    }

    // Verify that the pages were locked
    if (bFlag)
    {
        DebugPrintf(("ERROR - Unable to lock pages for user-mode buffer\n"));

        IoFreeMdl(
            pMdl
            );

        return ApiInsufficientResources;
    }

    // Get the kernel virtual address for the user-mode buffer
    pUserVa =
        MmGetSystemAddressForMdlSafe(
            pMdl,
            NormalPagePriority
            );

    if (pUserVa == NULL)
    {
        DebugPrintf(("ERROR - Unable to get kernel virtual address for user-mode buffer\n"));

        // Unlock the user-mode buffer pages
        MmUnlockPages(
            pMdl
            );

        // Release the user-mode buffer MDL
        IoFreeMdl(
            pMdl
            );

        return ApiInsufficientResources;
    }

    // Transfer data in blocks
    while (ByteCount != 0)
    {
        // Adjust remap if necessary
        if (bRemap)
        {
            // Clear upper bits
            RegValue = RemapOriginal & ~SpaceRange;

            // Adjust window to local address
            RegValue |= LocalAddress & SpaceRange;

            PLX_REG_WRITE(
                pdx,
                Offset_RegRemap,
                RegValue
                );
        }

        // Get current offset into space
        SpaceOffset = LocalAddress & (~SpaceRange);

        // Calculate bytes to transfer for next block
        if (ByteCount <= ((~SpaceRange) + 1))
        {
            BytesToTransfer = ByteCount;
        }
        else
        {
            BytesToTransfer = ((~SpaceRange) + 1) - SpaceOffset;
        }

        if (bReadOperation)
        {
            // Copy block to user buffer
            switch (AccessType)
            {
                case BitSize8:
                    DEV_MEM_TO_USER_8(
                        pUserVa,
                        (SpaceVa + SpaceOffset),
                        BytesToTransfer
                        );
                    break;

                case BitSize16:
                    DEV_MEM_TO_USER_16(
                        pUserVa,
                        (SpaceVa + SpaceOffset),
                        BytesToTransfer
                        );
                    break;

                case BitSize32:
                    DEV_MEM_TO_USER_32(
                        pUserVa,
                        (SpaceVa + SpaceOffset),
                        BytesToTransfer
                        );
                    break;

                case BitSize64:
                    // 64-bit not implemented yet
                    break;
            }
        }
        else
        {
            // Copy user buffer to device memory
            switch (AccessType)
            {
                case BitSize8:
                    USER_TO_DEV_MEM_8(
                        (SpaceVa + SpaceOffset),
                        pUserVa,
                        BytesToTransfer
                        );
                    break;

                case BitSize16:
                    USER_TO_DEV_MEM_16(
                        (SpaceVa + SpaceOffset),
                        pUserVa,
                        BytesToTransfer
                        );
                    break;

                case BitSize32:
                    USER_TO_DEV_MEM_32(
                        (SpaceVa + SpaceOffset),
                        pUserVa,
                        BytesToTransfer
                        );
                    break;

                case BitSize64:
                    // 64-bit not implemented yet
                    break;
            }
        }

        // Adjust for next block access
        (U32)pUserVa += BytesToTransfer;
        LocalAddress += BytesToTransfer;
        ByteCount    -= BytesToTransfer;
    }

    // Unlock the user-mode buffer pages
    MmUnlockPages(
        pMdl
        );

    // Release the user-mode buffer MDL
    IoFreeMdl(
        pMdl
        );

    // Restore the remap register
    if (bRemap)
    {
        PLX_REG_WRITE(
            pdx,
            Offset_RegRemap,
            RemapOriginal
            );
    }

    return ApiSuccess;
}




/******************************************************************************
 *
 * Function   :  PlxPciIoPortTransfer
 *
 * Description:  Read or Write from/to an I/O port
 *
 ******************************************************************************/
RETURN_CODE
PlxPciIoPortTransfer(
    U32          IoPort,
    ACCESS_TYPE  AccessType,
    VOID        *pValue,
    BOOLEAN      bReadOperation
    )
{
    if (pValue == NULL)
        return ApiNullParam;

    if (bReadOperation)
    {
        switch (AccessType)
        {
            case BitSize8:
                *(U8*)pValue =
                          IO_PORT_READ_8(
                              IoPort
                              );
                break;

            case BitSize16:
                *(U16*)pValue =
                           IO_PORT_READ_16(
                               IoPort
                               );
                break;

            case BitSize32:
                *(U32*)pValue =
                           IO_PORT_READ_32(
                               IoPort
                               );
                break;

            default:
                return ApiInvalidAccessType;
        }
    }
    else
    {
        switch (AccessType)
        {
            case BitSize8:
                IO_PORT_WRITE_8(
                    IoPort,
                    *(U8*)pValue
                    );
                break;

            case BitSize16:
                IO_PORT_WRITE_16(
                    IoPort,
                    *(U16*)pValue
                    );
                break;

            case BitSize32:
                IO_PORT_WRITE_32(
                    IoPort,
                    *(U32*)pValue
                    );
                break;

            default:
                return ApiInvalidAccessType;
        }
    }

    return ApiSuccess;
}




/******************************************************************************
 *
 * Function   :  PlxEepromAccess
 *
 * Description:  Access the Serial EEPROM
 *
 ******************************************************************************/
RETURN_CODE
PlxEepromAccess(
    DEVICE_EXTENSION *pdx,
    EEPROM_TYPE       EepromType,
    VOID             *pBuffer,
    U32               ByteCount,
    BOOLEAN           bReadOperation
    )
{
    U16          offset;
    U32          EepromValue;
    VOID        *pUserVa;
    PMDL         pMdl;
    BOOLEAN      bFlag;
    RETURN_CODE  rc;


    // Verify count is aligned on 4-byte boundary
    if (ByteCount & 0x3)
    {
        DebugPrintf(("ERROR - size not aligned on 4-byte boundary\n"));
        return ApiInvalidSize;
    }

    switch (EepromType)
    {
        case Eeprom93CS46:
            if (ByteCount > 0x80)
                return ApiInvalidSize;
            break;

        case Eeprom93CS56:
            if (ByteCount > 0x100)
                return ApiInvalidSize;
            break;

        case Eeprom93CS66:
            if (ByteCount > 0x200)
                return ApiInvalidSize;
            break;

        default:
            if (ByteCount > PLX_EEPROM_SIZE)
            {
                DebugPrintf((
                    "WARNING - size (%Xh) too large for unknown EEPROM type\n",
                    ByteCount
                    ));
                ByteCount = PLX_EEPROM_SIZE;
            }
            break;
    }

    // Build an MDL for the User-mode buffer
    pMdl =
        IoAllocateMdl(
            pBuffer,        // User-mode virtual address
            ByteCount,      // Size of buffer
            FALSE,          // Secondary buffer?
            FALSE,          // Charge quota?
            NULL            // IRP to associate
            );

    if (pMdl == NULL)
    {
        DebugPrintf(("ERROR - Unable to allocate MDL for user-mode buffer\n"));
        return ApiInsufficientResources;
    }

    bFlag = FALSE;

    // Lock the user-mode pages into memory
    try
    {
        if (bReadOperation)
        {
            MmProbeAndLockPages(
                pMdl,
                KernelMode,
                IoWriteAccess
                );
        }
        else
        {
            MmProbeAndLockPages(
                pMdl,
                KernelMode,
                IoReadAccess
                );
        }
    }
    except(EXCEPTION_EXECUTE_HANDLER)
    {
        // Flag the exception
        bFlag = TRUE;
    }

    // Verify that the pages were locked
    if (bFlag)
    {
        DebugPrintf(("ERROR - Unable to lock pages for user-mode buffer\n"));

        IoFreeMdl(
            pMdl
            );

        return ApiInsufficientResources;
    }

    // Get the kernel virtual address for the user-mode buffer
    pUserVa =
        MmGetSystemAddressForMdlSafe(
            pMdl,
            NormalPagePriority
            );

    if (pUserVa == NULL)
    {
        DebugPrintf(("ERROR - Unable to get kernel virtual address for user-mode buffer\n"));

        rc = ApiInsufficientResources;

        goto _ExitPlxEepromAccess;
    }

    // Initialize return value
    rc = ApiSuccess;

    // Read EEPROM values
    for (offset=0; offset < ByteCount; offset += sizeof(U32))
    {
        if (bReadOperation)
        {
            rc =
                PlxEepromReadByOffset(
                    pdx,
                    offset,
                    &EepromValue
                    );

            if (rc != ApiSuccess)
            {
                DebugPrintf(("ERROR - EEPROM read failed\n"));

                goto _ExitPlxEepromAccess;
            }

            /******************************************************
             * Endian conversion is needed since this function
             * returns data as it is ordered in the EEPROM, which
             * is by 16-bit offsets.  The EEPROM access by offset
             * function only supports access at 32-bit offsets.
             *****************************************************/
            EepromValue = ((EepromValue >> 16) | (EepromValue << 16));

            // Write value to user-mode buffer
            *(U32*)(((U32)pUserVa) + offset) = EepromValue;
        }
        else
        {
            // Get next 32-bit value to write
            EepromValue = *(U32*)(((U32)pUserVa) + offset);

            /******************************************************
             * Endian conversion is needed since this function
             * expects data as it is ordered in the EEPROM, which
             * is by 16-bit offsets.  The EEPROM access by offset
             * function only supports access at 32-bit offsets.
             *****************************************************/
            EepromValue = ((EepromValue >> 16) | (EepromValue << 16));

            rc =
                PlxEepromWriteByOffset(
                    pdx,
                    offset,
                    EepromValue
                    );

            if (rc != ApiSuccess)
            {
                DebugPrintf(("ERROR - EEPROM write failed\n"));

                goto _ExitPlxEepromAccess;
            }
        }
    }

_ExitPlxEepromAccess:
    // Unlock the user-mode buffer pages
    MmUnlockPages(
        pMdl
        );

    // Release the user-mode buffer MDL
    IoFreeMdl(
        pMdl
        );

    return rc;
}




/******************************************************************************
 *
 * Function   :  PlxPciPhysicalMemoryAllocate
 *
 * Description:  Allocate physically contiguous page-locked memory
 *
 ******************************************************************************/
RETURN_CODE
PlxPciPhysicalMemoryAllocate(
    DEVICE_EXTENSION *pdx,
    PCI_MEMORY       *pPciMem,
    BOOLEAN           bSmallerOk,
    VOID             *pOwner
    )
{
    U32               DecrementAmount;
    KIRQL             IrqL_Original;
    PHYSICAL_ADDRESS  BufferPhysicalAddr;
    PLX_PHYSICAL_MEM *pBufferObj;


    // Initialize buffer information
    pPciMem->UserAddr     = (U32)NULL;
    pPciMem->PhysicalAddr = (U32)NULL;

    /*******************************************************
     * Verify size
     *
     * A size of 0 is valid because this function may
     * be called to allocate a common buffer of size 0;
     * therefore, the information is reset & return sucess.
     ******************************************************/
    if (pPciMem->Size == 0)
    {
        return ApiSuccess;
    }

    // Allocate memory for new list object
    pBufferObj =
        ExAllocatePool(
            NonPagedPool,
            sizeof(PLX_PHYSICAL_MEM)
            );

    if (pBufferObj == NULL)
    {
        DebugPrintf((
            "ERROR - Memory allocation for list object failed\n"
            ));

        return ApiInsufficientResources;
    }

    // Initialize buffer object
    pBufferObj->pMdl        = NULL;
    pBufferObj->PciMem.Size = pPciMem->Size;

    // Set maximum physical address
    BufferPhysicalAddr.HighPart  = 0;
    BufferPhysicalAddr.u.LowPart = 0xFFFFFFFF;    // 4GB (32-bit) addressing

    // Setup amount to reduce on failure
    DecrementAmount = (pPciMem->Size / 10);

    do
    {
        // Attempt to allocate the buffer
        pBufferObj->pKernelVa =
            MmAllocateContiguousMemory(
                pBufferObj->PciMem.Size,
                BufferPhysicalAddr
                );

        if (pBufferObj->pKernelVa == NULL)
        {
            // Reduce memory request size if requested
            if (bSmallerOk && (pBufferObj->PciMem.Size > PAGE_SIZE))
            {
                pBufferObj->PciMem.Size -= DecrementAmount;
            }
            else
            {
                // Release the list object
                ExFreePool(
                    pBufferObj
                    );

                DebugPrintf((
                    "ERROR - Physical memory allocation failed\n"
                    ));

                pPciMem->Size = 0;

                return ApiInsufficientResources;
            }
        }
    }
    while (pBufferObj->pKernelVa == NULL);

    // Get physical address of buffer
    BufferPhysicalAddr =
        MmGetPhysicalAddress(
            pBufferObj->pKernelVa
            );

    pBufferObj->PciMem.PhysicalAddr = BufferPhysicalAddr.u.LowPart;

    // Build MDL for buffer if driver is WDM
    if (IsDriverWdm)
    {
        // Get an MDL. The MDL will be used to map into user space
        pBufferObj->pMdl =
            IoAllocateMdl(
                pBufferObj->pKernelVa,
                pBufferObj->PciMem.Size,
                FALSE,
                FALSE,
                NULL
                );

        // Check if the MDL allocation succeeded
        if (pBufferObj->pMdl == NULL)
            DebugPrintf(("ERROR - failed to allocate an MDL for buffer\n"));
        else
        {
            // Build the MDL
            MmBuildMdlForNonPagedPool(
                pBufferObj->pMdl
                );
        }
    }

    // Clear the buffer
    RtlZeroMemory(
        pBufferObj->pKernelVa,
        pBufferObj->PciMem.Size
        );

    DebugPrintf(("Allocated physical memory...\n"));

    DebugPrintf((
        "    Physical Addr: 0x%08x\n",
        pBufferObj->PciMem.PhysicalAddr
        ));

    DebugPrintf((
        "    Kernel VA    : 0x%08x\n",
        (U32)pBufferObj->pKernelVa
        ));

    DebugPrintf((
        "    Size         : %d Kb",
        (pBufferObj->PciMem.Size >> 10)
        ));

    if (pPciMem->Size != pBufferObj->PciMem.Size)
    {
        DebugPrintf_NoInfo((
            "  (req: %d Kb)\n",
            (pPciMem->Size >> 10)
            ));
    }
    else
    {
        DebugPrintf_NoInfo(("\n"));
    }

    // Record buffer owner
    pBufferObj->pOwner = pOwner;

    // Clear user address
    pBufferObj->PciMem.UserAddr = (U32)NULL;

    // Assign buffer to device if provided
    if (pdx != NULL)
    {
        // Return buffer information
        pPciMem->Size         = pBufferObj->PciMem.Size;
        pPciMem->PhysicalAddr = pBufferObj->PciMem.PhysicalAddr;

        // Initialize mappings list
        InitializeListHead(
            &(pBufferObj->List_Mappings)
            );

        KeInitializeSpinLock(
            &(pBufferObj->Lock_MappingsList)
            );

        // Add buffer object to list
        ExInterlockedInsertTailList(
            &(pdx->List_PhysicalMem),
            &(pBufferObj->ListEntry),
            &(pdx->Lock_PhysicalMemList)
            );
    }
    else
    {
        // Store common buffer information
        Gbl_CommonBuffer = *pBufferObj;

        // Initialize mappings list
        InitializeListHead(
            &(Gbl_CommonBuffer.List_Mappings)
            );

        KeInitializeSpinLock(
            &(Gbl_CommonBuffer.Lock_MappingsList)
            );

        // Release the list object
        ExFreePool(
            pBufferObj
            );
    }

    return ApiSuccess;
}




/******************************************************************************
 *
 * Function   :  PlxPciPhysicalMemoryFree
 *
 * Description:  Free previously allocated physically contiguous page-locked memory
 *
 ******************************************************************************/
RETURN_CODE
PlxPciPhysicalMemoryFree(
    DEVICE_EXTENSION *pdx,
    PCI_MEMORY       *pPciMem
    )
{
    KIRQL             IrqL_Original;
    PLIST_ENTRY       pList;
    PLX_PHYSICAL_MEM *pBufferObj;


    KeAcquireSpinLock(
        &(pdx->Lock_PhysicalMemList),
        &IrqL_Original
        );

    pList = pdx->List_PhysicalMem.Flink;

    // Traverse list to find the desired list object
    while (pList != &(pdx->List_PhysicalMem))
    {
        // Get the object
        pBufferObj =
            CONTAINING_RECORD(
                pList,
                PLX_PHYSICAL_MEM,
                ListEntry
                );

        // Check if the physical addresses matches
        if (pBufferObj->PciMem.PhysicalAddr == pPciMem->PhysicalAddr)
        {
            // Release lock until mappings are removed
            KeReleaseSpinLock(
                &(pdx->Lock_PhysicalMemList),
                IrqL_Original
                );

            // Make sure all mappings to this memory are unmapped
            PlxPciPhysicalMemoryUnmapAll_ByOwner(
                pdx,
                pBufferObj,
                NULL         // Ignore owner to remove all mappings
                );

            // Remove the object from the list
            KeAcquireSpinLock(
                &(pdx->Lock_PhysicalMemList),
                &IrqL_Original
                );

            RemoveEntryList(
                pList
                );

            KeReleaseSpinLock(
                &(pdx->Lock_PhysicalMemList),
                IrqL_Original
                );

            // Free the MDL
            if (pBufferObj->pMdl != NULL)
            {
                IoFreeMdl(
                    pBufferObj->pMdl
                    );
            }

            // Release the buffer
            if (pBufferObj->pKernelVa != NULL)
            {
                MmFreeContiguousMemory(
                    pBufferObj->pKernelVa
                    );
            }

            DebugPrintf((
                "Released physical memory at 0x%x (%d Kb)\n",
                pBufferObj->PciMem.PhysicalAddr,
                (pBufferObj->PciMem.Size >> 10)
                ));

            // Release the list object
            ExFreePool(
                pBufferObj
                );

            return ApiSuccess;
        }

        // Jump to next item in the list
        pList = pList->Flink;
    }

    KeReleaseSpinLock(
        &(pdx->Lock_PhysicalMemList),
        IrqL_Original
        );

    DebugPrintf((
        "ERROR - buffer object not found in list\n"
        ));

    return ApiInvalidData;
}




/******************************************************************************
 *
 * Function   :  PlxPciPhysicalMemoryMap
 *
 * Description:  Maps physical memory to User virtual address space
 *
 ******************************************************************************/
RETURN_CODE
PlxPciPhysicalMemoryMap(
    DEVICE_EXTENSION *pdx,
    PCI_MEMORY       *pPciMem,
    BOOLEAN           bDeviceMem,
    VOID             *pOwner
    )
{
    VOID             *pUserVa;
    KIRQL             IrqL_Original;
    BOOLEAN           bFound;
    PLIST_ENTRY       pList;
    PHYSICAL_ADDRESS  AddrPhysical;
    PLX_PHYSICAL_MEM *pMemObject;
    PLX_USER_MAPPING *pMapObject;


    // Set default return value
    pPciMem->UserAddr = (U32)NULL;

    // Find the memory object to map
    if (pPciMem->PhysicalAddr == Gbl_CommonBuffer.PciMem.PhysicalAddr)
    {
        if (Gbl_CommonBuffer.PciMem.PhysicalAddr == (U32)NULL)
        {
            DebugPrintf((
                "ERROR - Common buffer not allocated, cannot map to user space\n"
                ));

            return ApiFailed;
        }

        pMemObject = &Gbl_CommonBuffer;
    }
    else
    {
        // Find the object in the list
        KeAcquireSpinLock(
            &(pdx->Lock_PhysicalMemList),
            &IrqL_Original
            );

        pList = pdx->List_PhysicalMem.Flink;

        bFound = FALSE;

        // Traverse list to find the desired list object
        while (!bFound && (pList != &(pdx->List_PhysicalMem)))
        {
            // Get the object
            pMemObject =
                CONTAINING_RECORD(
                    pList,
                    PLX_PHYSICAL_MEM,
                    ListEntry
                    );

            // Check if the physical addresses matches
            if (pMemObject->PciMem.PhysicalAddr == pPciMem->PhysicalAddr)
            {
                bFound = TRUE;
            }
            else
            {
                // Jump to next item in the list
                pList = pList->Flink;
            }
        }

        KeReleaseSpinLock(
            &(pdx->Lock_PhysicalMemList),
            IrqL_Original
            );

        if (!bFound)
        {
            DebugPrintf((
                "ERROR - Physical memory object not found in list, unable to map\n"
                ));

            return ApiInvalidAddress;
        }
    }

    // Attempt to map the region
    if (IsDriverWdm)
    {
        // Verify an MDL for the memory
        if (pMemObject->pMdl == NULL)
        {
            DebugPrintf((
                "ERROR - MDL does not exist for this memory, cannot map to user space\n"
                ));

            return ApiInsufficientResources;
        }

        pUserVa =
            MmMapLockedPagesSpecifyCache(
                pMemObject->pMdl,
                UserMode,
                MmNonCached,
                NULL,
                FALSE,
                NormalPagePriority
                );
    }
    else
    {
        AddrPhysical.QuadPart = pMemObject->PciMem.PhysicalAddr;

        pUserVa =
            MapInUserSpace(
                AddrPhysical,
                pMemObject->PciMem.Size
                );
    }

    if (pUserVa == NULL)
    {
        DebugPrintf((
            "ERROR - Unable to map Physical address (0x%08x) ==> User Space\n",
            pMemObject->PciMem.PhysicalAddr
            ));

        return ApiInsufficientResources;
    }

    DebugPrintf((
        "Mapped Physical address (0x%08x) ==> Virtual address (0x%08x)\n",
        pMemObject->PciMem.PhysicalAddr, (U32)pUserVa
        ));

    // Return virtual address
    pPciMem->UserAddr = (U32)pUserVa;

    // Save mapping to list for this physical memory
    pMapObject =
        ExAllocatePool(
            NonPagedPool,
            sizeof(PLX_USER_MAPPING)
            );

    if (pMapObject == NULL)
    {
        DebugPrintf((
            "ERROR: Unable to save mapping, insufficient memory\n"
            ));
    }
    else
    {
        // Record the IRP owner
        pMapObject->pOwner = pOwner;

        // Record the virtual address
        pMapObject->pUserVa = pUserVa;

        // Save the mapping for later cleanup
        ExInterlockedInsertTailList(
            &(pMemObject->List_Mappings),
            &(pMapObject->ListEntry),
            &(pMemObject->Lock_MappingsList)
            );
    }

    return ApiSuccess;
}




/******************************************************************************
 *
 * Function   :  PlxPciPhysicalMemoryUnmap
 *
 * Description:  Unmap physical memory from User virtual address space
 *
 ******************************************************************************/
RETURN_CODE
PlxPciPhysicalMemoryUnmap(
    DEVICE_EXTENSION *pdx,
    PCI_MEMORY       *pPciMem
    )
{
    VOID             *pUserVa;
    KIRQL             IrqL_Original;
    BOOLEAN           bFound;
    PLIST_ENTRY       pList;
    PHYSICAL_ADDRESS  AddrPhysical;
    PLX_PHYSICAL_MEM *pMemObject;
    PLX_USER_MAPPING *pMapObject;


    // Find the memory object to unmap
    if (pPciMem->PhysicalAddr == Gbl_CommonBuffer.PciMem.PhysicalAddr)
    {
        if (Gbl_CommonBuffer.PciMem.PhysicalAddr == (U32)NULL)
        {
            DebugPrintf((
                "ERROR - Common buffer not allocated, cannot unmap from user space\n"
                ));

            return ApiFailed;
        }

        pMemObject = &Gbl_CommonBuffer;
    }
    else
    {
        // Find the object in the list
        KeAcquireSpinLock(
            &(pdx->Lock_PhysicalMemList),
            &IrqL_Original
            );

        pList = pdx->List_PhysicalMem.Flink;

        bFound = FALSE;

        // Traverse list to find the desired list object
        while (!bFound && (pList != &(pdx->List_PhysicalMem)))
        {
            // Get the object
            pMemObject =
                CONTAINING_RECORD(
                    pList,
                    PLX_PHYSICAL_MEM,
                    ListEntry
                    );

            // Check if the physical addresses matches
            if (pMemObject->PciMem.PhysicalAddr == pPciMem->PhysicalAddr)
            {
                bFound = TRUE;
            }
            else
            {
                // Jump to next item in the list
                pList = pList->Flink;
            }
        }

        KeReleaseSpinLock(
            &(pdx->Lock_PhysicalMemList),
            IrqL_Original
            );

        if (!bFound)
        {
            DebugPrintf((
                "ERROR - Physical memory object not found in list, unable to unmap\n"
                ));

            return ApiInvalidAddress;
        }
    }

    // Find the map object to unmap
    KeAcquireSpinLock(
        &(pMemObject->Lock_MappingsList),
        &IrqL_Original
        );

    pList = pMemObject->List_Mappings.Flink;

    bFound = FALSE;

    // Traverse list to find the desired list object
    while (!bFound && (pList != &(pMemObject->List_Mappings)))
    {
        // Get the object
        pMapObject =
            CONTAINING_RECORD(
                pList,
                PLX_USER_MAPPING,
                ListEntry
                );

        // Check if the virtual addresses matches
        if ((U32)pMapObject->pUserVa == pPciMem->UserAddr)
        {
            // Remove entry from the list
            RemoveEntryList(
                pList
                );

            bFound = TRUE;
        }
        else
        {
            // Jump to next item in the list
            pList = pList->Flink;
        }
    }

    KeReleaseSpinLock(
        &(pMemObject->Lock_MappingsList),
        IrqL_Original
        );

    if (!bFound)
    {
        DebugPrintf((
            "ERROR - Mapping object not found in list, unable to unmap\n"
            ));

        return ApiInvalidAddress;
    }

    // Unmap the memory
    if (pMapObject->pUserVa != (U32)NULL)
    {
        DebugPrintf((
            "Unmapping Virtual address (0x%08x) from User Space...\n",
            (U32)pMapObject->pUserVa
            ));

        if (IsDriverWdm)
        {
            MmUnmapLockedPages(
                pMapObject->pUserVa,
                pMemObject->pMdl
                );
        }
        else
        {
            ZwUnmapViewOfSection(
                (HANDLE) -1,
                pMapObject->pUserVa
                );
        }

        // Clear virtual address
        pPciMem->UserAddr = (U32)NULL;
    }
    else
    {
        DebugPrintf((
            "ERROR - Invalid virtual address (0x%08x), cannot unmap\n",
            pMapObject->pUserVa
            ));

        return ApiInvalidAddress;
    }

    // Release memory for map object
    ExFreePool(
        pMapObject
        );

    return ApiSuccess;
}




/******************************************************************************
 *
 * Function   :  PlxPciBarMap
 *
 * Description:  Map a PCI BAR Space into User virtual space
 *
 ******************************************************************************/
RETURN_CODE
PlxPciBarMap(
    DEVICE_EXTENSION *pdx,
    U8                BarIndex,
    VOID             *pUserVa,
    VOID             *pOwner
    )
{
    PLX_USER_MAPPING *pMapObject;


    // Set default address
    *(U32*)pUserVa = (U32)NULL;

    // Verify BAR is of type memory
    if (pdx->PciBar[BarIndex].IsIoMapped)
    {
        DebugPrintf((
            "ERROR - BAR %d is an I/O space, cannot map to user space\n",
            BarIndex
            ));

        return ApiInvalidPciSpace;
    }

    // Check if the space is valid
    if (pdx->PciBar[BarIndex].Physical.QuadPart == (U32)NULL)
    {
        DebugPrintf((
            "ERROR - BAR %d address (0x%08x) is invalid\n",
            BarIndex, (U32)(pdx->PciBar[BarIndex].Physical.QuadPart)
            ));

        return ApiInvalidAddress;
    }

    // Verify Kernel virtual address
    if (pdx->PciBar[BarIndex].pVa == NULL)
    {
        DebugPrintf((
            "ERROR - Kernel Virtual address for BAR %d is not valid\n",
            BarIndex
            ));

        return ApiInvalidAddress;
    }

    // Make sure memory size is valid
    if (pdx->PciBar[BarIndex].Size == 0)
    {
        DebugPrintf((
            "ERROR - Size of BAR %d is 0\n",
            BarIndex
            ));

        return ApiInvalidSize;
    }

    // Attempt to map the BAR into user space
    if (IsDriverWdm)
    {
        // Verify the MDL
        if (pdx->PciBar[BarIndex].pMdl == NULL)
        {
            DebugPrintf((
                "ERROR - MDL does not exist for BAR %d\n",
                BarIndex
                ));

            return ApiInsufficientResources;
        }

        *(U32*)pUserVa =
            (U32)MmMapLockedPagesSpecifyCache(
                     pdx->PciBar[BarIndex].pMdl,
                     UserMode,
                     MmNonCached,
                     NULL,
                     FALSE,
                     LowPagePriority
                     );
    }
    else
    {
        *(U32*)pUserVa =
            (U32)MapInUserSpace(
                     pdx->PciBar[BarIndex].Physical,
                     pdx->PciBar[BarIndex].Size
                     );
    }

    // Check if the mapping succeeded
    if (*(U32*)pUserVa == (U32)NULL)
    {
        DebugPrintf((
            "ERROR - Unable to map PCI BAR %d (0x%08x) ==> User space\n",
            BarIndex, pdx->PciBar[BarIndex].Physical.u.LowPart
            ));

        return ApiInsufficientResources;
    }

    DebugPrintf((
        "Mapped PCI BAR %d (0x%08x) ==> User Virtual address (0x%08x)\n",
        BarIndex, pdx->PciBar[BarIndex].Physical.u.LowPart, *(U32*)pUserVa
        ));


    // Add mapping to list for later unmapping
    pMapObject =
        ExAllocatePool(
            NonPagedPool,
            sizeof(PLX_USER_MAPPING)
            );

    if (pMapObject == NULL)
    {
        DebugPrintf(("ERROR: Unable to save mapping, insufficient memory\n"));
    }
    else
    {
        // Record mapping properties
        pMapObject->pOwner       = pOwner;
        pMapObject->BarIndex     = BarIndex;
        (U32)pMapObject->pUserVa = *(U32*)pUserVa;

        // Save the mapping for later cleanup
        ExInterlockedInsertTailList(
            &(pdx->List_BarMappings),
            &(pMapObject->ListEntry),
            &(pdx->Lock_BarMappingsList)
            );
    }

    return ApiSuccess;
}




/******************************************************************************
 *
 * Function   :  PlxPciBarUnmap
 *
 * Description:  Unmap a previously mapped PCI BAR Space from User virtual space
 *
 ******************************************************************************/
RETURN_CODE
PlxPciBarUnmap(
    DEVICE_EXTENSION *pdx,
    VOID             *pUserVa,
    VOID             *pOwner
    )
{
    KIRQL             IrqL_Original;
    PLIST_ENTRY       pList;
    PLX_USER_MAPPING *pMapObject;


    // Find the previous mapping object
    KeAcquireSpinLock(
        &(pdx->Lock_BarMappingsList),
        &IrqL_Original
        );

    pList = pdx->List_BarMappings.Flink;

    while (pList != &(pdx->List_BarMappings))
    {
        pMapObject =
            CONTAINING_RECORD(
                pList,
                PLX_USER_MAPPING,
                ListEntry
                );

        if ((pMapObject->pOwner       == pOwner) &&
            ((U32)pMapObject->pUserVa == *(U32*)pUserVa))
        {
            // Remove map object from list
            RemoveEntryList(
                pList
                );

            KeReleaseSpinLock(
                &(pdx->Lock_BarMappingsList),
                IrqL_Original
                );

            DebugPrintf((
                "Unmapping Virtual address (0x%08x) for BAR %d from User Space...\n",
                (U32)pMapObject->pUserVa, pMapObject->BarIndex
                ));

            // Unmap the space
            if (IsDriverWdm)
            {
                MmUnmapLockedPages(
                    pMapObject->pUserVa,
                    pdx->PciBar[pMapObject->BarIndex].pMdl
                    );
            }
            else
            {
                ZwUnmapViewOfSection(
                    (HANDLE) -1,
                    pMapObject->pUserVa
                    );
            }

            // Release the list object
            ExFreePool(
                pMapObject
                );

            return ApiSuccess;
        }

        // Jump to next item
        pList = pList->Flink;
    }

    DebugPrintf((
        "ERROR - Map object not found in list...\n"
        ));

    KeReleaseSpinLock(
        &(pdx->Lock_BarMappingsList),
        IrqL_Original
        );

    return ApiInvalidAddress;
}
