/*******************************************************************************
 * Copyright (c) 2002 PLX Technology, Inc.
 *
 * PLX Technology Inc. licenses this software under specific terms and
 * conditions.  Use of any of the software or derviatives thereof in any
 * product without a PLX Technology chip is strictly prohibited.
 *
 * PLX Technology, Inc. provides this software AS IS, WITHOUT ANY WARRANTY,
 * EXPRESS OR IMPLIED, INCLUDING, WITHOUT LIMITATION, ANY WARRANTY OF
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  PLX makes no guarantee
 * or representations regarding the use of, or the results of the use of,
 * the software and documentation in terms of correctness, accuracy,
 * reliability, currentness, or otherwise; and you rely on the software,
 * documentation and results solely at your own risk.
 *
 * IN NO EVENT SHALL PLX BE LIABLE FOR ANY LOSS OF USE, LOSS OF BUSINESS,
 * LOSS OF PROFITS, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES
 * OF ANY KIND.  IN NO EVENT SHALL PLX'S TOTAL LIABILITY EXCEED THE SUM
 * PAID TO PLX FOR THE PRODUCT LICENSED HEREUNDER.
 *
 ******************************************************************************/

/******************************************************************************
 *
 * File Name:
 *
 *      SupportFunc.c
 *
 * Description:
 *
 *      Additional support functions
 *
 * Revision History:
 *
 *      04-31-02 : PCI SDK v3.50
 *
 ******************************************************************************/


#include "ApiFunctions.h"
#include "CommonApi.h"
#include "GlobalVars.h"
#include "PciSupport.h"
#include "SupportFunc.h"

#if defined(DMA_SUPPORT)
    #include "Buffer.h"
#endif




/*********************************************************************
*
* Function   :  PlxSynchronizedRegisterModify
*
* Description:  Register modify to be called with KeSynchronizeExecution()
*
**********************************************************************/
BOOLEAN
PlxSynchronizedRegisterModify(
    PLX_REG_DATA *pRegData
    )
{
    U32 RegValue;


    RegValue =
        PLX_REG_READ(
            pRegData->pdx,
            pRegData->offset
            );

    RegValue |= pRegData->BitsToSet;
    RegValue &= ~(pRegData->BitsToClear);

    PLX_REG_WRITE(
        pRegData->pdx,
        pRegData->offset,
        RegValue
        );

    return TRUE;
}




/*********************************************************************
*
* Function   :  PlxRegistryInformationGet
*
* Description:  Gets driver configuration information from the registry
*
**********************************************************************/
VOID
PlxRegistryInformationGet(
    UNICODE_STRING       *pRegistryPath,
    REGISTRY_INFORMATION *pRegistryInfo
    )
{
    NTSTATUS                  status;
    RTL_QUERY_REGISTRY_TABLE  RegTable[2];
#if defined(NT_DRIVER)
    U32                      *marker;
    WCHAR                     slBuffer[200];
    UNICODE_STRING            supportedList;
    UNICODE_STRING            fragment;
#endif


    RtlZeroMemory(
        RegTable,
        sizeof(RegTable)
        );

    RegTable[0].Flags = RTL_QUERY_REGISTRY_REQUIRED | RTL_QUERY_REGISTRY_DIRECT;


    // Get Common DMA buffer size
    RegTable[0].Name         = L"CommonBufferSize";
    RegTable[0].EntryContext = &(pRegistryInfo->CommonBufferSize);

    status =
        RtlQueryRegistryValues(
            RTL_REGISTRY_ABSOLUTE,
            pRegistryPath->Buffer,
            RegTable,
            NULL,
            NULL
            );

    if ( !NT_SUCCESS(status) )
    {
        pRegistryInfo->CommonBufferSize = DEFAULT_SIZE_COMMON_BUFFER;
    }

    // Get Max SGL transfer size
    RegTable[0].Name         = L"MaxSglTransferSize";
    RegTable[0].EntryContext = &(pRegistryInfo->MaxSglTransferSize);

    status =
        RtlQueryRegistryValues(
            RTL_REGISTRY_ABSOLUTE,
            pRegistryPath->Buffer,
            RegTable,
            NULL,
            NULL
            );

    if ( !NT_SUCCESS(status) )
    {
        pRegistryInfo->MaxSglTransferSize = DEFAULT_SIZE_SGL_TRANSFER;
    }


#if defined(NT_DRIVER)
    // Get list of Valid IDs
    supportedList.MaximumLength = sizeof(slBuffer);
    supportedList.Buffer        = slBuffer;

    RegTable[0].Name          = L"SupportedIDs";
    RegTable[0].EntryContext  = &supportedList;

    status =
        RtlQueryRegistryValues(
            RTL_REGISTRY_ABSOLUTE,
            pRegistryPath->Buffer,
            RegTable,
            NULL,
            NULL
            );

    if ( !NT_SUCCESS(status) )
    {
        DebugPrintf((
            "ERROR - Unable to read %ws registry entry\n",
            RegTable[0].Name
            ));

        pRegistryInfo->ValidIdList[0] = PLX_DEFAULT_DEV_VEN_ID;
        pRegistryInfo->IdListSize     = 1;
    }
    else
    {
        // Now parse the unicode list and place the ID values into the array

        marker                    = pRegistryInfo->ValidIdList;
        pRegistryInfo->IdListSize = 0;
        fragment.Buffer           = supportedList.Buffer;
        fragment.MaximumLength    = sizeof(WCHAR) * 8;
        fragment.Length           = sizeof(WCHAR) * 8;

        while (1)
        {
            RtlUnicodeStringToInteger(
                &fragment,
                0x10,
                marker
                );

            fragment.Buffer += 9; /* must skip to next value +1 for space */
            marker++;
            (pRegistryInfo->IdListSize) += 1;

            if ((U32)fragment.Buffer >= (U32)supportedList.Buffer + (U32)supportedList.Length)
                break;
        }
    }
#endif
}




/******************************************************************************
 *
 * Function   :  PlxSearchDevices
 *
 * Description:  Search for a specific device using device location parameters
 *
 ******************************************************************************/
NTSTATUS
PlxSearchDevices(
    DEVICE_EXTENSION *pdx,
    DEVICE_LOCATION  *pDeviceCriteria,
    U32              *pSelection
    )
{
    U32            MatchFound;
    BOOLEAN        ContinueComparison;
    DEVICE_OBJECT *fdo;


    // Verify pointers
    if (pDeviceCriteria == NULL || pSelection == NULL)
        return STATUS_UNSUCCESSFUL;

    if (pdx->pDeviceObject == NULL)
        return STATUS_UNSUCCESSFUL;

    if (pdx->pDeviceObject->DriverObject == NULL)
        return STATUS_UNSUCCESSFUL;

    MatchFound = 0;
    fdo        = pdx->pDeviceObject->DriverObject->DeviceObject;

    // Compare with items in device list
    while (fdo != NULL)
    {
        // Get the device extension
        pdx = fdo->DeviceExtension;

        ContinueComparison = TRUE;

        // Compare Serial Number
        if ((pDeviceCriteria->SerialNumber[0] != '\0') && ContinueComparison)
        {
            if (_stricmp(
                    pdx->Device.SerialNumber,
                    pDeviceCriteria->SerialNumber
                    ) != 0)
            {
                ContinueComparison = FALSE;
            }
        }

        // Compare the Bus number
        if ((pDeviceCriteria->BusNumber != (U8)-1) && ContinueComparison)
        {
            if (pDeviceCriteria->BusNumber != pdx->Device.BusNumber)
                ContinueComparison = FALSE;
        }

        // Compare Slot Number
        if ((pDeviceCriteria->SlotNumber != (U8)-1) && ContinueComparison)
        {
            if (pDeviceCriteria->SlotNumber != pdx->Device.SlotNumber)
                ContinueComparison = FALSE;
        }

        // Compare Device ID
        if ((pDeviceCriteria->DeviceId != (U16)-1) && ContinueComparison)
        {
            if (pDeviceCriteria->DeviceId != pdx->Device.DeviceId)
                ContinueComparison = FALSE;
        }

        // Compare Vendor ID
        if ((pDeviceCriteria->VendorId != (U16)-1) && ContinueComparison)
        {
            if (pDeviceCriteria->VendorId != pdx->Device.VendorId)
                ContinueComparison = FALSE;
        }

        if (ContinueComparison == TRUE)
        {
            // Match found, check if it is the device we want
            if (MatchFound++ == *pSelection)
            {
                // Copy the device information
                RtlCopyMemory(
                    pDeviceCriteria,
                    &pdx->Device,
                    sizeof(DEVICE_LOCATION)
                    );
            }
        }

        fdo = fdo->NextDevice;
    }

    // Return the number of matched devices
    *pSelection = MatchFound;

    return STATUS_SUCCESS;
}




/******************************************************************************
 *
 * Function   :  PlxReportEvent
 *
 * Description:  Uses the input parameters to send a message to the Event Log
 *               found in the Administrative Tools Section of Windows NT.
 *
 ******************************************************************************/
VOID
PlxReportEvent(
    NTSTATUS ErrorCode,
    PVOID    pIoObject
    )
{
    PIO_ERROR_LOG_PACKET pPacket;


    // Try to allocate the packet
    pPacket =
        IoAllocateErrorLogEntry(
            pIoObject,
            sizeof(IO_ERROR_LOG_PACKET)
            );

    if (pPacket == NULL)
    {
        DebugPrintf(("ERROR - unable to allocate Error Log packet\n"));
        return;
    }

    // Fill in standard parts of the packet
    pPacket->ErrorCode         = ErrorCode;
    pPacket->MajorFunctionCode = 0;
    pPacket->RetryCount        = 0;
    pPacket->FinalStatus       = 0;
    pPacket->SequenceNumber    = 0;
    pPacket->IoControlCode     = 0;
    pPacket->DumpDataSize      = 0;

    // Log the message
    IoWriteErrorLogEntry(
        pPacket
        );
}




/******************************************************************************
 *
 * Function   :  GetBarIndex
 *
 * Description:  Associate a h/w resource with a bar number
 *
 ******************************************************************************/
U8
GetBarIndex(
    PHYSICAL_ADDRESS   address,
    PCI_COMMON_CONFIG *pciRegs
    )
{
    U8  i;
    U32 compareAddress;


    // Compare the physical address with each BAR
    for (i = 0; i < PCI_NUM_BARS; i++)
    {
        if (i == 6)
        {
            // Check if Expansion ROM BAR
            compareAddress = (pciRegs->u.type0.ROMBaseAddress & ~0x1);
        }
        else
        {
            if (pciRegs->u.type0.BaseAddresses[i] & 0x1)
                compareAddress = pciRegs->u.type0.BaseAddresses[i] & 0xFFFFFFFC;
            else
                compareAddress = pciRegs->u.type0.BaseAddresses[i] & 0xFFFFFFF0;
        }

        if (address.u.LowPart == compareAddress)
            return i;
    }

    // Unable to find the BAR index
    DebugPrintf((
        "ERROR - GetBarIndex() unable to match BAR value (0x%08x)\n",
        address.u.LowPart
        ));

    return (U8)-1;
}




/******************************************************************************
 *
 * Function   :  PlxCompleteIrp
 *
 * Description:  Complete an IRP
 *
 ******************************************************************************/
NTSTATUS
PlxCompleteIrp(
    PIRP     pIrp,
    NTSTATUS status
    )
{
    pIrp->IoStatus.Status = status;

    IoCompleteRequest(
        pIrp,
        IO_NO_INCREMENT
        );

    if (status == STATUS_CANCELLED)
        DebugPrintf(("...Cancelled IRP (0x%08x)\n", pIrp));
    else
        DebugPrintf(("...Completed IRP (0x%08x)\n", pIrp));

    return status;
}




/******************************************************************************
 *
 * Function   :  PlxCompleteIrpWithInformation
 *
 * Description:  Complete an IRP including modification of the Information field
 *
 ******************************************************************************/
NTSTATUS
PlxCompleteIrpWithInformation(
    PIRP     pIrp,
    NTSTATUS status,
    U32      Info
    )
{
    pIrp->IoStatus.Status      = status;
    pIrp->IoStatus.Information = Info;

    IoCompleteRequest(
        pIrp,
        IO_NO_INCREMENT
        );

    if (status == STATUS_CANCELLED)
        DebugPrintf(("...Cancelled IRP (0x%08x)\n", pIrp));
    else
        DebugPrintf(("...Completed IRP (0x%08x)\n", pIrp));

    return status;
}




/******************************************************************************
 *
 * Function   :  PlxInterruptIrpCancel
 *
 * Description:  Find the interrupt event associated with an IRP and cancel it
 *
 ******************************************************************************/
VOID
PlxInterruptIrpCancel(
    DEVICE_EXTENSION *pdx,
    PIRP              pIrp
    )
{
    KIRQL             IrqL_Original;
    PLIST_ENTRY       pNextEntry;
    INTR_WAIT_OBJECT *pEvent;


    KeAcquireSpinLock(
        &(pdx->Lock_InterruptWaitList),
        &IrqL_Original
        );

    pNextEntry = pdx->List_InterruptWait.Flink;

    // Find the IRP and cancel it
    while (pNextEntry != &(pdx->List_InterruptWait))
    {
        pEvent =
            CONTAINING_RECORD(
                pNextEntry,
                INTR_WAIT_OBJECT,
                ListEntry
                );

        // Check if this IRP should be completed
        if (pEvent->pIrpPending == pIrp)
        {
            // Remove the IRP pointer from list of pending IRPs
            RemoveEntryList(
                pNextEntry
                );

            KeReleaseSpinLock(
                &(pdx->Lock_InterruptWaitList),
                IrqL_Original
                );

            // Free the memory
            ExFreePool(
                pEvent
                );

            PlxCompleteIrpWithInformation(
                pIrp,
                STATUS_CANCELLED,
                0
                );

            return;
        }

        // Jump to next item in the list
        pNextEntry = pNextEntry->Flink;
    }

    KeReleaseSpinLock(
        &(pdx->Lock_InterruptWaitList),
        IrqL_Original
        );
}




/******************************************************************************
 *
 * Function   :  OnCancelInterruptIrp
 *
 * Description:  Called by the I/O Manager to cancel a pending interrupt attach IRP.
 *
 ******************************************************************************/
VOID
OnCancelInterruptIrp(
    PDEVICE_OBJECT fdo,
    PIRP           pIrp
    )
{
    IoReleaseCancelSpinLock(
        pIrp->CancelIrql
        );

    PlxInterruptIrpCancel(
        fdo->DeviceExtension,
        pIrp
        );
}




/******************************************************************************
 *
 * Function   :  PlxDmaChannelCleanup
 *
 * Description:  Called by the Cleanup routine to close any open channels
 *
 ******************************************************************************/
VOID
PlxDmaChannelCleanup(
    DEVICE_EXTENSION *pdx,
    VOID             *pOwner
    )
{
#if defined(DMA_SUPPORT)
    U8          i;
    DMA_CHANNEL channel;


    // Added to avoid compiler warning
    channel = PrimaryPciChannel0;

    for (i = 0; i < NUMBER_OF_DMA_CHANNELS; i++)
    {
        // Check if terminating application is the owner
        if (pdx->DmaInfo[i].pOwner == pOwner)
        {
            DebugPrintf(("Closing DMA channel %d\n", i));

            switch (i)
            {
                case 0:
                    channel = PrimaryPciChannel0;
                    break;

                case 1:
                    channel = PrimaryPciChannel1;
                    break;

                case 2:
                    channel = IopChannel2;
                    break;
            }

            switch (pdx->DmaInfo[i].state)
            {
                case DmaStateClosed:
                    // DMA closed already, do nothing
                    break;

                case DmaStateBlock:
                    PlxDmaBlockChannelClose(
                        pdx,
                        channel,
                        FALSE
                        );
                    break;

                case DmaStateSgl:
                    PlxDmaSglChannelClose(
                        pdx,
                        channel,
                        FALSE
                        );
                    break;

                default:
                    // Unknown or unsupported state
                    break;
            }
        }
    }
#endif  // DMA_SUPPORT
}




/******************************************************************************
 *
 * Function   :  OnCancelDmaIrp
 *
 * Description:  Called by the I/O Manager to cancel a pending DMA IRP
 *
 ******************************************************************************/
VOID
OnCancelDmaIrp(
    PDEVICE_OBJECT fdo,
    PIRP           pIrp
    )
{
#if defined(DMA_SUPPORT)
    U8                i;
    KIRQL             IrqL_Original;
    DEVICE_EXTENSION *pdx;


    IoReleaseCancelSpinLock(
        pIrp->CancelIrql
        );

    pdx = fdo->DeviceExtension;

    KeAcquireSpinLock(
        &(pdx->Lock_DmaChannel),
        &IrqL_Original
        );

    // Find the IRP and cancel it
    for (i = 0; i < NUMBER_OF_DMA_CHANNELS; i++)
    {
        if (pIrp == pdx->DmaInfo[i].pIrp)
        {
            // Remove IRP from pending list
            pdx->DmaInfo[i].pIrp = NULL;

            if (pdx->DmaInfo[i].pMdl != NULL)
            {
                // Unlock the buffer and free the MDL
                MmUnlockPages(
                    pdx->DmaInfo[i].pMdl
                    );

                IoFreeMdl(
                    pdx->DmaInfo[i].pMdl
                    );

                pdx->DmaInfo[i].pMdl = NULL;
            }

            if (pdx->DmaInfo[i].pSgl != NULL)
            {
                // Release the SGL descriptor buffer
                DriverBufferFree(
                    pdx->DmaInfo[i].pSgl
                    );

                pdx->DmaInfo[i].pSgl = NULL;
            }

            KeReleaseSpinLock(
                &(pdx->Lock_DmaChannel),
                IrqL_Original
                );

            IoSetCancelRoutine(
                pIrp,
                NULL
                );

            DebugPrintf(("...Cancelling unfinished DMA IRP (0x%08x)\n", pIrp));

            pIrp->IoStatus.Status      = STATUS_CANCELLED;
            pIrp->IoStatus.Information = 0;

            IoCompleteRequest(
                pIrp,
                IO_NO_INCREMENT
                );

            return;
        }
    }

    KeReleaseSpinLock(
        &(pdx->Lock_DmaChannel),
        IrqL_Original
        );
#endif  // DMA_SUPPORT
}




/******************************************************************************
 *
 * Function   :  PlxPciBarResourceMap
 *
 * Description:  Maps a PCI BAR register into Kernel space
 *
 ******************************************************************************/
NTSTATUS
PlxPciBarResourceMap(
    DEVICE_EXTENSION *pdx,
    U8                BarIndex
    )
{
    // Map into Kernel Virtual Space
    pdx->PciBar[BarIndex].pVa =
        MmMapIoSpace(
            pdx->PciBar[BarIndex].Physical,
            pdx->PciBar[BarIndex].Size,
            FALSE
            );

    if (pdx->PciBar[BarIndex].pVa == NULL)
    {
        /******************************************************************
         * In Windows, sometimes the BAR registers do not get mapped due to
         * insufficient page table entries.  Since the driver requires BAR0
         * for register access, we must try to map at least the registers.
         * If this fails, then the driver cannot load.
         *****************************************************************/
        if (BarIndex == 0)
        {
            // Attempt a minimum mapping
            pdx->PciBar[BarIndex].pVa =
                MmMapIoSpace(
                    pdx->PciBar[BarIndex].Physical,
                    MIN_SIZE_MAPPING_BAR_0,
                    FALSE
                    );

            if (pdx->PciBar[BarIndex].pVa == NULL)
            {
                return STATUS_INSUFFICIENT_RESOURCES;
            }
            else
            {
                pdx->PciBar[BarIndex].Size = MIN_SIZE_MAPPING_BAR_0;
            }
        }
        else
        {
            return STATUS_INSUFFICIENT_RESOURCES;
        }
    }

    if (IsDriverWdm)
    {
        // Get an MDL for future mapping into user space
        pdx->PciBar[BarIndex].pMdl =
            IoAllocateMdl(
                pdx->PciBar[BarIndex].pVa,
                pdx->PciBar[BarIndex].Size,
                FALSE,
                FALSE,
                NULL
                );

        // Check if the MDL allocation succeeded
        if (pdx->PciBar[BarIndex].pMdl == NULL)
        {
            DebugPrintf(("ERROR - MDL allocation for space failed\n"));
        }
        else
        {
            // Build the MDL
            MmBuildMdlForNonPagedPool(
                pdx->PciBar[BarIndex].pMdl
                );
        }
    }

    return STATUS_SUCCESS;
}




/******************************************************************************
 *
 * Function   :  PlxPciBarResourcesUnmap
 *
 * Description:  Unmap all mapped PCI BAR memory for a device
 *
 ******************************************************************************/
VOID
PlxPciBarResourcesUnmap(
    DEVICE_EXTENSION *pdx
    )
{
    U8 i;


    // Go through all the BARS
    for (i = 0; i < PCI_NUM_BARS; i++)
    {
        // Unmap the space from Kernel space if previously mapped
        if ((pdx->PciBar[i].IsIoMapped == FALSE) &&
            (pdx->PciBar[i].Physical.u.LowPart != 0))
        {
            DebugPrintf(("Unmapping BAR %d...\n", i));

            // Release the MDL describing the user space map
            if (pdx->PciBar[i].pMdl != (PMDL)NULL)
            {
                IoFreeMdl(
                    pdx->PciBar[i].pMdl
                    );
                pdx->PciBar[i].pMdl = NULL;
            }

            // Unmap from kernel space
            if (pdx->PciBar[i].pVa != NULL)
            {
                MmUnmapIoSpace(
                    pdx->PciBar[i].pVa,
                    pdx->PciBar[i].Size
                    );
                pdx->PciBar[i].pVa  = NULL;
            }
        }
    }
}




/******************************************************************************
 *
 * Function   :  PlxPciBarSpaceUnmapAll_ByOwner
 *
 * Description:  Unmap any PCI BAR spaces assigned to the specified owner
 *
 ******************************************************************************/
VOID
PlxPciBarSpaceUnmapAll_ByOwner(
    DEVICE_EXTENSION *pdx,
    VOID             *pOwner
    )
{
    U32               UserVa;
    KIRQL             IrqL_Original;
    PLIST_ENTRY       pList;
    PLX_USER_MAPPING *pMapObject;


    KeAcquireSpinLock(
        &(pdx->Lock_BarMappingsList),
        &IrqL_Original
        );

    pList = pdx->List_BarMappings.Flink;

    // Traverse list to find the desired list objects
    while (pList != &(pdx->List_BarMappings))
    {
        // Get the object
        pMapObject =
            CONTAINING_RECORD(
                pList,
                PLX_USER_MAPPING,
                ListEntry
                );

        // Check if owner matches
        if (pMapObject->pOwner == pOwner)
        {
            // Copy address
            UserVa = (U32)pMapObject->pUserVa;

            // Release list lock
            KeReleaseSpinLock(
                &(pdx->Lock_BarMappingsList),
                IrqL_Original
                );

            // Unmap BAR space
            PlxPciBarUnmap(
                pdx,
                &UserVa,
                pOwner
                ); 

            KeAcquireSpinLock(
                &(pdx->Lock_BarMappingsList),
                &IrqL_Original
                );

            // Restart parsing the list from the beginning
            pList = pdx->List_BarMappings.Flink;
        }
        else
        {
            // Jump to next item
            pList = pList->Flink;
        }
    }

    KeReleaseSpinLock(
        &(pdx->Lock_BarMappingsList),
        IrqL_Original
        );
}




/******************************************************************************
 *
 * Function   :  PlxPciPhysicalMemoryFreeAll_ByOwner
 *
 * Description:  Unmap & release all physical memory assigned to the specified owner
 *
 ******************************************************************************/
VOID
PlxPciPhysicalMemoryFreeAll_ByOwner(
    DEVICE_EXTENSION *pdx,
    VOID             *pOwner
    )
{
    KIRQL             IrqL_Original;
    PLIST_ENTRY       pList;
    PCI_MEMORY        PciMem;
    PLX_PHYSICAL_MEM *pMemObject;


    KeAcquireSpinLock(
        &(pdx->Lock_PhysicalMemList),
        &IrqL_Original
        );

    pList = pdx->List_PhysicalMem.Flink;

    // Traverse list to find the desired list objects
    while (pList != &(pdx->List_PhysicalMem))
    {
        // Get the object
        pMemObject =
            CONTAINING_RECORD(
                pList,
                PLX_PHYSICAL_MEM,
                ListEntry
                );

        // Check if owner matches
        if (pMemObject->pOwner == pOwner)
        {
            // Copy memory information
            PciMem = pMemObject->PciMem;

            // Release list lock
            KeReleaseSpinLock(
                &(pdx->Lock_PhysicalMemList),
                IrqL_Original
                );

            // Release the memory & remove from list
            PlxPciPhysicalMemoryFree(
                pdx,
                &PciMem
                ); 

            KeAcquireSpinLock(
                &(pdx->Lock_PhysicalMemList),
                &IrqL_Original
                );

            // Restart parsing the list from the beginning
            pList = pdx->List_PhysicalMem.Flink;
        }
        else
        {
            // Jump to next item
            pList = pList->Flink;
        }
    }

    KeReleaseSpinLock(
        &(pdx->Lock_PhysicalMemList),
        IrqL_Original
        );
}




/******************************************************************************
 *
 * Function   :  PlxPciPhysicalMemoryUnmapAll_ByOwner
 *
 * Description:  Unmap any physical memory assigned to the specified owner
 *
 ******************************************************************************/
VOID
PlxPciPhysicalMemoryUnmapAll_ByOwner(
    DEVICE_EXTENSION *pdx,
    PLX_PHYSICAL_MEM *pMemObject,
    VOID             *pOwner
    )
{
    VOID             *pUserVa;
    KIRQL             IrqL_Original;
    PCI_MEMORY        PciMem;
    PLIST_ENTRY       pList;
    PHYSICAL_ADDRESS  AddrPhysical;
    PLX_USER_MAPPING *pMapObject;


    // Verify size
    if (pMemObject->PciMem.Size == 0)
    {
        return;
    }

    // Setup memory properties
    PciMem.PhysicalAddr = pMemObject->PciMem.PhysicalAddr;
    PciMem.Size         = pMemObject->PciMem.Size;

    // Find the map object to unmap
    KeAcquireSpinLock(
        &(pMemObject->Lock_MappingsList),
        &IrqL_Original
        );

    pList = pMemObject->List_Mappings.Flink;

    // Traverse list to find the desired list object
    while (pList != &(pMemObject->List_Mappings))
    {
        // Get the object
        pMapObject =
            CONTAINING_RECORD(
                pList,
                PLX_USER_MAPPING,
                ListEntry
                );

        // Check if the virtual addresses matches
        if ((pOwner == NULL) || (pMapObject->pOwner == pOwner))
        {
            // Copy virtual address
            PciMem.UserAddr = (U32)pMapObject->pUserVa;

            // Release list lock
            KeReleaseSpinLock(
                &(pMemObject->Lock_MappingsList),
                IrqL_Original
                );

            // Unmap the memory & remove from list
            PlxPciPhysicalMemoryUnmap(
                pdx,
                &PciMem
                ); 

            KeAcquireSpinLock(
                &(pMemObject->Lock_MappingsList),
                &IrqL_Original
                );

            // Restart parsing the list from the beginning
            pList = pMemObject->List_Mappings.Flink;
        }
        else
        {
            // Jump to next item
            pList = pList->Flink;
        }
    }

    KeReleaseSpinLock(
        &(pMemObject->Lock_MappingsList),
        IrqL_Original
        );
}




/******************************************************************************
 *
 * Function   :  MapInUserSpace
 *
 * Description:  Maps a physical address to user space
 *
 ******************************************************************************/
PVOID
MapInUserSpace(
    PHYSICAL_ADDRESS AddrPhysical,
    U32              Size
    )
{
    U32                VirtualAddress;
    ULONG              length;
    PVOID              PhysicalMemorySection;
    HANDLE             hPhysicalMemory;
    NTSTATUS           status;
    LARGE_INTEGER      ViewBase;
    UNICODE_STRING     PhysicalMemory_Unicode;
    OBJECT_ATTRIBUTES  ObjectAttributes;


    RtlInitUnicodeString(
        &PhysicalMemory_Unicode,
        L"\\Device\\PhysicalMemory"
        );

    InitializeObjectAttributes(
        &ObjectAttributes,
        &PhysicalMemory_Unicode,
        OBJ_CASE_INSENSITIVE,
        (HANDLE) NULL,
        (PSECURITY_DESCRIPTOR) NULL
        );

    status =
        ZwOpenSection(
            &hPhysicalMemory,
            SECTION_ALL_ACCESS,
            &ObjectAttributes
            );

    if (!NT_SUCCESS(status))
    {
        DebugPrintf(("ERROR - Unable to obtain a handle to the physical memory\n"));
        return NULL;
    }

    status =
        ObReferenceObjectByHandle(
            hPhysicalMemory,
            SECTION_ALL_ACCESS,
            (POBJECT_TYPE) NULL,
            KernelMode,
            &PhysicalMemorySection,
            (POBJECT_HANDLE_INFORMATION)NULL
            );

    if (!NT_SUCCESS(status))
    {
        DebugPrintf(("ERROR - Unable to reference object by handle\n"));
        ZwClose(
            hPhysicalMemory
            );
        return NULL;
    }

    // Let the OS pick an address
    VirtualAddress = (U32) NULL;

    // Initialize view base that will receive the physical mapped address
    ViewBase = AddrPhysical;

    length = Size;

    // Map the section
    status =
        ZwMapViewOfSection(
            hPhysicalMemory,
            (HANDLE) -1,
            (PVOID)&VirtualAddress,
            0L,
            length,
            &ViewBase,
            &length,
            ViewShare,
            0,
            PAGE_READWRITE | PAGE_NOCACHE
            );

    if (!NT_SUCCESS(status))
    {
        DebugPrintf((
            "ERROR - Unable to map view of section, status = 0x%x\n",
            status
            ));

        ZwClose(
            hPhysicalMemory
            );

        return NULL;
    }

    /*
       Mapping the section above rounded the physical address down to the
       nearest 64K boundary.  Now return a virtual address that sits where
       we want by adding in the offset from the beginning of the section.
     */
    VirtualAddress += (U32)(AddrPhysical.QuadPart - ViewBase.QuadPart);

    return (PVOID)VirtualAddress;
}




/******************************************************************************
 *
 * Function   :  Plx_sleep
 *
 * Description:  Function as a normal sleep. Parameter is in millisecond
 *
 ******************************************************************************/
VOID
Plx_sleep(
    U32 delay
    )
{
    LARGE_INTEGER liTime;


    /* Convert milliseconds to 100-nanosecond increments using:
     *
     *     1 ns  = 10 ^ -9 sec
     *   100 ns  = 10 ^ -7 sec (1 timer interval)
     *     1 ms  = 10 ^ -3 sec
     *     1 ms  = (1 timer interval) * 10^4
     */
    delay = delay * 10000;

    // Negative value means relative time, not absolute
    liTime =
        RtlConvertLongToLargeInteger(
            -(LONG)delay
            );

    KeDelayExecutionThread(
        KernelMode,
        TRUE,
        &liTime
        );
}




#if defined(DMA_SUPPORT)
/******************************************************************************
 *
 * Function   :  PlxBlockDmaTransferComplete
 *
 * Description:  Perform any necessary cleanup after a Block DMA transfer
 *
 * Note       :  This function is designed to perform cleanup during the
 *               ISR DPC function.  It will be called at DISPATCH_LEVEL.
 *
 ******************************************************************************/
PIRP
PlxBlockDmaTransferComplete(
    DEVICE_EXTENSION *pdx,
    U8                DmaIndex
    )
{
    PIRP pIrp;


    if (pdx->DmaInfo[DmaIndex].pIrp == NULL)
    {
        DebugPrintf(("No pending DMA IRP to complete\n"));
        return NULL;
    }

    KeAcquireSpinLockAtDpcLevel(
        &(pdx->Lock_DmaChannel)
        );

    // Save the current IRP
    pIrp = pdx->DmaInfo[DmaIndex].pIrp;

    // Clear the pending IRP
    pdx->DmaInfo[DmaIndex].pIrp = NULL;

    KeReleaseSpinLockFromDpcLevel(
        &(pdx->Lock_DmaChannel)
        );

    // Restore chip state
    PlxChipRestoreAfterDma(
        pdx,
        DmaIndex
        );

    return pIrp;
}




/******************************************************************************
 *
 * Function   :  PlxSglDmaTransferComplete
 *
 * Description:  Perform any necessary cleanup after an SGL DMA transfer
 *
 * Note       :  This function is designed to perform cleanup during the
 *               ISR DPC function.  It will be called at DISPATCH_LEVEL.
 *
 ******************************************************************************/
PIRP
PlxSglDmaTransferComplete(
    DEVICE_EXTENSION *pdx,
    U8                DmaIndex
    )
{
    PIRP pIrp;


    if (pdx->DmaInfo[DmaIndex].pIrp == NULL)
    {
        DebugPrintf(("No pending DMA IRP to complete\n"));
        return NULL;
    }

    KeAcquireSpinLockAtDpcLevel(
        &(pdx->Lock_DmaChannel)
        );

    // Free the SGL Descriptor buffer
    if (pdx->DmaInfo[DmaIndex].pSgl != NULL)
    {
        DriverBufferFree(
            pdx->DmaInfo[DmaIndex].pSgl
            );

        pdx->DmaInfo[DmaIndex].pSgl = NULL;
    }

    // Unlock the data buffer and free the MDL
    if (pdx->DmaInfo[DmaIndex].pMdl != NULL)
    {
        MmUnlockPages(
            pdx->DmaInfo[DmaIndex].pMdl
            );

        IoFreeMdl(
            pdx->DmaInfo[DmaIndex].pMdl
            );

        pdx->DmaInfo[DmaIndex].pMdl = NULL;
    }

    // Save the current IRP
    pIrp = pdx->DmaInfo[DmaIndex].pIrp;

    // Clear the pending IRP
    pdx->DmaInfo[DmaIndex].pIrp = NULL;

    KeReleaseSpinLockFromDpcLevel(
        &(pdx->Lock_DmaChannel)
        );

    // Restore chip state
    PlxChipRestoreAfterDma(
        pdx,
        DmaIndex
        );

    return pIrp;
}




/******************************************************************************
 *
 * Function   :  PlxLockBufferAndBuildSgl
 *
 * Description:  Lock a user buffer and build an SGL for it
 *
 ******************************************************************************/
PVOID
PlxLockBufferAndBuildSgl(
    DEVICE_EXTENSION     *pdx,
    U8                    DmaIndex,
    DMA_TRANSFER_ELEMENT *pDma
    )
{
    U32              *pages;
    U32              *pDescriptor;
    U32              *pFirstDescPhys;
    U32               Count;
    U32               LocalAddress;
    U32               currentElementLength;
    PMDL              pMdl;
    KIRQL             IrqL_Original;
    BOOLEAN           bFlag;
    PHYSICAL_ADDRESS  AddrPhysical;


    // Get parameters
    Count        = pDma->TransferCount;
    LocalAddress = pDma->LocalAddr;

    // Get the MDL for the User buffer to get the page list
    pMdl =
        IoAllocateMdl(
            (PVOID)pDma->u.UserVa,
            Count,
            FALSE,
            FALSE,
            NULL
            );

    if (pMdl == NULL)
    {
        DebugPrintf(("ERROR - Unable to allocate an MDL for the User buffer\n"));
        return NULL;
    }

    // Attempt to lock the user buffer into memory
    bFlag = FALSE;

    try
    {
        MmProbeAndLockPages(
            pMdl,
            UserMode,
            IoModifyAccess
            );
    }
    except(EXCEPTION_EXECUTE_HANDLER)
    {
        // Flag the exception
        bFlag = TRUE;
    }

    // Verify that the pages were locked
    if (bFlag)
    {
        DebugPrintf(("ERROR - Unable to lock pages\n"));
        IoFreeMdl(
            pMdl
            );
        return NULL;
    }

    // Allocate a 16-byte aligned buffer for the SGL descriptors
    pDescriptor =
        DriverBufferMalloc(
            16 * ((pMdl->Size - sizeof(MDL)) / sizeof(U32))
            );

    if (pDescriptor == NULL)
    {
        DebugPrintf(("ERROR - Unable to allocate SGL buffer\n"));

        MmUnlockPages(
            pMdl
            );

        IoFreeMdl(
            pMdl
            );

        return NULL;
    }

    // Get Physical Address of first descriptor
    AddrPhysical =
        MmGetPhysicalAddress(
            pDescriptor
            );

    pFirstDescPhys = (U32 *)AddrPhysical.u.LowPart;

    // Save MDL & SGL addresses for deallocation after the DMA transfer
    KeAcquireSpinLock(
        &(pdx->Lock_DmaChannel),
        &IrqL_Original
        );

    pdx->DmaInfo[DmaIndex].pMdl = pMdl;
    pdx->DmaInfo[DmaIndex].pSgl = pDescriptor;

    KeReleaseSpinLock(
        &(pdx->Lock_DmaChannel),
        IrqL_Original
        );

    // Get the physical pages, which are provided after the MDL
    pages = (U32 *)(((U32)pMdl) + sizeof(MDL));

    // Check if the Local address should remain constant
    bFlag = pdx->DmaInfo[DmaIndex].bLocalAddrConstant;

    // Build the first SGL descriptor
    *(pDescriptor + SGL_DESC_IDX_PCI_ADDR) = (*pages << PAGE_SHIFT) + pMdl->ByteOffset;
    *(pDescriptor + SGL_DESC_IDX_LOC_ADDR) = LocalAddress;

    // Check if only 1 page is needed
    if (Count < (PAGE_SIZE - pMdl->ByteOffset))
    {
        // Set the count
        *(pDescriptor + SGL_DESC_IDX_COUNT) = Count;

        // Set the last descriptor
        *(pDescriptor + SGL_DESC_IDX_NEXT_DESC) =
                        (pDma->LocalToPciDma << 3) | (1 << 1) | (1 << 0);
    }
    else
    {
        // The User buffer is in more than one page

        // Set current transfer count
        currentElementLength = PAGE_SIZE - pMdl->ByteOffset;

        // Set the Local addess
        if (bFlag == FALSE)
            LocalAddress += currentElementLength;

        // Decrement bytes remaining
        Count -= currentElementLength;

        // Build the remaining SGL descriptors
        while (Count != 0)
        {
            // Check if pages are consecutive to minimize the number of descriptors
            if ((*(pages + 1) - *pages) != 1)
            {
                // Not consecutive, terminate the current element and start new descriptor
                pages++;

                // Setup transfer count
                *(pDescriptor + SGL_DESC_IDX_COUNT) = currentElementLength;

                // Get Physical address of next descriptor
                AddrPhysical =
                    MmGetPhysicalAddress(
                        (PVOID)(((U32)pDescriptor) + (4 * sizeof(U32)))
                        );

                // Set the next descriptor field
                *(pDescriptor + SGL_DESC_IDX_NEXT_DESC) =
                                AddrPhysical.u.LowPart | (pDma->LocalToPciDma << 3) | (1 << 0);

                // Point to the next descriptor
                pDescriptor = (U32 *)(((U32)pDescriptor) + (4 * sizeof(U32)));

                // Write next PCI address
                *(pDescriptor + SGL_DESC_IDX_PCI_ADDR) = *pages << PAGE_SHIFT;

                // Write next Local address
                *(pDescriptor + SGL_DESC_IDX_LOC_ADDR) = LocalAddress;

                currentElementLength = 0;
            }
            else
            {
                // Point to the next page
                pages++;
            }

            // Check if it is the last descriptor
            if (Count <= PAGE_SIZE)
            {
                // Increment current count
                currentElementLength += Count;

                // Set count = 0 to terminate while() loop
                Count = 0;
            }
            else
            {
                // Set next IOP address
                if (bFlag == FALSE)
                    LocalAddress += PAGE_SIZE;

                // Decrement bytes remaining
                Count -= PAGE_SIZE;

                // Increment current count
                currentElementLength += PAGE_SIZE;
            }
        }

        // Write transfer count
        *(pDescriptor + SGL_DESC_IDX_COUNT) = currentElementLength;

        // Set the last descriptor
        *(pDescriptor + SGL_DESC_IDX_NEXT_DESC) =
                        (pDma->LocalToPciDma << 3) | (1 << 1) | (1 << 0);
    }

    // Maintain cache coherency
    DriverBufferFlush();

    KeFlushIoBuffers(
        pMdl,
        (BOOLEAN)pDma->LocalToPciDma,
        TRUE
        );

    // Return the physical address of the SGL
    return (PVOID)pFirstDescPhys;
}

#endif // DMA_SUPPORT




#if defined(WDM_DRIVER)
/******************************************************************************
 *
 * Function   :  OnRequestComplete
 *
 * Description:  Set an event when a lower driver complete an IRP.
 *
 ******************************************************************************/
NTSTATUS
OnRequestComplete(
    PDEVICE_OBJECT fdo,
    PIRP           pIrp,
    PKEVENT        pKEvent
    )
{
    KeSetEvent(
       pKEvent,
       0,
       FALSE
       );

    return STATUS_MORE_PROCESSING_REQUIRED;
}




/******************************************************************************
 *
 * Function   :  ForwardAndWait
 *
 * Description:  Forward request to lower level and await completion, used
 *               in PnP's IRP_MN_START_DEVICE
 *
 ******************************************************************************/
NTSTATUS
ForwardAndWait(
    PDEVICE_OBJECT fdo,
    PIRP           pIrp
    )
{
    KEVENT    event;
    NTSTATUS  status;


    /* 
       Initialize a kernel event object to use in waiting for the lower-level
       driver to finish processing the object. It's a little known fact that the
       kernel stack *can* be paged, but only while someone is waiting in user 
       mode for an event to finish. Since neither we nor a completion routine 
       can be in the forbidden state, it's okay to put the event object on the 
       stack.
    */
    KeInitializeEvent(
        &event,
        NotificationEvent,
        FALSE
        );

    IoCopyCurrentIrpStackLocationToNext(
        pIrp
        );

    IoSetCompletionRoutine(
        pIrp,
        (PIO_COMPLETION_ROUTINE) OnRequestComplete,
        (PVOID) &event,
        TRUE,
        TRUE,
        TRUE
        );

    status =
        IoCallDriver(
            ((DEVICE_EXTENSION *) fdo->DeviceExtension)->pLowerDeviceObject,
            pIrp
            );

    if (status == STATUS_PENDING)
    {
        // Wait for completion
        KeWaitForSingleObject(
            &event,
            Executive,
            KernelMode,
            FALSE,
            NULL
            );

        return pIrp->IoStatus.Status;
    }

    return status;
}




/******************************************************************************
 *
 * Function   :  GetBusSlotNumber
 *
 * Description:  Get the bus and slot number of a supported device.
 *               This function does not work for the slot number.
 *
 ******************************************************************************/
NTSTATUS
GetBusSlotNumber(
    PDEVICE_OBJECT    pdo,
    DEVICE_EXTENSION *pdx
    )
{
    U8       slot;
    U32      ResultLength;
    U32      PropertyBuffer;
    U32      RegValue;
    U32      RegisterSave;
    U32      RegisterToCompare;
    NTSTATUS status;


    ResultLength = 0;

    // Get the bus number
    status =
        IoGetDeviceProperty(
             pdo,
             DevicePropertyBusNumber,
             sizeof(U32),
             &PropertyBuffer,
             &ResultLength
             );

    if ( !NT_SUCCESS(status) )
    {
        DebugPrintf((
            "ERROR - IoGetDeviceProperty() unable to get bus number, code = %Xh\n",
            status
            ));

        return status;
    }

    // Verify that the function did write back a U32
    if (ResultLength != sizeof(U32))
    {
        DebugPrintf((
            "ERROR - IoGetDeviceProperty() invalid ResultLength (%d)\n",
            ResultLength
            ));

        return STATUS_UNSUCCESSFUL;
    }

    // Store the Bus number
    pdx->Device.BusNumber = (U8)PropertyBuffer;


    /**************************************************************************
    * Now attempt to get the slot number
    *
    * Note: The IoGetDeviceProperty() function is not implemented correctly in
    *       Windows 98.  The code has been left here in case this is fixed in a
    *       future release.  If the IoGetDeviceProperty() function is unsuccessful,
    *       a workaround is provided to retrieve the correct slot number.
    ***************************************************************************/

    ResultLength = 0;

    status =
        IoGetDeviceProperty(
            pdo,
            DevicePropertyAddress,
            sizeof(U32),
            &PropertyBuffer,
            &ResultLength
            );

    if ( NT_SUCCESS(status) )
    {
        if (ResultLength != sizeof(U32))
        {
            DebugPrintf((
                "ERROR - IoGetDeviceProperty() invalid ResultLength (%d)\n",
                ResultLength
                ));

            return STATUS_UNSUCCESSFUL;
        }

        pdx->Device.SlotNumber = (U8)(PropertyBuffer >> 16);

        DebugPrintf((
            "Device information - PCI bus %d, slot %d, function %d\n",
            pdx->Device.BusNumber,
            (PropertyBuffer >> 16),
            (PropertyBuffer & 0xffff)
            ));

        return STATUS_SUCCESS;
    }


    /****************************************************************
    * We were unable to get the slot number, so another method is
    * required.  Our workaround is to scan the PCI bus and find the
    * device whose BAR0 matches the current device.
    ****************************************************************/

    DebugPrintf(("WARNING - IoGetDeviceProperty() unable to get slot number, code = "));

    switch (status)
    {
        case STATUS_BUFFER_TOO_SMALL:
            DebugPrintf_NoInfo(("STATUS_BUFFER_TOO_SMALL (req=%d bytes)\n", ResultLength));
            break;

        case STATUS_NOT_IMPLEMENTED:
            DebugPrintf_NoInfo(("STATUS_NOT_IMPLEMENTED\n"));
            break;

        case STATUS_NOT_FOUND:
            DebugPrintf_NoInfo(("STATUS_NOT_FOUND\n"));
            break;

        default:
            DebugPrintf_NoInfo(("%08xh\n", status));
            break;
    }

    DebugPrintf(("NOTE: Implementing workaround to get Slot number\n"));

    // Get BAR 0 value        
    PLX_PCI_REG_READ(
        pdx,
        CFG_BAR0,
        &RegisterToCompare
        );

    /***************************************************************
     * Scanning the PCI bus involves using a back-door method which
     * accesses I/O ports directly to perform PCI configuration
     * cycles.  The PLX unsupported PCI register calls are used here.
     **************************************************************/

    // Scan the PCI bus to find our device
    for (slot = 0; slot < MAX_PCI_DEV; slot++)
    {
        // Read the BAR register
        RegValue =
            PlxPciRegisterRead_Unsupported(
                pdx,
                (U8)pdx->Device.BusNumber,
                slot,
                CFG_BAR0,
                NULL
                );

        // Compare with our device
        if (RegValue == RegisterToCompare)
        {
            pdx->Device.SlotNumber = slot;

            DebugPrintf((
                "Workaround successful, device information - PCI bus %d, slot %d, function 0\n",
                pdx->Device.BusNumber,
                slot
                ));

            return STATUS_SUCCESS;
        }
    }

    DebugPrintf(("ERROR - Unable to implement workaround to get Slot number\n"));

    return STATUS_UNSUCCESSFUL;
}

#endif // WDM_DRIVER




#if defined(NT_DRIVER)
/******************************************************************************
 *
 * Function   :  IsSupportedDevice
 *
 * Description:  Determine if device is supported by the driver
 *
 ******************************************************************************/
BOOLEAN
IsSupportedDevice(
    U32                   DeviceVendorId,
    REGISTRY_INFORMATION *pRegistryInfo
    )
{
    U8 i;


    // Compare with list of Valid IDs
    for (i=0; i<pRegistryInfo->IdListSize; i++)
    {
        if (DeviceVendorId == pRegistryInfo->ValidIdList[i])
            return TRUE;
    }

    return FALSE;
}

#endif // NT_DRIVER
