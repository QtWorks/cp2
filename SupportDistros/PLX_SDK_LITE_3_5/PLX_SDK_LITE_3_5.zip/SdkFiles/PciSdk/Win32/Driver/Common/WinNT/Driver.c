/*******************************************************************************
 * Copyright (c) 2002 PLX Technology, Inc.
 *
 * PLX Technology Inc. licenses this software under specific terms and
 * conditions.  Use of any of the software or derviatives thereof in any
 * product without a PLX Technology chip is strictly prohibited.
 *
 * PLX Technology, Inc. provides this software AS IS, WITHOUT ANY WARRANTY,
 * EXPRESS OR IMPLIED, INCLUDING, WITHOUT LIMITATION, ANY WARRANTY OF
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  PLX makes no guarantee
 * or representations regarding the use of, or the results of the use of,
 * the software and documentation in terms of correctness, accuracy,
 * reliability, currentness, or otherwise; and you rely on the software,
 * documentation and results solely at your own risk.
 *
 * IN NO EVENT SHALL PLX BE LIABLE FOR ANY LOSS OF USE, LOSS OF BUSINESS,
 * LOSS OF PROFITS, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES
 * OF ANY KIND.  IN NO EVENT SHALL PLX'S TOTAL LIABILITY EXCEED THE SUM
 * PAID TO PLX FOR THE PRODUCT LICENSED HEREUNDER.
 *
 ******************************************************************************/

/******************************************************************************
 *
 * File Name:
 *
 *      Driver.c
 *
 * Description:
 *
 *      This file initializes the necessary system resources for
 *      for the PLX device.
 *
 * Revision History:
 *
 *      04-31-02 : PCI SDK v3.50
 *
 *****************************************************************************/


#include <stdio.h>
#include "CommonApi.h"
#include "Driver.h"
#include "Dispatch.h"
#include "GlobalVars.h"
#include "Messages.h"
#include "PlxInterrupt.h"
#include "SupportFunc.h"

#if defined(DMA_SUPPORT)
    #include "Buffer.h"
#endif

#if defined(WDM_DRIVER)
    #include "PciSupport.h"
    #include "PlugPlay.h"
    #include "Power.h"
#endif


#if defined(ALLOC_PRAGMA) && !defined(PLX_DEBUG)
    #pragma alloc_text(INIT, DriverEntry)
#endif




/******************************************************************************
 *
 * Function   :  DriverEntry
 *
 * Description:  Entry point for the driver.
 *
 ******************************************************************************/
NTSTATUS
DriverEntry(
    PDRIVER_OBJECT  pDriverObject,
    PUNICODE_STRING pRegistryPath
    )
{
    NTSTATUS             status;
    PDEVICE_OBJECT       fdo;
    REGISTRY_INFORMATION RegistryInfo;


    DebugPrintf_NoInfo(("\n"));
    DebugPrintf(("<========================================================>\n"));
    DebugPrintf((
        "PLX Windows Device Driver - built on %s %s\n",
        __DATE__, __TIME__
        ));

    DebugPrintf(("Supports Windows NT v4.0\n"));

    // Set flag to note that this is not a WDM driver
    IsDriverWdm = FALSE;

    DebugPrintf(("Device Registry path = \"%ws\"\n", pRegistryPath->Buffer));

    // Get configuration information from registry
    PlxRegistryInformationGet(
        pRegistryPath,
        &RegistryInfo
        );

    // Fill in the appropriate dispatch handlers
    pDriverObject->DriverUnload                         = DriverUnload;
    pDriverObject->MajorFunction[IRP_MJ_CREATE]         = Dispatch_Create;
    pDriverObject->MajorFunction[IRP_MJ_CLOSE]          = Dispatch_Close;
    pDriverObject->MajorFunction[IRP_MJ_READ]           = Dispatch_Read;
    pDriverObject->MajorFunction[IRP_MJ_WRITE]          = Dispatch_Write;
    pDriverObject->MajorFunction[IRP_MJ_CLEANUP]        = Dispatch_Cleanup;
    pDriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL] = Dispatch_IoControl;

    status =
        PlxPciBusScan(
            pDriverObject,
            &RegistryInfo
            );

    if ( !NT_SUCCESS(status) )
    {
        DebugPrintf(("ERROR - Unable to find any valid PLX devices\n"));

        DriverUnload(
            pDriverObject
            );

        return STATUS_SUCCESS;
    }

    // Set requested size
    Gbl_CommonBuffer.PciMem.Size = RegistryInfo.CommonBufferSize;

    // Allocate common buffer
    PlxPciPhysicalMemoryAllocate(
        NULL,                   // No device to assign buffer to
        &(Gbl_CommonBuffer.PciMem),
        TRUE,                   // Smaller buffer is ok
        pDriverObject           // Assign Driver object as owner
        );

#if defined(DMA_SUPPORT)
    if (RegistryInfo.MaxSglTransferSize != 0)
    {
        // Allocate a buffer for SGL descriptors
        if (DriverBufferInit(
                48 * ((RegistryInfo.MaxSglTransferSize >> PAGE_SHIFT) + 3)
                ))
        {
            DebugPrintf(("Allocated SGL descriptor buffer to support "));
            if (RegistryInfo.MaxSglTransferSize >= (1 << 10))
                DebugPrintf_NoInfo(("%d Kb transfers\n", RegistryInfo.MaxSglTransferSize >> 10));
            else
                DebugPrintf_NoInfo(("%d Byte transfers\n", RegistryInfo.MaxSglTransferSize));
        }
        else
            DebugPrintf(("ERROR - SGL descriptor buffer allocation failed\n"));
    }
#endif  // DMA_SUPPORT

    // Traverse the list of Devices and start each one
    fdo = pDriverObject->DeviceObject;

    while (fdo != NULL)
    {
        AssignDeviceResources(
            pDriverObject,
            fdo,
            pRegistryPath
            );

        fdo = fdo->NextDevice;
    }

    return STATUS_SUCCESS;
}




/******************************************************************************
 *
 * Function   :  DriverUnload
 *
 * Description:  Unload the driver.
 *
 ******************************************************************************/
VOID
DriverUnload(
    PDRIVER_OBJECT pDriverObject
    )
{
    PDEVICE_OBJECT fdo;
    PDEVICE_OBJECT pNext;


    DebugPrintf_NoInfo(("\n"));
    DebugPrintf(("Unloading Driver...\n"));

    // Release common buffer
    if (Gbl_CommonBuffer.PciMem.PhysicalAddr != (U32)NULL)
    {
        DebugPrintf((
            "De-allocating Common Buffer (%d Kb)...\n",
            (Gbl_CommonBuffer.PciMem.Size >> 10)
            ));

        // Free the MDL
        if (Gbl_CommonBuffer.pMdl != NULL)
        {
            IoFreeMdl(
                Gbl_CommonBuffer.pMdl
                );

            Gbl_CommonBuffer.pMdl = NULL;
        }

        // Release the buffer
        if (Gbl_CommonBuffer.pKernelVa != NULL)
        {
            MmFreeContiguousMemory(
                Gbl_CommonBuffer.pKernelVa
                );

            Gbl_CommonBuffer.pKernelVa = NULL;
        }
    }

#if defined(DMA_SUPPORT)
    DebugPrintf(("De-allocating SGL descriptor buffer...\n"));
    DriverBufferTerminate();
#endif

    fdo = pDriverObject->DeviceObject;

    while (fdo != NULL)
    {
        // Store next device pointer
        pNext = fdo->NextDevice;

        // Stop device and release its resources
        StopDevice(
            fdo
            );

        // Delete the device & remove from device list
        RemoveDevice(
            fdo
            );

        // Jump to next device object
        fdo = pNext;
    }

    DebugPrintf(("Driver unloaded\n"));
}




/******************************************************************************
 *
 * Function   :  AddDevice
 *
 * Description:  Add a new functional device object for a physical one
 *
 ******************************************************************************/
NTSTATUS
AddDevice(
    PDRIVER_OBJECT   pDriverObject,
    DEVICE_LOCATION *pDeviceInfo
    )
{
    U8                i;
    WCHAR             DeviceName[PLX_MAX_NAME_LENGTH];
    WCHAR             DeviceLinkName[PLX_MAX_NAME_LENGTH];
    NTSTATUS          status;
    UNICODE_STRING    DeviceName_Unicode;
    UNICODE_STRING    DeviceLinkName_Unicode;
    PDEVICE_OBJECT    fdo;
    DEVICE_EXTENSION *pdx;


    // Build a device name and attempt to create it
    for (i=0; i < 20; i++)
    {
        swprintf(
            DeviceName,
            L"\\Device\\" PLX_DRIVER_NAME_UNICODE L"-%d",
            i
            );

        RtlInitUnicodeString(
            &DeviceName_Unicode,
            DeviceName
            );

        // Create the device object
        status =
            IoCreateDevice(
                pDriverObject,
                sizeof(DEVICE_EXTENSION),
                &DeviceName_Unicode,
                FILE_DEVICE_UNKNOWN,
                0,
                FALSE,            // Shared by applications
                &fdo
                );

        // IoCreateDevice() will fail if the same object already exists
        if (NT_SUCCESS(status))
        {
            break;
        }
    }

    // Check if the creation succeeded
    if ( !NT_SUCCESS(status) )
    {
        DebugPrintf(("ERROR - Unable to create Device\n"));
        return status;
    }

    DebugPrintf((
        "Created Device (%ws)...\n",
        DeviceName
        ));

    // Link a Win32 name for user applications
    swprintf(
        DeviceLinkName,
        L"\\DosDevices\\" PLX_DRIVER_NAME_UNICODE L"-%d",
        i
        );

    RtlInitUnicodeString(
        &DeviceLinkName_Unicode,
        DeviceLinkName
        );

    DebugPrintf((
        "Creating Win32 symbolic link (%ws)...\n",
        DeviceLinkName
        ));

    status =
        IoCreateSymbolicLink(
            &DeviceLinkName_Unicode,
            &DeviceName_Unicode
            );

    if ( !NT_SUCCESS(status) )
    {
        DebugPrintf(("WARNING - Unable to create symbolic link for Win32 Apps\n"));
        swprintf(DeviceLinkName, L"");
    }

    // Initialize the device extension
    pdx = fdo->DeviceExtension;

    RtlZeroMemory(
        pdx,
        sizeof(DEVICE_EXTENSION)
        );

    pdx->pDeviceObject = fdo;
    pdx->Power         = D0;

    pdx->Device.BusNumber  = pDeviceInfo->BusNumber;
    pdx->Device.SlotNumber = pDeviceInfo->SlotNumber;
    pdx->Device.DeviceId   = pDeviceInfo->DeviceId;
    pdx->Device.VendorId   = pDeviceInfo->VendorId;

    sprintf(
        pdx->Device.SerialNumber,
        PLX_DRIVER_NAME "-%d",
        i
        );

    wcscpy(
        pdx->LinkName,
        DeviceLinkName
        );

    // Initialize PCI BAR variables
    for (i = 0 ; i < PCI_NUM_BARS; i++)
    {
        pdx->PciBar[i].pVa               = NULL;
        pdx->PciBar[i].Physical.QuadPart = (U32)NULL;
        pdx->PciBar[i].Size              = 0;
        pdx->PciBar[i].IsIoMapped        = FALSE;
        pdx->PciBar[i].pMdl              = NULL;

        InitializeListHead(
            &(pdx->PciBar[i].List_Mappings)
            );

        KeInitializeSpinLock(
            &(pdx->PciBar[i].Lock_MappingsList)
            );
    }

    KeInitializeSpinLock(
        &(pdx->Lock_HwAccess)
        );

    InitializeListHead(
        &(pdx->List_InterruptWait)
        );

    KeInitializeSpinLock(
        &(pdx->Lock_InterruptWaitList)
        );

    InitializeListHead(
        &(pdx->List_PhysicalMem)
        );

    KeInitializeSpinLock(
        &(pdx->Lock_PhysicalMemList)
        );

    InitializeListHead(
        &(pdx->List_BarMappings)
        );

    KeInitializeSpinLock(
        &(pdx->Lock_BarMappingsList)
        );

    ExInitializeFastMutex(
        &(pdx->DispatchMutex)
        );

    // Initialize the interrupt DPC
    KeInitializeDpc(
        &(pdx->DpcForIsr),
        DpcForIsr,
        pdx
        );

#if defined(DMA_SUPPORT)
    // Initialize DMA management variables
    for (i = 0 ; i < NUMBER_OF_DMA_CHANNELS; i++)
    { 
        pdx->DmaInfo[i].state              = DmaStateClosed;
        pdx->DmaInfo[i].bLocalAddrConstant = FALSE;
    }

    KeInitializeSpinLock(
        &(pdx->Lock_DmaChannel)
        );
#endif  // DMA_SUPPORT

    // Indicate the I/O Manager buffer management method
    fdo->Flags |= DO_BUFFERED_IO;

    // Manually clear the Device Initialzing flag
    fdo->Flags &= ~DO_DEVICE_INITIALIZING;

    return STATUS_SUCCESS;
}




/******************************************************************************
 *
 * Function   :  RemoveDevice
 *
 * Description:  Remove a functional device object
 *
 ******************************************************************************/
VOID
RemoveDevice(
    PDEVICE_OBJECT fdo
    )
{
    NTSTATUS           status;
    UNICODE_STRING     DeviceLinkName_Unicode;
    DEVICE_EXTENSION  *pdx;


    pdx = fdo->DeviceExtension;

    // Remove Win32 link name
    if (wcslen(pdx->LinkName) != 0)
    {
        DebugPrintf((
            "Removing Win32 link (%ws)\n",
            pdx->LinkName
            ));

        RtlInitUnicodeString(
            &DeviceLinkName_Unicode,
            pdx->LinkName
            );

        status =
            IoDeleteSymbolicLink(
                &DeviceLinkName_Unicode
                );

        if ( !NT_SUCCESS(status) )
            DebugPrintf(("WARNING - Unable to remove Win32 link\n"));
    }

    DebugPrintf(("Deleting device object...\n"));

    // Delete the functional device object
    IoDeleteDevice(
        fdo
        );
}




/******************************************************************************
 *
 * Function   :  StartDevice
 *
 * Description:  Start a device
 *
 ******************************************************************************/
NTSTATUS
StartDevice(
    PDEVICE_OBJECT            fdo,
    PCM_PARTIAL_RESOURCE_LIST ResourceListRaw,
    PCM_PARTIAL_RESOURCE_LIST ResourceList
    )
{
    U8                               i;
    U8                               BarIndex;
    U32                              vector;
    U32                              addressSpace;
    KIRQL                            IrqL;
    BOOLEAN                          intPresent;
    NTSTATUS                         status;
    KAFFINITY                        affinity;
    KINTERRUPT_MODE                  mode;
    PHYSICAL_ADDRESS                 AddressTranslated;
    DEVICE_EXTENSION                *pdx;
    PCI_COMMON_CONFIG                pciRegs;
    PCM_PARTIAL_RESOURCE_DESCRIPTOR  ResourceRaw;


    pdx         = fdo->DeviceExtension;
    intPresent  = FALSE;
    ResourceRaw = ResourceListRaw->PartialDescriptors;

    // Get the PCI base addresses
    HalGetBusData(
        PCIConfiguration,
        pdx->Device.BusNumber,
        pdx->Device.SlotNumber,
        &pciRegs,
        sizeof(PCI_COMMON_CONFIG)
        );

    DebugPrintf((
        "Resource list contains %d descriptors\n",
        ResourceListRaw->Count
        ));

    for (i = 0; i < ResourceListRaw->Count; ++i, ++ResourceRaw)
    {
        DebugPrintf_NoInfo(("            Resource %02d\n", i));

        switch (ResourceRaw->Type)
        {
            case CmResourceTypeInterrupt:
                intPresent = TRUE;

                // Translate the interrupt information to a kernel value
                vector =
                    HalGetInterruptVector(
                        PCIBus,
                        pdx->Device.BusNumber,
                        ResourceRaw->u.Interrupt.Level,
                        ResourceRaw->u.Interrupt.Vector,
                        &IrqL,
                        &affinity
                        );

                DebugPrintf_NoInfo((
                    "              Type    : Interrupt\n"
                    "              Vector  : 0x%02x        (Translated = 0x%02x)\n"
                    "              IRQL    : 0x%02x        (Translated = 0x%02x)\n"
                    "              Affinity: 0x%08x  (Translated = 0x%08x)\n",
                    ResourceRaw->u.Interrupt.Vector, vector,
                    ResourceRaw->u.Interrupt.Level, IrqL,
                    ResourceRaw->u.Interrupt.Affinity, affinity
                    ));

                if (ResourceRaw->Flags == CM_RESOURCE_INTERRUPT_LATCHED)
                {
                    mode = Latched;
                    DebugPrintf_NoInfo(("              Mode    : Latched\n"));
                }
                else
                {
                    mode = LevelSensitive;
                    DebugPrintf_NoInfo(("              Mode    : Level Sensitive\n"));
                }
                break;

            case CmResourceTypePort:
                addressSpace = 0x01;                          // Address is I/O mapped
                HalTranslateBusAddress(
                    PCIBus,
                    pdx->Device.BusNumber,
                    ResourceRaw->u.Port.Start,
                    &addressSpace,
                    &AddressTranslated
                    );

                DebugPrintf_NoInfo((
                    "              Type     : I/O Port\n"
                    "              Address  : 0x%08x  (Translated = 0x%08x)\n"
                    "              Size     : 0x%08x  ",
                    ResourceRaw->u.Port.Start.u.LowPart,
                    AddressTranslated.u.LowPart,
                    ResourceRaw->u.Port.Length
                    ));

                if (ResourceRaw->u.Port.Length >= (1 << 10))
                {
                    DebugPrintf_NoInfo((
                        "(%d Kb)\n",
                        ResourceRaw->u.Port.Length >> 10
                        ));
                }
                else
                {
                    DebugPrintf_NoInfo((
                        "(%d Bytes)\n",
                        ResourceRaw->u.Port.Length
                        ));
                }

                BarIndex =
                    GetBarIndex(
                        ResourceRaw->u.Port.Start,
                        &pciRegs
                        );

                if (BarIndex != (U8)-1)
                {
                    pdx->PciBar[BarIndex].Physical = ResourceRaw->u.Port.Start;
                    pdx->PciBar[BarIndex].Size     = ResourceRaw->u.Port.Length;

                    // Check if we need to map (usually on RISC platforms)
                    if (ResourceRaw->Flags & CM_RESOURCE_PORT_MEMORY)
                    {
                        pdx->PciBar[BarIndex].IsIoMapped = FALSE;

                        DebugPrintf_NoInfo(("              Kernel VA: "));

                        status =
                            PlxPciBarResourceMap(
                                pdx,
                                BarIndex
                                );

                        if ( NT_SUCCESS(status) )
                        {
                            DebugPrintf_NoInfo(("0x%08x\n", pdx->PciBar[BarIndex].pVa));
                        }
                        else
                        {
                            DebugPrintf_NoInfo((
                                "ERROR - Unable to map 0x%08x ==> Kernel VA\n",
                                ResourceRaw->u.Port.Start.u.LowPart
                                ));
                        }
                    }
                    else
                    {
                        pdx->PciBar[BarIndex].pVa        = NULL;
                        pdx->PciBar[BarIndex].IsIoMapped = TRUE;
                    }
                }
                break;

            case CmResourceTypeMemory:
                // Now translate address to a kernel address
                addressSpace = 0x00;                     // Address is memory mapped
                HalTranslateBusAddress(
                    PCIBus,
                    pdx->Device.BusNumber,
                    ResourceRaw->u.Memory.Start,
                    &addressSpace,
                    &AddressTranslated
                    );

                DebugPrintf_NoInfo((
                    "              Type     : Memory Space\n"
                    "              Address  : 0x%08x  (Translated = 0x%08x)\n"
                    "              Size     : 0x%08x  ",
                    ResourceRaw->u.Memory.Start.u.LowPart,
                    AddressTranslated.u.LowPart,
                    ResourceRaw->u.Memory.Length
                    ));

                if (ResourceRaw->u.Memory.Length >= (1 << 10))
                {
                    DebugPrintf_NoInfo((
                        "(%d Kb)\n",
                        ResourceRaw->u.Memory.Length >> 10
                        ));
                }
                else
                {
                    DebugPrintf_NoInfo((
                        "(%d Bytes)\n",
                        ResourceRaw->u.Memory.Length
                        ));
                }

                BarIndex =
                    GetBarIndex(
                        ResourceRaw->u.Memory.Start,
                        &pciRegs
                        );

                if (BarIndex != (U8)-1)
                {
                    DebugPrintf_NoInfo(("              Kernel VA: "));

                    // Record resources
                    pdx->PciBar[BarIndex].Physical   = ResourceRaw->u.Memory.Start;
                    pdx->PciBar[BarIndex].Size       = ResourceRaw->u.Memory.Length;
                    pdx->PciBar[BarIndex].IsIoMapped = FALSE;

                    status =
                        PlxPciBarResourceMap(
                            pdx,
                            BarIndex
                            );

                    if ( NT_SUCCESS(status) )
                    {
                        DebugPrintf_NoInfo(("0x%08x\n", pdx->PciBar[BarIndex].pVa));
                    }
                    else
                    {
                        DebugPrintf((
                            "ERROR - Unable to map 0x%08x ==> Kernel VA\n",
                            ResourceRaw->u.Memory.Start.u.LowPart
                            ));

                        // PCI BAR 0 is required for register access
                        if (BarIndex == 0)
                        {
                            DebugPrintf(("ERROR - BAR 0 mapping is required\n"));
                            return STATUS_INSUFFICIENT_RESOURCES;
                        }
                    }
                }
                break;

            case CmResourceTypeNull:
                DebugPrintf_NoInfo(("              Type: Null (unsupported)\n"));
                break;

            case CmResourceTypeDma:
                DebugPrintf_NoInfo(("              Type: DMA (unsupported)\n"));
                break;

            case CmResourceTypeDeviceSpecific:
                DebugPrintf_NoInfo(("              Type: Device Specific (unsupported)\n"));
                break;

            default:
                DebugPrintf_NoInfo(("              Type: ?Unknown Resource Type?\n"));
                break;
        }
    }

    // Make sure BAR 0 exists or the device can't be started
    if (pdx->PciBar[0].pVa == NULL)
    {
        DebugPrintf(("ERROR - BAR 0 address not configured, unable to load driver\n"));
        return STATUS_INSUFFICIENT_RESOURCES;
    }

    if (intPresent)
    {
        // Disable the PCI interrupt
        PlxChipPciInterruptDisable(
            pdx
            );

        status =
            IoConnectInterrupt(
                &pdx->pInterruptObject,
                OnInterrupt,
                pdx,
                NULL,
                vector,
                IrqL,
                IrqL,
                mode,
                TRUE,
                affinity,
                FALSE
                );

        if ( !NT_SUCCESS(status) )
        {
            DebugPrintf((
                "ERROR - IoConnectInterrupt() failed, status = 0x%08x\n",
                status
                ));

            PlxReportEvent(
                PLX_LOG_INVALID_INTERRUPT_CONNECTION,
                (PVOID)fdo
                );

            pdx->pInterruptObject = NULL;
        }
        else
        {
            DebugPrintf(("Connected to interrupt vector\n"));

            // Re-enable the PCI Interrupt
            KeSynchronizeExecution(
                pdx->pInterruptObject,
                PlxChipPciInterruptEnable,
                pdx
                );
        }
    }
    else
    {
        DebugPrintf(("No interrupt found\n"));
        pdx->pInterruptObject = NULL;
    }

#if defined(DMA_SUPPORT)
    //  Record Common buffer info into Mailbox registers

    // Write the Physical Address
    PLX_REG_WRITE(
        pdx,
        COMMON_BUFF_MBOX_ADDRESS,
        Gbl_CommonBuffer.PciMem.PhysicalAddr
        );

    // Write the Size
    PLX_REG_WRITE(
        pdx,
        COMMON_BUFF_MBOX_SIZE,
        Gbl_CommonBuffer.PciMem.Size
        );
#endif  // DMA_SUPPORT

    return STATUS_SUCCESS;
}




/******************************************************************************
 *
 * Function   :  StopDevice
 *
 * Description:  Stop a device
 *
 ******************************************************************************/
VOID
StopDevice(
    PDEVICE_OBJECT fdo
    )
{
    DEVICE_EXTENSION *pdx;


    pdx = fdo->DeviceExtension;

    // Free all interrupt resources
    if (pdx->pInterruptObject != NULL)
    {
        // Disable the PCI interrupt
        KeSynchronizeExecution(
            pdx->pInterruptObject,
            (PKSYNCHRONIZE_ROUTINE)PlxChipPciInterruptDisable,
            (PVOID)pdx
            );

        // Remove the ISR
        IoDisconnectInterrupt(
            pdx->pInterruptObject
            );

        pdx->pInterruptObject = NULL;
    }

    // Unmap I/O regions from kernel space (No local register access after this)
    PlxPciBarResourcesUnmap(
        pdx
        );
}




/******************************************************************************
 *
 * Function   :  PlxPciBusScan
 *
 * Description:  Scan the PCI Bus for PLX devices
 *
 ******************************************************************************/
NTSTATUS
PlxPciBusScan(
    PDRIVER_OBJECT        pDriverObject,
    REGISTRY_INFORMATION *pRegistryInfo
    )
{
    U8              bus;
    U8              slot;
    U8              MaxPciBus;
    U32             DevVenID;
    ULONG           rc;
    BOOLEAN         DeviceFound;
    NTSTATUS        status;
    DEVICE_LOCATION DeviceInfo;


    DebugPrintf(("Scanning PCI bus for supported devices...\n"));

    bus         = 0;
    MaxPciBus   = PCI_MAX_BUSES_TO_SCAN;
    DeviceFound = FALSE;

    while (1)
    {
        slot = 0;

        do
        {
            // Get the Device/Vendor ID of this device
            rc =
                HalGetBusData(
                    PCIConfiguration,
                    bus,
                    slot,
                    &DevVenID,
                    sizeof(U32)
                    );

            if (rc == 0)
            {
               // Specified Bus does not exist, skip scanning it
            }
            else if (rc != 2)
            {
                DebugPrintf((
                    "Scanning - %.4x %.4x  [Bus %.2x  Slot %.2x]\n",
                    DevVenID >> 16, DevVenID & 0xffff, bus, slot
                    ));

                // Verify against registry list of supported devices
                if (IsSupportedDevice(
                        DevVenID,
                        pRegistryInfo
                        ) == TRUE)
                {
                    DebugPrintf(("Supported device found, adding device...\n"));

                    // Fill device structure with the PCI information.
                    DeviceInfo.VendorId   = (U16)(DevVenID & 0xffff);
                    DeviceInfo.DeviceId   = (U16)(DevVenID >> 16);
                    DeviceInfo.BusNumber  = bus;
                    DeviceInfo.SlotNumber = slot;

                    status =
                        AddDevice(
                            pDriverObject,
                            &DeviceInfo
                            );

                    if (NT_SUCCESS(status))
                    {
                        DeviceFound = TRUE;
                    }
                }
            }

            // Increment to next slot
            slot++;
        }
        while ((slot < PCI_MAX_DEVICES) && (rc != 0));

        // Increment to next bus
        bus++;

        if (bus == MaxPciBus)
        {
            if (DeviceFound == TRUE)
            {
                return STATUS_SUCCESS;
            }

            return STATUS_NOT_FOUND;
        }
    }
}




/******************************************************************************
 *
 * Function   :  AssignDeviceResources
 *
 * Description:  Get the resource list for a device and Start it
 *
 ******************************************************************************/
NTSTATUS
AssignDeviceResources(
    PDRIVER_OBJECT  pDriverObject,
    PDEVICE_OBJECT  fdo,
    UNICODE_STRING *pRegistryPath
    )
{
    NTSTATUS           status;
    DEVICE_EXTENSION  *pdx;
    PCM_RESOURCE_LIST  ResourceList;


    pdx = fdo->DeviceExtension;

    // Assign our resources using the HAL
    status =
        HalAssignSlotResources(
            pRegistryPath,
            NULL,
            pDriverObject,
            fdo,
            PCIBus,
            pdx->Device.BusNumber,
            pdx->Device.SlotNumber,
            &ResourceList
            );

    if ( !NT_SUCCESS(status) )
    {
        ErrorPrintf(("ERROR - HAL resources assignment failed\n"));
        return status;
    }

    DebugPrintf(("HAL assigned slot resources\n"));

    status =
        StartDevice(
            fdo,
            &(ResourceList->List[0].PartialResourceList),
            NULL
            );

    if ( !NT_SUCCESS(status) )
    {
        DebugPrintf(("ERROR - Unable to Start device\n"));

        ExFreePool(
            ResourceList
            );

        return status;
    }

    return STATUS_SUCCESS;
}
