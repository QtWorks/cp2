/*******************************************************************************
 * Copyright (c) 2002 PLX Technology, Inc.
 * 
 * PLX Technology Inc. licenses this software under specific terms and
 * conditions.  Use of any of the software or derviatives thereof in any
 * product without a PLX Technology chip is strictly prohibited. 
 * 
 * PLX Technology, Inc. provides this software AS IS, WITHANY WARRANTY,
 * EXPRESS OR IMPLIED, INCLUDING, WITHLIMITATION, ANY WARRANTY OF
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  PLX makes no guarantee
 * or representations regarding the use of, or the results of the use of,
 * the software and documentation in terms of correctness, accuracy,
 * reliability, currentness, or otherwise; and you rely on the software,
 * documentation and results solely at your own risk.
 * 
 * NO EVENT SHALL PLX BE LIABLE FOR ANY LOSS OF USE, LOSS OF BUSINESS,
 * LOSS OF PROFITS, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES
 * OF ANY KIND.  NO EVENT SHALL PLX'S TOTAL LIABILITY EXCEED THE SUM
 * PAID TO PLX FOR THE PRODUCT LICENSED HEREUNDER.
 * 
 *****************************************************************************/

/******************************************************************************
 *
 * File Name:
 *
 *     PlxApi.c
 *
 * Description:
 *
 *     This file contains all the PCI API functions.
 *
 * Revision:
 *
 *     04-31-02: PCI SDK v3.50
 *
 *****************************************************************************/

/******************************************************************************
 *
 * NOTES:
 *
 * For customers interested in modifying or understanding this file, it is
 * important to point out a few items.
 *
 * First, this file has been modified extensively from any previous SDK releases.
 * Most of the modifications come as a result of bug fixes in use of the
 * DeviceIoControl calls.  The most important of these is to always avoid
 * using NULL in the OVERLAPPED parameter.
 *
 * Unfortunately, the current PLX API has some flaws in its design which have
 * resulted in complex situations when the driver calls are asynchronous.  Some
 * of these calls include PlxIntrAttach, PlxDmaSglTransfer, etc.  In previous
 * versions of the DLL, the OVERLAPPED parameter in DeviceIoControl was declared
 * as a local variable.  This resulted in exceptions when the driver completed
 * the I/O request because the DLL had already exited the function, which
 * destroyed the OVERLAPPED structure.
 *
 * In order to maintain backward compatibility with the current PLX API, the
 * solutions to the problems became quite complex.  These involved the
 * maintainance of global variables and linked lists inside the DLL.  This is
 * obviously not the best solution.
 *
 * Most likely, a future SDK release will involve a re-design of the Host API
 * calls for two purposes.  One goal is to make the API OS-neutral by removing
 * any Windows-specific parameters, such as HANDLE.  The other goal is to possibly
 * add API functions which will better fit in the situations where asynchronous
 * calls are used.  For example, the allocation and deallocation of OVERLAPPED
 * structures may be moved to the application level, although the type of object
 * will be transparent to avoid Windows centric code.
 *
 * These changes have not yet been determined, but keep in mind that PLX is
 * aware of the issue and is considering a re-design of the API for a future SDK
 * release.  There are currently no details or time frame for the API changes.
 * The majority of the changes will be in parameter definitions, to minimize
 * the porting effort for customers wanting to upgrade.  Even if PLX re-designs
 * the API, customers can still use this version of the API, as it has been
 * working fine.
 *
 * Please do not contact PLX regarding these changes as there is nothing
 * definite at this time with respect to the scope of the changes, the time
 * frame, or even whether the changes will actually take place.
 *
 *****************************************************************************/


#include <stdio.h>
#include <malloc.h>
#include <memory.h>
#include <wtypes.h>
#include <winioctl.h>
#include "PlxApi.h"
#include "PlxIoctl.h"




/**********************************************
 *               Definitions
 *********************************************/
// API Version information
#define API_VERSION_MAJOR               3
#define API_VERSION_MINOR               5
#define API_VERSION_REVISION            0

#define MAX_DMA_TIMEOUT                 1000         // Max timeout in milliseconds for DMA transfer
#define MAX_DMA_CHANNELS                4            // Max number of DMA channels for a device

#define DRIVER_PATH                     "\\\\.\\"    // Path to drivers


// List of PLX drivers to search for
char *PlxDrivers[] = 
{
    "Pci9080",
    "Pci9054",
    "Pci480",
    "Pci9030",
    "Pci9050",
    "Pci9056",
    "Pci9656",
    "0"          // Must be last item to mark end of list
};


typedef struct _IO_NODE
{
    IOCTLDATA        IoBuffer;                   // The pending I/O buffer
    OVERLAPPED       Overlapped;                 // The pending Overlapped structure
    BOOLEAN          InUse;                      // Flag specifying whether the I/O is pending
    struct _IO_NODE *pNext;                      // Pointer to the next node in the list
} IO_NODE;


typedef struct _PCI_BAR_SPACE
{
    U32     va;                                  // Virtual address of space
    U32     size;                                // Size of mapped region
    U32     offset;                              // Actual starting offset from virtual base
    BOOLEAN bMapAttempted;                       // Flag to specify if mapping was attempted 
} PCI_BAR_SPACE;


typedef struct _DEVICE_NODE
{
    HANDLE               Handle;                 // Handle to the device driver
    DEVICE_LOCATION      Location;               // Device location
    PCI_BAR_SPACE        PciSpace[PCI_NUM_BARS]; // Virtual address mappings for the device
    PCI_MEMORY           PciMemory;              // Address of the common buffer
    IO_NODE             *pEventList;             // List of event handles
    IO_NODE             *pDmaList;               // List of DMA I/O buffers
    struct _DEVICE_NODE *pNext;                  // Pointer to next device in the list
} DEVICE_NODE;




/**********************************************
 *           In-line Macros
 *********************************************/
#define LockGlobals()            EnterCriticalSection(&GlobalDataLock)
#define UnlockGlobals()          LeaveCriticalSection(&GlobalDataLock)
#define IoPoolReleaseNode(pNode) ((pNode)->InUse = FALSE)

#define DmaIndex(DmaChannel)     (DmaChannel - IopChannel2)




/**********************************************
 *          Portability Macros
 *********************************************/
#define IoMessage(hdl, cmd, pBuff, Size, Ovl) \
    DeviceIoControl( \
        (hdl),       \
        (cmd),       \
        (pBuff),     \
        (Size),      \
        (pBuff),     \
        (Size),      \
        NULL,        \
        (Ovl)        \
        )




/**********************************************
 *               Globals
 *
 * Note: This data is global to the application
 *       that attaches to this library.  Each
 *       distinct application will have its
 *       own global data space.
 *********************************************/
static IO_NODE          *pApiIoPoolList;     // Pointer to the pool of allocated I/O nodes
static DEVICE_NODE      *pApiDeviceList;     // Pointer to list of open devices and their resources
static CRITICAL_SECTION  GlobalDataLock;     // Synchronization object for global data protection




/**********************************************
 *       Private Function Prototypes
 *********************************************/
IO_NODE *
IoPoolGetNode(
    VOID
    );

DEVICE_NODE *
DeviceListAdd(
    HANDLE           hDevice,
    DEVICE_LOCATION *pLocation
    );

BOOLEAN
DeviceListRemove(
    HANDLE hDevice
    );

DEVICE_NODE *
DeviceListFind(
    HANDLE hDevice
    );

IO_NODE *
IoListAdd(
    IO_NODE **pIoList,
    HANDLE    hEvent
    );

BOOLEAN
IoListRemove(
    IO_NODE **pIoList,
    IO_NODE  *pIoNodeToRemove
    );

VOID
IoListDestroy(
    IO_NODE **pIoList
    );

IO_NODE *
IoListFindByEventHandle(
    IO_NODE *pIoList,
    HANDLE   hEvent
    );

BOOLEAN
DmaListBuild(
    DEVICE_NODE *pDevice
    );

IO_NODE *
DmaListGetNode(
    DEVICE_NODE *pDevice,
    U8           index
    );




/**********************************************
 *            Public Functions
 *********************************************/

/*****************************************************************************
 *
 * Function   :  DllMain
 *
 * Description:  DllMain is called by Windows each time a process or
 *               thread attaches or detaches to/from this DLL.
 *
 *****************************************************************************/
BOOLEAN WINAPI
DllMain(
    HANDLE hInst, 
    U32    ReasonForCall,
    LPVOID lpReserved
    )
{
    // Added to prevent compiler warning
    if (hInst == INVALID_HANDLE_VALUE)
    {
    }

    if (lpReserved == NULL)
    {
    }

    switch (ReasonForCall)
    {
        case DLL_PROCESS_ATTACH:

            // Initialize device list
            pApiDeviceList = NULL;

            // Initialize the I/O Node Pool
            pApiIoPoolList = NULL;

            // Initialize the synchronization object for global data
            InitializeCriticalSection(
                &GlobalDataLock
                );
            break;

        case DLL_PROCESS_DETACH:

            // Cycle through device list and remove resources allocated
            while (pApiDeviceList != NULL)
            {
                // The close will deallocate all resources used by the device
                PlxPciDeviceClose(
                    pApiDeviceList->Handle
                    );
            }

            // Destroy the I/O Node pool
            IoListDestroy(
                &pApiIoPoolList
                );

            // Release the synchronization object
            DeleteCriticalSection(
                &GlobalDataLock
                );
            break;

        case DLL_THREAD_ATTACH:
            // No need to do anything when threads are attached
            break;

        case DLL_THREAD_DETACH:
            // No need to do anything when threads are detached
            break;

        default:
            break;
    }

    return TRUE;
}




/******************************************************************************
 *
 * Function   :  PlxSdkVersion
 *
 * Description:  Return the API Library version number
 *
 *****************************************************************************/
RETURN_CODE
PlxSdkVersion(
    U8 *VersionMajor,
    U8 *VersionMinor,
    U8 *VersionRevision
    )
{
    if ((VersionMajor    == NULL) ||
        (VersionMinor    == NULL) ||
        (VersionRevision == NULL))
    {
        return ApiNullParam;
    }

    *VersionMajor    = API_VERSION_MAJOR;
    *VersionMinor    = API_VERSION_MINOR;
    *VersionRevision = API_VERSION_REVISION;

    return ApiSuccess;
}




/******************************************************************************
 *
 * Function   :  PlxDriverVersion
 *
 * Description:  Return the driver version number
 *
 *****************************************************************************/
RETURN_CODE
PlxDriverVersion(
    HANDLE  hDevice,
    U8     *VersionMajor,
    U8     *VersionMinor,
    U8     *VersionRevision
    )
{
    IO_NODE *pIoNode;


    if ((VersionMajor    == NULL) ||
        (VersionMinor    == NULL) ||
        (VersionRevision == NULL))
    {
        return ApiNullParam;
    }

    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        return ApiInvalidHandle;
    }

    pIoNode = IoPoolGetNode();

    IoMessage(
        hDevice,
        PLX_IOCTL_DRIVER_VERSION,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    *VersionMajor    = (U8)((pIoNode->IoBuffer.u.MgmtData.value >> 16) & 0xFF);
    *VersionMinor    = (U8)((pIoNode->IoBuffer.u.MgmtData.value >>  8) & 0xFF);
    *VersionRevision = (U8)((pIoNode->IoBuffer.u.MgmtData.value >>  0) & 0xFF);

    IoPoolReleaseNode(
        pIoNode
        );

    return ApiSuccess;
}




/******************************************************************************
 *
 * Function   :  PlxChipTypeGet
 *
 * Description:  Get the PLX Chip type and revision
 *
 *****************************************************************************/
RETURN_CODE
PlxChipTypeGet(
    HANDLE  hDevice,
    U32    *pChipType,
    U8     *pRevision
    )
{
    IO_NODE *pIoNode;


    if ((pChipType == NULL) ||
        (pRevision == NULL))
    {
        return ApiNullParam;
    }

    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        return ApiInvalidHandle;
    }

    pIoNode = IoPoolGetNode();

    IoMessage(
        hDevice,
        PLX_IOCTL_CHIP_TYPE_GET,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    *pChipType = pIoNode->IoBuffer.u.MiscData.data[0];
    *pRevision = (U8)(pIoNode->IoBuffer.u.MiscData.data[1]);

    IoPoolReleaseNode(
        pIoNode
        );

    return ApiSuccess;
}




/******************************************************************************
 *
 * Function   :  PlxPciBoardReset
 *
 * Description:  Resets a PCI board using the software reset feature.
 *
 *****************************************************************************/
VOID
PlxPciBoardReset(
    HANDLE hDevice
    )
{
    IO_NODE *pIoNode;


    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        return;
    }

    pIoNode = IoPoolGetNode();

    IoMessage(
        hDevice,
        PLX_IOCTL_PCI_BOARD_RESET,
        NULL,
        0,
        &(pIoNode->Overlapped)
        );

    IoPoolReleaseNode(
        pIoNode
        );
}




/******************************************************************************
 *
 * Function   :  PlxPciPhysicalMemoryAllocate
 *
 * Description:  Allocate a physically contigous buffer for DMA operations
 *
 *****************************************************************************/
RETURN_CODE
PlxPciPhysicalMemoryAllocate(
    HANDLE      hDevice,
    PCI_MEMORY *pMemoryInfo,
    BOOLEAN     bSmallerOk
    )
{
    IO_NODE     *pIoNode;
    RETURN_CODE  rc;


    if (pMemoryInfo == NULL)
        return ApiNullParam;

    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        return ApiInvalidHandle;
    }

    pIoNode = IoPoolGetNode();

    pIoNode->IoBuffer.u.MiscData.data[0]     = (U32)bSmallerOk;
    pIoNode->IoBuffer.u.MiscData.u.PciMemory = *pMemoryInfo;

    IoMessage(
        hDevice,
        PLX_IOCTL_PHYSICAL_MEM_ALLOCATE,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    // Copy buffer information
    *pMemoryInfo = pIoNode->IoBuffer.u.MiscData.u.PciMemory;

    rc = pIoNode->IoBuffer.ReturnCode;

    IoPoolReleaseNode(
        pIoNode
        );

    return rc;
}




/******************************************************************************
 *
 * Function   :  PlxPciPhysicalMemoryFree
 *
 * Description:  Free a previously allocated physically contigous DMA buffer
 *
 *****************************************************************************/
RETURN_CODE
PlxPciPhysicalMemoryFree(
    HANDLE      hDevice,
    PCI_MEMORY *pMemoryInfo
    )
{
    IO_NODE     *pIoNode;
    RETURN_CODE  rc;


    if (pMemoryInfo == NULL)
        return ApiNullParam;

    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        return ApiInvalidHandle;
    }

    // Unmap from user space if previously mapped
    if (pMemoryInfo->UserAddr != (U32)NULL)
    {
        PlxPciPhysicalMemoryUnmap(
            hDevice,
            pMemoryInfo
            );
    }

    pIoNode = IoPoolGetNode();

    pIoNode->IoBuffer.u.MiscData.u.PciMemory = *pMemoryInfo;

    IoMessage(
        hDevice,
        PLX_IOCTL_PHYSICAL_MEM_FREE,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    // Clear buffer information
    pMemoryInfo->PhysicalAddr = (U32)NULL;
    pMemoryInfo->Size         = 0;

    rc = pIoNode->IoBuffer.ReturnCode;

    IoPoolReleaseNode(
        pIoNode
        );

    return rc;
}




/******************************************************************************
 *
 * Function   :  PlxPciPhysicalMemoryMap
 *
 * Description:  Maps a page-locked buffer into user virtual space
 *
 *****************************************************************************/
RETURN_CODE
PlxPciPhysicalMemoryMap(
    HANDLE      hDevice,
    PCI_MEMORY *pMemoryInfo
    )
{
    IO_NODE     *pIoNode;
    RETURN_CODE  rc;


    if (pMemoryInfo == NULL)
        return ApiNullParam;

    // Set default return value
    pMemoryInfo->UserAddr = (U32)NULL;

    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        return ApiInvalidHandle;
    }

    // Verify buffer object
    if ((pMemoryInfo->PhysicalAddr == (U32)NULL) ||
        (pMemoryInfo->Size         == 0))
    {
        return ApiInvalidData;
    }

    pIoNode = IoPoolGetNode();

    pIoNode->IoBuffer.u.MiscData.data[0]     = (U32)FALSE;   // Specify non-device memory
    pIoNode->IoBuffer.u.MiscData.u.PciMemory = *pMemoryInfo;

    IoMessage(
        hDevice,
        PLX_IOCTL_PHYSICAL_MEM_MAP,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    pMemoryInfo->UserAddr = pIoNode->IoBuffer.u.MiscData.u.PciMemory.UserAddr;

    rc = pIoNode->IoBuffer.ReturnCode;

    IoPoolReleaseNode(
        pIoNode
        );

    return rc;
}





/******************************************************************************
 *
 * Function   :  PlxPciPhysicalMemoryUnmap
 *
 * Description:  Unmaps a page-locked buffer from user virtual space
 *
 *****************************************************************************/
RETURN_CODE
PlxPciPhysicalMemoryUnmap(
    HANDLE      hDevice,
    PCI_MEMORY *pMemoryInfo
    )
{
    IO_NODE     *pIoNode;
    RETURN_CODE  rc;


    if (pMemoryInfo == NULL)
        return ApiNullParam;

    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        return ApiInvalidHandle;
    }

    // Verify buffer object
    if ((pMemoryInfo->PhysicalAddr == (U32)NULL) ||
        (pMemoryInfo->Size         == 0))
    {
        return ApiInvalidData;
    }

    pIoNode = IoPoolGetNode();

    pIoNode->IoBuffer.u.MiscData.u.PciMemory = *pMemoryInfo;

    IoMessage(
        hDevice,
        PLX_IOCTL_PHYSICAL_MEM_UNMAP,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    pMemoryInfo->UserAddr = pIoNode->IoBuffer.u.MiscData.u.PciMemory.UserAddr;

    rc = pIoNode->IoBuffer.ReturnCode;

    IoPoolReleaseNode(
        pIoNode
        );

    return rc;
}




/******************************************************************************
 *
 * Function   :  PlxCommonBufferGet
 *
 * Description:  Retrieves the common buffer information for a given device.
 *
 *****************************************************************************/
RETURN_CODE
PlxPciCommonBufferGet(
    HANDLE      hDevice,
    PCI_MEMORY *pMemoryInfo
    )
{
    RETURN_CODE rc;


    // Get buffer properties
    rc =
        PlxPciCommonBufferProperties(
            hDevice,
            pMemoryInfo
            );

    if (rc != ApiSuccess)
        return rc;

    // Map buffer into user virtual space
    rc =
        PlxPciCommonBufferMap(
            hDevice,
            (VOID*)&(pMemoryInfo->UserAddr)
            );

    return rc;
}




/******************************************************************************
 *
 * Function   :  PlxCommonBufferProperties
 *
 * Description:  Retrieves the common buffer properties for a given device
 *
 *****************************************************************************/
RETURN_CODE
PlxPciCommonBufferProperties(
    HANDLE      hDevice,
    PCI_MEMORY *pMemoryInfo
    )
{
    IO_NODE     *pIoNode;
    DEVICE_NODE *pDevice;


    if (pMemoryInfo == NULL)
        return ApiNullParam;

    // Verify the handle
    pDevice =
        DeviceListFind(
            hDevice
            );

    if (pDevice == NULL)
        return ApiInvalidHandle;

    // If we already have the information, just copy it
    if (pDevice->PciMemory.PhysicalAddr != (U32)NULL)
    {
        *pMemoryInfo = pDevice->PciMemory;

        return ApiSuccess;
    }

    pIoNode = IoPoolGetNode();

    IoMessage(
        hDevice,
        PLX_IOCTL_COMMON_BUFFER_PROPERTIES,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    pMemoryInfo->PhysicalAddr = pIoNode->IoBuffer.u.MiscData.u.PciMemory.PhysicalAddr;
    pMemoryInfo->Size         = pIoNode->IoBuffer.u.MiscData.u.PciMemory.Size;

    IoPoolReleaseNode(
        pIoNode
        );

    // Clear virtual address
    pMemoryInfo->UserAddr = (U32)NULL;

    LockGlobals();

    // Save the data for any future calls
    pDevice->PciMemory.PhysicalAddr = pMemoryInfo->PhysicalAddr;
    pDevice->PciMemory.Size         = pMemoryInfo->Size;

    UnlockGlobals();

    return ApiSuccess;
}




/******************************************************************************
 *
 * Function   :  PlxCommonBufferMap
 *
 * Description:  Maps the common buffer into user virtual space
 *
 *****************************************************************************/
RETURN_CODE
PlxPciCommonBufferMap(
    HANDLE  hDevice,
    VOID   *pVa
    )
{
    PCI_MEMORY   MemInfo;
    RETURN_CODE  rc;
    DEVICE_NODE *pDevice;


    if (pVa == NULL)
        return ApiNullParam;

    // Set default return value
    *(U32*)pVa = (U32)NULL;

    // Verify the handle
    pDevice =
        DeviceListFind(
            hDevice
            );

    if (pDevice == NULL)
        return ApiInvalidHandle;

    // If buffer was previously mapped, just copy it
    if (pDevice->PciMemory.UserAddr != (U32)NULL)
    {
        *(U32*)pVa = pDevice->PciMemory.UserAddr;

        return ApiSuccess;
    }

    // Check for valid common buffer info
    if (pDevice->PciMemory.PhysicalAddr == (U32)NULL)
    {
        // Get buffer properties
        rc =
            PlxPciCommonBufferProperties(
                hDevice,
                &MemInfo
                );

        if (rc != ApiSuccess)
            return rc;
    }
    else
    {
        // Copy buffer properties
        MemInfo = pDevice->PciMemory;
    }

    rc =
        PlxPciPhysicalMemoryMap(
            hDevice,
            &MemInfo
            );

    if (rc == ApiSuccess)
    {
        *(U32*)pVa = MemInfo.UserAddr;

        // Save the data for any future calls
        LockGlobals();

        pDevice->PciMemory.UserAddr = MemInfo.UserAddr;

        UnlockGlobals();
    }

    return rc;
}





/******************************************************************************
 *
 * Function   :  PlxCommonBufferUnmap
 *
 * Description:  Unmaps the common buffer from user virtual space
 *
 *****************************************************************************/
RETURN_CODE
PlxPciCommonBufferUnmap(
    HANDLE  hDevice,
    VOID   *pVa
    )
{
    PCI_MEMORY   MemInfo;
    RETURN_CODE  rc;
    DEVICE_NODE *pDevice;


    if (pVa == NULL)
        return ApiNullParam;

    if (*(U32*)pVa == (U32)NULL)
        return ApiInvalidAddress;

    // Verify the handle
    pDevice =
        DeviceListFind(
            hDevice
            );

    if (pDevice == NULL)
        return ApiInvalidHandle;

    // Verify virtual address
    if (pDevice->PciMemory.UserAddr != *(U32*)pVa)
    {
        return ApiInvalidAddress;
    }

    // Copy buffer properties
    MemInfo = pDevice->PciMemory;

    rc =
        PlxPciPhysicalMemoryUnmap(
            hDevice,
            &MemInfo
            );

    if (rc == ApiSuccess)
    {
        // Clear internal data
        LockGlobals();

        pDevice->PciMemory.UserAddr = (U32)NULL;

        UnlockGlobals();

        // Clear buffer address
        *(U32*)pVa = (U32)NULL;
    }

    return rc;
}




/******************************************************************************
 *
 * Function   :  PlxPciDeviceOpen
 *
 * Description:  This obtains a handle to a PLX device.  The first device that
 *               matches the criteria in the first argument will be selected.
 *
 *****************************************************************************/
RETURN_CODE
PlxPciDeviceOpen(
    DEVICE_LOCATION *pDevice,
    HANDLE          *pHandle
    )
{
    U8           VerMajor;
    U8           VerMinor;
    U8           VerRevision;
    U32          i;
    char         DriverName[25];
    IO_NODE     *pIoNode;
    RETURN_CODE  rc;


    if ((pDevice == NULL) || (pHandle == NULL))
        return ApiNullParam;

    // Get the Serial number of the device, if not provided
    if (pDevice->SerialNumber[0] == '\0')
    {
        i = 0;

        // Search for the device matching the criteria
        rc =
            PlxPciDeviceFind(
                pDevice,
                &i
                );

        if (rc != ApiSuccess)
        {
            *pHandle = NULL;
            return rc;
        }
    }

    // If provided, the SerialNumber is sufficient to open a device
    sprintf(
        DriverName,
        DRIVER_PATH "%s",
        pDevice->SerialNumber
        );

    // Open the device
    *pHandle =
        CreateFile(
            DriverName,
            GENERIC_READ | GENERIC_WRITE,
            FILE_SHARE_READ | FILE_SHARE_WRITE,
            NULL,
            OPEN_EXISTING,
            FILE_FLAG_OVERLAPPED,
            NULL
            );

    if (*pHandle == INVALID_HANDLE_VALUE)
    {
        *pHandle = NULL;
        return ApiInvalidDeviceInfo;
    }

    // Add the handle to the device list.
    if (DeviceListAdd(
            *pHandle,
            pDevice
            ) == NULL)
    {
        CloseHandle(
            *pHandle
            );

        *pHandle = NULL;

        return ApiInsufficientResources;
    }

    // Verify the driver version
    PlxDriverVersion(
        *pHandle,
        &VerMajor,
        &VerMinor,
        &VerRevision
        );

    // Make sure the driver matches the DLL
    if ((VerMajor    != API_VERSION_MAJOR) ||
        (VerMinor    != API_VERSION_MINOR) ||
        (VerRevision != API_VERSION_REVISION))
    {
#if 0
/******************************************
 * The following code is commented out for
 * now until the driver version mechanism
 * can be verified.  Since DeviceOpen()
 * is called internally by other functions
 * in the DLL, Driver version verification
 * is not implemented properly yet.
 *****************************************/
        // Versions don't match, return
        DeviceListRemove(
            *pHandle
            );

        // Close the handle
        CloseHandle(
            *pHandle
            );

        *pHandle = NULL;

        return ApiInvalidDriverVersion;
#endif
    }

    pIoNode = IoPoolGetNode();

    // Get device data from driver
    IoMessage(
        *pHandle,
        PLX_IOCTL_DEVICE_INIT,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    // Copy device information 
    *pDevice = pIoNode->IoBuffer.u.MgmtData.u.Device;

    IoPoolReleaseNode(
        pIoNode
        );

    return ApiSuccess;
}




/******************************************************************************
 *
 * Function   :  PlxPciDeviceClose
 *
 * Description:  This closes a previously opened handle to a PCI device.  
 *
 *****************************************************************************/
RETURN_CODE
PlxPciDeviceClose(
    HANDLE hDevice
    )
{
    if (DeviceListRemove(
            hDevice
            ) == FALSE)
    {
        return ApiInvalidDeviceInfo;
    }

    // Close the handle
    CloseHandle(
        hDevice
        );

    return ApiSuccess;
}




/******************************************************************************
 *
 * Function   :  PlxPciDeviceFind
 *
 * Description:  This will search the driver's device extensions to find the 
 *               device that matches the input data.
 *
 *****************************************************************************/
RETURN_CODE
PlxPciDeviceFind(
    DEVICE_LOCATION *pDevice,
    U32             *pRequestLimit
    )
{
    U32              i;
    U32              totalDevFound;
    HANDLE           hDevice;
    BOOLEAN          driverOpened;
    IO_NODE         *pIoNode;
    RETURN_CODE      rc;
    DEVICE_LOCATION  DevInfo;


    // Check for null pointers
    if (pDevice == NULL || pRequestLimit == NULL)
    {
        return ApiNullParam;
    }

    totalDevFound = 0;
    driverOpened  = FALSE;

    pIoNode = IoPoolGetNode();

    i = 0;

    // Scan through present drivers for matches
    while (PlxDrivers[i][0] != '0')
    {
        sprintf(
            (char*)DevInfo.SerialNumber,
            "%s-0",
            PlxDrivers[i]
            );

        // Increment to next driver
        i++;

        rc =
            PlxPciDeviceOpen(
                &DevInfo,
                &hDevice
                );

        if (rc != ApiSuccess)
            continue;

        // Driver is open.  Find any devices that match

        driverOpened = TRUE;


        if (*pRequestLimit != FIND_AMOUNT_MATCHED)
            pIoNode->IoBuffer.u.MgmtData.value = *pRequestLimit - totalDevFound;
        else
            pIoNode->IoBuffer.u.MgmtData.value = FIND_AMOUNT_MATCHED;

        // Copy search criteria
        pIoNode->IoBuffer.u.MgmtData.u.Device = *pDevice;

        IoMessage(
            hDevice,
            PLX_IOCTL_PCI_DEVICE_FIND,
            &(pIoNode->IoBuffer),
            sizeof(IOCTLDATA),
            &(pIoNode->Overlapped)
            );

        totalDevFound += pIoNode->IoBuffer.u.MgmtData.value;

        if (*pRequestLimit != FIND_AMOUNT_MATCHED)
        {
            // Check to see if we have reached the specified device
            if (*pRequestLimit < totalDevFound)
            {
                *pDevice = pIoNode->IoBuffer.u.MgmtData.u.Device;

                IoPoolReleaseNode(
                    pIoNode
                    );

                PlxPciDeviceClose(
                    hDevice
                    );

                return ApiSuccess;
            }
        }

        PlxPciDeviceClose(
            hDevice
            );
    }

    IoPoolReleaseNode(
        pIoNode
        );

    if (driverOpened == FALSE)
    {
        if (*pRequestLimit == FIND_AMOUNT_MATCHED)
        {
            *pRequestLimit = 0;
        }

        return ApiNoActiveDriver;
    }

    if (*pRequestLimit == FIND_AMOUNT_MATCHED)
    {
        *pRequestLimit = totalDevFound;
        if (totalDevFound == 0)
        {
            return ApiInvalidDeviceInfo;
        }
        else
        {
            return ApiSuccess;
        }
    }

    return ApiInvalidDeviceInfo;
}




/******************************************************************************
 *
 * Function   :  PlxPciBarGet
 *
 * Description:  Returns the PCI BAR address of a PCI space
 *
 *****************************************************************************/
RETURN_CODE
PlxPciBarGet(
    HANDLE   hDevice,
    U8       BarIndex,
    U32     *pPciBar,
    BOOLEAN *pFlag_IsIoSpace
    )
{
    IO_NODE *pIoNode;


    if (pPciBar == NULL)
        return ApiNullParam;

    // Set default value
    *pPciBar = 0;

    // Verify BAR number
    switch (BarIndex)
    {
        case 0:
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
            break;

        default:
            return ApiInvalidIndex;
    }

    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        return ApiInvalidHandle;
    }

    pIoNode = IoPoolGetNode();

    pIoNode->IoBuffer.u.MgmtData.offset = BarIndex;

    IoMessage(
        hDevice,
        PLX_IOCTL_PCI_BAR_GET,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    *pPciBar = pIoNode->IoBuffer.u.MgmtData.value;

    if (pFlag_IsIoSpace != NULL)
        *pFlag_IsIoSpace = pIoNode->IoBuffer.u.MgmtData.u.bFlag;

    return ApiSuccess;
}




/******************************************************************************
 *
 * Function   :  PlxPciBarRangeGet
 *
 * Description:  Returns the size of a PCI BAR space
 *
 *****************************************************************************/
RETURN_CODE
PlxPciBarRangeGet(
    HANDLE  hDevice, 
    U8      BarIndex,
    U32    *pData
    )
{
    IO_NODE *pIoNode;


    if (pData == NULL)
        return ApiNullParam;

    // Verify BAR number
    switch (BarIndex)
    {
        case 0:
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
            break;

        default:
            return ApiInvalidIndex;
    }

    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        return ApiInvalidHandle;
    }

    pIoNode = IoPoolGetNode();

    pIoNode->IoBuffer.u.MgmtData.offset = BarIndex;

    IoMessage(
        hDevice,
        PLX_IOCTL_PCI_BAR_RANGE_GET,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    *pData = pIoNode->IoBuffer.u.MgmtData.value;

    IoPoolReleaseNode(
        pIoNode
        );

    return ApiSuccess;
}




/******************************************************************************
 *
 * Function   :  PlxPciBarMap
 *
 * Description:  Maps a PCI BAR space into user virtual space.
 *
 *****************************************************************************/
RETURN_CODE
PlxPciBarMap(
    HANDLE  hDevice,
    U8      BarIndex,
    VOID   *pVa
    )
{
    IO_NODE     *pIoNode;
    RETURN_CODE  rc;
    DEVICE_NODE *pDevice;


    if (pVa == NULL)
        return ApiNullParam;

    // Set default return value
    *(U32*)pVa = (U32)NULL;

    // Verify BAR number
    switch (BarIndex)
    {
        case 0:
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
        case 6:
            break;

        default:
            return ApiInvalidIndex;
    }

    // Verify the handle
    pDevice =
        DeviceListFind(
            hDevice
            );

    if (pDevice == NULL)
    {
        return ApiInvalidHandle;
    }

    // Check if mapping has already been performed
    if (pDevice->PciSpace[BarIndex].va != (U32)NULL)
    {
        *(U32*)pVa = pDevice->PciSpace[BarIndex].va;

        return ApiSuccess;
    }

    // Do not re-attempt failed mappings
    if (pDevice->PciSpace[BarIndex].bMapAttempted)
    {
        return ApiFailed;
    }

    // Flag map attempt
    pDevice->PciSpace[BarIndex].bMapAttempted = TRUE;

    pIoNode = IoPoolGetNode();

    pIoNode->IoBuffer.u.MgmtData.offset = BarIndex;

    IoMessage(
        hDevice,
        PLX_IOCTL_PCI_BAR_MAP,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    *(U32*)pVa = pIoNode->IoBuffer.u.MgmtData.value;

    rc = pIoNode->IoBuffer.ReturnCode;

    IoPoolReleaseNode(
        pIoNode
        );

    // Store value for later cleanup
    LockGlobals();

    pDevice->PciSpace[BarIndex].va = *(U32*)pVa;

    UnlockGlobals();

    return rc;
}




/******************************************************************************
 *
 * Function   :  PlxPciBarUnmap
 *
 * Description:  Unmaps a PCI BAR space from user virtual space
 *
 *****************************************************************************/
RETURN_CODE
PlxPciBarUnmap(
    HANDLE  hDevice,
    VOID   *pVa
    )
{
    U8           BarIndex;
    IO_NODE     *pIoNode;
    RETURN_CODE  rc;
    DEVICE_NODE *pDevice;


    if (pVa == NULL)
        return ApiNullParam;

    if (*(U32*)pVa == (U32)NULL)
    {
        return ApiInvalidAddress;
    }

    // Verify the handle
    pDevice =
        DeviceListFind(
            hDevice
            );

    if (pDevice == NULL)
    {
        return ApiInvalidHandle;
    }

    // Search for actual mapped address
    for (BarIndex = 0; BarIndex < PCI_NUM_BARS; BarIndex++)
    {
        // Compare virtual address
        if (*(U32*)pVa == pDevice->PciSpace[BarIndex].va)
        {
            // Unmap the space
            pIoNode = IoPoolGetNode();

            pIoNode->IoBuffer.u.MgmtData.offset = BarIndex;
            pIoNode->IoBuffer.u.MgmtData.value  = *(U32*)pVa;

            IoMessage(
                hDevice,
                PLX_IOCTL_PCI_BAR_UNMAP,
                &(pIoNode->IoBuffer),
                sizeof(IOCTLDATA),
                &(pIoNode->Overlapped)
                );

            rc = pIoNode->IoBuffer.ReturnCode;

            IoPoolReleaseNode(
                pIoNode
                );

            // Clear address
            *(U32*)pVa = (U32)NULL;

            // Clear internal data
            LockGlobals();

            pDevice->PciSpace[BarIndex].va            = (U32)NULL;
            pDevice->PciSpace[BarIndex].size          = 0;
            pDevice->PciSpace[BarIndex].offset        = 0;
            pDevice->PciSpace[BarIndex].bMapAttempted = FALSE;

            UnlockGlobals();

            return rc;
        }
    }

    return ApiInvalidAddress;
}




/******************************************************************************
 *
 * Function   :  PlxPciBaseAddressesGet
 *
 * Description:  Maps all valid PCI BAR spaces into user virtual space.
 *
 *****************************************************************************/
RETURN_CODE
PlxPciBaseAddressesGet(
    HANDLE             hDevice, 
    VIRTUAL_ADDRESSES *pVirtAddr
    )
{
    U8   i;
    U32 *pVa;


    if (pVirtAddr == NULL)
        return ApiNullParam;

    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        return ApiInvalidHandle;
    }

    for (i=0; i<PCI_NUM_BARS; i++)
    {
        switch (i)
        {
            case 0:
                pVa = &(pVirtAddr->Va0);
                break;

            case 1:
                pVa = &(pVirtAddr->Va1);
                break;

            case 2:
                pVa = &(pVirtAddr->Va2);
                break;

            case 3:
                pVa = &(pVirtAddr->Va3);
                break;

            case 4:
                pVa = &(pVirtAddr->Va4);
                break;

            case 5:
                pVa = &(pVirtAddr->Va5);
                break;

            case 6:
                pVa = &(pVirtAddr->VaRom);
                break;

            default:
                // Add to avoid compiler warning
                return ApiFailed;
        }

        PlxPciBarMap(
            hDevice,
            i,
            pVa
            );
    }

    return ApiSuccess;
}




/******************************************************************************
 *
 * Function   :  PlxPciConfigRegisterRead
 *
 * Description:  This is used to read a PCI configuration register
 *
 *****************************************************************************/
U32
PlxPciConfigRegisterRead(
    U8          bus,
    U8          slot,
    U16          offset,
    RETURN_CODE *pReturnCode
    )
{
    U32              RegValue;
    DWORD            OsVersion;
    HANDLE           hDevice;
    IO_NODE         *pIoNode;
    DEVICE_LOCATION  dev;


    /*****************************************************
     * Note: The access of PCI registers of a device in
     *       an arbitrary bus and slot is not supported
     *       in a Plug 'n' Play environment.
     *
     *       Since Windows NT 4.0 does not have PnP,
     *       PLX drivers can still access devices in any
     *       arbitrary bus or slot.  Therefore, a handle
     *       to any loaded PLX driver will work fine.
     *
     *       In PnP environments, PCI registers may be
     *       accessed only for devices for which a PLX
     *       driver is loaded.  Therefore, an attempt is
     *       made to open a device at the specific bus
     *       and slot.  If a device can be opened, a PLX
     *       driver is loaded for that device and its
     *       registers can be accessed.
     ****************************************************/

    OsVersion = GetVersion();

    if (((OsVersion & (1 << 31)) == 0) &&
        ((OsVersion & 0xff)      == 4))
    {
        // OS is NT 4.0
        dev.BusNumber  = (U8)-1;
        dev.SlotNumber = (U8)-1;
    }
    else
    {
        // OS is not NT 4.0, so must have PnP
        dev.BusNumber  = bus;
        dev.SlotNumber = slot;
    }

    dev.VendorId        = (U16)-1;
    dev.DeviceId        = (U16)-1;
    dev.SerialNumber[0] = '\0';

    // Get a Handle to a PLX driver to perform the PCI Config access
    if (PlxPciDeviceOpen(
            &dev,
            &hDevice
            ) != ApiSuccess)
    {
        if (pReturnCode != NULL)
            *pReturnCode = ApiConfigAccessFailed;

        return (U32)-1;
    }

    pIoNode = IoPoolGetNode();

    pIoNode->IoBuffer.u.MgmtData.u.Device.BusNumber  = bus;
    pIoNode->IoBuffer.u.MgmtData.u.Device.SlotNumber = slot;
    pIoNode->IoBuffer.u.MgmtData.offset              = offset;

    IoMessage(
        hDevice,
        PLX_IOCTL_PCI_REGISTER_READ,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );
        
    if (pReturnCode != NULL)
        *pReturnCode = pIoNode->IoBuffer.ReturnCode;

    RegValue = pIoNode->IoBuffer.u.MgmtData.value;

    IoPoolReleaseNode(
        pIoNode
        );

    PlxPciDeviceClose(
        hDevice
        );

    return RegValue;
}




/******************************************************************************
 *
 * Function   :  PlxPciConfigRegisterWrite
 *
 * Description:  This is used to write to a PCI configuration register
 *
 *****************************************************************************/
RETURN_CODE
PlxPciConfigRegisterWrite(
    U8   bus,
    U8   slot,
    U16  offset,
    U32 *pData
    )
{
    DWORD            OsVersion;
    HANDLE           hDevice;
    IO_NODE         *pIoNode;
    RETURN_CODE      rc;
    DEVICE_LOCATION  dev;


    if (pData == NULL)
        return ApiNullParam;

    /*****************************************************
     * Note: The access of PCI registers of a device in
     *       an arbitrary bus and slot is not supported
     *       in a Plug 'n' Play environment.
     *
     *       Since Windows NT 4.0 does not have PnP,
     *       PLX drivers can still access devices in any
     *       arbitrary bus or slot.  Therefore, a handle
     *       to any loaded PLX driver will work fine.
     *
     *       In PnP environments, PCI registers may be
     *       accessed only for devices for which a PLX
     *       driver is loaded.  Therefore, an attempt is
     *       made to open a device at the specific bus
     *       and slot.  If a device can be opened, a PLX
     *       driver is loaded for that device and its
     *       registers can be accessed.
     ****************************************************/

    OsVersion = GetVersion();

    if (((OsVersion & (1 << 31)) == 0) &&
        ((OsVersion & 0xff)      == 4))
    {
        // OS is NT 4.0
        dev.BusNumber  = (U8)-1;
        dev.SlotNumber = (U8)-1;
    }
    else
    {
        // OS is not NT 4.0, so must have PnP
        dev.BusNumber  = bus;
        dev.SlotNumber = slot;
    }

    dev.VendorId        = (U16)-1;
    dev.DeviceId        = (U16)-1;
    dev.SerialNumber[0] = '\0';

    // Get a Handle to a PLX driver to perform the PCI Config access
    if (PlxPciDeviceOpen(
            &dev,
            &hDevice
            ) != ApiSuccess)
    {
        return ApiConfigAccessFailed;
    }

    pIoNode = IoPoolGetNode();

    pIoNode->IoBuffer.u.MgmtData.u.Device.BusNumber  = bus;
    pIoNode->IoBuffer.u.MgmtData.u.Device.SlotNumber = slot;
    pIoNode->IoBuffer.u.MgmtData.offset              = offset;
    pIoNode->IoBuffer.u.MgmtData.value               = *pData;

    IoMessage(
        hDevice,
        PLX_IOCTL_PCI_REGISTER_WRITE,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    rc = pIoNode->IoBuffer.ReturnCode;

    IoPoolReleaseNode(
        pIoNode
        );

    PlxPciDeviceClose(
        hDevice
        );

    return rc;
}




/******************************************************************************
 *
 * Function   :  PlxPciRegisterRead_Unsupported
 *
 * Description:  Unsupported function to read a PCI register of any device
 *
 *****************************************************************************/
U32
PlxPciRegisterRead_Unsupported(
    U8           bus,
    U8           slot,
    U16          offset,
    RETURN_CODE *pReturnCode
    )
{
    U32              RegValue;
    HANDLE           hDevice;
    IO_NODE         *pIoNode;
    DEVICE_LOCATION  dev;


    /*****************************************************
     * Note: The access of PCI registers of a device in
     *       an arbitrary bus and slot may not be supported
     *       in true Plug 'n' Play Operating Systems.
     *
     *       In PLX PnP drivers, an unsupported function
     *       is provided which accesses PCI registers of
     *       any device in an arbitrary bus or slot.
     *
     *       **** WARNING **** WARNING **** WARNING ****
     *       This function may not be provided in future
     *       SDK releases.  There is also no guaratee that
     *       it will succeed in all systems.
     ****************************************************/

    // Select any PLX driver to perform the PCI Register access
    dev.BusNumber       = (U8)-1;
    dev.SlotNumber      = (U8)-1;
    dev.VendorId        = (U16)-1;
    dev.DeviceId        = (U16)-1;
    dev.SerialNumber[0] = '\0';

    if (PlxPciDeviceOpen(
            &dev,
            &hDevice
            ) != ApiSuccess)
    {
        if (pReturnCode != NULL)
            *pReturnCode = ApiConfigAccessFailed;

        return (U32)-1;
    }

    pIoNode = IoPoolGetNode();

    pIoNode->IoBuffer.u.MgmtData.u.Device.BusNumber  = bus;
    pIoNode->IoBuffer.u.MgmtData.u.Device.SlotNumber = slot;
    pIoNode->IoBuffer.u.MgmtData.offset              = offset;

    IoMessage(
        hDevice,
        PLX_IOCTL_PCI_REG_READ_UNSUPPORTED,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );
        
    if (pReturnCode != NULL)
        *pReturnCode = pIoNode->IoBuffer.ReturnCode;

    RegValue = pIoNode->IoBuffer.u.MgmtData.value;

    IoPoolReleaseNode(
        pIoNode
        );

    PlxPciDeviceClose(
        hDevice
        );

    return RegValue;
}




/******************************************************************************
 *
 * Function   :  PlxPciRegisterWrite_Unsupported
 *
 * Description:  Unsupported function to write a PCI register of any device
 *
 *****************************************************************************/
RETURN_CODE
PlxPciRegisterWrite_Unsupported(
    U8   bus,
    U8   slot,
    U16  offset,
    U32  value
    )
{
    HANDLE           hDevice;
    IO_NODE         *pIoNode;
    RETURN_CODE      rc;
    DEVICE_LOCATION  dev;


    /*****************************************************
     * Note: The access of PCI registers of a device in
     *       an arbitrary bus and slot may not be supported
     *       in true Plug 'n' Play Operating Systems.
     *
     *       In PLX PnP drivers, an unsupported function
     *       is provided which accesses PCI registers of
     *       any device in an arbitrary bus or slot.
     *
     *       **** WARNING **** WARNING **** WARNING ****
     *       This function may not be provided in future
     *       SDK releases.  There is also no guaratee that
     *       it will succeed in all systems.
     ****************************************************/

    // Select any PLX driver to perform the PCI Register access
    dev.BusNumber       = (U8)-1;
    dev.SlotNumber      = (U8)-1;
    dev.VendorId        = (U16)-1;
    dev.DeviceId        = (U16)-1;
    dev.SerialNumber[0] = '\0';

    if (PlxPciDeviceOpen(
            &dev,
            &hDevice
            ) != ApiSuccess)
    {
        return ApiConfigAccessFailed;
    }

    pIoNode = IoPoolGetNode();

    pIoNode->IoBuffer.u.MgmtData.u.Device.BusNumber  = bus;
    pIoNode->IoBuffer.u.MgmtData.u.Device.SlotNumber = slot;
    pIoNode->IoBuffer.u.MgmtData.offset              = offset;
    pIoNode->IoBuffer.u.MgmtData.value               = value;

    IoMessage(
        hDevice,
        PLX_IOCTL_PCI_REG_WRITE_UNSUPPORTED,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    rc = pIoNode->IoBuffer.ReturnCode;

    IoPoolReleaseNode(
        pIoNode
        );

    PlxPciDeviceClose(
        hDevice
        );

    return rc;
}




/******************************************************************************
 *
 * Function   :  PlxRegisterRead
 *
 * Description:  This function reads a register from a opened device
 *
 *****************************************************************************/
U32
PlxRegisterRead(
    HANDLE       hDevice,
    U16          offset,
    RETURN_CODE *pReturnCode
    )
{
    U32      RegValue;
    IO_NODE *pIoNode;


    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        if (pReturnCode != NULL)
            *pReturnCode = ApiInvalidHandle;
        return (U32)-1;
    }

    pIoNode = IoPoolGetNode();

    // Copy data to buffer
    pIoNode->IoBuffer.u.MgmtData.offset = offset;

    IoMessage(
        hDevice,
        PLX_IOCTL_REGISTER_READ,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    if (pReturnCode != NULL)
       *pReturnCode = pIoNode->IoBuffer.ReturnCode;

    RegValue = pIoNode->IoBuffer.u.MgmtData.value;

    IoPoolReleaseNode(
        pIoNode
        );

    return RegValue;
}




/******************************************************************************
 *
 * Function   :  PlxRegisterWrite
 *
 * Description:  This will write to a register of an opened device.
 *
 *****************************************************************************/
RETURN_CODE
PlxRegisterWrite(
    HANDLE hDevice,
    U16    offset,
    U32    value
    )
{
    IO_NODE     *pIoNode;
    RETURN_CODE  rc;


    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        return ApiInvalidHandle;
    }

    pIoNode = IoPoolGetNode();

    pIoNode->IoBuffer.u.MgmtData.offset = offset;
    pIoNode->IoBuffer.u.MgmtData.value  = value;

    IoMessage(
        hDevice,
        PLX_IOCTL_REGISTER_WRITE,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    rc = pIoNode->IoBuffer.ReturnCode;

    IoPoolReleaseNode(
        pIoNode
        );

    return rc;
}




/******************************************************************************
 *
 * Function   :  PlxRegisterMailboxRead
 *
 * Description:  This will read the value at a given Mailbox register.
 *
 *****************************************************************************/
U32
PlxRegisterMailboxRead(
    HANDLE       hDevice,
    MAILBOX_ID   MailboxId,
    RETURN_CODE *pReturnCode
    )
{
    U32      RegValue;
    IO_NODE *pIoNode;


    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        if (pReturnCode != NULL)
            *pReturnCode = ApiInvalidHandle;
        return (U32)-1;
    }

    pIoNode = IoPoolGetNode();

    pIoNode->IoBuffer.u.MgmtData.offset = (U16)MailboxId;

    IoMessage(
        hDevice,
        PLX_IOCTL_MAILBOX_READ,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    if (pReturnCode != NULL)
        *pReturnCode = pIoNode->IoBuffer.ReturnCode;

    RegValue = pIoNode->IoBuffer.u.MgmtData.value;

    IoPoolReleaseNode(
        pIoNode
        );

    return RegValue;
}




/******************************************************************************
 *
 * Function   :  PlxRegisterMailboxWrite
 *
 * Description:  This will write a value to a given Mailbox register.
 *
 *****************************************************************************/
RETURN_CODE
PlxRegisterMailboxWrite(
    HANDLE     hDevice,
    MAILBOX_ID MailboxId,
    U32        value
    )
{
    IO_NODE     *pIoNode;
    RETURN_CODE  rc;


    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        return ApiInvalidHandle;
    }

    pIoNode = IoPoolGetNode();

    pIoNode->IoBuffer.u.MgmtData.offset = (U16)MailboxId;
    pIoNode->IoBuffer.u.MgmtData.value  = value;
    
    IoMessage(
        hDevice,
        PLX_IOCTL_MAILBOX_WRITE,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    rc = pIoNode->IoBuffer.ReturnCode;

    IoPoolReleaseNode(
        pIoNode
        );

    return rc;
}




/******************************************************************************
 *
 * Function   :  PlxRegisterDoorbellRead
 *
 * Description:  This function returns the value of the last doorbell interrupt.
 *
 *****************************************************************************/
U32
PlxRegisterDoorbellRead(
    HANDLE       hDevice,
    RETURN_CODE *pReturnCode
    )
{
    U32      RegValue;
    IO_NODE *pIoNode;


    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        if (pReturnCode != NULL)
            *pReturnCode = ApiInvalidHandle;
        return (U32)-1;
    }

    pIoNode = IoPoolGetNode();

    IoMessage(
        hDevice,
        PLX_IOCTL_DOORBELL_READ,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    if (pReturnCode != NULL)
        *pReturnCode = pIoNode->IoBuffer.ReturnCode;

    RegValue = pIoNode->IoBuffer.u.MgmtData.value;

    IoPoolReleaseNode(
        pIoNode
        );

    return RegValue;
}




/******************************************************************************
 *
 * Function   :  PlxRegisterDoorbellSet
 *
 * Description:  This writes a value to the PCI to Local Doorbell Register.
 *
 *****************************************************************************/
RETURN_CODE
PlxRegisterDoorbellSet(
    HANDLE hDevice,
    U32    value
    )
{
    IO_NODE     *pIoNode;
    RETURN_CODE  rc;


    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        return ApiInvalidHandle;
    }

    pIoNode = IoPoolGetNode();

    pIoNode->IoBuffer.u.MgmtData.value = value;

    IoMessage(
        hDevice,
        PLX_IOCTL_DOORBELL_WRITE,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    rc = pIoNode->IoBuffer.ReturnCode;

    IoPoolReleaseNode(
        pIoNode
        );

    return rc;;
}




/******************************************************************************
 *
 * Function   :  PlxIntrEnable
 *
 * Description:  This will enable specific interrupts to activate.
 *
 *****************************************************************************/
RETURN_CODE
PlxIntrEnable(
    HANDLE    hDevice,
    PLX_INTR *pPlxIntr
    )
{
    IO_NODE     *pIoNode;
    RETURN_CODE  rc;


    // Check for null pointers
    if (pPlxIntr == NULL)
        return ApiNullParam;

    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        return ApiInvalidHandle;
    }

    pIoNode = IoPoolGetNode();

    pIoNode->IoBuffer.u.MiscData.u.IntrInfo = *pPlxIntr;

    IoMessage(
        hDevice,
        PLX_IOCTL_INTR_ENABLE,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    rc = pIoNode->IoBuffer.ReturnCode;

    IoPoolReleaseNode(
        pIoNode
        );

    return rc;
}




/******************************************************************************
 *
 * Function   :  PlxIntrDisable
 *
 * Description:  This will un-nable specific interrupts.
 *
 *****************************************************************************/
RETURN_CODE
PlxIntrDisable(
    HANDLE    hDevice,
    PLX_INTR *pPlxIntr
    )
{
    IO_NODE     *pIoNode;
    RETURN_CODE  rc;


    // Check for null pointers
    if (pPlxIntr == NULL)
        return ApiNullParam;

    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        return ApiInvalidHandle;
    }

    pIoNode = IoPoolGetNode();

    pIoNode->IoBuffer.u.MiscData.u.IntrInfo = *pPlxIntr;

    IoMessage(
        hDevice,
        PLX_IOCTL_INTR_DISABLE,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    rc = pIoNode->IoBuffer.ReturnCode;

    IoPoolReleaseNode(
        pIoNode
        );

    return rc;
}




/******************************************************************************
 *
 * Function   :  PlxIntrAttach
 *
 * Description:  This function stores an object in the driver which will eventually
 *               notify a user process that a specific interrupt occured.
 *
 *****************************************************************************/
RETURN_CODE
PlxIntrAttach(
    HANDLE    hDevice,
    PLX_INTR  intrTypes,
    HANDLE   *pEventHdl
    )
{
    IO_NODE     *pEvent;
    DEVICE_NODE *pDevice;


    if (pEventHdl == NULL)
        return ApiNullParam;

    // Verify the handle
    pDevice =
        DeviceListFind(
            hDevice
            );

    if (pDevice == NULL)
        return ApiInvalidHandle;

    // Check to see if the Event handle has been allocated already
    if (*pEventHdl != NULL)
    {
        pEvent =
            IoListFindByEventHandle(
                pDevice->pEventList,
                *pEventHdl
                );
    }
    else
    {
        pEvent = NULL;
    }

    // Allocate resources if Event handle not previously used
    if (pEvent == NULL)
    {
        // Create the event
        *pEventHdl =
            CreateEvent(
                NULL,          // Not inheritable to child processes
                TRUE,          // Manual reset?
                FALSE,         // Intial state
                NULL
                );

        if (*pEventHdl == NULL)
            return ApiInsufficientResources;

        // Save the resources for later release
        pEvent =
            IoListAdd(
                &(pDevice->pEventList),
                *pEventHdl
                );

        if (pEvent == NULL)
        {
            CloseHandle(*pEventHdl);
            return ApiInsufficientResources;
        }
    }


    // Fill in the I/O parameters
    pEvent->IoBuffer.ReturnCode            = ApiSuccess;
    pEvent->IoBuffer.u.MiscData.u.IntrInfo = intrTypes;

    /*************************************************************
     * Since this is an Overlapped message, the request will not
     * complete it until the interrupt or an error occurs.  In
     * that case, the return code is only valid in error conditions,
     * so we cannot rely on it; therefore, it is set beforehand.
     *************************************************************/

    // Send message to driver
    IoMessage(
        hDevice,
        PLX_IOCTL_INTR_ATTACH,
        &(pEvent->IoBuffer),
        sizeof(IOCTLDATA),
        &(pEvent->Overlapped)
        );

    return pEvent->IoBuffer.ReturnCode;
}




/******************************************************************************
 *
 * Function   :  PlxIntrWait
 *
 * Description:  Waits for an attached interrupt event
 *
 *****************************************************************************/
RETURN_CODE
PlxIntrWait(
    HANDLE hDevice,
    HANDLE hEvent,
    U32    Timeout_ms
    )
{
    // Added to avoid compiler warnings
    if ((hDevice == INVALID_HANDLE_VALUE) ||
        (hEvent  == INVALID_HANDLE_VALUE) ||
        (Timeout_ms == 0))
    {
    }

    // Not implemented in Windows
    return ApiUnsupportedFunction;
}




/******************************************************************************
 *
 * Function   :  PlxIntrStatusGet
 *
 * Description:  This returns the status of the last interrupt events.
 *
 *****************************************************************************/
RETURN_CODE
PlxIntrStatusGet(
    HANDLE    hDevice,
    PLX_INTR *pPlxIntr
    )
{
    IO_NODE     *pIoNode;
    RETURN_CODE  rc;


    if (pPlxIntr == NULL)
        return ApiNullParam;

    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        return ApiInvalidHandle;
    }

    pIoNode = IoPoolGetNode();

    IoMessage(
        hDevice,
        PLX_IOCTL_INTR_STATUS_GET,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    *pPlxIntr = pIoNode->IoBuffer.u.MiscData.u.IntrInfo;

    rc = pIoNode->IoBuffer.ReturnCode;

    IoPoolReleaseNode(
        pIoNode
        );

    return rc;
}




/******************************************************************************
 *
 * Function   :  PlxPciAbortAddrRead
 *
 * Description:  Read PCI Abort address
 *
 *****************************************************************************/
U32
PlxPciAbortAddrRead(
    HANDLE       hDevice,
    RETURN_CODE *pReturnCode
    )
{
    U32      RegValue;
    IO_NODE *pIoNode;


    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        if (pReturnCode != NULL)
            *pReturnCode = ApiInvalidHandle;
        return (U32)-1;
    }

    pIoNode = IoPoolGetNode();

    IoMessage(
        hDevice,
        PLX_IOCTL_ABORTADDR_READ,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    RegValue = pIoNode->IoBuffer.u.MgmtData.value;

    if (pReturnCode != NULL)
        *pReturnCode = pIoNode->IoBuffer.ReturnCode;

    IoPoolReleaseNode(
        pIoNode
        );

    return RegValue;
}




/******************************************************************************
 *
 * Function   :  PlxBusIopRead
 *
 * Description:  Allows Host initiated Reads from the PCI bus.
 *
 *****************************************************************************/
RETURN_CODE
PlxBusIopRead(
    HANDLE       hDevice,
    IOP_SPACE    IopSpace,
    U32          address,
    BOOLEAN      bRemap,
    VOID        *pBuffer,
    U32          ByteCount,
    ACCESS_TYPE  AccessType
    )
{
    IO_NODE     *pIoNode;
    RETURN_CODE  rc;


    if (pBuffer == NULL)
        return ApiNullParam;

    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        return ApiInvalidHandle;
    }

    pIoNode = IoPoolGetNode();

    pIoNode->IoBuffer.u.BusIopData.IopSpace     = IopSpace;
    pIoNode->IoBuffer.u.BusIopData.Address      = address;
    pIoNode->IoBuffer.u.BusIopData.bRemap       = bRemap;
    pIoNode->IoBuffer.u.BusIopData.TransferSize = ByteCount;
    pIoNode->IoBuffer.u.BusIopData.AccessType   = AccessType;
    pIoNode->IoBuffer.u.BusIopData.Buffer       = (U32)pBuffer;

    IoMessage(
        hDevice,
        PLX_IOCTL_BUS_IOP_READ,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    rc = pIoNode->IoBuffer.ReturnCode;

    IoPoolReleaseNode(
        pIoNode
        );

    return rc;
}




/******************************************************************************
 *
 * Function   :  PlxBusIopWrite
 *
 * Description:  Allows Host to initiate a data write to the PCI bus.
 *
 *****************************************************************************/
RETURN_CODE
PlxBusIopWrite(
    HANDLE       hDevice,
    IOP_SPACE    IopSpace,
    U32          address,
    BOOLEAN      bRemap,
    VOID        *pBuffer,
    U32          ByteCount,
    ACCESS_TYPE  AccessType
    )
{
    IO_NODE     *pIoNode;
    RETURN_CODE  rc;


    if (pBuffer == NULL)
        return ApiNullParam;

    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        return ApiInvalidHandle;
    }

    pIoNode = IoPoolGetNode();

    pIoNode->IoBuffer.u.BusIopData.IopSpace     = IopSpace;
    pIoNode->IoBuffer.u.BusIopData.Address      = address;
    pIoNode->IoBuffer.u.BusIopData.bRemap       = bRemap;
    pIoNode->IoBuffer.u.BusIopData.TransferSize = ByteCount;
    pIoNode->IoBuffer.u.BusIopData.AccessType   = AccessType;
    pIoNode->IoBuffer.u.BusIopData.Buffer       = (U32)pBuffer;

    IoMessage(
        hDevice,
        PLX_IOCTL_BUS_IOP_WRITE,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    rc = pIoNode->IoBuffer.ReturnCode;

    IoPoolReleaseNode(
        pIoNode
        );

    return rc;
}




/******************************************************************************
 *
 * Function   :  PlxIoPortRead
 *
 * Description:  Read an absolute address using I/O bus cycles.
 *
 *****************************************************************************/
RETURN_CODE
PlxIoPortRead(
    HANDLE       hDevice,
    U32          IoPort,
    ACCESS_TYPE  AccessType,
    VOID        *pValue
    )
{
    IO_NODE     *pIoNode;
    RETURN_CODE  rc;


    if (pValue == NULL)
       return ApiNullParam;

    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        return ApiInvalidHandle;
    }

    pIoNode = IoPoolGetNode();

    pIoNode->IoBuffer.u.BusIopData.Address    = IoPort;
    pIoNode->IoBuffer.u.BusIopData.AccessType = AccessType;

    IoMessage(
        hDevice,
        PLX_IOCTL_IO_PORT_READ,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    // Copy the data
    switch (AccessType)
    {
        case BitSize8:
            *(U8*)pValue = (U8)(pIoNode->IoBuffer.u.BusIopData.Buffer);
            break;

        case BitSize16:
            *(U16*)pValue = (U16)(pIoNode->IoBuffer.u.BusIopData.Buffer);
            break;

        case BitSize32:
            *(U32*)pValue = (U32)(pIoNode->IoBuffer.u.BusIopData.Buffer);
            break;

        default:
            return ApiInvalidAccessType;
    }

    rc = pIoNode->IoBuffer.ReturnCode;

    IoPoolReleaseNode(
        pIoNode
        );

    return rc;
}




/******************************************************************************
 *
 * Function   :  PlxIoPortWrite
 *
 * Description:  Write to an absolute address using I/O bus cycles.
 *
 *****************************************************************************/
RETURN_CODE
PlxIoPortWrite(
    HANDLE       hDevice,
    U32          IoPort,
    ACCESS_TYPE  AccessType,
    VOID        *pValue
    )
{
    IO_NODE     *pIoNode;
    RETURN_CODE  rc;


    if (pValue == NULL)
        return ApiNullParam;

    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        return ApiInvalidHandle;
    }

    pIoNode = IoPoolGetNode();

    switch (AccessType)
    {
        case BitSize8:
            pIoNode->IoBuffer.u.BusIopData.Buffer = *(U8*)pValue;
            break;

        case BitSize16:
            pIoNode->IoBuffer.u.BusIopData.Buffer = *(U16*)pValue;
            break;

        case BitSize32:
            pIoNode->IoBuffer.u.BusIopData.Buffer = *(U32*)pValue;
            break;

        default:
            return ApiInvalidAccessType;
    }

    pIoNode->IoBuffer.u.BusIopData.Address    = IoPort;
    pIoNode->IoBuffer.u.BusIopData.AccessType = AccessType;

    IoMessage(
        hDevice,
        PLX_IOCTL_IO_PORT_WRITE,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    rc = pIoNode->IoBuffer.ReturnCode;

    IoPoolReleaseNode(
        pIoNode
        );

    return rc;
}




/******************************************************************************
 *
 * Function   :  PlxSerialEepromPresent
 *
 * Description:  Returns TRUE if a serial EEPROM device is detected.
 *
 * Note       :  A blank EEPROM may return FALSE depending upon PLX chip type.
 *
 *****************************************************************************/
BOOLEAN
PlxSerialEepromPresent(
    HANDLE       hDevice,
    RETURN_CODE *pReturnCode
    )
{
    IO_NODE *pIoNode;
    BOOLEAN  EepromPresent;


    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        if (pReturnCode != NULL)
            *pReturnCode = ApiInvalidHandle;
        return FALSE;
    }

    pIoNode = IoPoolGetNode();

    IoMessage(
        hDevice,
        PLX_IOCTL_EEPROM_PRESENT,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    if (pReturnCode != NULL)
        *pReturnCode = pIoNode->IoBuffer.ReturnCode;

    EepromPresent = pIoNode->IoBuffer.u.MgmtData.u.bFlag;

    IoPoolReleaseNode(
        pIoNode
        );

    return EepromPresent;
}




/******************************************************************************
 *
 * Function   :  PlxSerialEepromRead
 *
 * Description:  Read the configuration EEPROM of a PCI device
 *
 *****************************************************************************/
RETURN_CODE
PlxSerialEepromRead(
    HANDLE       hDevice,
    EEPROM_TYPE  EepromType,
    U32         *pBuffer,
    U32          size
    )
{
    IO_NODE     *pIoNode;
    RETURN_CODE  rc;


    if (pBuffer == NULL)
        return ApiNullParam;

    if (size == 0)
        return ApiInvalidSize;

    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        return ApiInvalidHandle;
    }

    pIoNode = IoPoolGetNode();

    pIoNode->IoBuffer.u.MiscData.data[0]      = (U32)pBuffer;
    pIoNode->IoBuffer.u.MiscData.data[1]      = size;
    pIoNode->IoBuffer.u.MiscData.u.EepromType = EepromType;

    IoMessage(
        hDevice,
        PLX_IOCTL_EEPROM_READ,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    rc = pIoNode->IoBuffer.ReturnCode;

    IoPoolReleaseNode(
        pIoNode
        );

    return rc;
}




/******************************************************************************
 *
 * Function   :  PlxSerialEepromReadByOffset
 *
 * Description:  Read a value from a specified offset of the EEPROM
 *
 *****************************************************************************/
RETURN_CODE
PlxSerialEepromReadByOffset(
    HANDLE  hDevice,
    U16     offset,
    U32    *pValue
    )
{
    IO_NODE     *pIoNode;
    RETURN_CODE  rc;


    if (pValue == NULL)
        return ApiNullParam;

    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        return ApiInvalidHandle;
    }

    pIoNode = IoPoolGetNode();

    pIoNode->IoBuffer.u.MgmtData.offset = offset;

    IoMessage(
        hDevice,
        PLX_IOCTL_EEPROM_READ_BY_OFFSET,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    rc = pIoNode->IoBuffer.ReturnCode;

    IoPoolReleaseNode(
        pIoNode
        );

    if (rc == ApiSuccess)
    {
        *pValue = pIoNode->IoBuffer.u.MgmtData.value;
    }
    else
    {
        *pValue = (U32)-1;
    }

    return rc;
}




/******************************************************************************
 *
 * Function   :  PlxSerialEepromWrite
 *
 * Description:  Write to the configuration EEPROM of a PCI device
 *
 *****************************************************************************/
RETURN_CODE
PlxSerialEepromWrite(
    HANDLE       hDevice,
    EEPROM_TYPE  EepromType,
    U32         *pBuffer,
    U32          size
    )
{
    IO_NODE     *pIoNode;
    RETURN_CODE  rc;


    if (pBuffer == NULL)
        return ApiNullParam;

    if (size == 0)
        return ApiInvalidSize;

    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        return ApiInvalidHandle;
    }

    pIoNode = IoPoolGetNode();

    pIoNode->IoBuffer.u.MiscData.data[0]      = (U32)pBuffer;
    pIoNode->IoBuffer.u.MiscData.data[1]      = size;
    pIoNode->IoBuffer.u.MiscData.u.EepromType = EepromType;

    IoMessage(
        hDevice,
        PLX_IOCTL_EEPROM_WRITE,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    rc = pIoNode->IoBuffer.ReturnCode;

    IoPoolReleaseNode(
        pIoNode
        );

    return rc;
}




/******************************************************************************
 *
 * Function   :  PlxSerialEepromWriteByOffset
 *
 * Description:  Write a value to a specified offset of the EEPROM
 *
 *****************************************************************************/
RETURN_CODE
PlxSerialEepromWriteByOffset(
    HANDLE  hDevice,
    U16     offset,
    U32     value
    )
{
    IO_NODE     *pIoNode;
    RETURN_CODE  rc;


    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        return ApiInvalidHandle;
    }

    pIoNode = IoPoolGetNode();

    pIoNode->IoBuffer.u.MgmtData.offset = offset;
    pIoNode->IoBuffer.u.MgmtData.value  = value;

    IoMessage(
        hDevice,
        PLX_IOCTL_EEPROM_WRITE_BY_OFFSET,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    rc = pIoNode->IoBuffer.ReturnCode;

    IoPoolReleaseNode(
        pIoNode
        );

    return rc;
}




/******************************************************************************
 *
 * Function   :  PlxDmaControl
 *
 * Description:  Perform a Command on a specified DMA channel.
 *
 *****************************************************************************/
RETURN_CODE
PlxDmaControl(
    HANDLE      hDevice,
    DMA_CHANNEL channel,
    DMA_COMMAND command
    )
{
    IO_NODE     *pIoNode;
    RETURN_CODE  rc;


    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        return ApiInvalidHandle;
    }

    pIoNode = IoPoolGetNode();

    pIoNode->IoBuffer.u.DmaData.channel   = channel;
    pIoNode->IoBuffer.u.DmaData.u.command = command;

    IoMessage(
        hDevice,
        PLX_IOCTL_DMA_CONTROL,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    rc = pIoNode->IoBuffer.ReturnCode;

    IoPoolReleaseNode(
        pIoNode
        );

    return rc;
}




/******************************************************************************
 *
 * Function   :  PlxDmaStatus
 *
 * Description:  Read the status of a DMA transfer.
 *
 *****************************************************************************/
RETURN_CODE
PlxDmaStatus(
    HANDLE      hDevice,
    DMA_CHANNEL channel
    )
{
    IO_NODE     *pIoNode;
    RETURN_CODE  rc;


    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        return ApiInvalidHandle;
    }

    pIoNode = IoPoolGetNode();

    pIoNode->IoBuffer.u.DmaData.channel = channel;

    IoMessage(
        hDevice,
        PLX_IOCTL_DMA_STATUS,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    rc = pIoNode->IoBuffer.ReturnCode;

    IoPoolReleaseNode(
        pIoNode
        );

    return rc;
}




/******************************************************************************
 *
 * Function   :  PlxDmaBlockChannelOpen
 *
 * Description:  Open a channel to perform DMA Block transfers.
 *
 *****************************************************************************/
RETURN_CODE
PlxDmaBlockChannelOpen(
    HANDLE            hDevice,
    DMA_CHANNEL       channel,
    DMA_CHANNEL_DESC *pDesc
    )
{
    IO_NODE     *pIoNode;
    DEVICE_NODE *pDevice;
    RETURN_CODE  rc;


    if (pDesc == NULL)
        return ApiNullParam;

    // Verify the handle
    pDevice =
        DeviceListFind(
            hDevice
            );

    if (pDevice == NULL)
        return ApiInvalidHandle;

    pIoNode = IoPoolGetNode();

    pIoNode->IoBuffer.u.DmaData.channel = channel;
    pIoNode->IoBuffer.u.DmaData.u.desc  = *pDesc;

    IoMessage(
        hDevice,
        PLX_IOCTL_DMA_BLOCK_CHANNEL_OPEN,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    rc = pIoNode->IoBuffer.ReturnCode;

    IoPoolReleaseNode(
        pIoNode
        );

    // Build the DMA I/O buffers list if it hasn't been done
    if (pDevice->pDmaList == NULL)
    {
        DmaListBuild(
            pDevice
            );
    }

    return rc;
}




/******************************************************************************
 *
 * Function   :  PlxDmaBlockTransfer
 *
 * Description:  Start a Block DMA transfer
 *
 *****************************************************************************/
RETURN_CODE
PlxDmaBlockTransfer(
    HANDLE                hDevice,
    DMA_CHANNEL           channel,
    DMA_TRANSFER_ELEMENT *pDmaData,
    BOOLEAN               returnImmediate
    )
{
    DWORD        StatusCode;
    IO_NODE     *pDmaNode;
    DEVICE_NODE *pDevice;


    if (pDmaData == NULL)
        return ApiNullParam;

    // Verify the handle
    pDevice =
        DeviceListFind(
            hDevice
            );

    if (pDevice == NULL)
        return ApiInvalidHandle;

    pDmaNode =
        DmaListGetNode(
            pDevice,
            (U8)DmaIndex(channel)
            );

    if (pDmaNode == NULL)
        return ApiDmaChannelUnavailable;

    pDmaNode->IoBuffer.u.DmaData.channel    = channel;
    pDmaNode->IoBuffer.u.DmaData.u.TxParams = *pDmaData;
    pDmaNode->IoBuffer.ReturnCode           = ApiSuccess;

    /*************************************************************
     * Since this is an Asynchronous operation, the request will not
     * complete it until the interrupt or an error occurs.  In
     * that case, the return code is only valid in error conditions,
     * so we cannot rely on it; therefore, it is set beforehand.
     *************************************************************/

    IoMessage(
        hDevice,
        PLX_IOCTL_DMA_BLOCK_TRANSFER,
        &(pDmaNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pDmaNode->Overlapped)
        );

    // Don't wait for completion if requested not to
    if (returnImmediate)
        return pDmaNode->IoBuffer.ReturnCode;

    if (pDmaNode->IoBuffer.ReturnCode != ApiSuccess)
        return pDmaNode->IoBuffer.ReturnCode;

    StatusCode =
        WaitForSingleObject(
            pDmaNode->Overlapped.hEvent,
            MAX_DMA_TIMEOUT
            );

    switch (StatusCode)
    {
        case WAIT_OBJECT_0:
            return pDmaNode->IoBuffer.ReturnCode;

        case WAIT_TIMEOUT:
            return ApiPciTimeout;

        case WAIT_FAILED:
            return ApiFailed;
    }

    return ApiFailed;
}




/******************************************************************************
 *
 * Function   :  PlxDmaBlockChannelClose
 *
 * Description:  Close a previously opened DMA channel.
 *
 *****************************************************************************/
RETURN_CODE
PlxDmaBlockChannelClose(
    HANDLE      hDevice,
    DMA_CHANNEL channel
    )
{
    IO_NODE     *pIoNode;
    RETURN_CODE  rc;


    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        return ApiInvalidHandle;
    }

    pIoNode = IoPoolGetNode();

    pIoNode->IoBuffer.u.DmaData.channel = channel;

    IoMessage(
        hDevice,
        PLX_IOCTL_DMA_BLOCK_CHANNEL_CLOSE,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    rc = pIoNode->IoBuffer.ReturnCode;

    IoPoolReleaseNode(
        pIoNode
        );

    return rc;
}




/******************************************************************************
 *
 * Function   :  PlxDmaSglChannelOpen
 *
 * Description:  Open a channel to perform sgl transfers.
 *
 *****************************************************************************/
RETURN_CODE
PlxDmaSglChannelOpen(
    HANDLE            hDevice,
    DMA_CHANNEL       channel,
    DMA_CHANNEL_DESC *pDesc
    )
{
    IO_NODE     *pIoNode;
    DEVICE_NODE *pDevice;
    RETURN_CODE  rc;


    if (pDesc == NULL)
        return ApiNullParam;

    // Verify the handle
    pDevice =
        DeviceListFind(
            hDevice
            );

    if (pDevice == NULL)
        return ApiInvalidHandle;

    pIoNode = IoPoolGetNode();

    pIoNode->IoBuffer.u.DmaData.channel = channel;
    pIoNode->IoBuffer.u.DmaData.u.desc  = *pDesc;    

    IoMessage(
        hDevice,
        PLX_IOCTL_DMA_SGL_OPEN,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    rc = pIoNode->IoBuffer.ReturnCode;

    IoPoolReleaseNode(
        pIoNode
        );

    // Build the DMA I/O buffers list if it hasn't been done
    if (pDevice->pDmaList == NULL)
    {
        DmaListBuild(
            pDevice
            );
    }

    return rc;
}




/******************************************************************************
 *
 * Function   :  PlxDmaSglTransfer
 *
 * Description:  Start an SGL DMA transfer
 *
 *****************************************************************************/
RETURN_CODE
PlxDmaSglTransfer(
    HANDLE                hDevice,
    DMA_CHANNEL           channel,
    DMA_TRANSFER_ELEMENT *pDmaData,
    BOOLEAN               returnImmediate
    )
{
    DWORD        StatusCode;
    IO_NODE     *pDmaNode;
    DEVICE_NODE *pDevice;


    if (pDmaData == NULL)
        return ApiNullParam;

    // Verify the handle
    pDevice = DeviceListFind(
                  hDevice
                  );
    if (pDevice == NULL)
        return ApiInvalidHandle;

    pDmaNode = DmaListGetNode(
                   pDevice,
                   (U8)DmaIndex(channel)
                   );

    if (pDmaNode == NULL)
        return ApiDmaChannelUnavailable;

    // Copy parameter information
    pDmaNode->IoBuffer.u.DmaData.channel    = channel;
    pDmaNode->IoBuffer.u.DmaData.u.TxParams = *pDmaData;
    pDmaNode->IoBuffer.ReturnCode           = ApiSuccess;

    /*************************************************************
     * Since this is an Asynchronous operation, the request will not
     * complete it until the interrupt or an error occurs.  In
     * that case, the return code is only valid in error conditions,
     * so we cannot rely on it; therefore, it is set beforehand.
     *************************************************************/

    IoMessage(
        hDevice,
        PLX_IOCTL_DMA_SGL_TRANSFER,
        &(pDmaNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pDmaNode->Overlapped)
        );

    // Don't wait for completion if requested not to
    if (returnImmediate)
        return pDmaNode->IoBuffer.ReturnCode;

    if (pDmaNode->IoBuffer.ReturnCode != ApiSuccess)
        return pDmaNode->IoBuffer.ReturnCode;

    StatusCode =
        WaitForSingleObject(
            pDmaNode->Overlapped.hEvent, 
            MAX_DMA_TIMEOUT
            );

    switch (StatusCode)
    {
        case WAIT_OBJECT_0:
            return pDmaNode->IoBuffer.ReturnCode;

        case WAIT_TIMEOUT:
            return ApiPciTimeout;

        case WAIT_FAILED:
            return ApiFailed;
    }

    return ApiFailed;
}




/******************************************************************************
 *
 * Function   :  PlxDmaSglChannelClose
 *
 * Description:  Close a previously opened DMA channel.
 *
 *****************************************************************************/
RETURN_CODE
PlxDmaSglChannelClose(
    HANDLE      hDevice,
    DMA_CHANNEL channel
    )
{
    IO_NODE     *pIoNode;
    RETURN_CODE  rc;


    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        return ApiInvalidHandle;
    }

    pIoNode = IoPoolGetNode();

    pIoNode->IoBuffer.u.DmaData.channel = channel;

    IoMessage(
        hDevice,
        PLX_IOCTL_DMA_SGL_CLOSE,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    rc = pIoNode->IoBuffer.ReturnCode;

    IoPoolReleaseNode(
        pIoNode
        );

    return rc;
}




/******************************************************************************
 *
 * Function   :  PlxMuInboundPortRead
 *
 * Description:  Get a Message Frame. 
 *
 *****************************************************************************/
RETURN_CODE
PlxMuInboundPortRead(
    HANDLE  hDevice,
    U32    *pFrame
    )
{
    IO_NODE     *pIoNode;
    RETURN_CODE  rc;


    if (pFrame == NULL)
        return ApiNullParam;
    
    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        return ApiInvalidHandle;
    }

    pIoNode = IoPoolGetNode();

    IoMessage(
        hDevice,
        PLX_IOCTL_MU_INBOUND_PORT_READ,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    *pFrame = pIoNode->IoBuffer.u.MgmtData.value;

    rc = pIoNode->IoBuffer.ReturnCode;

    IoPoolReleaseNode(
        pIoNode
        );

    return rc;
}




/******************************************************************************
 *
 * Function   :  PlxMuInboundPortWrite
 *
 * Description:  Write a message frame to the Inbound Port.
 *
 *****************************************************************************/
RETURN_CODE
PlxMuInboundPortWrite(
    HANDLE  hDevice,
    U32    *pFrame
    )
{
    IO_NODE     *pIoNode;
    RETURN_CODE  rc;


    if (pFrame == NULL)
        return ApiNullParam;

    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        return ApiInvalidHandle;
    }

    pIoNode = IoPoolGetNode();

    pIoNode->IoBuffer.u.MgmtData.value = *pFrame;

    IoMessage(
        hDevice,
        PLX_IOCTL_MU_INBOUND_PORT_WRITE,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    rc = pIoNode->IoBuffer.ReturnCode;

    IoPoolReleaseNode(
        pIoNode
        );

    return rc;

}




/******************************************************************************
 *
 * Function   :  PlxMuOutboundPortRead
 *
 * Description:  Retrieve a posted message frame.
 *
 *****************************************************************************/
RETURN_CODE
PlxMuOutboundPortRead(
    HANDLE  hDevice,
    U32    *pFrame
    )
{
    IO_NODE     *pIoNode;
    RETURN_CODE  rc;


    if (pFrame == NULL)
        return ApiNullParam;

    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        return ApiInvalidHandle;
    }

    pIoNode = IoPoolGetNode();

    IoMessage(
        hDevice,
        PLX_IOCTL_MU_OUTBOUND_PORT_READ,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    *pFrame = pIoNode->IoBuffer.u.MgmtData.value;

    rc = pIoNode->IoBuffer.ReturnCode;

    IoPoolReleaseNode(
        pIoNode
        );

    return rc;
}




/******************************************************************************
 *
 * Function   :  PlxMuOutboundPortWrite
 *
 * Description:  Post a message to the Outbound Port.
 *
 *****************************************************************************/
RETURN_CODE
PlxMuOutboundPortWrite(
    HANDLE  hDevice,
    U32    *pFrame
    )
{
    IO_NODE     *pIoNode;
    RETURN_CODE  rc;


    if (pFrame == NULL)
        return ApiNullParam;

    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        return ApiInvalidHandle;
    }

    pIoNode = IoPoolGetNode();

    pIoNode->IoBuffer.u.MgmtData.value = *pFrame;

    IoMessage(
        hDevice,
        PLX_IOCTL_MU_OUTBOUND_PORT_WRITE,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    rc = pIoNode->IoBuffer.ReturnCode;

    IoPoolReleaseNode(
        pIoNode
        );

    return rc;
}




/******************************************************************************
 *
 * Function   :  PlxMuHostOutboundIndexRead
 *
 * Description:  Read the Messaging Unit's Outbound Index Register
 *
 *****************************************************************************/
U32
PlxMuHostOutboundIndexRead(
    HANDLE       hDevice,
    RETURN_CODE *pReturnCode
    )
{
    U32      RegValue;
    IO_NODE *pIoNode;


    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        if (pReturnCode != NULL)
            *pReturnCode = ApiInvalidHandle;
        return (U32)-1;
    }

    pIoNode = IoPoolGetNode();

    IoMessage(
        hDevice,
        PLX_IOCTL_MU_OUTINDEX_READ,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    if (pReturnCode != NULL)
        *pReturnCode = pIoNode->IoBuffer.ReturnCode;

    RegValue = pIoNode->IoBuffer.u.MgmtData.value;

    IoPoolReleaseNode(
        pIoNode
        );

    return RegValue;
}




/******************************************************************************
 *
 * Function   :  PlxMuHostOutboundIndexWrite
 *
 * Description:  Write to the Messaging Unit's Outbound Index Register
 *
 *****************************************************************************/
RETURN_CODE
PlxMuHostOutboundIndexWrite(
    HANDLE hDevice,
    U32    value
    )
{
    IO_NODE     *pIoNode;
    RETURN_CODE  rc;


    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        return ApiInvalidHandle;
    }

    pIoNode = IoPoolGetNode();

    pIoNode->IoBuffer.u.MgmtData.value = value;

    IoMessage(
        hDevice,
        PLX_IOCTL_MU_OUTINDEX_WRITE,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    rc = pIoNode->IoBuffer.ReturnCode;

    IoPoolReleaseNode(
        pIoNode
        );

    return rc;

}




/******************************************************************************
 *
 * Function   :  PlxPowerLevelGet
 *
 * Description:  Retrieve the Power Level from a PCI device
 *
 *****************************************************************************/
PLX_POWER_LEVEL
PlxPowerLevelGet(
    HANDLE       hDevice,
    RETURN_CODE *pReturnCode
    )
{
    IO_NODE         *pIoNode;
    PLX_POWER_LEVEL  PowerLevel;


    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        if (pReturnCode != NULL) 
            *pReturnCode = ApiInvalidHandle;
        return (PLX_POWER_LEVEL)(U32)-1;
    }

    pIoNode = IoPoolGetNode();

    IoMessage(
        hDevice,
        PLX_IOCTL_POWER_LEVEL_GET,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    if (pReturnCode != NULL) 
        *pReturnCode = pIoNode->IoBuffer.ReturnCode;

    PowerLevel = (PLX_POWER_LEVEL)(pIoNode->IoBuffer.u.MgmtData.value);

    IoPoolReleaseNode(
        pIoNode
        );

    return PowerLevel;
}




/******************************************************************************
 *
 * Function   :  PlxPowerLevelSet
 *
 * Description:  Set the power level of a PCI device.
 *
 *****************************************************************************/
RETURN_CODE
PlxPowerLevelSet(
    HANDLE          hDevice,
    PLX_POWER_LEVEL PowerLevel
    )
{
    IO_NODE     *pIoNode;
    RETURN_CODE  rc;


    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        return ApiInvalidHandle;
    }

    pIoNode = IoPoolGetNode();

    pIoNode->IoBuffer.u.MgmtData.value = (U32)PowerLevel;

    IoMessage(
        hDevice,
        PLX_IOCTL_POWER_LEVEL_SET,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    rc = pIoNode->IoBuffer.ReturnCode;

    IoPoolReleaseNode(
        pIoNode
        );

    return rc;
}




/******************************************************************************
 *
 * Function   :  PlxPmIdRead
 *
 * Description:  Read the Power Management ID value.
 *
 *****************************************************************************/
U8
PlxPmIdRead(
    HANDLE       hDevice,
    RETURN_CODE *pReturnCode
    )
{
    U8       RetValue;
    IO_NODE *pIoNode;


    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        if (pReturnCode != NULL)
            *pReturnCode = ApiInvalidHandle;
        return (U8)-1;
    }

    pIoNode = IoPoolGetNode();

    IoMessage(
        hDevice,
        PLX_IOCTL_PM_ID_READ,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    if (pReturnCode != NULL)
        *pReturnCode = pIoNode->IoBuffer.ReturnCode;

    RetValue = (U8)(pIoNode->IoBuffer.u.MgmtData.value);

    IoPoolReleaseNode(
        pIoNode
        );

    return RetValue;
}




/******************************************************************************
 *
 * Function   :  PlxPmNcpRead
 *
 * Description:  Read the PowerManagement Next Capablilities Pointer value
 *
 *****************************************************************************/
U8
PlxPmNcpRead(
    HANDLE       hDevice,
    RETURN_CODE *pReturnCode
    )
{
    U8       RetValue;
    IO_NODE *pIoNode;


    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        if (pReturnCode != NULL)
            *pReturnCode = ApiInvalidHandle;
        return (U8)-1;
    }

    pIoNode = IoPoolGetNode();

    IoMessage(
        hDevice,
        PLX_IOCTL_PM_NCP_READ,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    if (pReturnCode != NULL)
        *pReturnCode = pIoNode->IoBuffer.ReturnCode;

    RetValue = (U8)(pIoNode->IoBuffer.u.MgmtData.value);

    IoPoolReleaseNode(
        pIoNode
        );

    return RetValue;
}




/******************************************************************************
 *
 * Function   :  PlxHotSwapIdRead
 *
 * Description:  Read the Hot Swap ID value.
 *
 *****************************************************************************/
U8
PlxHotSwapIdRead(
    HANDLE       hDevice,
    RETURN_CODE *pReturnCode
    )
{
    U8       RetValue;
    IO_NODE *pIoNode;


    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        if (pReturnCode != NULL)
            *pReturnCode = ApiInvalidHandle;
        return (U8)-1;
    }

    pIoNode = IoPoolGetNode();

    IoMessage(
        hDevice,
        PLX_IOCTL_HS_ID_READ,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    if (pReturnCode != NULL)
        *pReturnCode = pIoNode->IoBuffer.ReturnCode;

    RetValue = (U8)(pIoNode->IoBuffer.u.MgmtData.value);

    IoPoolReleaseNode(
        pIoNode
        );

    return RetValue;
}




/******************************************************************************
 *
 * Function   :  PlxHotSwapNcpRead
 *
 * Description:  Read the HotSwap Next Capablilities Pointer value
 *
 *****************************************************************************/
U8
PlxHotSwapNcpRead(
    HANDLE       hDevice,
    RETURN_CODE *pReturnCode
    )
{
    U8       RetValue;
    IO_NODE *pIoNode;


    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        if (pReturnCode != NULL)
            *pReturnCode = ApiInvalidHandle;
        return (U8)-1;
    }

    pIoNode = IoPoolGetNode();

    IoMessage(
        hDevice,
        PLX_IOCTL_HS_NCP_READ,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    if (pReturnCode != NULL)
        *pReturnCode = (pIoNode->IoBuffer.ReturnCode);

    RetValue = (U8)(pIoNode->IoBuffer.u.MgmtData.value);

    IoPoolReleaseNode(
        pIoNode
        );

    return RetValue;
}




/******************************************************************************
 *
 * Function   :  PlxHotSwapStatus
 *
 * Description:  Report the status of the HotSwap Register.
 *
 *****************************************************************************/
U8
PlxHotSwapStatus(
    HANDLE       hDevice,
    RETURN_CODE *pReturnCode
    )
{
    U8       RetValue;
    IO_NODE *pIoNode;


    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        if (pReturnCode != NULL)
            *pReturnCode = ApiInvalidHandle;
        return (U8)-1;
    }

    pIoNode = IoPoolGetNode();

    IoMessage(
        hDevice,
        PLX_IOCTL_HS_STATUS,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    if (pReturnCode != NULL)
        *pReturnCode = pIoNode->IoBuffer.ReturnCode;

    RetValue = (U8)(pIoNode->IoBuffer.u.MgmtData.value);

    IoPoolReleaseNode(
        pIoNode
        );

    return RetValue;
}




/******************************************************************************
 *
 * Function   :  PlxVpdIdRead
 *
 * Description:  Read the Vital Product Data ID value.
 *
 *****************************************************************************/
U8
PlxVpdIdRead(
    HANDLE       hDevice,
    RETURN_CODE *pReturnCode
    )
{
    U8       RetValue;
    IO_NODE *pIoNode;


    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        if (pReturnCode != NULL)
            *pReturnCode = ApiInvalidHandle;
        return (U8)-1;
    }

    pIoNode = IoPoolGetNode();

    IoMessage(
        hDevice,
        PLX_IOCTL_VPD_ID_READ,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    if (pReturnCode != NULL)
        *pReturnCode = pIoNode->IoBuffer.ReturnCode;

    RetValue = (U8)(pIoNode->IoBuffer.u.MgmtData.value);

    IoPoolReleaseNode(
        pIoNode
        );

    return RetValue;
}




/******************************************************************************
 *
 * Function   :  PlxVpdNcpRead
 *
 * Description:  Read the Vital Product Data Next Capablilities Pointer
 *
 *****************************************************************************/
U8
PlxVpdNcpRead(
    HANDLE       hDevice,
    RETURN_CODE *pReturnCode
    )
{
    U8       RetValue;
    IO_NODE *pIoNode;


    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        if (pReturnCode != NULL)
            *pReturnCode = ApiInvalidHandle;
        return (U8)-1;
    }

    pIoNode = IoPoolGetNode();

    IoMessage(
        hDevice,
        PLX_IOCTL_VPD_NCP_READ,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    if (pReturnCode != NULL)
        *pReturnCode = pIoNode->IoBuffer.ReturnCode;

    RetValue = (U8)(pIoNode->IoBuffer.u.MgmtData.value);

    IoPoolReleaseNode(
        pIoNode
        );

    return RetValue;
}




/******************************************************************************
 *
 * Function   :  PlxVpdRead
 *
 * Description:  Read the Vpd Data
 *
 *****************************************************************************/
U32
PlxVpdRead(
    HANDLE       hDevice,
    U16          offset,
    RETURN_CODE *pReturnCode
    )
{
    U32      RetValue;
    IO_NODE *pIoNode;


    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        if (pReturnCode != NULL)
            *pReturnCode = ApiInvalidHandle;
        return (U32)-1;
    }

    pIoNode = IoPoolGetNode();

    pIoNode->IoBuffer.u.MgmtData.offset = offset;

    IoMessage(
        hDevice,
        PLX_IOCTL_VPD_READ,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    if (pReturnCode != NULL)
        *pReturnCode = pIoNode->IoBuffer.ReturnCode;

    RetValue = pIoNode->IoBuffer.u.MgmtData.value;

    IoPoolReleaseNode(
        pIoNode
        );

    return RetValue;
}




/******************************************************************************
 *
 * Function   :  PlxVpdWrite
 *
 * Description:  Write to the VPD location
 *
 *****************************************************************************/
RETURN_CODE
PlxVpdWrite(
    HANDLE hDevice,
    U16    offset,
    U32    value
    )
{
    IO_NODE     *pIoNode;
    RETURN_CODE  rc;


    // Verify the handle
    if (DeviceListFind(
            hDevice
            ) == NULL)
    {
        return ApiInvalidHandle;
    }

    pIoNode = IoPoolGetNode();

    pIoNode->IoBuffer.u.MgmtData.offset = offset;
    pIoNode->IoBuffer.u.MgmtData.value  = value;

    IoMessage(
        hDevice,
        PLX_IOCTL_VPD_WRITE,
        &(pIoNode->IoBuffer),
        sizeof(IOCTLDATA),
        &(pIoNode->Overlapped)
        );

    rc = pIoNode->IoBuffer.ReturnCode;

    IoPoolReleaseNode(
        pIoNode
        );

    return rc;
}




/***********************************************************
*
*                  PRIVATE FUNCTIONS
*
***********************************************************/
                              

/******************************************************************************
 *
 * Function   :  IoPoolGetNode
 *
 * Description:  Returns an I/O Node from a pool.  New structures are
 *               allocated on an as-needed basis.  An event handle is
 *               also allocated and inserted into the overlapped strucure.
 *
 * Returns    :  Pointer    - to an IO_NODE structure
 *               NULL       - if error 
 *
 *****************************************************************************/
IO_NODE *
IoPoolGetNode(
    VOID
    )
{
    IO_NODE *pIoNode;
    IO_NODE *pIoNodePrevious;


    LockGlobals();

    pIoNode = pApiIoPoolList;

    // Added to prevent compiler warning
    pIoNodePrevious = pIoNode;

    // Search for an unused already allocated node
    while (pIoNode != NULL)
    {
        if (pIoNode->InUse == FALSE)
        {
            pIoNode->InUse = TRUE;

            UnlockGlobals();

            pIoNode->Overlapped.Internal     = 0;
            pIoNode->Overlapped.InternalHigh = 0;
            pIoNode->Overlapped.Offset       = 0;
            pIoNode->Overlapped.OffsetHigh   = 0;

            return pIoNode;
        }

        pIoNodePrevious = pIoNode;
        pIoNode         = pIoNode->pNext;
    }

    // Allocate a new node
    pIoNode = (IO_NODE *)malloc(sizeof(IO_NODE));
    if (pIoNode == NULL)
    {
        UnlockGlobals();
        return NULL;
    }

    // Mark as In Use
    pIoNode->InUse = TRUE;

    // End the list
    pIoNode->pNext = NULL;

    // Add the node to the list
    if (pApiIoPoolList == NULL)
        pApiIoPoolList = pIoNode;
    else
        pIoNodePrevious->pNext = pIoNode;

    UnlockGlobals();

    // Allocate the event
    pIoNode->Overlapped.hEvent = 
        CreateEvent(
            NULL,          // Not inheritable to child processes
            TRUE,          // Manual reset?
            FALSE,         // Intial state
            NULL
            );

    pIoNode->Overlapped.Internal     = 0;
    pIoNode->Overlapped.InternalHigh = 0;
    pIoNode->Overlapped.Offset       = 0;
    pIoNode->Overlapped.OffsetHigh   = 0;

    return pIoNode;
}




/**********************************************
*          Device List Functions
**********************************************/

/******************************************************************************
 *
 * Function   :  DeviceListAdd
 *
 * Description:  Add a new node to the list with the provided handle
 *
 * Returns    :  Pointer    - to newly added node
 *               NULL       - if error 
 *
 *****************************************************************************/
DEVICE_NODE *
DeviceListAdd(
    HANDLE           hDevice,
    DEVICE_LOCATION *pLocation
    )
{
    U8           i;
    DEVICE_NODE  *pCurrentDevice;
    DEVICE_NODE  *pPreviousDevice;


    LockGlobals();

    pPreviousDevice = pApiDeviceList;

    if (pApiDeviceList != NULL)
    {
        while (pPreviousDevice->pNext != NULL)
        {
            pPreviousDevice = pPreviousDevice->pNext;
        }
    }

    // Allocate a new node
    pCurrentDevice = (DEVICE_NODE *)malloc(sizeof(DEVICE_NODE));

    if (pCurrentDevice == NULL)
    {
        UnlockGlobals();
        return NULL;
    }

    // Fill in new data
    pCurrentDevice->Handle     = hDevice;
    pCurrentDevice->pEventList = NULL;
    pCurrentDevice->pDmaList   = NULL;
    pCurrentDevice->pNext      = NULL;

    pCurrentDevice->Location = *pLocation;

    pCurrentDevice->PciMemory.UserAddr     = (U32)NULL;
    pCurrentDevice->PciMemory.PhysicalAddr = (U32)NULL;
    pCurrentDevice->PciMemory.Size         = 0;

    for (i = 0; i < PCI_NUM_BARS; i++)
    {
        pCurrentDevice->PciSpace[i].va            = (U32)NULL;
        pCurrentDevice->PciSpace[i].size          = 0;
        pCurrentDevice->PciSpace[i].offset        = 0;
        pCurrentDevice->PciSpace[i].bMapAttempted = FALSE;
    }

    // Adjust the pointers
    if (pApiDeviceList == NULL)
    {
        pApiDeviceList = pCurrentDevice;
    }
    else
    {
        pPreviousDevice->pNext = pCurrentDevice;
    }

    // Release access to globals
    UnlockGlobals();

    return pCurrentDevice;
}




/******************************************************************************
 *
 * Function   :  DeviceListRemove
 *
 * Description:  Remove the node in the list associated with a handle
 *
 * Returns    :  TRUE    - if sucessful
 *               FALSE   - if unable to remove/find node
 *
 *****************************************************************************/
BOOLEAN
DeviceListRemove(
    HANDLE hDevice
    )
{
    U8           i;
    BOOLEAN      DeviceFound;
    DEVICE_NODE *pCurrentDevice;
    DEVICE_NODE *pPreviousDevice;


    pCurrentDevice =
        DeviceListFind(
            hDevice
            );

    if (pCurrentDevice == NULL)
        return FALSE;

    // Unmap any leftover virtual addresses
    for (i = 0; i < PCI_NUM_BARS; i++)
    {
        PlxPciBarUnmap(
            hDevice,
            &(pCurrentDevice->PciSpace[i].va)
            );
    }

    // Unmap the common buffer
    if (pCurrentDevice->PciMemory.UserAddr != (U32)NULL)
    {
        PlxPciCommonBufferUnmap(
            hDevice,
            &(pCurrentDevice->PciMemory)
            );
    }

    LockGlobals();
    
    // Traverse device list to remove device
    pCurrentDevice = pApiDeviceList;

    // Added to prevent compiler warning
    pPreviousDevice = pCurrentDevice;

    // Search for the node in the Device List
    DeviceFound = FALSE;
    do
    {
        if (pCurrentDevice->Handle == hDevice)
            DeviceFound = TRUE;
        else
        {
            // Check for end of list
            if (pCurrentDevice->pNext == NULL)
            {
                UnlockGlobals();
                return FALSE;
            }

            pPreviousDevice = pCurrentDevice;
            pCurrentDevice  = pCurrentDevice->pNext;
        }
    }
    while (DeviceFound == FALSE);

    // Remove device from the list
    if (pApiDeviceList == pCurrentDevice)
    {
        pApiDeviceList = pCurrentDevice->pNext;
    }
    else
    {
        pPreviousDevice->pNext = pCurrentDevice->pNext;
    }

    // Release access to globals
    UnlockGlobals();

    // Clear the Event List
    if (pCurrentDevice->pEventList != NULL)
    {
        IoListDestroy(
            &(pCurrentDevice->pEventList)
            );
    }

    // Clear the DMA List
    if (pCurrentDevice->pDmaList != NULL)
    {
        IoListDestroy(
            &(pCurrentDevice->pDmaList)
            );
    }

    // Release memory
    free(
        pCurrentDevice
        );

    return TRUE;
}




/******************************************************************************
 *
 * Function   :  DeviceListFind
 *
 * Description:  Locate the node in the list associated with a handle
 *
 * Returns    :  Pointer   - if sucessful
 *               NULL      - if unable to find node
 *
 *****************************************************************************/
DEVICE_NODE *
DeviceListFind(
    HANDLE hDevice
    )
{
    DEVICE_NODE *pCurrentDevice;


    LockGlobals();

    pCurrentDevice = pApiDeviceList;

    // Search for the node in the Device List
    while (pCurrentDevice != NULL)
    {
        if (pCurrentDevice->Handle == hDevice)
        {
            UnlockGlobals();
            return pCurrentDevice;
        }

        pCurrentDevice = pCurrentDevice->pNext;
    }

    UnlockGlobals();

    return NULL;
}





/**********************************************
*           I/O List Functions
**********************************************/

/******************************************************************************
 *
 * Function   :  IoListAdd
 *
 * Description:  Add a new node to the provided list
 *
 * Returns    :  Pointer to newly added node or NULL, if error 
 *
 *****************************************************************************/
IO_NODE *
IoListAdd(
    IO_NODE **pIoList,
    HANDLE    hEvent
    )
{
    IO_NODE *pNewNode;
    IO_NODE *pCurrNode;


    // Allocate a new node
    pNewNode = (IO_NODE *)malloc(sizeof(IO_NODE));

    if (pNewNode == NULL)
    {
        return NULL;
    }

    pNewNode->pNext = NULL;

    // Clear the overlapped structure
    memset(
        &(pNewNode->Overlapped),
        0,
        sizeof(OVERLAPPED)
        );

    // Save the Event handle
    pNewNode->Overlapped.hEvent = hEvent;

    LockGlobals();

    if (*pIoList != NULL)
    {
        pCurrNode = *pIoList;

        while (pCurrNode->pNext != NULL)
        {
            pCurrNode = pCurrNode->pNext;
        }

        // Add node to the list
        pCurrNode->pNext = pNewNode;
    }
    else
    {
        *pIoList = pNewNode;
    }

    UnlockGlobals();

    return pNewNode;
}




/******************************************************************************
 *
 * Function   :  IoListRemove
 *
 * Description:  Remove the node from the provided list
 *
 * Returns    :  TRUE    - if sucessful
 *               FALSE   - if unable to remove/find node
 *
 *****************************************************************************/
BOOLEAN
IoListRemove(
    IO_NODE **pIoList,
    IO_NODE  *pIoNodeToRemove
    )
{
    BOOL     bFlag;
    DWORD    BytesTransferred;
    IO_NODE *pCurrentNode;
    IO_NODE *pPreviousNode;


    if (*pIoList == NULL)
        return FALSE;

    LockGlobals();

    pCurrentNode = *pIoList;

    // Added to prevent compiler warning
    pPreviousNode = pCurrentNode;

    // Search for the node in the Event List
    bFlag = FALSE;
    do
    {
        if (pCurrentNode == pIoNodeToRemove)
            bFlag = TRUE;
        else
        {
            // Check for end of list
            if (pCurrentNode->pNext == NULL)
            {
                UnlockGlobals();
                return FALSE;
            }

            pPreviousNode = pCurrentNode;
            pCurrentNode  = pCurrentNode->pNext;
        }
    }
    while (bFlag == FALSE);

    // Adjust the pointers
    if (*pIoList == pCurrentNode)
    {
        *pIoList = pCurrentNode->pNext;
    }
    else
    {
        pPreviousNode->pNext = pCurrentNode->pNext;
    }

    // Release access to globals
    UnlockGlobals();

    // Check the status of the Overlapped operation
    bFlag =
        GetOverlappedResult(
            pCurrentNode->Overlapped.hEvent,
            &(pCurrentNode->Overlapped),
            &BytesTransferred,
            FALSE           // Don't wait for completion
            );

    if (bFlag == FALSE)
    {
        if (GetLastError() == ERROR_IO_INCOMPLETE)
            return FALSE;
    }

    // Cleanup the Event Node if the operation has completed

    // Release the event handle
    CloseHandle(
        pCurrentNode->Overlapped.hEvent
        );

    // Release I/O node memory
    free(
        pCurrentNode
        );

    return TRUE;
}




/******************************************************************************
 *
 * Function   :  IoListFindByEventHandle
 *
 * Description:  Locate the node in the list associated with a handle
 *
 * Returns    :  Pointer   - if sucessful
 *               NULL      - if unable to find event node
 *
 *****************************************************************************/
IO_NODE *
IoListFindByEventHandle(
    IO_NODE *pIoList,
    HANDLE   hEvent
    )
{
    LockGlobals();

    // Search for the node in the list
    while (pIoList != NULL)
    {
        if (pIoList->Overlapped.hEvent == hEvent)
        {
            UnlockGlobals();
            return pIoList;
        }

        pIoList = pIoList->pNext;
    }

    UnlockGlobals();

    return NULL;
}




/******************************************************************************
 *
 * Function   :  IoListDestroy
 *
 * Description:  Empty a list of I/O nodes
 *
 *
 *****************************************************************************/
VOID
IoListDestroy(
    IO_NODE **pIoList
    )
{
    while (*pIoList != NULL)
    {
        IoListRemove(
            pIoList,
            *pIoList
            );
    }
}




/**********************************************
*             DMA List Functions
**********************************************/

/******************************************************************************
 *
 * Function   :  DmaListBuild
 *
 * Description:  Builds the DMA list associated with a device
 *
 *****************************************************************************/
BOOLEAN
DmaListBuild(
    DEVICE_NODE *pDevice
    )
{
    U8        i;
    IO_NODE  *pNewDma;
    IO_NODE  *pDmaList;


    // Added to prevent compiler warning
    pDmaList = NULL;

    LockGlobals();

    for (i=0; i<MAX_DMA_CHANNELS; i++)
    {
        // Allocate a new node
        pNewDma = (IO_NODE *)malloc(sizeof(IO_NODE));

        if (pNewDma == NULL)
        {
            UnlockGlobals();
            return FALSE;
        }

        // Clear the overlapped structure
        memset(
            &(pNewDma->Overlapped),
            0,
            sizeof(OVERLAPPED)
            );

        // Allocate the Event handle
        pNewDma->Overlapped.hEvent =
            CreateEvent(
                NULL,          // Not inheritable to child processes
                TRUE,          // Manual reset?
                FALSE,         // Intial state
                NULL
                );

        if (pNewDma->Overlapped.hEvent == NULL)
        {
            UnlockGlobals();
            free(
                pNewDma
                );
            return FALSE;
        }

        // Clear the next pointer
        pNewDma->pNext = NULL;

        // Add node to the list
        if (pDevice->pDmaList == NULL)
            pDevice->pDmaList = pNewDma;
        else
            pDmaList->pNext = pNewDma;

        pDmaList = pNewDma;
    }

    UnlockGlobals();

    return TRUE;
}




/******************************************************************************
 *
 * Function   :  DmaListGetNode
 *
 * Description:  Retrieves the node in the DMA list at an index
 *
 *****************************************************************************/
IO_NODE *
DmaListGetNode(
    DEVICE_NODE *pDevice,
    U8           index
    )
{
    U8       i;
    IO_NODE *pDmaNode;


    i = 0;

    LockGlobals();

    pDmaNode = pDevice->pDmaList;

    while (pDmaNode != NULL)
    {
        if (i == index)
        {
            UnlockGlobals();
            return pDmaNode;
        }

        i++;
        pDmaNode = pDmaNode->pNext;
    }

    UnlockGlobals();

    return NULL;
}
