/*******************************************************************************
 * Copyright (c) 2002 PLX Technology, Inc.
 *
 * PLX Technology Inc. licenses this software under specific terms and
 * conditions.  Use of any of the software or derviatives thereof in any
 * product without a PLX Technology chip is strictly prohibited.
 *
 * PLX Technology, Inc. provides this software AS IS, WITHOUT ANY WARRANTY,
 * EXPRESS OR IMPLIED, INCLUDING, WITHOUT LIMITATION, ANY WARRANTY OF
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  PLX makes no guarantee
 * or representations regarding the use of, or the results of the use of,
 * the software and documentation in terms of correctness, accuracy,
 * reliability, currentness, or otherwise; and you rely on the software,
 * documentation and results solely at your own risk.
 *
 * IN NO EVENT SHALL PLX BE LIABLE FOR ANY LOSS OF USE, LOSS OF BUSINESS,
 * LOSS OF PROFITS, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES
 * OF ANY KIND.  IN NO EVENT SHALL PLX'S TOTAL LIABILITY EXCEED THE SUM
 * PAID TO PLX FOR THE PRODUCT LICENSED HEREUNDER.
 *
 ******************************************************************************/

/******************************************************************************
 *
 * File Name:
 *
 *      IntEvt.c
 *
 * Description:
 *
 *      The "Interrupt Event" sample application, which demonstrates how to
 *      register and wait for specific interrupt events using the PLX API.
 *
 * Revision History:
 *
 *      04-31-02 : PCI SDK v3.50
 *
 ******************************************************************************/


#include "PlxApi.h"

#if defined(_WIN32)
    #include "..\\Common\\ConsFunc.h"
    #include "..\\Common\\PlxInit.h"
#endif

#if defined(PLX_LINUX)
    #include "ConsFunc.h"
    #include "PlxInit.h"
#endif

#include "Reg9030.h"    // Used for triggering local interrupt on these chips
#include "Reg9050.h"




/**********************************************
*               Globals
**********************************************/
volatile U8 ThreadStatus;
U32         ChipType;




/**********************************************
*               Functions
**********************************************/
void
TestAttachDma(
    HANDLE hDevice
    );

DWORD WINAPI
InterruptAttachThreadDma(
    LPVOID pParam
    );

void
TestAttachLocalInt(
    HANDLE hDevice
    );

DWORD WINAPI
InterruptAttachThreadLocalInt(
    LPVOID pParam
    );





/******************************************************************************
 *
 * Function   :  main
 *
 * Description:  The main entry point
 *
 *****************************************************************************/
int 
main(
    void
    )
{
    S8              DeviceSelected;
    U8              Revision;
    HANDLE          hDevice;
    RETURN_CODE     rc;
    DEVICE_LOCATION Device;


    ConsoleInitialize();

    Cls();

    PlxPrintf("\n\n");
    PlxPrintf("\t\t   PLX Interrupt Attach Sample Application\n");
    PlxPrintf("\t\t             January 2001\n");


    /************************************
    *         Select Device
    ************************************/
    DeviceSelected =
        SelectDevice(
            &Device
            );

    if (DeviceSelected == -1)
    {
        ConsoleEnd();
        exit(0);
    }

    rc =
        PlxPciDeviceOpen(
            &Device,
            &hDevice
            );

    if (rc != ApiSuccess)
    {
        PlxPrintf("\n   ERROR: Unable to find or select a PLX device\n");

        _Pause;

        ConsoleEnd();

        exit(-1);
    }

    PlxPrintf(
        "\nSelected: %.4x %.4x [bus %.2x  slot %.2x]\n\n",
        Device.DeviceId, Device.VendorId,
        Device.BusNumber, Device.SlotNumber
        );



    /************************************
    *        Perform the Test
    ************************************/
    PlxChipTypeGet(
        hDevice,
        &ChipType,
        &Revision
        );

    switch (ChipType)
    {
        case 0x9030:
        case 0x9050:
            TestAttachLocalInt(
                hDevice
                );
            break;

        case 0x9080:
        case 0x9054:
        case 0x9056:
        case 0x9656:
        case 0x0480:
            TestAttachDma(
                hDevice
                );
            break;

        default:
            PlxPrintf("\nERROR:  Undefined PLX Chip type\n");
            break;
    }




    /************************************
    *        Close the Device
    ************************************/
    PlxPciDeviceClose(
        hDevice
        );

    _Pause;

    PlxPrintf("\n\n");

    ConsoleEnd();

    exit(0);
}




/********************************************************
*
********************************************************/
void
TestAttachDma(
    HANDLE hDevice
    )
{
    U32                   LocalAddress;
    DWORD                 pThreadId;
    PCI_MEMORY            PciBuffer;
    RETURN_CODE           rc;
    DMA_CHANNEL_DESC      DmaDesc;
    DMA_TRANSFER_ELEMENT  DmaData;


    PlxPrintf(
        "Description:\n"
        "     This sample will test the Interrupt Attach API by\n"
        "     initiating a Block DMA transfer and waiting for the\n"
        "     DMA interrupt.  The attach and wait operation is\n"
        "     performed in a separate thread, allowing the main\n"
        "     thread to continue processing if it wishes.\n"
        );

    PlxPrintf(
        "\n"
        " WARNING: There is no safeguard mechanism to protect against invalid\n"
        "          local bus addresses.  Please be careful when selecting local\n"
        "          addresses to transfer data to/from.  System crashes will result\n"
        "          if an invalid address is accessed.\n"
        "\n\n"
        );

    PlxPrintf("Please enter a valid local address --> ");
    Plx_scanf("%x", &LocalAddress);
    PlxPrintf("\n");

    // Get DMA buffer parameters
    PlxPciCommonBufferProperties(
        hDevice,
        &PciBuffer
        );


    // Initialize the DMA channel
    DmaDesc.EnableReadyInput         = 1;
    DmaDesc.EnableBTERMInput         = 0;
    DmaDesc.EnableIopBurst           = 0;
    DmaDesc.EnableWriteInvalidMode   = 0;
    DmaDesc.EnableDmaEOTPin          = 0;
    DmaDesc.DmaStopTransferMode      = AssertBLAST;
    DmaDesc.HoldIopAddrConst         = 0;
    DmaDesc.HoldIopSourceAddrConst   = 0;
    DmaDesc.HoldIopDestAddrConst     = 0;
    DmaDesc.DemandMode               = 0;
    DmaDesc.EnableTransferCountClear = 0;
    DmaDesc.WaitStates               = 0;
    DmaDesc.IopBusWidth              = 2;   // 32-bit
    DmaDesc.EOTEndLink               = 0;
    DmaDesc.ValidStopControl         = 0;
    DmaDesc.ValidModeEnable          = 0;
    DmaDesc.EnableDualAddressCycles  = 0;
    DmaDesc.Reserved1                = 0;
    DmaDesc.TholdForIopWrites        = 0;
    DmaDesc.TholdForIopReads         = 0;
    DmaDesc.TholdForPciWrites        = 0;
    DmaDesc.TholdForPciReads         = 0;
    DmaDesc.EnableFlybyMode          = 0;
    DmaDesc.FlybyDirection           = 0;
    DmaDesc.EnableDoneInt            = 1;
    DmaDesc.Reserved2                = 0;
    DmaDesc.DmaChannelPriority       = Channel0Highest;

    PlxPrintf("  Opening Block DMA Channel 0.... ");
    rc =
        PlxDmaBlockChannelOpen(
            hDevice,
            PrimaryPciChannel0,
            &DmaDesc
            );

    if (rc == ApiSuccess)
        PlxPrintf("Ok\n");
    else
        PlxPrintf("*ERROR* - Unable to open DMA channel, rc=%s\n", PlxSdkErrorText(rc));


    PlxPrintf("  Spawning Attach thread......... ");

    ThreadStatus = 0;

    CreateThread(
        NULL,                          // Security
        0,                             // Same stack size
        InterruptAttachThreadDma,      // Thread start routine
        (LPVOID)hDevice,               // Handle parameter
        0,                             // Creation flags
        &pThreadId                     // Thread ID
        );

    // Wait till thread starts
    while (ThreadStatus != 1)
        Sleep(1);

    // Transfer the Data
    DmaData.u.PciAddrLow      = PciBuffer.PhysicalAddr;
    DmaData.PciAddrHigh       = 0x0;
    DmaData.LocalAddr         = LocalAddress;
    DmaData.TransferCount     = 0x10;
    DmaData.LocalToPciDma     = 1;
    DmaData.TerminalCountIntr = 0;

    PlxPrintf("  Transferring DMA Block (Ch 0).. Ok\n");
    PlxPrintf("  Waiting for DMA Interrupt...... ");

    rc =
        PlxDmaBlockTransfer(
            hDevice,
            PrimaryPciChannel0,
            &DmaData,
            TRUE
            );

    if (rc != ApiSuccess)
        PlxPrintf("*ERROR* - Unable to transer DMA, rc=%s\n", PlxSdkErrorText(rc));


    // Wait till threads receive interrupt
    while (ThreadStatus != 2)
        Sleep(1);


    PlxPrintf("\n");


    // Close DMA Channels
    PlxPrintf("  Closing Block DMA Channel 0.... ");
    rc =
        PlxDmaBlockChannelClose(
            hDevice,
            PrimaryPciChannel0
            );

    if (rc == ApiSuccess)
        PlxPrintf("Ok\n");
    else
        PlxPrintf("*ERROR* - Unable to close DMA, rc=%s\n", PlxSdkErrorText(rc));
}




/********************************************************
*
********************************************************/
DWORD WINAPI
InterruptAttachThreadDma(
    LPVOID pParam
    )
{
    DWORD         EventStatus;
    HANDLE        hDevice;
    static HANDLE hInterruptEvent;
    PLX_INTR      PlxInterrupt;


    PlxPrintf("Ok (Thread started)\n");

    hDevice = (HANDLE)pParam;

    // Clear interrupt fields
    memset(
        &PlxInterrupt,
        0,
        sizeof(PLX_INTR)
        );

    PlxPrintf("  Attach Event to DMA Ch 0 Int... ");
    PlxInterrupt.PciDmaChannel0 = 1;
    PlxIntrAttach(
        hDevice,
        PlxInterrupt,
        &hInterruptEvent
        );

    PlxPrintf("Ok (hEvent=0x%08x)\n", hInterruptEvent);

    // Signal that thread is ready
    ThreadStatus = 1;

    // Wait for interrupt event
    EventStatus =
        WaitForSingleObject(
            hInterruptEvent,
            10 * 1000
            );

    switch (EventStatus)
    {
        case WAIT_OBJECT_0:
            PlxPrintf("*DMA Ch 0 Int Rcvd*  ");
            break;

        case WAIT_TIMEOUT:
            PlxPrintf("*DMA Ch 0 Timeout*  ");
            break;

        case WAIT_FAILED:
            PlxPrintf("*ERROR* - Failed while waiting for interrupt\n");
            break;

        default:
            PlxPrintf("*ERROR* - Unknown, EventStatus = 0x%08x\n", EventStatus);
            break;
    }

    // Signal that thread is exiting
    ThreadStatus = 2;

    return 0;
}




/********************************************************
*
********************************************************/
void
TestAttachLocalInt(
    HANDLE hDevice
    )
{
    U16          OffsetRegInt;
    U32          RegisterValue;
    DWORD        pThreadId;
    HANDLE       ThreadHandle;
    PLX_INTR     PlxInterrupt;
    RETURN_CODE  rc;


    PlxPrintf(
        "Description:\n"
        "     This sample will test the Interrupt Attach API by\n"
        "     manually triggering a local interrupt of the PLX\n"
        "     chip.  This is done by inverting the polarity which\n"
        "     force the interrupt to go active.  The attach and wait\n"
        "     operation is performed in a separate thread, allowing\n"
        "     the main thread to continue processing if it wishes.\n"
        "\n"
        );

    _Pause;

    switch (ChipType)
    {
        case 0x9030:
            OffsetRegInt = PCI9030_INT_CTRL_STAT;
            break;

        case 0x9050:
            OffsetRegInt = PCI9050_INT_CTRL_STAT;
            break;

        default:
            PlxPrintf("\nERROR:  Undefined PLX Chip type\n");
            return;
    }

    // Clear Interrupt fields
    memset(
        &PlxInterrupt,
        0,
        sizeof(PLX_INTR)
        );

    PlxPrintf("  Enable Local & PCI Ints........ ");
    PlxInterrupt.PciMainInt    = 1;
    PlxInterrupt.IopToPciInt   = 1;
    PlxInterrupt.IopToPciInt_2 = 1;
    rc =
        PlxIntrEnable(
            hDevice,
            &PlxInterrupt
            );

    if (rc != ApiSuccess)
        PlxPrintf("*ERROR* - Intr Enable failed, code = %s\n", PlxSdkErrorText(rc));
    else
        PlxPrintf("Ok\n");


    PlxPrintf("  Spawning Attach Thread......... ");

    ThreadStatus = 0;

    ThreadHandle =
        CreateThread(
            NULL,                          // Security
            0,                             // Same stack size
            InterruptAttachThreadLocalInt, // Thread start routine
            (LPVOID)hDevice,               // Handle parameter
            0,                             // Creation flags
            &pThreadId                     // Thread ID
            );

    if (ThreadHandle == NULL)
    {
        PlxPrintf("*ERROR* - CreateThread() failed\n");
        return;
    }

    // Delay to let thread start
    Sleep(500);

    PlxPrintf("  Waiting for Interrupt Events... ");

    // Delay a bit before triggering interrupt
    Sleep(500);

    // Get Interrupt Control/Status register
    RegisterValue =
        PlxRegisterRead(
            hDevice,
            OffsetRegInt,
            &rc
            );

    // Write to polarity to trigger interrupt 1
    PlxRegisterWrite(
        hDevice,
        OffsetRegInt,
        RegisterValue | (1 << 1)
        );

    // Delay for a bit
    Sleep(300);


    while (ThreadStatus == 0)
        Sleep(1);

    PlxPrintf("\n");


    // Clear Polarity bits
    PlxRegisterWrite(
        hDevice,
        OffsetRegInt,
        RegisterValue & ~((1 << 1) | (1 << 4))
        );


    // Clear interrupt fields
    memset(
        &PlxInterrupt,
        0,
        sizeof(PLX_INTR)
        );

    // Verify we received a Local 1 Interrupt
    PlxPrintf("  Last interrupt reported........ ");
    rc =
        PlxIntrStatusGet(
            hDevice,
            &PlxInterrupt
            );

    if (rc != ApiSuccess)
        PlxPrintf("*ERROR* - PlxIntrStatusGet() failed, code = %s\n", PlxSdkErrorText(rc));
    else
    {
        if (PlxInterrupt.IopToPciInt == 1)
        {
            PlxPrintf("Local Interrupt 1\n");
        }
        else
        {
            PlxPrintf("*ERROR* - No interrupt reported\n");
        }
    }
}




/********************************************************
*
********************************************************/
DWORD WINAPI
InterruptAttachThreadLocalInt(
    LPVOID pParam
    )
{
    DWORD        EventStatus;
    HANDLE       hDevice;
    HANDLE       hInterruptEvent;
    PLX_INTR     PlxInterrupt;
    RETURN_CODE  rc;


    PlxPrintf("Ok (Thread started)\n");

    hDevice = (HANDLE)pParam;

    // Clear interrupt fields
    memset(
        &PlxInterrupt,
        0,
        sizeof(PLX_INTR)
        );

    PlxPrintf("  Attach Event to Interrupt 1.... ");
    PlxInterrupt.PciMainInt  = 0;
    PlxInterrupt.IopToPciInt = 1;
    rc =
        PlxIntrAttach(
            hDevice,
            PlxInterrupt,
            &hInterruptEvent
            );

    if (rc != ApiSuccess)
    {
        PlxPrintf("*ERROR* - Attach failed, rc=%s\n", PlxSdkErrorText(rc));
        ThreadStatus = 2;;
        return 0;
    }
    PlxPrintf("Ok (hEvent=0x%08x)\n", hInterruptEvent);


    // Wait for interrupt event
    EventStatus =
        WaitForSingleObject(
            hInterruptEvent,
            10 * 1000
            );

    switch (EventStatus)
    {
        case WAIT_OBJECT_0:
            PlxPrintf("*Local Int Rcvd*  ");
            break;

        case WAIT_TIMEOUT:
            PlxPrintf("*Local Int Timeout* ");
            break;

        case WAIT_FAILED:
            PlxPrintf("*ERROR* - Failed while waiting for interrupt\n");
            break;

        default:
            PlxPrintf("*ERROR* - Unknown, EventStatus = 0x%08x\n", EventStatus);
            break;
    }

    ThreadStatus = 2;

    return 0;
}
