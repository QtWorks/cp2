/*******************************************************************************
 * Copyright (c) 2002 PLX Technology, Inc.
 *
 * PLX Technology Inc. licenses this software under specific terms and
 * conditions.  Use of any of the software or derviatives thereof in any
 * product without a PLX Technology chip is strictly prohibited.
 *
 * PLX Technology, Inc. provides this software AS IS, WITHOUT ANY WARRANTY,
 * EXPRESS OR IMPLIED, INCLUDING, WITHOUT LIMITATION, ANY WARRANTY OF
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  PLX makes no guarantee
 * or representations regarding the use of, or the results of the use of,
 * the software and documentation in terms of correctness, accuracy,
 * reliability, currentness, or otherwise; and you rely on the software,
 * documentation and results solely at your own risk.
 *
 * IN NO EVENT SHALL PLX BE LIABLE FOR ANY LOSS OF USE, LOSS OF BUSINESS,
 * LOSS OF PROFITS, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES
 * OF ANY KIND.  IN NO EVENT SHALL PLX'S TOTAL LIABILITY EXCEED THE SUM
 * PAID TO PLX FOR THE PRODUCT LICENSED HEREUNDER.
 *
 ******************************************************************************/

/******************************************************************************
 *
 * File Name:
 *
 *      SglNoApi.c
 *
 * Description:
 *
 *      This sample demonstrates how to manually setup an SGL DMA transfer.
 *
 * Revision History:
 *
 *      05-31-02 : PCI SDK v3.50
 *
 ******************************************************************************/


/******************************************************************************
 *
 * NOTE:
 *
 * This sample is provided for those needing direct control over the SGL
 * descriptors in a DMA transfer.  Because an Operating System is present
 * (i.e. Windows), the PlxDmaSglTransfer() API call must build SGL descriptors
 * for the scattered pages of a user-mode buffer.  This happens inside the
 * driver, so it's is all transparent to a user application.  Hence, no control
 * over the SGL descriptors is possible.  The Windows memory manager determines
 * how a buffer is scattered.
 *
 * In this sample, the SGL API call is bypassed and the SGL DMA is manually
 * controlled by the application.  Since a valid PCI physical address is needed,
 * the Common Buffer allocated by the driver is used.  The virtual address, physical
 * address, and size of this buffer are available.  The buffer is also contiguous
 * in memory and is reserved for use by applications.  The driver itself does not
 * use the buffer.  These properties make it a perfect candidate for DMA transfers.
 *
 * As an additional note, management of the buffer is left up to applications.
 * This involves memory usage and synchronization if multiple threads/applications
 * plan to use the buffer simultaneously.  The OS provides mechanisms for shared
 * memory synchronization, which is not shown here.  Note that in this scenario,
 * the PLX chip/DMA engine is considered another "user" of this memory during
 * DMA transfers, so care must be taken.
 *
 * Users will notice that the code presented here is somewhat complex.  This
 * is due to the fact that the PLX chip must be accessed at a register-level,
 * rather than at the API level.  Some portability of code is lost and the code
 * will not be as easily maintainable.  The cleanest approach possible was taken
 * here and some code can be removed if only a single PLX chip must be supported.
 * This sample is intended for use with any PLX chip and is written accordingly.
 ******************************************************************************/


#include "PlxApi.h"

#if defined(_WIN32)
    #include "..\\Common\\ConsFunc.h"
    #include "..\\Common\\PlxInit.h"
#endif

#if defined(PLX_LINUX)
    #include "ConsFunc.h"
    #include "PlxInit.h"
#endif




/**********************************************
*               Functions
**********************************************/
BOOLEAN
SetupDmaDescriptors(
    HANDLE  hDevice,
    U32    *pSglPciAddress
    );

void 
PerformSglDmaTransfer(
    HANDLE hDevice,
    U32    SglPciAddress
    );




/******************************************************************************
 *
 * Function   :  main
 *
 * Description:  The main entry point
 *
 *****************************************************************************/
int
main(
    void
    )
{
    S8              DeviceSelected;
    U32             SglPciAddress;
    HANDLE          hDevice;
    RETURN_CODE     rc;
    DEVICE_LOCATION Device;


    ConsoleInitialize();

    Cls();

    PlxPrintf("\n\n");
    PlxPrintf("\t\t PLX SGL Without API Sample Application\n");
    PlxPrintf("\t\t              October 2001\n");


    /************************************
    *         Select Device
    ************************************/
    DeviceSelected =
        SelectDevice(
            &Device
            );

    if (DeviceSelected == -1)
    {
        ConsoleEnd();
        exit(0);
    }

    rc =
        PlxPciDeviceOpen(
            &Device,
            &hDevice
            );

    if (rc != ApiSuccess)
    {
        PlxPrintf("\n   ERROR: Unable to find or select a PLX device\n");

        _Pause;

        ConsoleEnd();

        exit(-1);
    }

    PlxPrintf(
        "\nSelected: %.4x %.4x [bus %.2x  slot %.2x]\n\n",
        Device.DeviceId, Device.VendorId,
        Device.BusNumber, Device.SlotNumber
        );



    /*******************************************************
    * First, setup The DMA descriptors in PCI memory
    *******************************************************/
    if (SetupDmaDescriptors(
            hDevice,
            &SglPciAddress
            ) == TRUE)
    {
        PerformSglDmaTransfer(
            hDevice,
            SglPciAddress
            );
    }



    /************************************
    *        Close the Device
    ************************************/
    PlxPciDeviceClose(
        hDevice
        );

    _Pause;

    PlxPrintf("\n\n");

    ConsoleEnd();

    exit(0);
}




/******************************************************************************
 *
 * Function   :  SetupDmaDescriptors
 *
 * Description:  This function sets up DMA SGL descriptors in the DMA common
 *               buffer provided by the PLX driver.  The goal here is to
 *               transfer 2 blocks of data, resulting in the need for 2
 *               SGL descriptors.  The descriptors are placed at the start
 *               of the common buffer, followed by the buffers for the data.
 *
 *               After this function completes, the common buffer should look
 *               similar to the following:
 *
 *
 *              Offset  __________________________
 *                     |                          |
 *                00h  |     First Descriptor     |
 *                     |        (16 bytes)        |
 *                     |--------------------------|
 *                     |                          |
 *                10h  |     Second Decriptor     |
 *                     |        (16 bytes)        |
 *                     |--------------------------|
 *                     |                          |
 *                      \/\/\/\/\/\/\/\/\/\/\/\/\/
 *
 *                      /\/\/\/\/\/\/\/\/\/\/\/\/\
 *                     |                          |
 *               100h  |     First data buffer    |
 *                     |        (256 bytes)       |
 *                     |--------------------------|
 *                     |                          |
 *               200h  |    Second data buffer    |
 *                     |        (256 bytes)       |
 *                     |__________________________| 
 *
 *****************************************************************************/
BOOLEAN
SetupDmaDescriptors(
    HANDLE  hDevice,
    U32    *pSglPciAddress
    )
{
    U8          SglOffsetPci;
    U8          SglOffsetLocal;
    U8          SglOffsetCount;
    U8          SglOffsetNextDesc;
    U8          Revision;
    U32         ChipType;
    U32         pBuffer;
    U32         LocalAddress;
    PCI_MEMORY  PciBuffer;
    RETURN_CODE rc;


    PlxChipTypeGet(
        hDevice,
        &ChipType,
        &Revision
        );

    // The descriptor organization varies by chip type
    switch (ChipType)
    {
        case 0x9050:
        case 0x9030:
            *pSglPciAddress = 0;
            PlxPrintf("ERROR: DMA not supported by the selected device\n");
            return FALSE;

        case 0x9080:
        case 0x9054:
        case 0x9056:
        case 0x9656:
            SglOffsetPci      = 0x0;
            SglOffsetLocal    = 0x4;
            SglOffsetCount    = 0x8;
            SglOffsetNextDesc = 0xc;
            break;

        default:
            *pSglPciAddress = 0;
            PlxPrintf("ERROR: Unsupported PLX chip (%X)\n", ChipType);
            return FALSE;
    }



    /************************************************
    *
    *            Get a local address
    *
    ************************************************/
    PlxPrintf(
        "Description:\n"
        "     This sample will demonstrate a manual SGL DMA transfer.\n"
        "     It will transfer 2 blocks of data from the common buffer\n"
        "     using DMA chaining and wait for the DMA interrupt.\n"
        );

    PlxPrintf(
        "\n"
        " WARNING: There is no safeguard mechanism to protect against invalid\n"
        "          local bus addresses.  Please be careful when selecting local\n"
        "          addresses to transfer data to/from.  System crashes will result\n"
        "          if an invalid address is accessed.\n"
        "\n\n"
        );

    PlxPrintf("Please enter a valid local address --> ");
    Plx_scanf("%x", &LocalAddress);
    PlxPrintf("\n");



    /************************************************
    *
    *         Get Common buffer information
    *
    ************************************************/
    PlxPrintf("  Getting Common Buffer info..... ");

    rc =
        PlxPciCommonBufferProperties(
            hDevice,
            &PciBuffer
            );

    if (rc != ApiSuccess)
    {
        *pSglPciAddress = 0;
        PlxPrintf("ERROR - rc=%s\n", PlxSdkErrorText(rc));
        return FALSE;
    }
    PlxPrintf("Ok (PCI Addr=%08x)\n", PciBuffer.PhysicalAddr);


    PlxPrintf("  Get virtual addr for buffer.... ");
    rc =
        PlxPciCommonBufferMap(
            hDevice,
            &(PciBuffer.UserAddr)
            );

    if (rc != ApiSuccess)
    {
        *pSglPciAddress = 0;
        PlxPrintf("ERROR - rc=%s\n", PlxSdkErrorText(rc));
        return FALSE;
    }
    PlxPrintf("Ok (VA=%08x)\n", PciBuffer.UserAddr);

    pBuffer = PciBuffer.UserAddr;

    // Align buffer address to 16 byte boundary (required by DMA engine)
    while (PciBuffer.PhysicalAddr & 0xF)
    {
        pBuffer                += 1;
        PciBuffer.PhysicalAddr += 1;
    }



    /************************************************
    *
    *          Write first DMA descriptor
    *
    ************************************************/
    PlxPrintf("  Write first DMA Descriptor..... ");

    // PCI physical address of data buffer
    *(U32*)(pBuffer + SglOffsetPci)      = PciBuffer.PhysicalAddr + 0x100;

    // Local address
    *(U32*)(pBuffer + SglOffsetLocal)    = LocalAddress;

    // Number of bytes to transfer
    *(U32*)(pBuffer + SglOffsetCount)    = 0x100;

    // Next Desc Address & Local->PCI & Desc in PCI space
    *(U32*)(pBuffer + SglOffsetNextDesc) = (PciBuffer.PhysicalAddr + 0x10) |
                                                       (1 << 3) | (1 << 0);
    PlxPrintf("Ok\n");


    // Increment to next descriptor
    pBuffer += 0x10;



    /************************************************
    *
    *          Write second DMA descriptor
    *
    ************************************************/
    PlxPrintf("  Write second DMA Descriptor.... ");

    // PCI physical address of data buffer
    *(U32*)(pBuffer + SglOffsetPci)      = PciBuffer.PhysicalAddr + 0x200;

    // Local address
    *(U32*)(pBuffer + SglOffsetLocal)    = LocalAddress + 0x100;

    // Number of bytes to transfer
    *(U32*)(pBuffer + SglOffsetCount)    = 0x100;

    // Next Desc Address & Local->PCI & End of chain & Desc in PCI space
    *(U32*)(pBuffer + SglOffsetNextDesc) = 0x0 | (1 << 3) | (1 << 1) | (1 << 0);

    PlxPrintf("Ok\n");
   

    // Provide PCI address of first descriptor
    *pSglPciAddress = PciBuffer.PhysicalAddr;


    PlxPrintf("  Unmap virtual addr of buffer... ");
    rc =
        PlxPciCommonBufferUnmap(
            hDevice,
            &(PciBuffer.UserAddr)
            );

    if (rc != ApiSuccess)
    {
        PlxPrintf("ERROR - rc=%s\n", PlxSdkErrorText(rc));
    }
    else
    {
        PlxPrintf("Ok\n");
    }

    return TRUE;
}




/******************************************************************************
 *
 * Function   :  PerformSglDmaTransfer
 *
 * Description:  Initiates the SGL DMA transfer and waits for completion
 *
 *****************************************************************************/
void
PerformSglDmaTransfer(
    HANDLE hDevice,
    U32    SglPciAddress
    )
{
    U8          Revision;
    U16         OffsetDescr;
    U16         OffsetDmaCmd;
    U32         ChipType;
    U32         RegValue;
    HANDLE      hInterruptEvent;
    PLX_INTR    PlxInterrupt;
    RETURN_CODE rc;
#if defined(_WIN32)
    DWORD       EventStatus;
#endif


    // Clear interrupt fields
    memset(
        &PlxInterrupt,
        0,
        sizeof(PLX_INTR)
        );

    PlxChipTypeGet(
        hDevice,
        &ChipType,
        &Revision
        );

    switch (ChipType)
    {
        case 0x9080:
        case 0x9054:
        case 0x9056:
        case 0x9656:
            OffsetDescr  = 0x90;
            OffsetDmaCmd = 0xa8;

            /**********************************************
             * Set DMA mode to:
             *
             * - 32-bit bus
             * - Ready Input
             * - DMA Chaining
             * - DMA Done interrupt enabled
             * - Route DMA interrupt to PCI
             *********************************************/
            PlxRegisterWrite(
                hDevice,
                0x80,             // DMA 0 Mode offset
                0x00020642
                );
            break;

        default:
            PlxPrintf("ERROR: Unsupported PLX chip (%X)\n", ChipType);
            return;
    }


    /************************************************
    *
    *    Attach an event to the DMA interrupt
    *
    ************************************************/
    PlxPrintf("  Attach event to DMA Interrupt.. ");

    PlxInterrupt.PciDmaChannel0 = 1;
    rc =
        PlxIntrAttach(
            hDevice,
            PlxInterrupt,
            &hInterruptEvent
            );
    if (rc != ApiSuccess)
        PlxPrintf("*ERROR* - Attach failed, rc=%s\n", PlxSdkErrorText(rc));
    else
        PlxPrintf("Ok (hEvent=0x%08x)\n", hInterruptEvent);



    /************************************************
    *
    *       Enable the DMA and PCI interrupts
    *
    ************************************************/
    PlxPrintf("  Enable DMA 0 & PCI Interrupt... ");

    PlxInterrupt.PciMainInt = 1;
    rc =
        PlxIntrEnable(
            hDevice,
            &PlxInterrupt
            );
    if (rc != ApiSuccess)
        PlxPrintf("*ERROR* - Enable failed, rc=%s\n", PlxSdkErrorText(rc));
    else
        PlxPrintf("Ok\n");



    /************************************************
    *
    *          Initialize DMA Next Descriptor
    *
    ************************************************/
    // Address of first Desc & Desc in PCI space (bit 0)
    PlxRegisterWrite(
        hDevice,
        OffsetDescr,             // DMA 0 Descriptor pointer offset
        SglPciAddress | (1 << 0)
        );



    /************************************************
    *
    *              Start DMA engine
    *
    ************************************************/
    PlxPrintf("  Start DMA transfer............. ");
    RegValue =
        PlxRegisterRead(
            hDevice,
            OffsetDmaCmd,
            NULL
            );

    // First enable the DMA channel
    RegValue |= (1 << 0);

    PlxRegisterWrite(
        hDevice,
        OffsetDmaCmd,
        RegValue
        );

    // Start the transfer
    RegValue |= (1 << 1);

    PlxRegisterWrite(
        hDevice,
        OffsetDmaCmd,
        RegValue
        );

    PlxPrintf("Ok\n");



    /************************************************
    *
    *           Wait for DMA completion
    *
    ************************************************/
    PlxPrintf("  Wait for interrupt event....... ");

#if defined(_WIN32)
    EventStatus =
        WaitForSingleObject(
            hInterruptEvent,
            10 * 1000
            );

    switch (EventStatus)
    {
        case WAIT_OBJECT_0:
            PlxPrintf("Ok (DMA 0 Int received)\n");
            break;

        case WAIT_TIMEOUT:
            PlxPrintf("*ERROR* - Interrupt Timeout\n");
            break;

        case WAIT_FAILED:
            PlxPrintf("*ERROR* - Interrupt failed\n");
            break;

        default:
            PlxPrintf("*ERROR* - Unknown, EventStatus = 0x%08x\n", EventStatus);
            break;
    }

#elif defined(PLX_LINUX)

    rc =
        PlxIntrWait(
            hDevice,
            hInterruptEvent,
            10 * 1000
            );

    switch (rc)
    {
        case ApiSuccess:
            PlxPrintf("Ok (DMA 0 Int received)\n");
            break;

        case ApiWaitTimeout:
            PlxPrintf("*ERROR* - Interrupt Timeout\n");
            break;

        case ApiWaitCanceled:
            PlxPrintf("*ERROR* - Interrupt event cancelled\n");
            break;

        default:
            PlxPrintf("*ERROR* - API failed (rc=%s)\n", PlxSdkErrorText(rc));
            break;
    }
#endif

}
