#ifndef __CPU8260_H
#define __CPU8260_H

/*******************************************************************************
 * Copyright (c) 2001 PLX Technology, Inc.
 *
 * PLX Technology Inc. licenses this software under specific terms and
 * conditions.  Use of any of the software or derviatives thereof in any
 * product without a PLX Technology chip is strictly prohibited.
 *
 * PLX Technology, Inc. provides this software AS IS, WITHOUT ANY WARRANTY,
 * EXPRESS OR IMPLIED, INCLUDING, WITHOUT LIMITATION, ANY WARRANTY OF
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  PLX makes no guarantee
 * or representations regarding the use of, or the results of the use of,
 * the software and documentation in terms of correctness, accuracy,
 * reliability, currentness, or otherwise; and you rely on the software,
 * documentation and results solely at your own risk.
 *
 * IN NO EVENT SHALL PLX BE LIABLE FOR ANY LOSS OF USE, LOSS OF BUSINESS,
 * LOSS OF PROFITS, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES
 * OF ANY KIND.  IN NO EVENT SHALL PLX'S TOTAL LIABILITY EXCEED THE SUM
 * PAID TO PLX FOR THE PRODUCT LICENSED HEREUNDER.
 *
 ******************************************************************************/

/***************************************************************************
 *
 * File Name:
 *
 *      Cpu8260.h
 *
 * Description:
 *
 *      MPC8260 Register definitions
 *
 * Revision History:
 *
 *      09-01-01 : PCI SDK v3.40
 *
 ***************************************************************************/


#include "Plx.h"
#include "PlxTypes.h"




//
//  Special Purpose Registers - User Level
//

#define SPR_XER                        1                // Fixed-point Exception
#define SPR_LR                         8                // Link Register
#define SPR_CTR                        9                // Count Register
#define SPR_TBL_READ                 268                // Time-Base Low for Reads
#define SPR_TBU_READ                 269                // Time-Base Upper for Reads


//
//  Special Purpose Registers - Supervisor Level
//

#define SPR_DSISR                     18                // Data Storage Exception Status
#define SPR_DAR                       19                // Data Address
#define SPR_DEC                       22                // Decrementer
#define SPR_SRR0                      26                // Machine Status Save/Restore 0
#define SPR_SRR1                      27                // Machine Status Save/Restore 1
#define SPR_SPGR0                    272                // Special Purpose General 0
#define SPR_SPGR1                    273                // Special Purpose General 1
#define SPR_SPGR2                    274                // Special Purpose General 2
#define SPR_SPGR3                    275                // Special Purpose General 3
#define SPR_TBL_WRITE                284                // Time-Base Low for Writes
#define SPR_TBU_WRITE                285                // Time-Base Upper for Writes
#define SPR_PVR                      287                // Processor Version Register


//
//  Special Purpose Registers - 8260-Specific
//

#define SPR_DMISS                    976                // Data TLB Miss Address
#define SPR_DCMP                     977                // Data TLB Compare
#define SPR_HASH1                    978                // Primary Hash Address
#define SPR_HASH2                    979                // Secondary Hash Address
#define SPR_IMISS                    980                // Instruction TLB Miss Address
#define SPR_ICMP                     981                // Instruction TLB Compare
#define SPR_RPA                      982                // Required Physical Address
#define SPR_HID0                    1008                // Hardware Implementation-Dependent 0
#define SPR_HID1                    1009                // Hardware Implementation-Dependent 1
#define SPR_IABR                    1010                // Instruction Address Breakpoint
#define SPR_HID2                    1011                // Hardware Implementation-Dependent 2


//
//  DPRAM - Dual Port RAM
//

#define IMMR_DPRAM_1                0x00000             // Dual-port RAM 1 (16 Kbytes)
#define IMMR_DPRAM_RSVD_1           0x04000             // Reserved (16 Kbytes)
#define IMMR_DPRAM_2                0x08000             // Dual-port RAM 2 (4 Kbytes)
#define IMMR_DPRAM_RSVD_2           0x09000             // Reserved (8 Kbytes)
#define IMMR_DPRAM_3                0x0b000             // Dual-port RAM 3 (4 Kbytes)
#define IMMR_DPRAM_RSVD_3           0x0c000             // Reserved (16 Kbytes)


//
//  SIU - System interface unit
//

#define IMMR_SIU_SIUMCR             0x10000             // Module Configuration
#define IMMR_SIU_SYPCR              0x10004             // System Protection Control
#define IMMR_SIU_RSVD_1             0x10008             // Reserved (6 bytes)
#define IMMR_SIU_SWSR               0x1000e             // Software Service
#define IMMR_SIU_RSVD_2             0x10010             // Reserved (20 bytes)
#define IMMR_SIU_BCR                0x10024             // Bus Configuration
#define IMMR_SIU_PPC_ACR            0x10028             // 60x Bus Arbiter Configuration
#define IMMR_SIU_PPC_ALRH           0x1002c             // 60x Bus Arbitration-level High
#define IMMR_SIU_PPC_ALRL           0x10030             // 60x Bus Arbitration-level Low
#define IMMR_SIU_LCL_ACR            0x10034             // Local Bus Arbiter Configuration
#define IMMR_SIU_LCL_ALRH           0x10038             // Local Bus Arbitration-level High
#define IMMR_SIU_LCL_ALRL           0x1003c             // Local Bus Arbitration-level Low
#define IMMR_SIU_TESCR1             0x10040             // 60x Bus Transfer Error Status/Control 1
#define IMMR_SIU_TESCR2             0x10044             // 60x Bus Transfer Error Status/Control 2
#define IMMR_SIU_L_TESCR1           0x10048             // Local Bus Transfer Error Status/Control 1
#define IMMR_SIU_L_TESCR2           0x1004c             // Local Bus Transfer Error Status/Control 2
#define IMMR_SIU_PDTEA              0x10050             // 60x Bus DMA Transfer Error Address
#define IMMR_SIU_PDTEM              0x10054             // 60x Bus DMA Transfer Error MSNUM
#define IMMR_SIU_RSVD_3             0x10055             // Reserved (3 bytes)
#define IMMR_SIU_LDTEA              0x10058             // Local Bus DMA Transfer Error Address
#define IMMR_SIU_LDTEM              0x1005c             // Local Bus DMA Transfer Error MSNUM
#define IMMR_SIU_RSVD_4             0x1005d             // Reserved (163 bytes)


//
//  MEMC - Memory Controller
//

#define IMMR_MEMC_BR0               0x10100             // Bank 0
#define IMMR_MEMC_OR0               0x10104
#define IMMR_MEMC_BR1               0x10108             // Bank 1
#define IMMR_MEMC_OR1               0x1010c
#define IMMR_MEMC_BR2               0x10110             // Bank 2
#define IMMR_MEMC_OR2               0x10114
#define IMMR_MEMC_BR3               0x10118             // Bank 3
#define IMMR_MEMC_OR3               0x1011c
#define IMMR_MEMC_BR4               0x10120             // Bank 4
#define IMMR_MEMC_OR4               0x10124
#define IMMR_MEMC_BR5               0x10128             // Bank 5
#define IMMR_MEMC_OR5               0x1012c
#define IMMR_MEMC_BR6               0x10130             // Bank 6
#define IMMR_MEMC_OR6               0x10134
#define IMMR_MEMC_BR7               0x10138             // Bank 7
#define IMMR_MEMC_OR7               0x1013c
#define IMMR_MEMC_BR8               0x10140             // Bank 8
#define IMMR_MEMC_OR8               0x10144
#define IMMR_MEMC_BR9               0x10148             // Bank 9
#define IMMR_MEMC_OR9               0x1014c
#define IMMR_MEMC_BR10              0x10150             // Bank 10
#define IMMR_MEMC_OR10              0x10154
#define IMMR_MEMC_BR11              0x10158             // Bank 11
#define IMMR_MEMC_OR11              0x1015c
#define IMMR_MEMC_RSVD_1            0x10160             // Reserved (8 bytes)
#define IMMR_MEMC_MAR               0x10168             // Memory Address Register
#define IMMR_MEMC_RSVD_2            0x1016c             // Reserved (4 bytes)
#define IMMR_MEMC_MAMR              0x10170             // Machine A Mode
#define IMMR_MEMC_MBMR              0x10174             // Machine B Mode
#define IMMR_MEMC_MCMR              0x10178             // Machine C Mode
#define IMMR_MEMC_RSVD_3            0x1017c             // Reserved (6 bytes)
#define IMMR_MEMC_MPTPR             0x10184             // Periodic Timer Prescaler
#define IMMR_MEMC_MDR               0x10188             // Memory Data
#define IMMR_MEMC_RSVD_4            0x1018c             // Reserved (4 bytes)
#define IMMR_MEMC_PSDMR             0x10190             // 60x bus SDRAM mode
#define IMMR_MEMC_LSDMR             0x10194             // Local bus SDRAM mode
#define IMMR_MEMC_PURT              0x10198             // 60x bus-assigned UPM refresh timer
#define IMMR_MEMC_PSRT              0x1019c             // 60x bus-assigned SDRAM refresh timer
#define IMMR_MEMC_LURT              0x101a0             // Local bus-assigned UPM refresh timer
#define IMMR_MEMC_LSRT              0x101a4             // Local bus-assigned SDRAM refresh timer
#define IMMR_MEMC_IMMR              0x101a8             // Internal Memory-Mapped Register
#define IMMR_MEMC_RSVD_5            0x101ac             // Reserved (84 bytes)


//
//  SIMT - System Integration Timers
//

#define IMMR_SIMT_RSVD_1            0x10200             // Reserved (32 bytes)
#define IMMR_SIMT_TMCNTSC           0x10220             // Time counter status & control
#define IMMR_SIMT_TMCNT             0x10224             // Time counter
#define IMMR_SIMT_RSVD_2            0x10228             // Reserved (4 bytes)
#define IMMR_SIMT_TMCNTAL           0x1022c             // Time counter alarm
#define IMMR_SIMT_RSVD_3            0x10230             // Reserved (16 bytes)
#define IMMR_SIMT_PISCR             0x10240             // Periodic Int Status/Ctrl
#define IMMR_SIMT_PITC              0x10244             // Periodic Int Count
#define IMMR_SIMT_PITR              0x10248             // Periodic Int Timer
#define IMMR_SIMT_RSVD_4            0x1024c             // Reserved (94 bytes)
#define IMMR_SIMT_RSVD_5            0x102aa             // Reserved (2,390 bytes)


//
//  Interrupt Controller
//

#define IMMR_INT_SICR               0x10c00             // SIU Interrupt Configuration
#define IMMR_INT_SIVEC              0x10c04             // SIU Interrupt Vector
#define IMMR_INT_SIPNR_H            0x10c08             // SIU Interrupt Pending (High)
#define IMMR_INT_SIPNR_L            0x10c0c             // SIU Interrupt Pending (Low)
#define IMMR_INT_SIPRR              0x10c10             // SIU Interrupt Priority
#define IMMR_INT_SCPRR_H            0x10c14             // CPM Interrupt Priority (High)
#define IMMR_INT_SCPRR_L            0x10c18             // CPM Interrupt Priority (Low)
#define IMMR_INT_SIMR_H             0x10c1c             // SIU Interrupt Mask (High)
#define IMMR_INT_SIMR_L             0x10c20             // SIU Interrupt Mask (Low)
#define IMMR_INT_SIEXR              0x10c24             // SIU External Interrupt Control
#define IMMR_INT_RSVD_1             0x10c28             // Reserved (88 bytes)


//
//  CLKR - Clocks and Reset
//

#define IMMR_CLKR_SCCR              0x10c80             // System Clock Control
#define IMMR_CLKR_SCMR              0x10c88             // System Clock Mode
#define IMMR_CLKR_RSR               0x10c90             // Reset Status
#define IMMR_CLKR_RMR               0x10c94             // Reset Mode
#define IMMR_CLKR_RSVD_1            0x10c98             // Reserved (88 bytes)


//
//  PIO - I/O Port
//

#define IMMR_PIO_PDIRA              0x10d00             // Port A Data Direction
#define IMMR_PIO_PPARA              0x10d04             // Port A Pin Assignment
#define IMMR_PIO_PSORA              0x10d08             // Port A Special Options
#define IMMR_PIO_PODRA              0x10d0c             // Port A Open Drain
#define IMMR_PIO_PDATA              0x10d10             // Port A Data
#define IMMR_PIO_RSVD_1             0x10d14             // Reserved (12 bytes)
#define IMMR_PIO_PDIRB              0x10d20             // Port B Data Direction
#define IMMR_PIO_PPARB              0x10d24             // Port B Pin Assignment
#define IMMR_PIO_PSORB              0x10d28             // Port B Special Options
#define IMMR_PIO_PODRB              0x10d2c             // Port B Open Drain
#define IMMR_PIO_PDATB              0x10d30             // Port B Data
#define IMMR_PIO_RSVD_2             0x10d34             // Reserved (12 bytes)
#define IMMR_PIO_PDIRC              0x10d40             // Port C Data Direction
#define IMMR_PIO_PPARC              0x10d44             // Port C Pin Assignment
#define IMMR_PIO_PSORC              0x10d48             // Port C Special Options
#define IMMR_PIO_PODRC              0x10d4c             // Port C Open Drain
#define IMMR_PIO_PDATC              0x10d50             // Port C Data
#define IMMR_PIO_RSVD_3             0x10d54             // Reserved (12 bytes)
#define IMMR_PIO_PDIRD              0x10d60             // Port D Data Direction
#define IMMR_PIO_PPARD              0x10d64             // Port D Pin Assignment
#define IMMR_PIO_PSORD              0x10d68             // Port D Special Options
#define IMMR_PIO_PODRD              0x10d6c             // Port D Open Drain
#define IMMR_PIO_PDATD              0x10d70             // Port D Data
#define IMMR_PIO_RSVD_4             0x10d74             // Reserved (12 bytes)


//
//  TIMR - CPM Timers
//

#define IMMR_TIMR_TGCR1             0x10d80             // Timer 1 & 2 Global Configuration
#define IMMR_TIMR_RSVD_1            0x10d81             // Reserved (3 bytes)
#define IMMR_TIMR_TGCR2             0x10d84             // Timer 3 & 4 Global Configuration
#define IMMR_TIMR_RSVD_2            0x10d85             // Reserved (11 bytes)
#define IMMR_TIMR_TMR1              0x10d90             // Timer 1 Mode
#define IMMR_TIMR_TMR2              0x10d92             // Timer 2 Mode
#define IMMR_TIMR_TRR1              0x10d94             // Timer 1 Reference
#define IMMR_TIMR_TRR2              0x10d96             // Timer 2 Reference
#define IMMR_TIMR_TCR1              0x10d98             // Timer 1 Capture
#define IMMR_TIMR_TCR2              0x10d9a             // Timer 2 Capture
#define IMMR_TIMR_TCN1              0x10d9c             // Timer 1 Counter
#define IMMR_TIMR_TCN2              0x10d9e             // Timer 2 Counter
#define IMMR_TIMR_TMR3              0x10da0             // Timer 3 Mode
#define IMMR_TIMR_TMR4              0x10da2             // Timer 4 Mode
#define IMMR_TIMR_TRR3              0x10da4             // Timer 3 Reference
#define IMMR_TIMR_TRR4              0x10da6             // Timer 4 Reference
#define IMMR_TIMR_TCR3              0x10da8             // Timer 3 Capture
#define IMMR_TIMR_TCR4              0x10daa             // Timer 4 Capture
#define IMMR_TIMR_TCN3              0x10dac             // Timer 3 Counter
#define IMMR_TIMR_TCN4              0x10dae             // Timer 4 Counter
#define IMMR_TIMR_TER1              0x10db0             // Timer 1 Event
#define IMMR_TIMR_TER2              0x10db2             // Timer 2 Event
#define IMMR_TIMR_TER3              0x10db4             // Timer 3 Event
#define IMMR_TIMR_TER4              0x10db6             // Timer 4 Event
#define IMMR_TIMR_RSVD_3            0x10d74             // Reserved (670 bytes)


//
//  SDMA
//

#define IMMR_SDMA_SDSR              0x11018             // SDMA Status
#define IMMR_SDMA_RSVD_1            0x11019             // Reserved (3 bytes)
#define IMMR_SDMA_SDMR              0x1101c             // SDMA Mask
#define IMMR_SDMA_RSVD_2            0x1101d             // Reserved (3 bytes)


//
//  IDMA
//

#define IMMR_IDMA_IDSR1             0x11020             // IDMA 1 Event
#define IMMR_IDMA_RSVD_1            0x11021             // Reserved (3 bytes)
#define IMMR_IDMA_IDMR1             0x11024             // IDMA 1 Mask
#define IMMR_IDMA_RSVD_2            0x11025             // Reserved (3 bytes)

#define IMMR_IDMA_IDSR2             0x11028             // IDMA 2 Event
#define IMMR_IDMA_RSVD_3            0x11029             // Reserved (3 bytes)
#define IMMR_IDMA_IDMR2             0x1102c             // IDMA 2 Mask
#define IMMR_IDMA_RSVD_4            0x1102d             // Reserved (3 bytes)

#define IMMR_IDMA_IDSR3             0x11030             // IDMA 3 Event
#define IMMR_IDMA_RSVD_5            0x11031             // Reserved (3 bytes)
#define IMMR_IDMA_IDMR3             0x11034             // IDMA 3 Mask
#define IMMR_IDMA_RSVD_6            0x11035             // Reserved (3 bytes)

#define IMMR_IDMA_IDSR4             0x11038             // IDMA 4 Event
#define IMMR_IDMA_RSVD_7            0x11039             // Reserved (3 bytes)
#define IMMR_IDMA_IDMR4             0x1103c             // IDMA 4 Mask
#define IMMR_IDMA_RSVD_8            0x1103d             // Reserved (707 bytes)


//
//  FCCx - Fast Communication Controllers
//

#define IMMR_FCC_GFMR1             0x11300              // FCC 1 General Mode
#define IMMR_FCC_FPSMR1            0x11304              // FCC 1 Protocol-Specific Mode
#define IMMR_FCC_FTODR1            0x11308              // FCC 1 Transmit-on-demand
#define IMMR_FCC_RSVD_1            0x1130a              // Reserved (2 bytes)
#define IMMR_FCC_FDSR1             0x1130c              // FCC 1 Data Synchonization
#define IMMR_FCC_RSVD_2            0x1130e              // Reserved (2 bytes)
#define IMMR_FCC_FCCE1             0x11310              // FCC 1 Event Register
#define IMMR_FCC_FCCM1             0x11314              // FCC 1 Mask Register
#define IMMR_FCC_FCCS1             0x11318              // FCC 1 Status Register
#define IMMR_FCC_RSVD_3            0x11319              // Reserved (3 bytes)
#define IMMR_FCC_FTIRR1_PHY0       0x1131c              // FCC 1 Transmit Internal Rate for PHY 0
#define IMMR_FCC_FTIRR1_PHY1       0x1131d              // FCC 1 Transmit Internal Rate for PHY 1
#define IMMR_FCC_FTIRR1_PHY2       0x1131e              // FCC 1 Transmit Internal Rate for PHY 2
#define IMMR_FCC_FTIRR1_PHY3       0x1131f              // FCC 1 Transmit Internal Rate for PHY 3

#define IMMR_FCC_GFMR2             0x11320              // FCC 2 General Mode
#define IMMR_FCC_FPSMR2            0x11324              // FCC 2 Protocol-Specific Mode
#define IMMR_FCC_FTODR2            0x11328              // FCC 2 Transmit-on-demand
#define IMMR_FCC_RSVD_4            0x1132a              // Reserved (2 bytes)
#define IMMR_FCC_FDSR2             0x1132c              // FCC 2 Data Synchonization
#define IMMR_FCC_RSVD_5            0x1132e              // Reserved (2 bytes)
#define IMMR_FCC_FCCE2             0x11330              // FCC 2 Event Register
#define IMMR_FCC_FCCM2             0x11334              // FCC 2 Mask Register
#define IMMR_FCC_FCCS2             0x11338              // FCC 2 Status Register
#define IMMR_FCC_RSVD_6            0x11339              // Reserved (3 bytes)
#define IMMR_FCC_FTIRR2_PHY0       0x1133c              // FCC 2 Transmit Internal Rate for PHY 0
#define IMMR_FCC_FTIRR2_PHY1       0x1133d              // FCC 2 Transmit Internal Rate for PHY 1
#define IMMR_FCC_FTIRR2_PHY2       0x1133e              // FCC 2 Transmit Internal Rate for PHY 2
#define IMMR_FCC_FTIRR2_PHY3       0x1133f              // FCC 2 Transmit Internal Rate for PHY 3

#define IMMR_FCC_GFMR3             0x11340              // FCC 3 General Mode
#define IMMR_FCC_FPSMR3            0x11344              // FCC 3 Protocol-Specific Mode
#define IMMR_FCC_FTODR3            0x11348              // FCC 3 Transmit-on-demand
#define IMMR_FCC_RSVD_7            0x1134a              // Reserved (2 bytes)
#define IMMR_FCC_FDSR3             0x1134c              // FCC 3 Data Synchonization
#define IMMR_FCC_RSVD_8            0x1134e              // Reserved (2 bytes)
#define IMMR_FCC_FCCE3             0x11350              // FCC 3 Event Register
#define IMMR_FCC_FCCM3             0x11354              // FCC 3 Mask Register
#define IMMR_FCC_FCCS3             0x11358              // FCC 3 Status Register
#define IMMR_FCC_RSVD_9            0x11359              // Reserved (167 bytes)


//
//  BRG (5-8) - Baud-Rate Generators
//

#define IMMR_BRG_BRGC5              0x115f0             // BRG 5 Configuration
#define IMMR_BRG_BRGC6              0x115f4             // BRG 6 Configuration
#define IMMR_BRG_BRGC7              0x115f8             // BRG 7 Configuration
#define IMMR_BRG_BRGC8              0x115fc             // BRG 8 Configuration
#define IMMR_BRG_RSVD_1             0x11600             // Reserved (608 bytes)


//
//  I2C
//

#define IMMR_I2C_I2MOD              0x11860             // I2C Mode
#define IMMR_I2C_RSVD_1             0x11860             // Reserved (3 bytes)
#define IMMR_I2C_I2ADD              0x11860             // I2C Address
#define IMMR_I2C_RSVD_2             0x11860             // Reserved (3 bytes)
#define IMMR_I2C_I2BRG              0x11860             // I2C BRG
#define IMMR_I2C_RSVD_3             0x11860             // Reserved (3 bytes)
#define IMMR_I2C_I2COM              0x11860             // I2C Command
#define IMMR_I2C_RSVD_4             0x11860             // Reserved (3 bytes)
#define IMMR_I2C_I2CER              0x11860             // I2C Event
#define IMMR_I2C_RSVD_5             0x11860             // Reserved (3 bytes)
#define IMMR_I2C_I2CMR              0x11860             // I2C Mask
#define IMMR_I2C_RSVD_6             0x11860             // Reserved (315 bytes)


//
//  CP - Communications Processor
//

#define IMMR_CP_CPCR                0x119c0             // CP Command
#define IMMR_CP_RCCR                0x119c4             // CP Configuration
#define IMMR_CP_RSVD_1              0x119c8             // Reserved (12 bytes)
#define IMMR_CP_RTER                0x119d6             // CP Timers Event
#define IMMR_CP_RTMR                0x119da             // CP Timers Mask
#define IMMR_CP_RTSCR               0x119dc             // CP Time-stamp timer control
#define IMMR_CP_RSVD_2              0x119de             // Reserved (2 bytes)
#define IMMR_CP_RTSR                0x119e0             // CP Time-stamp


//
//  BRG (1-4) - Baud-Rate Generators
//

#define IMMR_BRG_BRGC1              0x119f0             // BRG 1 Configuration
#define IMMR_BRG_BRGC2              0x119f4             // BRG 2 Configuration
#define IMMR_BRG_BRGC3              0x119f8             // BRG 3 Configuration
#define IMMR_BRG_BRGC4              0x119fc             // BRG 4 Configuration

 
//
//  SCCx - Serial Communication Controllers
//

#define IMMR_SCC_GSMR_L1           0x11a00              // SCC 1 General Mode (Low)
#define IMMR_SCC_GSMR_H1           0x11a04              // SCC 1 General Mode (High)
#define IMMR_SCC_PSMR1             0x11a08              // SCC 1 Protocol Specific Mode
#define IMMR_SCC_RSVD_1            0x11a0a              // Reserved (2 bytes)
#define IMMR_SCC_TODR1             0x11a0c              // SCC 1 Transmit-on-demand
#define IMMR_SCC_DSR1              0x11a0e              // SCC 1 Data Synchronization
#define IMMR_SCC_SCCE1             0x11a10              // SCC 1 Event
#define IMMR_SCC_SCCM1             0x11a14              // SCC 1 Mask
#define IMMR_SCC_SCCS1             0x11a17              // SCC 1 Status
#define IMMR_SCC_RSVD_2            0x11118              // Reserved (8 bytes)

#define IMMR_SCC_GSMR_L2           0x11a20              // SCC 2 General Mode (Low)
#define IMMR_SCC_GSMR_H2           0x11a24              // SCC 2 General Mode (High)
#define IMMR_SCC_PSMR2             0x11a28              // SCC 2 Protocol Specific Mode
#define IMMR_SCC_RSVD_3            0x11a2a              // Reserved (2 bytes)
#define IMMR_SCC_TODR2             0x11a2c              // SCC 2 Transmit-on-demand
#define IMMR_SCC_DSR2              0x11a2e              // SCC 2 Data Synchronization
#define IMMR_SCC_SCCE2             0x11a30              // SCC 2 Event
#define IMMR_SCC_SCCM2             0x11a34              // SCC 2 Mask
#define IMMR_SCC_SCCS2             0x11a37              // SCC 2 Status
#define IMMR_SCC_RSVD_4            0x11138              // Reserved (8 bytes)

#define IMMR_SCC_GSMR_L3           0x11a40              // SCC 3 General Mode (Low)
#define IMMR_SCC_GSMR_H3           0x11a44              // SCC 3 General Mode (High)
#define IMMR_SCC_PSMR3             0x11a48              // SCC 3 Protocol Specific Mode
#define IMMR_SCC_RSVD_5            0x11a4a              // Reserved (2 bytes)
#define IMMR_SCC_TODR3             0x11a4c              // SCC 3 Transmit-on-demand
#define IMMR_SCC_DSR3              0x11a4e              // SCC 3 Data Synchronization
#define IMMR_SCC_SCCE3             0x11a50              // SCC 3 Event
#define IMMR_SCC_SCCM3             0x11a54              // SCC 3 Mask
#define IMMR_SCC_SCCS3             0x11a57              // SCC 3 Status
#define IMMR_SCC_RSVD_6            0x11158              // Reserved (8 bytes)

#define IMMR_SCC_GSMR_L4           0x11a60              // SCC 4 General Mode (Low)
#define IMMR_SCC_GSMR_H4           0x11a64              // SCC 4 General Mode (High)
#define IMMR_SCC_PSMR4             0x11a68              // SCC 4 Protocol Specific Mode
#define IMMR_SCC_RSVD_7            0x11a6a              // Reserved (2 bytes)
#define IMMR_SCC_TODR4             0x11a6c              // SCC 4 Transmit-on-demand
#define IMMR_SCC_DSR4              0x11a6e              // SCC 4 Data Synchronization
#define IMMR_SCC_SCCE4             0x11a70              // SCC 4 Event
#define IMMR_SCC_SCCM4             0x11a74              // SCC 4 Mask
#define IMMR_SCC_SCCS4             0x11a77              // SCC 4 Status
#define IMMR_SCC_RSVD_8            0x11178              // Reserved (8 bytes)


//
//  SMC - Serial Management Controllers
//

#define IMMR_SMC_SMCMR1             0x11a82             // SMC 1 Mode
#define IMMR_SMC_SMCE1              0x11a86             // SMC 1 Event
#define IMMR_SMC_SMCM1              0x11a8a             // SMC 1 Mask
#define IMMR_SMC_RSVD_1             0x11a8b             // Reserved (7 bytes)

#define IMMR_SMC_SMCMR2             0x11a92             // SMC 2 Mode
#define IMMR_SMC_SMCE2              0x11a96             // SMC 2 Event
#define IMMR_SMC_SMCM2              0x11a9a             // SMC 2 Mask
#define IMMR_SMC_RSVD_2             0x11a9b             // Reserved (5 bytes)


//
//  SPI - Serial Peripheral Interface
//

#define IMMR_SPI_SPMODE             0x11aa0             // SPI Mode
#define IMMR_SPI_RSVD_1             0x11aa2             // Reserved (4 bytes)
#define IMMR_SPI_SPIE               0x11aa6             // SPI Event
#define IMMR_SPI_RSVD_2             0x11aa7             // Reserved (4 bytes)
#define IMMR_SPI_SPIM               0x11aaa             // SPI Mask
#define IMMR_SPI_RSVD_3             0x11aab             // Reserved (4 bytes)
#define IMMR_SPI_SPCOM              0x11aad             // SPI Command
#define IMMR_SPI_RSVD_4             0x11aa7             // Reserved (4 bytes)


//
//  CPM Mux
//

#define IMMR_CM_CMXSI1CR            0x11b00             // CPM Mux SI1 Clock Route
#define IMMR_CM_CMXSI2CR            0x11b02             // CPM Mux SI2 Clock Route
#define IMMR_CM_RSVD_1              0x11b03             // Reserved (1 byte)
#define IMMR_CM_CMXFCR              0x11b04             // CPM Mux FCC Clock Route
#define IMMR_CM_CMXSCR              0x11b08             // CPM Mux SCC Clock Route
#define IMMR_CM_CMXSMR              0x11b0c             // CPM Mux SMC Clock Route
#define IMMR_CM_RSVD_2              0x11b0d             // Reserved (1 byte)
#define IMMR_CM_CMXUAR              0x11b0e             // CPM Mux UTOPIA Address
#define IMMR_CM_RSVD_3              0x11b0d             // Reserved (16 bytes)


//
//  SIx - Serial Interfaces
//

#define IMMR_SI_SI1AMR             0x11b20              // SI 1 TDMA1 Mode
#define IMMR_SI_SI1BMR             0x11b22              // SI 1 TDMB1 Mode
#define IMMR_SI_SI1CMR             0x11b24              // SI 1 TDMC1 Mode
#define IMMR_SI_SI1DMR             0x11b26              // SI 1 TDMD1 Mode
#define IMMR_SI_SI1GMR             0x11b28              // SI 1 Global Mode
#define IMMR_SI_SI1CMDR            0x11b2a              // SI 1 Command
#define IMMR_SI_SI1STR             0x11b2c              // SI 1 Status
#define IMMR_SI_SI1RSR             0x11b2e              // SI 1 RAM Shadow Address

#define IMMR_SI_SI2AMR             0x11b40              // SI 2 TDMA1 Mode
#define IMMR_SI_SI2BMR             0x11b42              // SI 2 TDMB1 Mode
#define IMMR_SI_SI2CMR             0x11b44              // SI 2 TDMC1 Mode
#define IMMR_SI_SI2DMR             0x11b46              // SI 2 TDMD1 Mode
#define IMMR_SI_SI2GMR             0x11b48              // SI 2 Global Mode
#define IMMR_SI_RSVD_1             0x11b49              // Reserved (1 byte)
#define IMMR_SI_SI2CMDR            0x11b4a              // SI 2 Command
#define IMMR_SI_RSVD_2             0x11b4b              // Reserved (1 byte)
#define IMMR_SI_SI2STR             0x11b4c              // SI 2 Status
#define IMMR_SI_RSVD_3             0x11b4d              // Reserved (1 byte)
#define IMMR_SI_SI2RSR             0x11b4e              // SI 2 RAM Shadow Address


//
//  MCCx - Multi-Channel Controllers
//

#define IMMR_MCC_MCCE1             0x11b30              // MCC 1 Event
#define IMMR_MCC_MCCM1             0x11b34              // MCC 1 Mask
#define IMMR_MCC_RSVD_1            0x11b36              // Reserved (2 bytes)
#define IMMR_MCC_MCCF1             0x11b38              // MCC 1 Configuration
#define IMMR_MCC_RSVD_2            0x11b39              // Reserved (7 bytes)

#define IMMR_MCC_MCCE2             0x11b50              // MCC 2 Event
#define IMMR_MCC_MCCM2             0x11b54              // MCC 2 Mask
#define IMMR_MCC_MCCF2             0x11b58              // MCC 2 Configuration
#define IMMR_MCC_RSVD_3            0x11b59              // Reserved (1,159 bytes)


//
//  SI1 RAM - Serial Interface Routing RAM
//

#define IMMR_SIRAM_SI1TxRAM         0x12000             // SI 1 Transmit Routing RAM
#define IMMR_SIRAM_RSVD_1           0x12200             // Reserved (512 bytes)
#define IMMR_SIRAM_SI1RxRAM         0x12400             // SI 1 Receive Routing RAM
#define IMMR_SIRAM_RSVD_2           0x12600             // Reserved (512 bytes)

#define IMMR_SIRAM_SI2TxRAM         0x12800             // SI 2 Transmit Routing RAM
#define IMMR_SIRAM_RSVD_3           0x12a00             // Reserved (512 bytes)
#define IMMR_SIRAM_SI2RxRAM         0x12c00             // SI 2 Receive Routing RAM
#define IMMR_SIRAM_RSVD_4           0x12e00             // Reserved (512 bytes)




/***************************************************************************
 *
 *      Register bit-level definitions and CPU descriptor structures
 *
 ***************************************************************************/

//
//  SIU Interrupt Numbers
//

#define SIU_INT_NONE                 0
#define SIU_INT_I2C                  1
#define SIU_INT_SPI                  2
#define SIU_INT_RISC_TIMERS          3
#define SIU_INT_SMC1                 4
#define SIU_INT_SMC2                 5
#define SIU_INT_IDMA1                6
#define SIU_INT_IDMA2                7
#define SIU_INT_IDMA3                8
#define SIU_INT_IDMA4                9
#define SIU_INT_SDMA                10
#define SIU_INT_RESERVED_1          11
#define SIU_INT_TIMER1              12
#define SIU_INT_TIMER2              13
#define SIU_INT_TIMER3              14
#define SIU_INT_TIMER4              15
#define SIU_INT_TMCNT               16
#define SIU_INT_PIT                 17
#define SIU_INT_RESERVED_2          18
#define SIU_INT_IRQ1                19
#define SIU_INT_IRQ2                20
#define SIU_INT_IRQ3                21
#define SIU_INT_IRQ4                22
#define SIU_INT_IRQ5                23
#define SIU_INT_IRQ6                24
#define SIU_INT_IRQ7                25
#define SIU_INT_RESERVED_3          26
#define SIU_INT_FCC1                32
#define SIU_INT_FCC2                33
#define SIU_INT_FCC3                34
#define SIU_INT_RESERVED_4          35
#define SIU_INT_MCC1                36
#define SIU_INT_MCC2                37
#define SIU_INT_RESERVED_5          38
#define SIU_INT_RESERVED_6          39
#define SIU_INT_SCC1                40
#define SIU_INT_SCC2                41
#define SIU_INT_SCC3                42
#define SIU_INT_SCC4                43
#define SIU_INT_RESERVED_7          44
#define SIU_INT_PC15                48
#define SIU_INT_PC14                49
#define SIU_INT_PC13                50
#define SIU_INT_PC12                51
#define SIU_INT_PC11                52
#define SIU_INT_PC10                53
#define SIU_INT_PC9                 54
#define SIU_INT_PC8                 55
#define SIU_INT_PC7                 56
#define SIU_INT_PC6                 57
#define SIU_INT_PC5                 58
#define SIU_INT_PC4                 59
#define SIU_INT_PC3                 60
#define SIU_INT_PC2                 61
#define SIU_INT_PC1                 62
#define SIU_INT_PC0                 63
#define SIU_INT_TOTAL_NUM           64                  // Total number of interrupt vectors


//
//  CPM Channel Numbers (Page # & Sub-block)
//

#define CPM_CHANNEL_NONE            ((0x00 << 5) | 0x00)
#define CPM_CHANNEL_FCC1            ((0x04 << 5) | 0x10)
#define CPM_CHANNEL_FCC1_ATM        ((0x04 << 5) | 0x0e)
#define CPM_CHANNEL_FCC2            ((0x05 << 5) | 0x11)
#define CPM_CHANNEL_FCC2_ATM        ((0x05 << 5) | 0x0e)
#define CPM_CHANNEL_FCC3            ((0x06 << 5) | 0x12)
#define CPM_CHANNEL_SCC1            ((0x00 << 5) | 0x04)
#define CPM_CHANNEL_SCC2            ((0x01 << 5) | 0x05)
#define CPM_CHANNEL_SCC3            ((0x02 << 5) | 0x06)
#define CPM_CHANNEL_SCC4            ((0x03 << 5) | 0x07)
#define CPM_CHANNEL_SMC1            ((0x07 << 5) | 0x08)
#define CPM_CHANNEL_SMC2            ((0x08 << 5) | 0x09)
#define CPM_CHANNEL_RAND            ((0x0a << 5) | 0x0e)
#define CPM_CHANNEL_SPI             ((0x09 << 5) | 0x0a)
#define CPM_CHANNEL_I2C             ((0x0a << 5) | 0x0b)
#define CPM_CHANNEL_TIMER           ((0x0a << 5) | 0x0f)
#define CPM_CHANNEL_MCC1            ((0x07 << 5) | 0x1c)
#define CPM_CHANNEL_MCC2            ((0x08 << 5) | 0x1d)
#define CPM_CHANNEL_IDMA1           ((0x07 << 5) | 0x14)
#define CPM_CHANNEL_IDMA2           ((0x08 << 5) | 0x15)
#define CPM_CHANNEL_IDMA3           ((0x09 << 5) | 0x16)
#define CPM_CHANNEL_IDMA4           ((0x0a << 5) | 0x17)


//
//  CPM Sub-Channel Numbers
//

#define CPM_SUBCHANNEL_NONE         0x00
#define CPM_SUBCHANNEL_FCC_HDLC     0x00
#define CPM_SUBCHANNEL_FCC_ATM      0x0a
#define CPM_SUBCHANNEL_FCC_ETH      0x0c
#define CPM_SUBCHANNEL_FCC_TRANSP   0x0f


//
//  CPM Commands
//

#define CPM_CMD_RESET               BE_U32_BIT0
#define CPM_CMD_INIT_RX_TX          0x00
#define CPM_CMD_INIT_RX             0x01
#define CPM_CMD_INIT_TX             0x02
#define CPM_CMD_HUNT_MODE           0x03
#define CPM_CMD_STOP_TX             0x04
#define CPM_CMD_GRACEFUL_STOP_TX    0x05
#define CPM_CMD_RESTART_TX          0x06
#define CPM_CMD_CLOSE_RX_BD         0x07
#define CPM_CMD_SET_GROUP_ADDR      0x08
#define CPM_CMD_TIMER_SET_TIMER     0x08
#define CPM_CMD_SMC_GCI_TIMEOUT     0x09
#define CPM_CMD_IDMA_START_IDMA     0x09
#define CPM_CMD_MCC_STOP_RX         0x09
#define CPM_CMD_FCC_ATM_TX          0x0a
#define CPM_CMD_SCC_RESET_BCS       0x0a
#define CPM_CMD_SMC_GCI_ABORT       0x0a
#define CPM_CMD_IDMA_STOP_IDMA      0x0b


//
//  SCC1 Parameter RAM
//

#define IMMR_SCC1_PARAM_RBASE       0x8000              // Receive BD Table base
#define IMMR_SCC1_PARAM_TBASE       0x8002              // Transmit BD Table base
#define IMMR_SCC1_PARAM_RFCR        0x8004              // Receive Function Code Register
#define IMMR_SCC1_PARAM_TFCR        0x8005              // Transmit Function Code Register
#define IMMR_SCC1_PARAM_MRBLR       0x8006              // Maximum Receive Buffer Length
#define IMMR_SCC1_PARAM_RBPTR       0x8010              // Current CPM internal Rx BD pointer
#define IMMR_SCC1_PARAM_TBPTR       0x8020              // Current CPM internal Tx BD pointer


//
//  SCC1 UART Mode-Specific Paramter RAM
//

#define IMMR_SCC1_UART_MAX_IDL      0x8038              // Max Idle characters
#define IMMR_SCC1_UART_IDLC         0x803a              // Temporary Idle counter
#define IMMR_SCC1_UART_BRKCR        0x803c              // Break Count register
#define IMMR_SCC1_UART_PAREC        0x803e              // Parity Error count
#define IMMR_SCC1_UART_FRMEC        0x8040              // Frame Error count
#define IMMR_SCC1_UART_NOSEC        0x8042              // Noise Error count
#define IMMR_SCC1_UART_BRKEC        0x8044              // Break condition count
#define IMMR_SCC1_UART_BRKLN        0x8046              // Last Break received length
#define IMMR_SCC1_UART_UADDR1       0x8048              // UART address character 1
#define IMMR_SCC1_UART_UADDR2       0x804a              // UART address character 2
#define IMMR_SCC1_UART_RTEMP        0x804c              // Temporary Storage
#define IMMR_SCC1_UART_TOSEQ        0x804e              // Transmit Out-of-Sequence character
#define IMMR_SCC1_UART_CHAR1        0x8050              // Control Character 1
#define IMMR_SCC1_UART_CHAR2        0x8052              // Control Character 2
#define IMMR_SCC1_UART_CHAR3        0x8054              // Control Character 3
#define IMMR_SCC1_UART_CHAR4        0x8056              // Control Character 4
#define IMMR_SCC1_UART_CHAR5        0x8058              // Control Character 5
#define IMMR_SCC1_UART_CHAR6        0x805a              // Control Character 6
#define IMMR_SCC1_UART_CHAR7        0x805c              // Control Character 7
#define IMMR_SCC1_UART_CHAR8        0x805e              // Control Character 8
#define IMMR_SCC1_UART_RCCM         0x8060              // Receive Control Character Mask
#define IMMR_SCC1_UART_RCCR         0x8062              // Receive Control Character register
#define IMMR_SCC1_UART_RLBC         0x8064              // Receive last break character


//
//  SCC2 Parameter RAM
//

#define IMMR_SCC2_PARAM_RBASE       0x8100              // Receive BD Table base
#define IMMR_SCC2_PARAM_TBASE       0x8102              // Transmit BD Table base
#define IMMR_SCC2_PARAM_RFCR        0x8104              // Receive Function Code Register
#define IMMR_SCC2_PARAM_TFCR        0x8105              // Transmit Function Code Register
#define IMMR_SCC2_PARAM_MRBLR       0x8106              // Maximum Receive Buffer Length
#define IMMR_SCC2_PARAM_RBPTR       0x8110              // Current CPM internal Rx BD pointer
#define IMMR_SCC2_PARAM_TBPTR       0x8120              // Current CPM internal Tx BD pointer


//
//  SCC2 UART Mode-Specific Paramter RAM
//

#define IMMR_SCC2_UART_MAX_IDL      0x8138              // Max Idle characters
#define IMMR_SCC2_UART_IDLC         0x813a              // Temporary Idle counter
#define IMMR_SCC2_UART_BRKCR        0x813c              // Break Count register
#define IMMR_SCC2_UART_PAREC        0x813e              // Parity Error count
#define IMMR_SCC2_UART_FRMEC        0x8140              // Frame Error count
#define IMMR_SCC2_UART_NOSEC        0x8142              // Noise Error count
#define IMMR_SCC2_UART_BRKEC        0x8144              // Break condition count
#define IMMR_SCC2_UART_BRKLN        0x8146              // Last Break received length
#define IMMR_SCC2_UART_UADDR1       0x8148              // UART address character 1
#define IMMR_SCC2_UART_UADDR2       0x814a              // UART address character 2
#define IMMR_SCC2_UART_RTEMP        0x814c              // Temporary Storage
#define IMMR_SCC2_UART_TOSEQ        0x814e              // Transmit Out-of-Sequence character
#define IMMR_SCC2_UART_CHAR1        0x8150              // Control Character 1
#define IMMR_SCC2_UART_CHAR2        0x8152              // Control Character 2
#define IMMR_SCC2_UART_CHAR3        0x8154              // Control Character 3
#define IMMR_SCC2_UART_CHAR4        0x8156              // Control Character 4
#define IMMR_SCC2_UART_CHAR5        0x8158              // Control Character 5
#define IMMR_SCC2_UART_CHAR6        0x815a              // Control Character 6
#define IMMR_SCC2_UART_CHAR7        0x815c              // Control Character 7
#define IMMR_SCC2_UART_CHAR8        0x815e              // Control Character 8
#define IMMR_SCC2_UART_RCCM         0x8160              // Receive Control Character Mask
#define IMMR_SCC2_UART_RCCR         0x8162              // Receive Control Character register
#define IMMR_SCC2_UART_RLBC         0x8164              // Receive last break character


//
//  SCC3 Parameter RAM
//

#define IMMR_SCC3_PARAM_RBASE       0x8200              // Receive BD Table base
#define IMMR_SCC3_PARAM_TBASE       0x8202              // Transmit BD Table base
#define IMMR_SCC3_PARAM_RFCR        0x8204              // Receive Function Code Register
#define IMMR_SCC3_PARAM_TFCR        0x8205              // Transmit Function Code Register
#define IMMR_SCC3_PARAM_MRBLR       0x8206              // Maximum Receive Buffer Length
#define IMMR_SCC3_PARAM_RBPTR       0x8210              // Current CPM internal Rx BD pointer
#define IMMR_SCC3_PARAM_TBPTR       0x8220              // Current CPM internal Tx BD pointer


//
//  SCC3 UART Mode-Specific Paramter RAM
//

#define IMMR_SCC3_UART_MAX_IDL      0x8238              // Max Idle characters
#define IMMR_SCC3_UART_IDLC         0x823a              // Temporary Idle counter
#define IMMR_SCC3_UART_BRKCR        0x823c              // Break Count register
#define IMMR_SCC3_UART_PAREC        0x823e              // Parity Error count
#define IMMR_SCC3_UART_FRMEC        0x8240              // Frame Error count
#define IMMR_SCC3_UART_NOSEC        0x8242              // Noise Error count
#define IMMR_SCC3_UART_BRKEC        0x8244              // Break condition count
#define IMMR_SCC3_UART_BRKLN        0x8246              // Last Break received length
#define IMMR_SCC3_UART_UADDR1       0x8248              // UART address character 1
#define IMMR_SCC3_UART_UADDR2       0x824a              // UART address character 2
#define IMMR_SCC3_UART_RTEMP        0x824c              // Temporary Storage
#define IMMR_SCC3_UART_TOSEQ        0x824e              // Transmit Out-of-Sequence character
#define IMMR_SCC3_UART_CHAR1        0x8250              // Control Character 1
#define IMMR_SCC3_UART_CHAR2        0x8252              // Control Character 2
#define IMMR_SCC3_UART_CHAR3        0x8254              // Control Character 3
#define IMMR_SCC3_UART_CHAR4        0x8256              // Control Character 4
#define IMMR_SCC3_UART_CHAR5        0x8258              // Control Character 5
#define IMMR_SCC3_UART_CHAR6        0x825a              // Control Character 6
#define IMMR_SCC3_UART_CHAR7        0x825c              // Control Character 7
#define IMMR_SCC3_UART_CHAR8        0x825e              // Control Character 8
#define IMMR_SCC3_UART_RCCM         0x8260              // Receive Control Character Mask
#define IMMR_SCC3_UART_RCCR         0x8262              // Receive Control Character register
#define IMMR_SCC3_UART_RLBC         0x8264              // Receive last break character


//
//  Constants used in SCC Buffer Descriptors
//

#define SCC_RX_EMPTY                BE_U16_BIT0
#define SCC_RX_WRAP                 BE_U16_BIT2
#define SCC_RX_INTERRUPT            BE_U16_BIT3
#define SCC_RX_CONTROL              BE_U16_BIT4
#define SCC_RX_ADDRESS              BE_U16_BIT5
#define SCC_RX_CONTINUOUS           BE_U16_BIT6
#define SCC_RX_IDLE_CLOSE           BE_U16_BIT7
#define SCC_RX_MATCH_ADDRESS        BE_U16_BIT8
#define SCC_RX_BREAK                BE_U16_BIT10
#define SCC_RX_FRAMING              BE_U16_BIT11
#define SCC_RX_PARITY               BE_U16_BIT12
#define SCC_RX_OVERRUN              BE_U16_BIT14
#define SCC_RX_LOST_CD              BE_U16_BIT15

#define SCC_TX_READY                BE_U16_BIT0
#define SCC_TX_WRAP                 BE_U16_BIT2
#define SCC_TX_INTERRUPT            BE_U16_BIT3
#define SCC_TX_CLEAR_REPORT         BE_U16_BIT4
#define SCC_TX_ADDRESS              BE_U16_BIT5
#define SCC_TX_CONTINUOUS           BE_U16_BIT6
#define SCC_TX_PREAMBLE             BE_U16_BIT7
#define SCC_TX_NO_STOP_BIT          BE_U16_BIT8
#define SCC_TX_LOST_CTS             BE_U16_BIT15


//
//  FCC Parameter RAM
//

#define IMMR_FCC1_PARAM_RIPTR        0x8400             // FCC 1 Rx internal temporary data pointer
#define IMMR_FCC1_PARAM_TIPTR        0x8402             // FCC 1 Tx internal temporary data pointer
#define IMMR_FCC1_PARAM_MRBLR        0x8406             // FCC 1 Maximum Receive Buffer Length
#define IMMR_FCC1_PARAM_RSTATE       0x8408             // FCC 1 Rx Internal State
#define IMMR_FCC1_PARAM_RBASE        0x840c             // FCC 1 Rx BD Table base
#define IMMR_FCC1_PARAM_TSTATE       0x8418             // FCC 1 Tx Internal State
#define IMMR_FCC1_PARAM_TBASE        0x841c             // FCC 1 Tx BD Table base

#define IMMR_FCC2_PARAM_RIPTR        0x8500             // FCC 2 Rx internal temporary data pointer
#define IMMR_FCC2_PARAM_TIPTR        0x8502             // FCC 2 Tx internal temporary data pointer
#define IMMR_FCC2_PARAM_MRBLR        0x8506             // FCC 2 Maximum Receive Buffer Length
#define IMMR_FCC2_PARAM_RSTATE       0x8508             // FCC 2 Rx Internal State
#define IMMR_FCC2_PARAM_RBASE        0x850c             // FCC 2 Rx BD Table base
#define IMMR_FCC2_PARAM_TSTATE       0x8518             // FCC 2 Tx Internal State
#define IMMR_FCC2_PARAM_TBASE        0x851c             // FCC 2 Tx BD Table base

#define IMMR_FCC3_PARAM_RIPTR        0x8500             // FCC 3 Rx internal temporary data pointer
#define IMMR_FCC3_PARAM_TIPTR        0x8502             // FCC 3 Tx internal temporary data pointer
#define IMMR_FCC3_PARAM_MRBLR        0x8506             // FCC 3 Maximum Receive Buffer Length
#define IMMR_FCC3_PARAM_RSTATE       0x8508             // FCC 3 Rx Internal State
#define IMMR_FCC3_PARAM_RBASE        0x850c             // FCC 3 Rx BD Table base
#define IMMR_FCC3_PARAM_TSTATE       0x8518             // FCC 3 Tx Internal State
#define IMMR_FCC3_PARAM_TBASE        0x851c             // FCC 3 Tx BD Table base


//
//  FCC Ethernet Mode-Specific Parameter RAM
//

#define IMMR_FCC1_ETH_CAM_PTR        0x8440             // FCC 1 CAM address
#define IMMR_FCC1_ETH_C_MASK         0x8444             // FCC 1 Constant MASK for CRC
#define IMMR_FCC1_ETH_C_PRES         0x8448             // FCC 1 Preset CRC
#define IMMR_FCC1_ETH_CRCEC          0x844c             // FCC 1 CRC Error Counter
#define IMMR_FCC1_ETH_ALEC           0x8450             // FCC 1 Alignment Error Counter
#define IMMR_FCC1_ETH_DISFC          0x8454             // FCC 1 Discarded Frame Counter
#define IMMR_FCC1_ETH_RET_LIM        0x8458             // FCC 1 Retry Limit
#define IMMR_FCC1_ETH_P_PER          0x845c             // FCC 1 Persistence
#define IMMR_FCC1_ETH_GADDR_H        0x8460             // FCC 1 Group Address Filter (High)
#define IMMR_FCC1_ETH_GADDR_L        0x8464             // FCC 1 Group Address Filter (Low)
#define IMMR_FCC1_ETH_TFCSTAT        0x8468             // FCC 1 Out-of-Sequence TxBD Status/Control
#define IMMR_FCC1_ETH_TFCLEN         0x846a             // FCC 1 Out-of-Sequence TxBD Length
#define IMMR_FCC1_ETH_TFCPTR         0x846c             // FCC 1 Out-of-Sequence TxBD Buffer Pointer
#define IMMR_FCC1_ETH_MFLR           0x8470             // FCC 1 Maximum Frame Length
#define IMMR_FCC1_ETH_PADDR1_H       0x8472             // FCC 1 Physical Address of Station (High)
#define IMMR_FCC1_ETH_PADDR1_M       0x8474             // FCC 1 Physical Address of Station (Middle)
#define IMMR_FCC1_ETH_PADDR1_L       0x8476             // FCC 1 Physical Address of Station (Low)
#define IMMR_FCC1_ETH_IADDR_H        0x84a0             // FCC 1 Individual Address Filter (High)
#define IMMR_FCC1_ETH_IADDR_L        0x84a4             // FCC 1 Individual Address Filter (Low)
#define IMMR_FCC1_ETH_MINFLR         0x84a8             // FCC 1 Minimum Frame Length
#define IMMR_FCC1_ETH_TADDR_H        0x84aa             // FCC 1 Hash Table Address Addition (High)
#define IMMR_FCC1_ETH_TADDR_M        0x84ac             // FCC 1 Hash Table Address Addition (Middle)
#define IMMR_FCC1_ETH_TADDR_L        0x84ae             // FCC 1 Hash Table Address Addition (Low)
#define IMMR_FCC1_ETH_PAD_PTR        0x84b0             // FCC 1 Internal PAD Pointer
#define IMMR_FCC1_ETH_MAXD1          0x84b8             // FCC 1 Maximum DMA 1 Length
#define IMMR_FCC1_ETH_MAXD2          0x84ba             // FCC 1 Maximum DMA 2 Length
#define IMMR_FCC1_ETH_OCTC           0x84c0             // FCC 1 Total Num of Octets of Data Received
#define IMMR_FCC1_ETH_COLC           0x84c4             // FCC 1 Total Num of Collisions
#define IMMR_FCC1_ETH_BROC           0x84c8             // FCC 1 Total Num of Good Rx Broadcast Packets
#define IMMR_FCC1_ETH_MULC           0x84cc             // FCC 1 Total Num of Good Rx Multicast Packets
#define IMMR_FCC1_ETH_USPC           0x84d0             // FCC 1 Total Num of Good Rx Packets less than 64 Octets Long
#define IMMR_FCC1_ETH_FRGC           0x84d4             // FCC 1 Total Num of Bad Rx Packets less than 64 Octets Long
#define IMMR_FCC1_ETH_OSPC           0x84d8             // FCC 1 Total Num of Good Rx Packets greater than 1518 Octets Long
#define IMMR_FCC1_ETH_JBRC           0x84dc             // FCC 1 Total Num of Bad Rx Packets greater than 1518 Octets Long
#define IMMR_FCC1_ETH_P64C           0x84e0             // FCC 1 Total Num of Rx Packets which were 64 Octets Long
#define IMMR_FCC1_ETH_P65C           0x84e4             // FCC 1 Total Num of Rx Packets which were between 65 & 127 Octets Long
#define IMMR_FCC1_ETH_P128C          0x84e8             // FCC 1 Total Num of Rx Packets which were between 128 & 255 Octets Long
#define IMMR_FCC1_ETH_P256C          0x84ec             // FCC 1 Total Num of Rx Packets which were between 256 & 511 Octets Long
#define IMMR_FCC1_ETH_P512C          0x84f0             // FCC 1 Total Num of Rx Packets which were between 512 & 1023 Octets Long
#define IMMR_FCC1_ETH_P1024C         0x84f4             // FCC 1 Total Num of Rx Packets which were between 1024 & 1518 Octets Long

#define IMMR_FCC2_ETH_CAM_PTR        0x8540             // FCC 2 CAM address
#define IMMR_FCC2_ETH_C_MASK         0x8544             // FCC 2 Constant MASK for CRC
#define IMMR_FCC2_ETH_C_PRES         0x8548             // FCC 2 Preset CRC
#define IMMR_FCC2_ETH_CRCEC          0x854c             // FCC 2 CRC Error Counter
#define IMMR_FCC2_ETH_ALEC           0x8550             // FCC 2 Alignment Error Counter
#define IMMR_FCC2_ETH_DISFC          0x8554             // FCC 2 Discarded Frame Counter
#define IMMR_FCC2_ETH_RET_LIM        0x8558             // FCC 2 Retry Limit
#define IMMR_FCC2_ETH_P_PER          0x855c             // FCC 2 Persistence
#define IMMR_FCC2_ETH_GADDR_H        0x8560             // FCC 2 Group Address Filter (High)
#define IMMR_FCC2_ETH_GADDR_L        0x8564             // FCC 2 Group Address Filter (Low)
#define IMMR_FCC2_ETH_TFCSTAT        0x8568             // FCC 2 Out-of-Sequence TxBD Status/Control
#define IMMR_FCC2_ETH_TFCLEN         0x856a             // FCC 2 Out-of-Sequence TxBD Length
#define IMMR_FCC2_ETH_TFCPTR         0x856c             // FCC 2 Out-of-Sequence TxBD Buffer Pointer
#define IMMR_FCC2_ETH_MFLR           0x8570             // FCC 2 Maximum Frame Length
#define IMMR_FCC2_ETH_PADDR1_H       0x8572             // FCC 2 Physical Address of Station (High)
#define IMMR_FCC2_ETH_PADDR1_M       0x8574             // FCC 2 Physical Address of Station (Middle)
#define IMMR_FCC2_ETH_PADDR1_L       0x8576             // FCC 2 Physical Address of Station (Low)
#define IMMR_FCC2_ETH_IADDR_H        0x85a0             // FCC 2 Individual Address Filter (High)
#define IMMR_FCC2_ETH_IADDR_L        0x85a4             // FCC 2 Individual Address Filter (Low)
#define IMMR_FCC2_ETH_MINFLR         0x85a8             // FCC 2 Minimum Frame Length
#define IMMR_FCC2_ETH_TADDR_H        0x85aa             // FCC 2 Hash Table Address Addition (High)
#define IMMR_FCC2_ETH_TADDR_M        0x85ac             // FCC 2 Hash Table Address Addition (Middle)
#define IMMR_FCC2_ETH_TADDR_L        0x85ae             // FCC 2 Hash Table Address Addition (Low)
#define IMMR_FCC2_ETH_PAD_PTR        0x85b0             // FCC 2 Internal PAD Pointer
#define IMMR_FCC2_ETH_MAXD1          0x85b8             // FCC 2 Maximum DMA 1 Length
#define IMMR_FCC2_ETH_MAXD2          0x85ba             // FCC 2 Maximum DMA 2 Length
#define IMMR_FCC2_ETH_OCTC           0x85c0             // FCC 2 Total Num of Octets of Data Received
#define IMMR_FCC2_ETH_COLC           0x85c4             // FCC 2 Total Num of Collisions
#define IMMR_FCC2_ETH_BROC           0x85c8             // FCC 2 Total Num of Good Rx Broadcast Packets
#define IMMR_FCC2_ETH_MULC           0x85cc             // FCC 2 Total Num of Good Rx Multicast Packets
#define IMMR_FCC2_ETH_USPC           0x85d0             // FCC 2 Total Num of Good Rx Packets less than 64 Octets Long
#define IMMR_FCC2_ETH_FRGC           0x85d4             // FCC 2 Total Num of Bad Rx Packets less than 64 Octets Long
#define IMMR_FCC2_ETH_OSPC           0x85d8             // FCC 2 Total Num of Good Rx Packets greater than 1518 Octets Long
#define IMMR_FCC2_ETH_JBRC           0x85dc             // FCC 2 Total Num of Bad Rx Packets greater than 1518 Octets Long
#define IMMR_FCC2_ETH_P64C           0x85e0             // FCC 2 Total Num of Rx Packets which were 64 Octets Long
#define IMMR_FCC2_ETH_P65C           0x85e4             // FCC 2 Total Num of Rx Packets which were between 65 & 127 Octets Long
#define IMMR_FCC2_ETH_P128C          0x85e8             // FCC 2 Total Num of Rx Packets which were between 128 & 255 Octets Long
#define IMMR_FCC2_ETH_P256C          0x85ec             // FCC 2 Total Num of Rx Packets which were between 256 & 511 Octets Long
#define IMMR_FCC2_ETH_P512C          0x85f0             // FCC 2 Total Num of Rx Packets which were between 512 & 1023 Octets Long
#define IMMR_FCC2_ETH_P1024C         0x85f4             // FCC 2 Total Num of Rx Packets which were between 1024 & 1518 Octets Long


//
//  Constants used in FCC Buffer Descriptors
//

#define FCC_RX_EMPTY                BE_U16_BIT0
#define FCC_RX_WRAP                 BE_U16_BIT2
#define FCC_RX_INTERRUPT            BE_U16_BIT3
#define FCC_RX_LAST                 BE_U16_BIT4
#define FCC_RX_FIRST                BE_U16_BIT5
#define FCC_RX_MISS                 BE_U16_BIT7
#define FCC_RX_BROADCAST            BE_U16_BIT8
#define FCC_RX_MULTICAST            BE_U16_BIT9
#define FCC_RX_ERR_LEN              BE_U16_BIT10
#define FCC_RX_ERR_ALIGNMENT        BE_U16_BIT11
#define FCC_RX_ERR_SHORT            BE_U16_BIT12
#define FCC_RX_ERR_CRC              BE_U16_BIT13
#define FCC_RX_ERR_OVERRUN          BE_U16_BIT14
#define FCC_RX_ERR_COLLISION        BE_U16_BIT15

#define FCC_TX_READY                BE_U16_BIT0
#define FCC_TX_PAD                  BE_U16_BIT1
#define FCC_TX_WRAP                 BE_U16_BIT2
#define FCC_TX_INTERRUPT            BE_U16_BIT3
#define FCC_TX_LAST                 BE_U16_BIT4
#define FCC_TX_TRANSMIT_CRC         BE_U16_BIT5
#define FCC_TX_DEFER                BE_U16_BIT6
#define FCC_TX_ERR_HEARTBEAT        BE_U16_BIT7
#define FCC_TX_ERR_LATE_COLLISION   BE_U16_BIT8
#define FCC_TX_ERR_RETRANS_LIMIT    BE_U16_BIT9
#define FCC_TX_ERR_UNDERRUN         BE_U16_BIT14
#define FCC_TX_ERR_LOST_CARRIER     BE_U16_BIT15


//
//  SCC Buffer Descriptor structure
//

typedef struct _SCC_BD
{
    volatile U16 Status;          // BD Rx or Tx status
    volatile U16 Length;          // Data Length
    volatile U32 DataBuffer;      // Data buffer pointer
} SCC_BD;


//
//  FCC Buffer Descriptor structure
//

typedef SCC_BD      FCC_BD;




#endif
