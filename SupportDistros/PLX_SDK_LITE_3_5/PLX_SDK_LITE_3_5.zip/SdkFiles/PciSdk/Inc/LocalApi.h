#ifndef __LOCALAPI_H
#define __LOCALAPI_H

/*******************************************************************************
 * Copyright (c) 2001 PLX Technology, Inc.
 *
 * PLX Technology Inc. licenses this software under specific terms and
 * conditions.  Use of any of the software or derviatives thereof in any
 * product without a PLX Technology chip is strictly prohibited.
 *
 * PLX Technology, Inc. provides this software AS IS, WITHOUT ANY WARRANTY,
 * EXPRESS OR IMPLIED, INCLUDING, WITHOUT LIMITATION, ANY WARRANTY OF
 * MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  PLX makes no guarantee
 * or representations regarding the use of, or the results of the use of,
 * the software and documentation in terms of correctness, accuracy,
 * reliability, currentness, or otherwise; and you rely on the software,
 * documentation and results solely at your own risk.
 *
 * IN NO EVENT SHALL PLX BE LIABLE FOR ANY LOSS OF USE, LOSS OF BUSINESS,
 * LOSS OF PROFITS, INDIRECT, INCIDENTAL, SPECIAL OR CONSEQUENTIAL DAMAGES
 * OF ANY KIND.  IN NO EVENT SHALL PLX'S TOTAL LIABILITY EXCEED THE SUM
 * PAID TO PLX FOR THE PRODUCT LICENSED HEREUNDER.
 *
 ******************************************************************************/

/******************************************************************************
 *
 * File Name:
 *
 *      LocalApi.h
 *
 * Description:
 *
 *      Local API functions declarations
 *
 * Revision:
 *
 *      09-31-01 : PCI SDK v3.40
 *
 ******************************************************************************/


#include "PlxTypes.h"


#ifdef __cplusplus
extern "C" {
#endif




/******************************************
* Miscellaneous Functions
******************************************/
RETURN_CODE
PlxSdkVersion(
    U8 *VersionMajor,
    U8 *VersionMinor,
    U8 *VersionRevision
    );

void
PlxChipTypeGet(
    BUS_INDEX  busIndex,
    U32       *pChipType,
    U8        *pRevision
    );

ADDRESS
PlxChipBaseAddressGet(
    BUS_INDEX    busIndex,
    RETURN_CODE *rc
    );

void
PlxVerifyEndianAccess(
    BUS_INDEX busIndex
    );


/******************************************
* Initialization Functions
******************************************/
RETURN_CODE
PlxInitApi(
    API_PARMS *ApiParms
    );

RETURN_CODE
PlxInitPciBusProperties(
    BUS_INDEX     busIndex,
    PCI_BUS_PROP *PciBusProp
    );

RETURN_CODE
PlxInitPciSpace(
    BUS_INDEX busIndex,
    PCI_SPACE PciSpace,
    ADDRESS   PciWindowBase,
    U32       size
    );

RETURN_CODE
PlxInitIopBusProperties(
    BUS_INDEX     busIndex,
    IOP_SPACE     IopSpace,
    IOP_BUS_PROP *IopBusProp
    );

RETURN_CODE
PlxInitIopArbitration(
    BUS_INDEX       busIndex,
    IOP_ARBIT_DESC *ArbDesc
    );

RETURN_CODE
PlxInitLocalSpace(
    BUS_INDEX busIndex,
    IOP_SPACE IopSpace,
    ADDRESS   LocalBase,
    U32       size
    );

RETURN_CODE
PlxInitIopEndian(
    BUS_INDEX        busIndex,
    IOP_ENDIAN_DESC *IopEndianDesc
    );

RETURN_CODE
PlxInitPowerManagement(
    BUS_INDEX  busIndex,
    PM_PROP   *PmProp
    );

RETURN_CODE
PlxInitVPDAddress(
    BUS_INDEX busIndex,
    U32       VpdBaseAddress
    );

RETURN_CODE
PlxInitDone(
    BUS_INDEX busIndex
    );


/******************************************
* Register Access Functions
******************************************/
RETURN_CODE
PlxPciConfigRegisterRead(
    U32  bus,
    U32  slot,
    U32  offset,
    U32 *pData
    );

RETURN_CODE
PlxPciConfigRegisterWrite(
    U32  bus,
    U32  slot,
    U32  offset,
    U32 *pData
    );

U32
PlxRegisterRead(
    BUS_INDEX    busIndex,
    U32          offset,
    RETURN_CODE *rc
    );

RETURN_CODE
PlxRegisterWrite(
    BUS_INDEX busIndex,
    U32       offset,
    U32       data
    );

U32
PlxRegisterMailboxRead(
    BUS_INDEX    busIndex,
    MAILBOX_ID   MailboxId,
    RETURN_CODE *rc
    );

RETURN_CODE
PlxRegisterMailboxWrite(
    BUS_INDEX  busIndex,
    MAILBOX_ID MailboxId,
    U32        data
    );

U32
PlxRegisterDoorbellRead(
    BUS_INDEX    busIndex,
    RETURN_CODE *rc
    );

RETURN_CODE
PlxRegisterDoorbellSet(
    BUS_INDEX busIndex,
    U32       data
    );


/******************************************
* Interrupt Support Functions
******************************************/
RETURN_CODE
PlxIntrEnable(
    BUS_INDEX  busIndex,
    PLX_INTR  *pPlxIntr
    );

RETURN_CODE
PlxIntrDisable(
    BUS_INDEX  busIndex,
    PLX_INTR  *pPlxIntr
    );

BOOLEAN
PlxIntrStatusGet(
    BUS_INDEX    busIndex,
    PLX_INTR    *pPlxIntr,
    RETURN_CODE *rc
    );

U32
PlxPciAbortAddrRead(
    BUS_INDEX    busIndex,
    RETURN_CODE *rc
    );


/******************************************
* PCI Access Functions
******************************************/
RETURN_CODE
PlxBusPciRead(
    BUS_INDEX    busIndex,
    PCI_SPACE    PciSpace,
    ADDRESS      PciAddress,
    void        *pDestination,
    U32          TransferSize,
    ACCESS_TYPE  AccessType
    );

RETURN_CODE
PlxBusPciWrite(
    BUS_INDEX    busIndex,
    PCI_SPACE    PciSpace,
    ADDRESS      PciAddress,
    void        *pSource,
    U32          TransferSize,
    ACCESS_TYPE  AccessType
    );


/******************************************
* Serial EEPROM Access Functions
******************************************/
BOOLEAN
PlxSerialEepromPresent(
    BUS_INDEX    busIndex,
    RETURN_CODE *rc
    );

RETURN_CODE
PlxSerialEepromRead(
    BUS_INDEX    busIndex,
    EEPROM_TYPE  EepromType,
    U32         *pBuffer,
    U32          size
    );

RETURN_CODE
PlxSerialEepromReadByOffset(
    BUS_INDEX  busIndex,
    U16        offset,
    U32       *pValue
    );

RETURN_CODE
PlxSerialEepromWrite(
    BUS_INDEX    busIndex,
    EEPROM_TYPE  EepromType,
    U32         *pBuffer,
    U32          size
    );

RETURN_CODE
PlxSerialEepromWriteByOffset(
    BUS_INDEX busIndex,
    U16       offset,
    U32       value
    );


/******************************************
* DMA Functions
******************************************/
RETURN_CODE
PlxDmaResourceManagerInit(
    DMA_PARMS *pDmaParms
    );

void
PlxDmaIsr(
    DMA_CHANNEL channel
    );

RETURN_CODE
PlxDmaControl(
    DMA_CHANNEL channel,
    U32         ElementIndex,
    DMA_COMMAND DmaCommand
    );

RETURN_CODE
PlxDmaStatus(
    DMA_CHANNEL channel,
    U32         ElementIndex
    );


/******************************************
* Block DMA Functions
******************************************/
RETURN_CODE
PlxDmaBlockChannelOpen(
    DMA_CHANNEL       channel,
    DMA_CHANNEL_DESC *pDmaChannelDesc
    );

RETURN_CODE
PlxDmaBlockTransfer(
    DMA_CHANNEL           channel,
    DMA_TRANSFER_ELEMENT *pDmaData,
    BOOLEAN               ReturnImmediate
    );

RETURN_CODE
PlxDmaBlockTransferRestart(
    DMA_CHANNEL channel,
    U32         TransferSize,
    BOOLEAN     ReturnImmediate
    );

RETURN_CODE
PlxDmaBlockChannelClose(
    DMA_CHANNEL channel
    );


/******************************************
* SGL DMA Functions
******************************************/
RETURN_CODE
PlxDmaSglChannelOpen(
    DMA_CHANNEL       channel,
    DMA_CHANNEL_DESC *pDmaChannelDesc
    );

RETURN_CODE
PlxDmaSglBuild(
    DMA_CHANNEL            channel,
    U32                    SglSize,
    DMA_TRANSFER_ELEMENT **pFirstElement
    );

RETURN_CODE
PlxDmaSglFill(
    DMA_TRANSFER_ELEMENT *pFirstElement,
    U32                   index,
    DMA_TRANSFER_ELEMENT *pDmaData
    );

RETURN_CODE
PlxDmaSglTransfer(
    DMA_CHANNEL           channel,
    DMA_TRANSFER_ELEMENT *pFirstElement,
    BOOLEAN               ReturnImmediate
    );

RETURN_CODE
PlxDmaSglChannelClose(
    DMA_CHANNEL channel
    );


/******************************************
* Shuttle DMA Functions
******************************************/
RETURN_CODE
PlxDmaShuttleChannelOpen(
    DMA_CHANNEL       channel,
    DMA_CHANNEL_DESC *pDmaChannelDesc
    );

RETURN_CODE
PlxDmaShuttleTransfer(
    DMA_CHANNEL           channel,
    U32                   ElementIndex,
    DMA_TRANSFER_ELEMENT *pDmaData,
    BOOLEAN               ReturnImmediate
    );

RETURN_CODE
PlxDmaShuttleTransferRestart(
    DMA_CHANNEL channel,
    U32         ElementIndex,
    U32         TransferSize,
    BOOLEAN     ReturnImmediate
    );

RETURN_CODE
PlxDmaShuttleChannelClose(
    DMA_CHANNEL channel
    );


/******************************************
* Messaging Unit Functions
******************************************/
RETURN_CODE
PlxMuInit(
    BUS_INDEX busIndex,
    U32       FifoSize,
    ADDRESS   LocalAddr
    );

RETURN_CODE
PlxMuInboundPortRead(
    BUS_INDEX  busIndex,
    U32       *pFramePointer
    );

RETURN_CODE
PlxMuInboundPortWrite(
    BUS_INDEX  busIndex,
    U32       *pFramePointer
    );

RETURN_CODE
PlxMuOutboundPortRead(
    BUS_INDEX  busIndex,
    U32       *pFramePointer
    );

RETURN_CODE
PlxMuOutboundPortWrite(
    BUS_INDEX  busIndex,
    U32       *pFramePointer
    );

U32
PlxMuHostOutboundIndexRead(
    BUS_INDEX    busIndex,
    RETURN_CODE *rc
    );

RETURN_CODE
PlxMuIopOutboundIndexWrite(
    BUS_INDEX busIndex,
    U32       IopOutboundIndex
    );

U32
PlxMuIopOutboundIndexRead(
    BUS_INDEX    busIndex,
    RETURN_CODE *rc
    );


/******************************************
* Power Management Functions
******************************************/
BOOLEAN
PlxIsPowerLevelSupported(
    BUS_INDEX       busIndex,
    PLX_POWER_LEVEL PowerLevel
    );

PLX_POWER_LEVEL
PlxPowerLevelGet(
    BUS_INDEX    busIndex,
    RETURN_CODE *rc
    );

RETURN_CODE
PlxPowerLevelSet(
    BUS_INDEX       busIndex,
    PLX_POWER_LEVEL PowerLevel
    );

U32
PlxPowerConsumedRead(
    BUS_INDEX        busIndex,
    PLX_POWER_LEVEL  PowerLevel,
    RETURN_CODE     *rc
    );

RETURN_CODE
PlxPowerConsumedWrite(
    BUS_INDEX       busIndex,
    PLX_POWER_LEVEL PowerLevel,
    U32             power
    );

U32
PlxPowerDissipatedRead(
    BUS_INDEX        busIndex,
    PLX_POWER_LEVEL  PowerLevel,
    RETURN_CODE     *rc
    );

RETURN_CODE
PlxPowerDissipatedWrite(
    BUS_INDEX       busIndex,
    PLX_POWER_LEVEL PowerLevel,
    U32             power
    );


/******************************************
* New Capabilities Functions
******************************************/
BOOLEAN
PlxIsNewCapabilityEnabled(
    BUS_INDEX busIndex,
    U8        CapabilityToVerify
    );


/******************************************
* Hot Swap Functions
******************************************/
U8
PlxHotSwapIdRead(
    BUS_INDEX    busIndex,
    RETURN_CODE *rc
    );

RETURN_CODE
PlxHotSwapIdWrite(
    BUS_INDEX busIndex,
    U8        Id
    );

U8
PlxHotSwapNcpRead(
    BUS_INDEX    busIndex,
    RETURN_CODE *rc
    );

RETURN_CODE
PlxHotSwapNcpWrite(
    BUS_INDEX busIndex,
    U8        value
    );

U8
PlxHotSwapStatus(
    BUS_INDEX busIndex
    );

RETURN_CODE
PlxHotSwapEnable(
    BUS_INDEX busIndex
    );

RETURN_CODE
PlxHotSwapDisable(
    BUS_INDEX busIndex
    );


/******************************************
* VPD Functions
******************************************/
U8
PlxVpdIdRead(
    BUS_INDEX    busIndex,
    RETURN_CODE *rc
    );

RETURN_CODE
PlxVpdIdWrite(
    BUS_INDEX busIndex,
    U8        Id
    );

U8
PlxVpdNcpRead(
    BUS_INDEX    busIndex,
    RETURN_CODE *rc
    );

RETURN_CODE
PlxVpdNcpWrite(
    BUS_INDEX busIndex,
    U8        value
    );

U32
PlxVpdRead(
    BUS_INDEX    busIndex,
    U16          offset,
    RETURN_CODE *rc
    );

RETURN_CODE
PlxVpdWrite(
    BUS_INDEX busIndex,
    U16       offset,
    U32       VpdData
    );

RETURN_CODE
PlxVpdEnable(
    BUS_INDEX busIndex
    );

RETURN_CODE
PlxVpdDisable(
    BUS_INDEX busIndex
    );




#ifdef __cplusplus
}
#endif

#endif
